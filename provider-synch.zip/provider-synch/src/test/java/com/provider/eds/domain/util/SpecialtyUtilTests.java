package com.provider.eds.domain.util;

import com.medica.model.eds.provider.Specialty;
import com.provider.eds.model.utils.SpecialtyUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class SpecialtyUtilTests {
    @Test
    public void testIsActive() {
        assertThat(SpecialtyUtil.isActive(null)).isFalse();
        Specialty specialty= Specialty.builder().logicalDeleteFlg(null).build();
        assertThat(SpecialtyUtil.isActive(specialty)).isFalse();
        specialty.setLogicalDeleteFlg(false);
        assertThat(SpecialtyUtil.isActive(specialty)).isTrue();
        specialty.setLogicalDeleteFlg(true);
        assertThat(SpecialtyUtil.isActive(specialty)).isFalse();
    }
    @Test
    public void testIsPrimary() {
        assertThat(SpecialtyUtil.isPrimary(null)).isFalse();
        Specialty specialty= Specialty.builder().build();
        assertThat(SpecialtyUtil.isPrimary(specialty)).isFalse();
        specialty.setPrimaryFlg(false);
        assertThat(SpecialtyUtil.isPrimary(specialty)).isFalse();
        specialty.setPrimaryFlg(true);
        assertThat(SpecialtyUtil.isPrimary(specialty)).isTrue();
    }
}
