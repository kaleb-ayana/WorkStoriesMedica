package com.provider.eds.domain.util;

import com.medica.model.eds.provider.Network;
import com.provider.eds.model.utils.AffiliationUtil;
import com.provider.eds.model.utils.NetworkUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class NetworkUtilTests {
    @Test
    public void testNetworkResynchTags() {
        Network networkOne= null;
        assertThat(NetworkUtil.hasProperResynchTag(networkOne)).isFalse();
        networkOne= Network.builder().resynchTag(null).build();
        assertThat(NetworkUtil.hasProperResynchTag(networkOne)).isFalse();
        networkOne= Network.builder().resynchTag("").build();
        assertThat(NetworkUtil.hasProperResynchTag(networkOne)).isFalse();
        networkOne= Network.builder().resynchTag("XX").build();
        assertThat(NetworkUtil.hasProperResynchTag(networkOne)).isTrue();
    }

    @Test
    public void testNetworkMatching() {
        assertThat(AffiliationUtil.isMatching(null,null)).isTrue();
        Network networkOne=new Network();
        Network networkTwo=new Network();
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isTrue();
        networkOne= this.getNetwork("affProvIdTy", "mtvAffProvId", "SITE");
        networkTwo= this.getNetwork("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isTrue();
        networkTwo= this.getNetwork("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isTrue();

        networkTwo= this.getNetwork("affProvIdT", "mtvAffProvId", "SITE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isFalse();
        networkTwo= this.getNetwork("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isTrue();

        networkTwo= this.getNetwork("affProvIdTy", "mtvAffProvI", "SITE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isFalse();
        networkTwo= this.getNetwork("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isTrue();

        networkTwo= this.getNetwork("affProvIdTy", "mtvAffProvId", "SIE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isFalse();
        networkTwo= this.getNetwork("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(NetworkUtil.isMatching(networkOne,networkTwo)).isTrue();

    }

    private Network getNetwork(String mtvProviderId, String addressId, String effDt) {
        return Network
                .builder()
                .mtvProviderId(mtvProviderId)
                .addressId(addressId)
                .effDt(effDt)
                .build();
    }
}
