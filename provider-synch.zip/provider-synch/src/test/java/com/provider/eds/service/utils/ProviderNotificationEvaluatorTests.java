package com.provider.eds.service.utils;


import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.medica.model.eds.provider.Provider;
import com.medica.model.eds.provider.Specialty;
import com.provider.eds.model.misc.Constants;
import com.provider.eds.model.misc.ProviderCategoryCd;
import com.provider.eds.model.misc.ProviderIdType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ProviderNotificationEvaluatorTests {
    @Autowired
    private ProviderNotificationEvaluator evaluator;

    @Test
    public void testIsConcreteSiteTest() {
        Provider provider=
                Provider
                        .builder()
                        .providerId("12")
                        .sitePrimarySpeciality("00K5")
                        .providerIdType(ProviderIdType.MD5.toString())
                        .providerCategoryCd(ProviderCategoryCd.SITE.toString())
                        .build();
        provider.setOpvProviderAddress(new ArrayList<>());
        provider.setOpvProviderSpecialty(new ArrayList<>());
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        Address address= Address
                .builder()
                .logicalDeleteFlg(false)
                .addressTypeCode(Constants.A2_ADDRESS)
                .addrMd5Hash("132k34jlkeree3433")
                .build();

        Specialty specialty= Specialty
                .builder()
                .logicalDeleteFlg(false)
                .primaryFlg(true)
                .build();
        provider.getOpvProviderAddress().add(address);
        provider.getOpvProviderSpecialty().add(specialty);
        assertThat(this.evaluator.isLocationCandidate(provider)).isTrue();
        address.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isLocationCandidate(provider)).isFalse();
        address.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isLocationCandidate(provider)).isTrue();
        specialty.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isLocationCandidate(provider)).isFalse();
        specialty.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isLocationCandidate(provider)).isTrue();
        specialty.setPrimaryFlg(false);
        assertThat(this.evaluator.isLocationCandidate(provider)).isFalse();
        specialty.setPrimaryFlg(true);
        assertThat(this.evaluator.isLocationCandidate(provider)).isTrue();

        provider.setSitePrimarySpeciality("");
        assertThat(this.evaluator.isLocationCandidate(provider)).isFalse();
        provider.setSitePrimarySpeciality("sds");
        assertThat(this.evaluator.isLocationCandidate(provider)).isTrue();

        assertThat(this.evaluator.isLocationCandidate(provider)).isTrue();
        address.setAddrMd5Hash("");
        assertThat(this.evaluator.isLocationCandidate(provider)).isFalse();
        address.setAddrMd5Hash("353534");
        assertThat(this.evaluator.isLocationCandidate(provider)).isTrue();

    }
    @Test
    public void testIsPractitionerTest() {
        Provider provider=
                Provider
                        .builder()
                        .providerId("12")
                        .providerIdType(ProviderIdType.NPI1.toString())
                        .providerCategoryCd(ProviderCategoryCd.PRACT.toString())
                        .build();
        provider.setOpvProviderAddress(new ArrayList<>());
        provider.setOpvProviderAlternateId(new ArrayList<>());
        provider.setOpvProviderSpecialty(new ArrayList<>());
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        Address address= Address
                .builder()
                .logicalDeleteFlg(false)
                .addressTypeCode(Constants.AP_ADDRESS)
                .build();
        AlternateIdentifier alternateId= AlternateIdentifier
                .builder()
                .alternateIdTypeCd(Constants.NPI1)
                .logicalDeleteFlg(false)
                .mtvProviderCategoryCd("P")
                .build();
        Specialty specialty= Specialty
                .builder()
                .logicalDeleteFlg(false)
                .primaryFlg(true)
                .build();
        provider.getOpvProviderAddress().add(address);
        provider.getOpvProviderAlternateId().add(alternateId);
        provider.getOpvProviderSpecialty().add(specialty);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
        address.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        address.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
        specialty.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        specialty.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
        alternateId.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        alternateId.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
   }
    @BeforeEach
    public void beforeAllM(){
        ReflectionTestUtils.setField(evaluator, "expirationDate", "2021-12-31");
    }
   @Test
    public void testHasNonVoidedAlternateIdTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        ArrayList<AlternateIdentifier> alternateIdentifiers =new ArrayList<>();
        provider.setOpvProviderAlternateId(alternateIdentifiers);
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, false));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, true));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.NPI1, false));
        assertThat(this.evaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.TAX)).isTrue();
        assertThat(this.evaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.NPI1)).isTrue();
        assertThat(this.evaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.NPI2)).isFalse();
    }
    @Test
    public void testGetAlternateIdTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.A2_ADDRESS)).isNullOrEmpty();
        ArrayList<AlternateIdentifier> alternateIdentifiers =new ArrayList<>();
        provider.setOpvProviderAlternateId(alternateIdentifiers);
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, false));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, true));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.NPI1, true));
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.TAX)).hasSize(2);
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.NPI1)).hasSize(1);
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.NPI2)).hasSize(0);
    }

    @Test
    public void testhasNonVoidedAddressTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        ArrayList<Address> addressArrayList =new ArrayList<>();
        provider.setOpvProviderAddress(addressArrayList);
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();;
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.AP_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.AP_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, false));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS)).isTrue();
        addressArrayList.add(this.createAddress(Constants.AP_ADDRESS, null, false));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.AP_ADDRESS)).isTrue();

    }

    private Address createAddress(String typeCode, String md5Hash, boolean logicalDeleteFlag) {
        return Address
                .builder()
                .addressTypeCode(typeCode)
                .addrMd5Hash(md5Hash)
                .effDt("2021-01-01")
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
    private Provider createProvider(String lastName, String primarySpecialtyCd) {
        return Provider
                .builder()
                .lastNameOrgName(lastName)
                .sitePrimarySpeciality(primarySpecialtyCd)
                .build();
    }
    private AlternateIdentifier createAlternativeIdentifier(String cdType, boolean logicalDeleteFlag ) {
        return AlternateIdentifier
                .builder()
                .alternateIdTypeCd(cdType)
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
}
