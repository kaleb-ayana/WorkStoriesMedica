package com.provider.eds.domain.util;

import com.medica.model.eds.provider.Address;
import com.provider.eds.model.utils.AddressUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AddressUtilTests {
    @Test
    public void testIsActive() {
        assertThat(AddressUtil.isActive(null)).isFalse();
        assertThat(AddressUtil.isActive(Address.builder().logicalDeleteFlg(false).build())).isTrue();
        assertThat(AddressUtil.isActive(Address.builder().logicalDeleteFlg(true).build())).isFalse();
    }
    @Test
    public void testHasMD5Hash() {
        assertThat(AddressUtil.hasMD5Hash(null)).isFalse();
        assertThat(AddressUtil.hasMD5Hash(Address.builder().addrMd5Hash(null).build())).isFalse();
        assertThat(AddressUtil.hasMD5Hash(Address.builder().addrMd5Hash("").build())).isFalse();
        assertThat(AddressUtil.hasMD5Hash(Address.builder().addrMd5Hash("XX").build())).isTrue();
    }
    @Test
    public void testHasType() {
        assertThat(AddressUtil.hasType(null, null)).isFalse();
        assertThat(AddressUtil.hasType(Address.builder().addressTypeCode(null).build(), null)).isTrue();
        assertThat(AddressUtil.hasType(Address.builder().addressTypeCode("TAX").build(), null)).isFalse();
        assertThat(AddressUtil.hasType(Address.builder().addressTypeCode("TAX").build(), "")).isFalse();
        assertThat(AddressUtil.hasType(Address.builder().addressTypeCode(null).build(), "TAX")).isFalse();
        assertThat(AddressUtil.hasType(Address.builder().addressTypeCode("").build(), "TAX")).isFalse();
        assertThat(AddressUtil.hasType(Address.builder().addressTypeCode("TAX").build(), "TAX")).isTrue();

//        assertThat(AddressUtil.hasMD5Hash(Address.builder().addrMd5Hash("").build())).isFalse();
//        assertThat(AddressUtil.hasMD5Hash(Address.builder().addrMd5Hash("XX").build())).isTrue();
    }
}
