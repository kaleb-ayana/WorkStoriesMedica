package com.provider.eds.domain.util;

import com.medica.model.eds.provider.*;
import com.provider.eds.model.misc.Constants;
import com.provider.eds.service.utils.ProviderUtil;
import org.assertj.core.api.AssertionsForClassTypes;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class ProviderUtilTests {
    @Test
    public void testGetPrototypeNetworksFor() {
        List<Network> networkList= new ArrayList<>();
        networkList.add(createNetwork("222", "2023-01-01", "33VVV333"));
        networkList.add(createNetwork("222", "2024-01-01", "33VVV444"));
        networkList.add(createNetwork("222", "2024-01-01", "33VVV444"));
        networkList.add(createNetwork("333", "2024-01-01", "55VVV666"));
        Provider provider= Provider
                .builder()
                .providerId("111")
                .opvProviderNetworkDirectory( networkList )
                .build();
        AssertionsForClassTypes.assertThat(ProviderUtil.getPrototypeNetworksFor(provider, "222").size()).isEqualTo(2);
        AssertionsForClassTypes.assertThat(ProviderUtil.getPrototypeNetworksFor(provider, "333").size()).isEqualTo(1);
        provider.getOpvProviderNetworkDirectory().add(createNetwork("222", "2025-01-01", "33VVV444"));
        AssertionsForClassTypes.assertThat(ProviderUtil.getPrototypeNetworksFor(provider, "222").size()).isEqualTo(3);
        provider.getOpvProviderNetworkDirectory().add(createNetwork("222", "2025-01-01", "33VVV444"));
        AssertionsForClassTypes.assertThat(ProviderUtil.getPrototypeNetworksFor(provider, "222").size()).isEqualTo(3);

    }
    @Test
    public void testHasPayToAffiliationsWith() {
        Provider provider= Provider
                .builder()
                .providerId("123")
                .opvProviderAffiliation(
                        List.of(
                                createPayToAffiliation("012", "900", "HOSP","2022-01-01","2023-01-01", false,"2022-01-01;2023-01-01;false"),
                                createPayToAffiliation("012", "901", "TAX","2022-01-01","2023-01-01", false,"2022-01-01;2023-01-01;false"),
                                createPayToAffiliation("012", "902", "TAX","2022-01-01","2023-01-01", false,"2022-01-01;2023-01-01;false"),
                                createPayToAffiliation("013", "903", "HOSP","2022-01-01","2023-01-01", false,"2022-01-01;2023-01-01;false")

                        )
                )
                .build();
        AssertionsForClassTypes.assertThat(ProviderUtil.hasPayToAffiliationsWith(provider, "011")).isFalse();
        AssertionsForClassTypes.assertThat(ProviderUtil.hasPayToAffiliationsWith(provider, "012")).isTrue();
    }

    @Test
    public void testRemovePayToAffiliationsWith() {
        List<Affiliation> affiliationList= new ArrayList<>();
        affiliationList.add(createPayToAffiliation("012", "900", "HOSP","2022-01-01","2023-01-01", false, "2022-01-01;2023-01-01;false"));
        affiliationList.add(createPayToAffiliation("012", "901", "TAX","2022-01-01","2023-01-01", false, "2022-01-01;2023-01-01;false"));
        affiliationList.add(createPayToAffiliation("012", "902", "TAX","2022-01-02","2023-01-01", false, "2022-01-01;2023-01-01;false"));
        affiliationList.add(createPayToAffiliation("013", "903", "HOSP","2022-01-01","2023-01-01", false, "2022-01-01;2023-01-01;false"));
        Provider provider= Provider
                .builder()
                .providerId("123")
                .opvProviderAffiliation(affiliationList )
                .build();
        ProviderUtil.removePayToAffiliationsWith(provider, "013");
        AssertionsForClassTypes.assertThat(ProviderUtil.hasPayToAffiliationsWith(provider, "013")).isFalse();
        AssertionsForClassTypes.assertThat(ProviderUtil.hasPayToAffiliationsWith(provider, "012")).isTrue();
        ProviderUtil.removePayToAffiliationsWith(provider,"012");
        AssertionsForClassTypes.assertThat(ProviderUtil.hasPayToAffiliationsWith(provider, "013")).isFalse();
    }
    @Test
    public void testGetPrototypePayToAffiliationsFor() {
        Provider provider= Provider
                .builder()
                .providerId("123")
                .opvProviderAffiliation(
                        List.of(
                                createPayToAffiliation("012", "900", "HOSP","2022-01-01","2023-01-01", false, "2022-01-01;2023-01-01;false"),
                                createPayToAffiliation("012", "901", "TAX","2022-01-01","2023-01-01", false, "2022-01-01;2023-01-01;false"),
                                createPayToAffiliation("012", "902", "TAX","2022-01-02","2023-01-01", false, "2022-01-01;2023-01-01;false"),
                                createPayToAffiliation("013", "903", "HOSP","2022-01-01","2023-01-01", false, "2022-01-01;2023-01-01;false")

                        )
                )
                .build();
        AssertionsForClassTypes.assertThat(ProviderUtil.getPrototypePayToAffiliationsFor(provider, "012").size()).isEqualTo(2);
        AssertionsForClassTypes.assertThat(ProviderUtil.getPrototypePayToAffiliationsFor(provider, "015")).isNull();
    }
    @Test
    public void testMD5Ids() {
        List<Address> addresses= new ArrayList<>();
        addresses.add(this.createPracticeLocation("md5-1","add-1", "2020-01-01", "2021-01-01", false));
        Provider provider= Provider
                .builder()
                .opvProviderAddress(addresses)
                .build();
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider)).isNotNull();
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).size()).isEqualTo(1);
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).md5).isEqualTo("md5-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).addressId).isEqualTo("add-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).effDt).isEqualTo("2020-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).endDt).isEqualTo("2021-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).logicalDeleteFlag).isEqualTo(false);

        addresses.add(this.createPracticeLocation("md5-1","add-1", "2019-01-01", "2022-01-01", false));
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).size()).isEqualTo(1);
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).md5).isEqualTo("md5-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).addressId).isEqualTo("add-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).effDt).isEqualTo("2019-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).endDt).isEqualTo("2022-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).logicalDeleteFlag).isEqualTo(false);
        addresses.add(this.createPracticeLocation("md5-2","add-2", "2018-01-01", "2024-01-01", false));
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).size()).isEqualTo(2);
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).md5).isEqualTo("md5-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).addressId).isEqualTo("add-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).effDt).isEqualTo("2019-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).endDt).isEqualTo("2022-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(0).logicalDeleteFlag).isEqualTo(false);
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).md5).isEqualTo("md5-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).addressId).isEqualTo("add-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).effDt).isEqualTo("2018-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).endDt).isEqualTo("2024-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).logicalDeleteFlag).isEqualTo(false);

        addresses.add(this.createPracticeLocation("md5-2","add-2", "2017-01-01", "2025-01-01", true));
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).size()).isEqualTo(2);
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).md5).isEqualTo("md5-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).addressId).isEqualTo("add-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).effDt).isEqualTo("2017-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).endDt).isEqualTo("2025-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).logicalDeleteFlag).isEqualTo(false);

        addresses.add(this.createPracticeLocation("md5-3", "add-3", "2017-01-01", "2025-01-01", true));
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).size()).isEqualTo(3);
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).md5).isEqualTo("md5-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).addressId).isEqualTo("add-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).effDt).isEqualTo("2017-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).endDt).isEqualTo("2025-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).logicalDeleteFlag).isEqualTo(false);

        addresses.add(this.createPracticeLocation("md5-2", "add-2", "2017-01-01", "2025-01-01", true));
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).size()).isEqualTo(3);
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).md5).isEqualTo("md5-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).addressId).isEqualTo("add-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).effDt).isEqualTo("2017-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).endDt).isEqualTo("2025-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getAddressMatchedMD5Hashes(provider).get(1).logicalDeleteFlag).isEqualTo(false);
    }
    @Test
    public void testGetTaxIds() {
        List<AlternateIdentifier> alternateIdentifiers= new ArrayList<>();
        alternateIdentifiers.add(this.createTaxEntity("tx-1", "2020-01-01", "2021-01-01", false));
        Provider provider= Provider
                .builder()
                .opvProviderAlternateId(alternateIdentifiers)
                .build();
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider)).isNotNull();
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).size()).isEqualTo(1);
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).alternateId).isEqualTo("tx-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).effDt).isEqualTo("2020-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).endDt).isEqualTo("2021-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).logicalDeleteFlag).isEqualTo(false);

        alternateIdentifiers.add(this.createTaxEntity("tx-1", "2019-01-01", "2022-01-01", false));
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).size()).isEqualTo(1);
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).alternateId).isEqualTo("tx-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).effDt).isEqualTo("2019-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).endDt).isEqualTo("2022-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).logicalDeleteFlag).isEqualTo(false);
        alternateIdentifiers.add(this.createTaxEntity("tx-2", "2018-01-01", "2024-01-01", false));
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).size()).isEqualTo(2);
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).alternateId).isEqualTo("tx-1");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).effDt).isEqualTo("2019-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).endDt).isEqualTo("2022-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(0).logicalDeleteFlag).isEqualTo(false);
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).alternateId).isEqualTo("tx-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).effDt).isEqualTo("2018-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).endDt).isEqualTo("2024-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).logicalDeleteFlag).isEqualTo(false);

        alternateIdentifiers.add(this.createTaxEntity("tx-2", "2017-01-01", "2025-01-01", true));
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).size()).isEqualTo(2);
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).alternateId).isEqualTo("tx-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).effDt).isEqualTo("2017-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).endDt).isEqualTo("2025-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).logicalDeleteFlag).isEqualTo(false);

        alternateIdentifiers.add(this.createTaxEntity("tx-3", "2017-01-01", "2025-01-01", true));
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).size()).isEqualTo(3);
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).alternateId).isEqualTo("tx-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).effDt).isEqualTo("2017-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).endDt).isEqualTo("2025-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).logicalDeleteFlag).isEqualTo(false);

        alternateIdentifiers.add(this.createTaxEntity("tx-2", "2017-01-01", "2025-01-01", true));
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).size()).isEqualTo(3);
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).alternateId).isEqualTo("tx-2");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).effDt).isEqualTo("2017-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).endDt).isEqualTo("2025-01-01");
        AssertionsForClassTypes.assertThat(ProviderUtil.getTaxIds(provider).get(1).logicalDeleteFlag).isEqualTo(false);
    }
    @Test
    public void testHasProperResynchTags0() {
        Provider provider1= Provider
                .builder()
                .opvProviderPanel(List.of( Panel.builder().resynchTag("sval").build(),  Panel.builder().resynchTag("sval2").build() ))
                .opvProviderNetworkDirectory(List.of( Network.builder().resynchTag("sval").build(), Network.builder().resynchTag("sval2").build() ))
                .build();
        assertThat(ProviderUtil.hasProperResynchTag(provider1)).isTrue();
        Provider provider2= Provider
                .builder()
                .opvProviderAffiliation(List.of(Affiliation.builder().resynchTag("someVal").build(), Affiliation.builder().resynchTag("someVal2").build()) )
                .opvProviderPanel(List.of( Panel.builder().resynchTag("sval").build(),  Panel.builder().resynchTag("sval2").build() ))
                .opvProviderNetworkDirectory(List.of( Network.builder().resynchTag("sval").build(), Network.builder().resynchTag("sval2").build() ))
                .build();
        assertThat(ProviderUtil.hasProperResynchTag(provider2)).isTrue();
        Provider provider3= Provider
                .builder()
                .opvProviderAffiliation(List.of(Affiliation.builder().resynchTag(null).build(), Affiliation.builder().resynchTag("someVal2").build()) )
                .opvProviderPanel(List.of( Panel.builder().resynchTag("sval").build(),  Panel.builder().resynchTag("sval2").build() ))
                .opvProviderNetworkDirectory(List.of( Network.builder().resynchTag("sval").build(), Network.builder().resynchTag("sval2").build() ))
                .build();
        assertThat(ProviderUtil.hasProperResynchTag(provider3)).isFalse();
    }
    private Panel createPanelWithProvider(String providerId) {
        return Panel
                .builder()
                .mtvProviderId(providerId)
                .build();
    }
    private Network createNetworkDirectoryWithProvider(String providerId) {
        return Network
                .builder()
                .mtvProviderId(providerId)
                .build();
    }
    private Affiliation createAffiliationWithProvider(String providerId) {
        return Affiliation
                .builder()
                .mtvAffiliateProviderId(providerId)
                .build();
    }
    private AlternateIdentifier createTaxEntity(String taxId, String effDt, String endDt, boolean logicalDeleteFlag) {
        return AlternateIdentifier
            .builder()
            .alternateId(taxId)
            .effDt(effDt)
            .endDt(endDt)
            .alternateIdTypeCd(Constants.TAX)
            .logicalDeleteFlg(logicalDeleteFlag)
            .build();
    }
    private Address createPracticeLocation(String md5, String addressId, String effDt, String endDt, boolean logicalDeleteFlag) {
        return Address
            .builder()
            .addrMd5Hash(md5)
            .mtvAddrId(addressId)
            .effDt(effDt)
            .endDt(endDt)
            .addressTypeCode(Constants.A2_ADDRESS)
            .logicalDeleteFlg(logicalDeleteFlag)
            .build();
    }
    private Affiliation createPayToAffiliation(String mtvProviderId, String providerId, String afflType, String effDt, String endDt, boolean logicalDeleteFlag, String resynchTag) {
        return Affiliation
                .builder()
                .affiliateProviderIdType(Constants.TAX)
                .mtvAffiliateProviderId(mtvProviderId)
                .affiliateProviderId(providerId)
                .affiliationType(afflType)
                .effDt(effDt)
                .endDt(endDt)
                .resynchTag(resynchTag)
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
    private Network createNetwork(String mtvProviderId, String effDt, String addressId) {
        return Network
                .builder()
                .mtvProviderId(mtvProviderId)
                .effDt(effDt)
                .addressId(addressId)
                .praclocProviderIdType("MD5")
                .build();
    }
}
