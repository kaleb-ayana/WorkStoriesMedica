package com.provider.eds.domain.util;

import com.medica.model.eds.provider.Affiliation;
import com.provider.eds.model.utils.AffiliationUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AffiliationUtilTests {
    @Test
    public void testAffiliationResynchTags() {
        Affiliation affiliationOne= null;
        assertThat(AffiliationUtil.hasProperResynchTag(affiliationOne)).isFalse();
        affiliationOne= Affiliation.builder().resynchTag(null).build();
        assertThat(AffiliationUtil.hasProperResynchTag(affiliationOne)).isFalse();
        affiliationOne= Affiliation.builder().resynchTag("").build();
        assertThat(AffiliationUtil.hasProperResynchTag(affiliationOne)).isFalse();
        affiliationOne= Affiliation.builder().resynchTag("XX").build();
        assertThat(AffiliationUtil.hasProperResynchTag(affiliationOne)).isTrue();
    }

    @Test
    public void testAffiliationMatching() {
        assertThat(AffiliationUtil.isMatching(null,null)).isTrue();
        Affiliation affiliationOne=new Affiliation();
        Affiliation affiliationTwo=new Affiliation();
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isFalse();
        affiliationOne= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        affiliationTwo.setResynchTag(null);
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isFalse();
        affiliationTwo.setResynchTag("resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isTrue();
        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isTrue();

        affiliationTwo= this.getAffl("affProvIdT", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isFalse();
        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isTrue();

        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvI", "SITE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isFalse();
        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isTrue();

        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SIE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isFalse();
        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isTrue();

        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffype", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isFalse();
        affiliationTwo= this.getAffl("affProvIdTy", "mtvAffProvId", "SITE", "hospAffType", "resynch");
        assertThat(AffiliationUtil.isMatching(affiliationOne,affiliationTwo)).isTrue();


    }

    private Affiliation getAffl(String affiliateProviderIdType, String mtvAffiliateProviderId, String affiliationType, String hospitalAffiliationType, String tag) {
        return Affiliation
                .builder()
                .affiliateProviderIdType(affiliateProviderIdType)
                .mtvAffiliateProviderId(mtvAffiliateProviderId)
                .affiliationType(affiliationType)
                .hospitalAffiliationType(hospitalAffiliationType)
                .resynchTag(tag)
                .build();
    }
}
