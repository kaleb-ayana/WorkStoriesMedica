package com.provider.eds.service;

import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.Affiliation;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.provider.eds.service.utils.Util;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import static com.provider.eds.service.utils.Util.convertStringToBoolean;
import static org.assertj.core.api.Assertions.assertThat;

public class UtilTest {
    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    @Test
    public void testConvertStringToBoolean() {
        assertThat(convertStringToBoolean(null)).isFalse();
        assertThat(convertStringToBoolean("null")).isFalse();
        assertThat(convertStringToBoolean("")).isFalse();
        assertThat(convertStringToBoolean("NonBooleanValue")).isFalse();
        assertThat(convertStringToBoolean("123")).isFalse();
        assertThat(convertStringToBoolean("12.3")).isFalse();
        assertThat(convertStringToBoolean("true")).isTrue();
        assertThat(convertStringToBoolean("TruE")).isTrue();
        assertThat(convertStringToBoolean("TRUE")).isTrue();
        assertThat(convertStringToBoolean("false")).isFalse();
        assertThat(convertStringToBoolean("FalSE")).isFalse();
        assertThat(convertStringToBoolean("FALSE")).isFalse();
    }
    @Test
    public void testEpochLocalDateTimeCoversion() {
        long test_timestamp = Long.parseLong("1671991006307");

        LocalDateTime triggerTime =
                LocalDateTime.ofInstant(Instant.ofEpochMilli(test_timestamp),
                        TimeZone.getDefault().toZoneId());
        assertThat(triggerTime).isNotNull();
        assertThat(Util.parseTimeStamp("1671991006307")).isNotNull();
    }
    @Test
    public void testBetweenDate() {
        LocalDate effDate = LocalDate.parse("2022-01-01", formatter);
        LocalDate endDate = LocalDate.parse("2022-12-31", formatter);
        LocalDate d1 = LocalDate.parse("2022-04-16", formatter);
        LocalDate d2 = LocalDate.parse("2022-01-01", formatter);
        LocalDate d3 = LocalDate.parse("2022-12-31", formatter);
        LocalDate d4 = LocalDate.parse("2023-01-01", formatter);
        LocalDate d5 = LocalDate.parse("2020-01-01", formatter);

        assertThat(Util.isBetweenDate(d1, effDate, endDate)).isTrue();
        assertThat(Util.isBetweenDate(d2, effDate, endDate)).isTrue();
        assertThat(Util.isBetweenDate(d3, effDate, endDate)).isTrue();
        assertThat(Util.isBetweenDate(d4, effDate, endDate)).isFalse();
        assertThat(Util.isBetweenDate(d5, effDate, endDate)).isFalse();
    }

    @Test
    public void testConvertDateStrToLocalDate() {
        assertThat(Util.convertDateStrToLocalDate("2099-12-12")).isNotNull();
        assertThat(Util.convertDateStrToLocalDate("2099-12-12").getYear()).isEqualTo(2099);
        assertThat(Util.convertDateStrToLocalDate("20991212")).isNull();
        assertThat(Util.convertDateStrToLocalDate("fv")).isNull();
    }
    @Test
    public void testIsProperDateString() {
        assertThat(Util.isProperDateString("2099-12-12")).isTrue();
        assertThat(Util.isProperDateString(null)).isFalse();
        assertThat(Util.isProperDateString("")).isFalse();
        assertThat(Util.isProperDateString(" ")).isFalse();
        assertThat(Util.isProperDateString("209912-12")).isFalse();
        assertThat(Util.isProperDateString("20991212")).isFalse();

    }
    @Test
    public void testIsDigits() {
        assertThat(Util.isDigits("1234")).isTrue();
        assertThat(Util.isDigits(null)).isFalse();
        assertThat(Util.isDigits("")).isFalse();
        assertThat(Util.isDigits("  ")).isFalse();
        assertThat(Util.isDigits("123r")).isFalse();
    }
    @Test
    public void listTests() {
        assertThat(Util.isNonNullNonEmpty(List.of("Value-1"))).isTrue();
        assertThat(Util.isNonNullNonEmpty(new ArrayList<String>())).isFalse();
        assertThat(Util.isNonNullNonEmpty(null)).isFalse();

        assertThat(Util.nullOrEmpty(List.of("Value-1"))).isFalse();
        assertThat(Util.nullOrEmpty(null)).isTrue();
        assertThat(Util.nullOrEmpty(new ArrayList<String>())).isTrue();
    }
    @Test
    public void testParseDateAndCheckExpiration2() {
        assertThat(Util.hasNonExpiredEndDate("", "2022-12-31")).isTrue();
        assertThat(Util.hasNonExpiredEndDate(" ", "2022-12-31")).isTrue();
        assertThat(Util.hasNonExpiredEndDate(null, "2022-12-31")).isTrue();
        assertThat(Util.hasNonExpiredEndDate("01-01-2023", "2022-12-31")).isFalse();
        assertThat(Util.hasNonExpiredEndDate("01-01-2021", "2022-12-31")).isFalse();
        assertThat(Util.hasNonExpiredEndDate("2022-11-09", "2022-12-31")).isFalse();
        assertThat(Util.hasNonExpiredEndDate("2022-11-10", "2022-12-31")).isFalse();
        assertThat(Util.hasNonExpiredEndDate("2023-11-09", "2022-12-31")).isTrue();
        assertThat(Util.hasNonExpiredEndDate("2023-11-10", "2022-12-31")).isTrue();
        assertThat(Util.hasNonExpiredEndDate("2022-11-08", "2022-12-31")).isFalse();
        assertThat(Util.hasNonExpiredEndDate("2022-12-31", "2022-12-31")).isFalse();
    }
    @Test
    public void testFilterFieldValuesMethod() {
        List<AlternateIdentifier> list= List.of(this.alternateIdentifier(), this.alternateIdentifier());
        list.get(1).setAlternateId("222");
        list.get(1).setEffDt("2932896");
        assertThat(Util.filterFieldValues(list, AlternateIdentifier::getAlternateId)).isEqualTo(List.of("111","222"));
        assertThat(Util.filterFieldValues(list, AlternateIdentifier::getEffDt)).isEqualTo(List.of("18993","2932896"));
        list.get(1).setEffDt("18993");
        assertThat(Util.filterFieldValues(list, AlternateIdentifier::getEffDt, true)).isEqualTo(List.of("18993"));
    }
    @Test
    public void testConvertToDate() {
        assertThat(Util.convertToDate(null)).isNull();
        assertThat(Util.convertToDate("123456")).isNotEmpty();
    }
    @Test
    public void testConvertToLocalDate() {
        assertThat(Util.convertIntDateStrToLocalDate(null)).isNull();
        assertThat(Util.convertIntDateStrToLocalDate("")).isNull();
        assertThat(Util.convertIntDateStrToLocalDate("2932896").toString()).isEqualTo("9999-12-31");
    }

    private AlternateIdentifier alternateIdentifier() {
        return AlternateIdentifier
                .builder()
                .alternateId("111")
                .alternateIdTypeCd("BA")
                .effDt("18993")
                .endDt("2932896")
                .sourceSystemCd("MTV")
                .build();
    }
    private Address address() {
        return Address
            .builder()
            .mtvAddrId("234 Random")
            .effDt("18993")
            .endDt("2932896")
            .build();
    }
  /*  private Contract contract() {
        return Contract
            .builder()
            .effDt("18993")
            .endDt("2932896")
            .build();
    }*/
    private Affiliation affiliation() {
        return Affiliation
            .builder()
            .effDt("18993")
            .endDt("2932896")
            .build();
    }
}
