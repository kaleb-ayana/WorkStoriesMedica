package com.provider.eds.service;

import com.medica.reference.service.ProviderReferenceService;
import com.medica.model.eds.provider.Network;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.model.misc.Constants;
import com.provider.eds.model.misc.MD5Hash;
import com.provider.eds.repository.ProviderRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@ExtendWith(MockitoExtension.class)
public class NetworkResynchTest {

    @InjectMocks
    ProviderService providerService;

    @InjectMocks
    ProviderReferenceService providerReferenceService;

    @Mock
    ProviderRepository providerRepository ;

    @Test
    public void testResynchPayToAffiliationsNoPaytoAffiliatoins() {
        List<Network> networkList= new ArrayList<>();
        networkList.add(createPracticeLocation("012", "900", "2022-01-01","2023-01-01", false));
        networkList.add(createPracticeLocation("012", "901", "2022-01-01","2023-01-01", false));
        networkList.add(createPracticeLocation("013", "903", "2022-01-01","2023-01-01", false));

        List<MD5Hash> md5HashList= new ArrayList<>();
        md5HashList.add(MD5Hash.builder().md5("11").addressId("900").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build());
        md5HashList.add(MD5Hash.builder().md5("22").addressId("901").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build());

        Provider provider= Provider
                .builder()
                .providerId("123")
                .opvProviderNetworkDirectory(networkList )
                .build();
        this.providerService.resynchNetwork(provider, "012", md5HashList);
        assertThat(provider.getOpvProviderNetworkDirectory().size()).isEqualTo(3);
        assertThat(provider.getOpvProviderNetworkDirectory().get(1).getPraclocProviderId()).isEqualTo("11");
        assertThat(provider.getOpvProviderNetworkDirectory().get(2).getPraclocProviderId()).isEqualTo("22");
    }

    private Network createPracticeLocation(String mtvProviderId, String addressId, String effDt, String endDt, boolean logicalDeleteFlag) {
        return Network
                .builder()
                .mtvProviderId(mtvProviderId)
                .addressId(addressId)
                .praclocProviderIdType(Constants.MD5)
                .effDt(effDt)
                .endDt(endDt)
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
}
