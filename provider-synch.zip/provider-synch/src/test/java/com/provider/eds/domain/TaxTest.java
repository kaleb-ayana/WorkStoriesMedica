package com.provider.eds.domain;

import com.provider.eds.model.misc.Tax;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class TaxTest {
    @Test
    public void testMerge() {
        Tax tax1= Tax.builder().alternateId("11").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build();
        assertThat(Tax.merge(tax1, null)).isNotNull();
        assertThat(Tax.merge(tax1, null).alternateId).isEqualTo("11");
        assertThat(Tax.merge(null, null)).isNull();
        Tax tax2= Tax.builder().alternateId("111").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build();
        assertThat(Tax.merge(tax1, tax2)).isNull();
        tax2= Tax.builder().alternateId("11").effDt("2021-01-01").endDt("2023-12-31").logicalDeleteFlag(false).build();
        Tax result= Tax.merge(tax1, tax2);
        assertThat(result).isNotNull();
        assertThat(result.effDt).isEqualTo("2020-01-01");
        assertThat(result.endDt).isEqualTo("2023-12-31");
    }
}
