/*
package com.provider.eds.domain;

import com.provider.eds.model.Contract;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.service.utils.Util;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class ContractTests {
    @Test
    public void testNetworkMatchForContract() {
        Provider provider= new Provider();
        Contract contract= buildContract();
        assertThat(contract.hasNetworkIdIn(List.of("YU"))).isFalse();
        assertThat(contract.hasNetworkIdIn(List.of("PA", "YU"))).isFalse();
        assertThat(contract.hasNetworkIdIn(null)).isFalse();
        contract.setNetworkId(null);
        assertThat(contract.hasNetworkIdIn(List.of("PA", "YU"))).isFalse();
        contract.setNetworkId("");
        assertThat(contract.hasNetworkIdIn(List.of("PA", "YU"))).isFalse();
    }
    @Test
    public void testParticipationMatchForContract() {
        Provider provider= new Provider();
        Contract contract= buildContract();
        assertThat(contract.hasParticipationCodeIn(List.of("YU"))).isFalse();
        assertThat(contract.hasParticipationCodeIn(List.of("PA", "YU"))).isTrue();
        assertThat(contract.hasParticipationCodeIn(null)).isFalse();
        contract.setParticipationCd(null);
        assertThat(contract.hasParticipationCodeIn(List.of("PA", "YU"))).isFalse();
        contract.setParticipationCd("");
        assertThat(contract.hasParticipationCodeIn(List.of("PA", "YU"))).isFalse();
    }
    @Test
    public void testEffectiveDateForContract() {
        LocalDate localDate= Util.convertIntDateStrToLocalDate("18993");
        LocalDate prevDate= localDate.minusYears(1);
        assertThat(localDate).isNotNull();
        Contract contract= buildContract();
        assertThat(contract.isEffectiveOnOrAfter(LocalDate.of(2021, 1,1))).isTrue();
        contract.setEndDt(null);
        assertThat(contract.isEffectiveOnOrAfter(LocalDate.of(2021, 1,1))).isTrue();
        contract.setEndDt("18993");
        assertThat(contract.isEffectiveOnOrAfter(LocalDate.of(2021, 1,1))).isTrue();
        contract.setEndDt("2022-01-01");
        assertThat(contract.isEffectiveOnOrAfter(LocalDate.of(2021, 1,1))).isTrue();
        contract.setEndDt("2022fdfg01-01");
        assertThat(contract.isEffectiveOnOrAfter(LocalDate.of(2021, 1,1))).isFalse();

    }
    @Test
    public void testIsNotLogicallyDeleted() {
        Contract contract= buildContract();
        assertThat(contract.isNotLogicallyDeleted()).isTrue();
        contract.setLogicalDeleteFlg(true);
        assertThat(contract.isNotLogicallyDeleted()).isFalse();
    }
    private Contract buildContract() {
        return Contract
            .builder()
            .networkId("MANCARECOML2")
            .participationCd("PA")
            .effDt("18993")
            .endDt("2932896")
            .build();
    }
    private Contract buildContract(String networkId, String participationCode, String endDate, boolean logicalDeleteFlag) {
        return Contract
            .builder()
            .contractId("123")
            .networkId(networkId)
            .participationCd(participationCode)
            .endDt(endDate)
            .logicalDeleteFlg(logicalDeleteFlag)
            .build();
    }
}*/
