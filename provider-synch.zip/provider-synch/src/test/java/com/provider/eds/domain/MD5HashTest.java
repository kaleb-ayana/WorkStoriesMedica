package com.provider.eds.domain;

import com.provider.eds.model.misc.MD5Hash;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class MD5HashTest {
    @Test
    public void testMerge() {
        MD5Hash md51= MD5Hash.builder().md5("11").addressId("11").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build();
        assertThat(MD5Hash.merge(md51, null)).isNotNull();
        assertThat(MD5Hash.merge(md51, null).md5).isEqualTo("11");
        assertThat(MD5Hash.merge(null, null)).isNull();
        MD5Hash md52= MD5Hash.builder().md5("111").addressId("111").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build();
        assertThat(MD5Hash.merge(md51, md52)).isNull();
        md52= MD5Hash.builder().md5("11").addressId("11").effDt("2021-01-01").endDt("2023-12-31").logicalDeleteFlag(false).build();
        MD5Hash result= MD5Hash.merge(md51, md52);
        assertThat(result).isNotNull();
        assertThat(result.effDt).isEqualTo("2020-01-01");
        assertThat(result.endDt).isEqualTo("2023-12-31");
    }
}
