package com.provider.eds.domain.util;

import com.medica.model.eds.provider.Panel;
import com.provider.eds.model.utils.PanelUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class PanelUtilTests {
    @Test
    public void testAffiliationResynchTags() {
        Panel panel= null;
        assertThat(PanelUtil.hasProperResynchTag(panel)).isFalse();
        panel= Panel.builder().resynchTag(null).build();
        assertThat(PanelUtil.hasProperResynchTag(panel)).isFalse();
        panel= Panel.builder().resynchTag("").build();
        assertThat(PanelUtil.hasProperResynchTag(panel)).isFalse();
        panel= Panel.builder().resynchTag("XX").build();
        assertThat(PanelUtil.hasProperResynchTag(panel)).isTrue();
    }

    @Test
    public void testPanelMatching() {
        assertThat(PanelUtil.isMatching(null,null)).isTrue();
        Panel panelOne=new Panel();
        Panel panelTwo=new Panel();
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isTrue();
        panelOne= this.getPanel("affProvIdTy", "mtvAffProvId", "SITE");
        panelTwo= this.getPanel("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isTrue();
        panelTwo= this.getPanel("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isTrue();

        panelTwo= this.getPanel("affProvIdT", "mtvAffProvId", "SITE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isFalse();
        panelTwo= this.getPanel("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isTrue();

        panelTwo= this.getPanel("affProvIdTy", "mtvAffProvI", "SITE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isFalse();
        panelTwo= this.getPanel("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isTrue();

        panelTwo= this.getPanel("affProvIdTy", "mtvAffProvId", "SIE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isFalse();
        panelTwo= this.getPanel("affProvIdTy", "mtvAffProvId", "SITE");
        assertThat(PanelUtil.isMatching(panelOne,panelTwo)).isTrue();

    }

    private Panel getPanel(String mtvProviderId, String addressId, String effDt) {
        return Panel
                .builder()
                .mtvProviderId(mtvProviderId)
                .addressId(addressId)
                .effDt(effDt)
                .build();
    }
}
