package com.provider.eds.domain.util;

import com.medica.model.eds.provider.AlternateIdentifier;
import com.provider.eds.model.utils.AlternateIdentifierUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AlternateIdentifierUtilTests {
    @Test
    public void testHasMtvProviderCategoryCdTests() {
        assertThat(AlternateIdentifierUtil.hasMtvProviderCategoryCd(null,null)).isFalse();
        assertThat(AlternateIdentifierUtil.hasMtvProviderCategoryCd(null,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasMtvProviderCategoryCd(null,"P")).isFalse();
        AlternateIdentifier identifier= AlternateIdentifier.builder().mtvProviderCategoryCd(null).build();
        assertThat(AlternateIdentifierUtil.hasMtvProviderCategoryCd(identifier,"P")).isFalse();
        identifier= AlternateIdentifier.builder().mtvProviderCategoryCd("G").build();
        assertThat(AlternateIdentifierUtil.hasMtvProviderCategoryCd(identifier,"P")).isFalse();
        identifier= AlternateIdentifier.builder().mtvProviderCategoryCd("G").build();
        assertThat(AlternateIdentifierUtil.hasMtvProviderCategoryCd(identifier,"G")).isTrue();
    }
    @Test
    public void testHasTypeTests() {
        assertThat(AlternateIdentifierUtil.hasType(null,null)).isFalse();
        assertThat(AlternateIdentifierUtil.hasType(null,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasType(null,"TAX")).isFalse();
        AlternateIdentifier identifier= AlternateIdentifier.builder().alternateIdTypeCd(null).build();
        assertThat(AlternateIdentifierUtil.hasType(identifier,"TAX")).isFalse();
        identifier= AlternateIdentifier.builder().alternateIdTypeCd("NPI1").build();
        assertThat(AlternateIdentifierUtil.hasType(identifier,"TAX")).isFalse();
        identifier= AlternateIdentifier.builder().alternateIdTypeCd("NPI1").build();
        assertThat(AlternateIdentifierUtil.hasType(identifier,"NPI1")).isTrue();
    }
    @Test
    public void testIsTaxEntity() {
        assertThat(AlternateIdentifierUtil.isTaxEntity(null)).isFalse();
        AlternateIdentifier identifier= AlternateIdentifier.builder().alternateIdTypeCd("TAX").build();
        assertThat(AlternateIdentifierUtil.isTaxEntity(identifier)).isTrue();
        identifier= AlternateIdentifier.builder().alternateIdTypeCd(null).build();
        assertThat(AlternateIdentifierUtil.isTaxEntity(identifier)).isFalse();
        identifier= AlternateIdentifier.builder().alternateIdTypeCd("NPI1").build();
        assertThat(AlternateIdentifierUtil.isTaxEntity(identifier)).isFalse();
    }

    @Test
    public void testIsActive() {
        assertThat(AlternateIdentifierUtil.isActive(null)).isFalse();
        assertThat(AlternateIdentifierUtil.isActive(AlternateIdentifier.builder().logicalDeleteFlg(false).build())).isTrue();
        assertThat(AlternateIdentifierUtil.isActive(AlternateIdentifier.builder().logicalDeleteFlg(true).build())).isFalse();
    }
}
