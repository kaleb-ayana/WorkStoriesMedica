package com.provider.eds.service;

import com.medica.model.eds.common.ProviderNotification;
import com.medica.model.eds.provider.*;
import com.provider.eds.model.misc.Constants;
import com.provider.eds.model.misc.Tax;
import com.provider.eds.service.messagers.KafkaTemplateWrapperService;
import com.provider.eds.service.utils.ProviderNotificationEvaluator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.support.SendResult;
import org.springframework.util.concurrent.ListenableFuture;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
@SpringBootTest
public class ProviderServiceTest {

    @InjectMocks
    ProviderService providerService;

    @Mock
    ProviderNotificationEvaluator providerNotificationEvaluator;

    @Spy
    @InjectMocks
    ProviderService providerServiceSpy;
    @Mock
    private KafkaTemplateWrapperService kafkaTemplateWrapperService ;

    @BeforeEach
    public void init(){
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void testHasProperResynchTags() {
        assertThat(this.providerService.hasProperResynchTags(null)).isTrue();
        List<Provider> providerList= new ArrayList<>();
        Provider provider1= Provider
                .builder()
                .opvProviderAffiliation(
                        List.of(Affiliation.builder().resynchTag("someVal").build(),
                                Affiliation.builder().resynchTag("someVal2").build())
                )
                .build();
        providerList.add(provider1);
        assertThat(this.providerService.hasProperResynchTags(null)).isTrue();
        assertThat(this.providerService.hasProperResynchTags(null)).isTrue();
        provider1.setOpvProviderPanel(List.of(
                Panel.builder().resynchTag("sval").build(),
                Panel.builder().resynchTag("sval2").build()
        ));
        assertThat(this.providerService.hasProperResynchTags(null)).isTrue();
        provider1.setOpvProviderNetworkDirectory(List.of(
                Network.builder().resynchTag("sval").build(),
                Network.builder().resynchTag("sval2").build()
        ));
        assertThat(this.providerService.hasProperResynchTags(null)).isTrue();
        Provider provider2= Provider
                .builder()
                .opvProviderAffiliation(
                        List.of(Affiliation.builder().resynchTag("someVal").build(),
                                Affiliation.builder().resynchTag("someVal2").build())
                )
                .build();
        providerList.add(provider2);
        assertThat(this.providerService.hasProperResynchTags(providerList)).isTrue();
        Provider provider3= Provider
                .builder()
                .opvProviderAffiliation(List.of(Affiliation.builder().resynchTag(null).build(), Affiliation.builder().resynchTag("someVal2").build()) )
                .opvProviderPanel(List.of( Panel.builder().resynchTag("sval").build(),  Panel.builder().resynchTag("sval2").build() ))
                .opvProviderNetworkDirectory(List.of( Network.builder().resynchTag("sval").build(), Network.builder().resynchTag("sval2").build() ))
                .build();
        providerList.add(provider3);
        assertThat(this.providerService.hasProperResynchTags(providerList)).isFalse();
    }
    @Test
    public void testResynchPayToAffiliationsNoPaytoAffiliatoins() {
        List<Affiliation> affiliationList= new ArrayList<>();
        affiliationList.add(createPayToAffiliation("012", "900", "TAX","2022-01-01","2023-01-01", false));
        affiliationList.add(createPayToAffiliation("012", "901", "TAX","2022-01-01","2023-01-01", false));
        affiliationList.add(createPayToAffiliation("013", "903", "HOSP","2022-01-01","2023-01-01", false));

        List<Tax> taxList= new ArrayList<>();
        taxList.add(Tax.builder().alternateId("11").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build());
        taxList.add(Tax.builder().alternateId("22").effDt("2020-01-01").endDt("2022-12-31").logicalDeleteFlag(false).build());

        Provider provider= Provider
                .builder()
                .providerId("123")
                .opvProviderAffiliation(affiliationList )
                .build();
        affiliationList.get(0).setResynchTag("2022-01-01;2023-01-01;false");
        affiliationList.get(1).setResynchTag("2022-01-01;2023-01-01;false");
        affiliationList.get(2).setResynchTag("2022-01-01;2023-01-01;false");
        this.providerService.resynchPayToAffiliations(provider, "012", taxList);
        assertThat(provider.getOpvProviderAffiliation().size()).isEqualTo(3);
        assertThat(provider.getOpvProviderAffiliation().get(1).getAffiliateProviderId()).isEqualTo("11");
        assertThat(provider.getOpvProviderAffiliation().get(2).getAffiliateProviderId()).isEqualTo("22");
    }

    private Affiliation createPayToAffiliation(String mtvProviderId, String providerId, String afflType, String effDt, String endDt, boolean logicalDeleteFlag) {
        return Affiliation
                .builder()
                .affiliateProviderIdType(Constants.TAX)
                .mtvAffiliateProviderId(mtvProviderId)
                .affiliateProviderId(providerId)
                .affiliationType(afflType)
                .effDt(effDt)
                .endDt(endDt)
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }

    @Test
    public void testProcessOrchestrationMessage(){

        Provider provider= Provider
                .builder()
                .providerId("12345678")
                .sourceSystemCd("MTV")
                .opvProviderAddress(new ArrayList<>())
                .opvProviderAlternateId(new ArrayList<>())
                .build();

       provider.getOpvProviderAddress().add(buildAddress("1243534sdf232433545rdgv2","DHP Address","Demignway "
               ,"BA","Madison","WI","2020-01-01","2020-04-30","345"));

        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("112233","TAX"
                ,"MTV",false,"2022-01-01","2024-04-30","DHP","PAYTO"
                ,"TAX"));
        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("222","NPI2"
                ,"MTV",false,"2022-05-01","9999-12-31","DHP","PAYTO"
                ,"NPI2"));
        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("333","NPI1"
                ,"MTV",false,"2020-01-01","2021-12-31","DHP","PAYTO"
                ,"TAX"));
        provider.getOpvProviderAddress().get(0).setLogicalDeleteFlg(false);
        Mockito.when(providerNotificationEvaluator.getNonVoidedAlternateIdTypeOf(Mockito.any(), Mockito.eq(Constants.TAX))).thenReturn(provider.getOpvProviderAlternateId());


        List<ProviderNotification> providerNotificationList = providerService.processProviderNotificationMessage(null);
        assertThat(providerNotificationList.size()).isEqualTo(0);

        Mockito.when(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(false);
        Mockito.when(providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        providerNotificationList = providerService.processProviderNotificationMessage(provider);
        assertThat(providerNotificationList.size()).isEqualTo(0);


        Mockito.when(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(false);
        providerNotificationList = providerService.processProviderNotificationMessage(provider);
        assertThat(providerNotificationList.size()).isEqualTo(0);

        Mockito.when(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.isPractitionerCandidate(provider)).thenReturn(false);
        providerNotificationList = providerService.processProviderNotificationMessage(provider);
        assertThat(providerNotificationList.size()).isEqualTo(3);

        Mockito.when(providerNotificationEvaluator.isPractitionerCandidate(provider)).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.isLocationCandidate(provider)).thenReturn(false);
        providerNotificationList = providerService.processProviderNotificationMessage(provider);
        assertThat(providerNotificationList.size()).isEqualTo(4);
        assertThat(providerNotificationList.get(0).getSOURCE_SYSTEM_ID()).isEqualTo("12345678");
        assertThat(providerNotificationList.get(0).getSOURCE_SYSTEM_CD()).isEqualTo("MTV");
        assertThat(providerNotificationList.get(1).getSOURCE_SYSTEM_ID()).isEqualTo("12345678");
        assertThat(providerNotificationList.get(1).getSOURCE_SYSTEM_CD()).isEqualTo("MTV");
        assertThat(providerNotificationList.get(2).getSOURCE_SYSTEM_ID()).isEqualTo("12345678");
        assertThat(providerNotificationList.get(2).getSOURCE_SYSTEM_CD()).isEqualTo("MTV");


        Mockito.when(providerNotificationEvaluator.isLocationCandidate(provider)).thenReturn(true);
        providerNotificationList = providerService.processProviderNotificationMessage(provider);
        assertThat(providerNotificationList.size()).isEqualTo(5);

        provider.setProviderId("7891234");
        provider.setSourceSystemCd("SYM");

        Mockito.when(providerNotificationEvaluator.isLocationCandidate(provider)).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.isPractitionerCandidate(provider)).thenReturn(false);
        providerNotificationList = providerService.processProviderNotificationMessage(provider);
        assertThat(providerNotificationList.size()).isEqualTo(4);

        assertThat(providerNotificationList.get(0).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(providerNotificationList.get(0).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");
        assertThat(providerNotificationList.get(1).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(providerNotificationList.get(1).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");
        assertThat(providerNotificationList.get(2).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(providerNotificationList.get(2).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");
        assertThat(providerNotificationList.get(3).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(providerNotificationList.get(3).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");

    }

    private static Address buildAddress(String addrMd5Hash, String name, String addressLine1, String addressTypeCode, String city, String stateCd, String effDt, String endDt, String zipCd4) {
        return Address.builder()
                .addrMd5Hash(addrMd5Hash)
                .name(name)
                .addressLine1(addressLine1)
                .addressTypeCode(addressTypeCode)
                .city(city)
                .stateCd(stateCd)
                .effDt(effDt)
                .endDt(endDt)
                .zipCd4(zipCd4)
                .build();
    }

    private static AlternateIdentifier buildAlternateIdentifier(String alternateId, String alternateIdTypeCd, String sourceSystemCd, Boolean logicalDeleteFlg
           , String effDt, String endDt, String entityName, String mtvProviderCategoryCd, String mtvProviderTypeCd) {
        return AlternateIdentifier
                .builder()
                .alternateId(alternateId)
                .alternateIdTypeCd(alternateIdTypeCd)
                .sourceSystemCd(sourceSystemCd)
                .logicalDeleteFlg(logicalDeleteFlg)
                .effDt(effDt)
                .endDt(endDt)
                .entityName(entityName)
                .mtvProviderCategoryCd(mtvProviderCategoryCd)
                .mtvProviderTypeCd(mtvProviderTypeCd)
                .build();
    }

    @Test
    public void testProduceOrchestrationTopicMessages() throws Exception{

        List<ProviderNotification> resultList= new ArrayList<>();
        List<Provider> providerList = new ArrayList<>();


        Method privateMethod = ProviderService.class.getDeclaredMethod("produceProviderNotificationTopicMessages",List.class);
        privateMethod.setAccessible(true);
        Mockito.when(providerServiceSpy.processProviderNotificationMessage(Mockito.any())).thenReturn(resultList);
        privateMethod.invoke(providerServiceSpy,providerList);
        Mockito.verify(kafkaTemplateWrapperService,Mockito.times(0)).produceProviderNotificationTopicMessage(Mockito.any());

        ListenableFuture<SendResult<String, Object>> responseFuture = Mockito.mock(ListenableFuture.class);
        Mockito.when(kafkaTemplateWrapperService.produceProviderNotificationTopicMessage(Mockito.any())).thenReturn(responseFuture);

      Provider provider= Provider
                .builder()
                .opvProviderAddress(new ArrayList<>())
                .opvProviderAlternateId(new ArrayList<>())
                .build();

        providerList.add(provider);

        resultList.add(ProviderNotification.builder().PROVIDER_ID("12355").PROVIDER_ID_TYPE("TAX").PROVIDER_CATEGORY_CD("PAYTO").LOGICAL_DELETE_FLG(false).build());
        resultList.add(ProviderNotification.builder().PROVIDER_ID("1243534sdf232433545rdgv2").PROVIDER_ID_TYPE("MD5").PROVIDER_CATEGORY_CD("SITE").LOGICAL_DELETE_FLG(false).build());
        Mockito.when(providerNotificationEvaluator.isLocationCandidate(provider)).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.isPractitionerCandidate(provider)).thenReturn(true);
        Mockito.when(providerServiceSpy.processProviderNotificationMessage(Mockito.any())).thenReturn(resultList);
        privateMethod.invoke(providerServiceSpy,providerList);

        Mockito.verify(kafkaTemplateWrapperService,Mockito.times(2)).produceProviderNotificationTopicMessage(Mockito.any());


    }
}