package com.provider.eds.config;

import com.medica.model.eds.common.ResynchNotification;
import com.medica.model.eds.provider.Message;
import com.provider.eds.model.misc.ErroredRecord;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.errors.RecordTooLargeException;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.errors.DeserializationExceptionHandler;
import org.apache.kafka.streams.errors.ProductionExceptionHandler;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.annotation.KafkaStreamsDefaultConfiguration;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;

import static org.apache.kafka.streams.StreamsConfig.APPLICATION_ID_CONFIG;
import static org.apache.kafka.streams.StreamsConfig.BOOTSTRAP_SERVERS_CONFIG;

@Slf4j
@Configuration
@EnableKafkaStreams
public class KafkaConfig {
    @Value(value = "${spring.kafka.streams.application-id}")
    private String applicationId;
    @Value(value = "${spring.kafka.streams.kafka-brokers}")
    private String bootstrapServers;
    @Value(value = "${spring.kafka.streams.offset}")
    private String offset;
    

    public static class StreamsDeserializationErrorHandler implements DeserializationExceptionHandler {

        @Override
        public void configure(Map<String, ?> configs) {
            
        }

        @Override
        public DeserializationHandlerResponse handle(ProcessorContext context, ConsumerRecord<byte[], byte[]> record,
                Exception exception) {
            log.info("Error In Recoerd: {}  Exception: {}", record.toString(), exception);
            return null;
        }
    }

    public static class StreamsRecordProducerErrorHandler implements ProductionExceptionHandler {
        @Override
        public ProductionExceptionHandlerResponse handle(ProducerRecord<byte[], byte[]> record, Exception exception) {
            if (exception instanceof RecordTooLargeException ) {
                return ProductionExceptionHandlerResponse.CONTINUE;
            }
            return ProductionExceptionHandlerResponse.FAIL;
        }
    
        @Override
        public void configure(Map<String, ?> configs) { }
    }

    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    KafkaStreamsConfiguration kStreamsConfig() {
        Map<String, Object> props = new HashMap<>();
        props.put(APPLICATION_ID_CONFIG, applicationId);
        props.put(BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, offset);
        props.put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, StreamsDeserializationErrorHandler.class);
        props.put(StreamsConfig.DEFAULT_PRODUCTION_EXCEPTION_HANDLER_CLASS_CONFIG, StreamsRecordProducerErrorHandler.class);
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, 900000);
        return new KafkaStreamsConfiguration(props);
    }

    @Bean
    @Qualifier("producerFactory")
    public ProducerFactory<String, Message> producerFactorySecondary(KafkaProperties properties) {
        Map<String, Object> producerProperties = properties.buildProducerProperties();
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, org.springframework.kafka.support.serializer.JsonSerializer.class);
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);
        return new DefaultKafkaProducerFactory(producerProperties);
    }

    @Bean
    @Qualifier("producerResynchFactory")
    public ProducerFactory<String, ErroredRecord> producerFactoryResynch(KafkaProperties properties) {
        Map<String, Object> producerProperties = properties.buildProducerProperties();
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, org.springframework.kafka.support.serializer.JsonSerializer.class);
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);
        return new DefaultKafkaProducerFactory(producerProperties);
    }

    @Bean
    @Qualifier("kafkaTemplateResynch")
    public KafkaTemplate<String, ResynchNotification> kafkaTemplateProviderResynch(@Qualifier("producerResynchFactory") ProducerFactory<String, ErroredRecord> producerFactoryResynch) {
        return new KafkaTemplate(producerFactoryResynch);
    }

    @Bean
    @Qualifier("kafkaTemplateProviderNotification")
    public KafkaTemplate<String, String> kafkaTemplateString(@Qualifier("producerProviderNotificationFactory") ProducerFactory<String, String> producerProviderNotificationFactory) {
        return new KafkaTemplate(producerProviderNotificationFactory);
    }

    @Bean
    @Qualifier("producerProviderNotificationFactory")
    public ProducerFactory<String, String> producerOrchestrationFactory(KafkaProperties properties) {
        Map<String, Object> producerProperties = properties.buildProducerProperties();
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, this.bootstrapServers);
        return new DefaultKafkaProducerFactory(producerProperties);
    }


}