package com.provider.eds.model.misc;

public class ObjectTooBigException extends Exception{
    public ObjectTooBigException() {
        super();
    }
    public ObjectTooBigException(String message) {
        super(message);
    }
}
