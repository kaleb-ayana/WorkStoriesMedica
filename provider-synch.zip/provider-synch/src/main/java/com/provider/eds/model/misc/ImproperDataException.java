package com.provider.eds.model.misc;

public class ImproperDataException extends Exception{
    public ImproperDataException() {
        super();
    }
    public ImproperDataException(String message) {
        super(message);
    }
}
