package com.provider.eds.service.utils;

import com.provider.eds.model.misc.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
public class Util {

    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static boolean hasNonExpiredEndDate(String endDate, String expirationDate) {
        if(endDate == null || endDate.isBlank()) {
            endDate = Constants.OPEN_END_DATE;
        }
        LocalDate expiryDate = null;
        LocalDate endDateFormatted=null;
        try {
            expiryDate= LocalDate.parse(expirationDate, formatter);
            endDateFormatted = LocalDate.parse(endDate, formatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return endDateFormatted.isAfter(expiryDate);
    }

    public static LocalDateTime parseTimeStamp(String timeStamp) {
        try{
            return LocalDateTime.ofInstant(Instant.ofEpochMilli(Long.parseLong(timeStamp)),TimeZone.getDefault().toZoneId());
        } catch( Exception e) {
            return null;
        }
    }
    public static LocalDate parseDate(String dateString) {
        LocalDate date = null;
        try {
            date = LocalDate.parse(dateString, formatter);
        } catch (DateTimeParseException e) {
            log.info("Error parsing date.");
        } finally {
            return date;
        }
    }
    public static LocalDate getSmallerDate(LocalDate localDate1, LocalDate localDate2) {
        if(Objects.isNull(localDate1))
            return localDate2;
        if(Objects.isNull(localDate2))
            return localDate1;
        return localDate1.isBefore(localDate2) ? localDate1 : localDate2;
    }

    public static LocalDate getBiggerDate(LocalDate localDate1, LocalDate localDate2) {
        if(Objects.isNull(localDate1))
            return localDate2;
        if(Objects.isNull(localDate2))
            return localDate1;
        return localDate1.isAfter(localDate2) ? localDate1 : localDate2;
    }
    public static Boolean isBetweenDate(LocalDate d, LocalDate effDate, LocalDate endDate) {
        if(Objects.isNull(d) || Objects.isNull(effDate) || Objects.isNull(endDate)){
            return false;
        }

        if((d.isAfter(effDate) || d.isEqual(effDate)) && (d.isBefore(endDate) || d.isEqual(endDate))){
            return true;
        }
        return false;
    }
    public static LocalDate parseDateOrDefault(String dateString) {
        if(! StringUtils.hasText(dateString) || "null".equalsIgnoreCase(dateString))
            dateString = Constants.OPEN_END_DATE;
        return parseDate(dateString);
    }
    public static String parseDateOrDefaultString(String dateString) {
        return parseDateOrDefault(dateString).toString();
    }
    public static <T> List<T> filterList(List<T> list, Predicate<T> condition) {
        if(Objects.isNull(list) || list.isEmpty())
            return list;
        return list.stream().filter(condition).collect(Collectors.toList());
    }
    public static <T> boolean isNonNullNonEmpty(List<T> list) {
        return (! nullOrEmpty(list));
    }
    public static <T> boolean nullOrEmpty(List<T> list) {
        return Objects.isNull(list) || list.isEmpty();
    }

    public static <T, String> List<String> filterFieldValues(List<T> list, Function<T, String> mapFunction) {
        return filterFieldValues(list, mapFunction, false);
    }
    public static <T, String> List<String> filterFieldValues(List<T> list, Function<T, String> mapFunction, boolean uniqueFlag) {
        if(Objects.isNull(list) || list.isEmpty())
            return null;
        List<String> stringList= list.stream().map(mapFunction).filter(item -> Objects.nonNull(item) && ! item.toString().isBlank()).collect(Collectors.toList());
        if(! uniqueFlag || nullOrEmpty(stringList))
            return stringList;

        return new ArrayList<>(new HashSet<>(stringList));
    }

    public static boolean isProperDateString(String dateString) {
        if(Objects.isNull(dateString) || dateString.isBlank())
            return false;
        try {
            return Objects.nonNull(LocalDate.parse(dateString, formatter));
        } catch(DateTimeParseException e) {
            return false;
        }
    }
    public static boolean isDigits(String dateString) {
        if(Objects.isNull(dateString) || dateString.isBlank())
            return false;
        try {
            return Objects.nonNull(Long.parseLong (dateString));
        } catch (NumberFormatException e) {
            return false;
        }
    }
    public static String convertToDate(String intDate) {
        String calcDate = "";
        if (intDate == null) {
            return intDate;
        }
        calcDate = String.valueOf(LocalDate.ofEpochDay(Long.parseLong(intDate)));
        return calcDate;
    }

    public static LocalDate convertIntDateStrToLocalDate(String intDate) {
        String calcDate = "";
        if (intDate == null || intDate.isBlank() || ! isDigits(intDate)) {
            return null;
        }
        return LocalDate.ofEpochDay(Long.parseLong(intDate));
    }
    public static LocalDate convertDateStrToLocalDate(String dateString) {
        if(Objects.isNull(dateString) || dateString.isBlank())
            return null;
        try {
            return LocalDate.parse(dateString, formatter);
        } catch(DateTimeParseException e) {
            return null;
        }
    }

    public static boolean convertStringToBoolean(String str) {
        if(! StringUtils.hasText(str))
            return false;
        try {
            return Boolean.parseBoolean(str);
        } catch (Exception e) {
            return false;
        }
    }

    public static String getMinDate(String date1, String date2) {
        LocalDate localDate1= parseToLocalDate(date1);
        LocalDate localDate2= parseToLocalDate(date2);
        if(Objects.isNull(localDate1))
            return date2;
        if(Objects.isNull(localDate2))
            return date1;
        return localDate1.isBefore(localDate2) ? date1 : date2;
    }

    public static String getMaxDate(String date1, String date2) {
        LocalDate localDate1= parseToLocalDate(date1);
        LocalDate localDate2= parseToLocalDate(date2);
        if(Objects.isNull(localDate1))
            return date2;
        if(Objects.isNull(localDate2))
            return date1;
        return localDate1.isAfter(localDate2) ? date1 : date2;
    }

    private static Long parseToLong(String dataOrDateTime) {
        try {
            return Long.parseLong(dataOrDateTime);
        } catch(NumberFormatException e) {
            return null;
        }
    }
    private static LocalDate parseToLocalDate(String date) {
        try {
            return LocalDate.parse(date);
        } catch (Throwable throwable) {
            return null;
        }
    }
    public static boolean hasValue(String field) {
        return Objects.nonNull(field) && (! field.isBlank());
    }

    public static <T> boolean hasList(List<T> list, Predicate<T> condition) {
        return nonEmpty(selectFromList(list, condition));
    }

    public static <T> List<T> selectFromList(List<T> list, Predicate<T> condition) {
        if(Objects.isNull(list) || list.isEmpty())
            return list;
        if(Objects.isNull(condition))
            return null;
        return list.stream().filter(condition).collect(Collectors.toList());
    }

    public static <T> boolean nonEmpty(List<T> list) {
        return ! nullOrEmpty(list);
    }
    public static boolean getOrDefault(Boolean flag) {
        return Objects.isNull(flag) ? false : flag.booleanValue();
    }
}