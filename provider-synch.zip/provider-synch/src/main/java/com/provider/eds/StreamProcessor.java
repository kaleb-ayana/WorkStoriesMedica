package com.provider.eds;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medica.model.eds.common.ResynchNotification;
import com.provider.eds.model.misc.ImproperDataException;
import com.provider.eds.model.misc.ObjectTooBigException;
import com.provider.eds.service.ProviderService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.serializer.JsonSerde;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Component
@Slf4j
public class StreamProcessor {
    @Autowired
    private ObjectMapper objectMapper;

//    @Autowired
//    @Qualifier("kafkaTemplateMessage")
//    public KafkaTemplate<String, Message> kafkaTemplate;

    @Value("${topics.inbound}")
    private String INBOUND_TOPIC;


    @Autowired
    ProviderService providerService;


    @Autowired
    @Qualifier("kafkaTemplateResynch")
    public KafkaTemplate<String, ResynchNotification> kafkaTemplate;

    @Autowired
    void providerTopology(StreamsBuilder streamsBuilder) {
        final Serde<String> STRING_SERDE = Serdes.String();
        final JsonSerde<ResynchNotification> MESSAGE_JSON_SERDE = new JsonSerde<>(ResynchNotification.class);
        KStream<String, ResynchNotification> orchestrationProviderKStream = streamsBuilder.stream(INBOUND_TOPIC, Consumed.with(STRING_SERDE, MESSAGE_JSON_SERDE));

        orchestrationProviderKStream
            .peek(((key, value) -> log.info("Received avro message with key [" + key + "]" + " - > " + value + "-".repeat(20))))
            .filter((key, value) -> Objects.nonNull(key) && Objects.nonNull(value))
            .foreach((key, value) -> {
                try {
                    this.providerService.processResynchNotification(value);
                    log.info("Resynch for " + key + " Completed. ===");
                } catch (ImproperDataException | ObjectTooBigException e) {
                    log.warn("Resynch for " + key + " Failed. XXX");
                    this.kafkaTemplate.send(this.INBOUND_TOPIC+".dlt", key, value);
//                    throw new RuntimeException(e);
                }
            });

    }

    public ResynchNotification parseAndMessage(String value, String key) throws JsonProcessingException {
        try {
            return objectMapper.readValue(value, ResynchNotification.class);
        } catch (JsonProcessingException e) {
            log.error("Error parsing avro message with key " + key);
            throw e;
        }
    }

}