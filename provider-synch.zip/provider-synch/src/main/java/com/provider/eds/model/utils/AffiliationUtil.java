package com.provider.eds.model.utils;

import com.medica.model.eds.provider.Affiliation;
import com.provider.eds.model.misc.Constants;
import org.springframework.util.StringUtils;

import java.util.Objects;

public class AffiliationUtil {
   //Expects affiliations to have resynchTag
    public static boolean isMatching(Affiliation affiliationOne, Affiliation affiliationTwo) { // SPECIFIC
        if (Objects.isNull(affiliationOne))
            return affiliationOne == affiliationTwo;
        if(Objects.isNull(affiliationTwo))
            return false;
        return
                Objects.equals(affiliationOne.getSourceSystemCd(), affiliationTwo.getSourceSystemCd()) &&
                Objects.equals(affiliationOne.getAffiliateProviderIdType(), affiliationTwo.getAffiliateProviderIdType()) &&
                Objects.equals(affiliationOne.getMtvAffiliateProviderId(), affiliationTwo.getMtvAffiliateProviderId()) &&
                Objects.equals(affiliationOne.getAffiliationType(), affiliationTwo.getAffiliationType()) &&
                Objects.equals(affiliationOne.getHospitalAffiliationType(), affiliationTwo.getHospitalAffiliationType()) &&
                hasProperResynchTag(affiliationOne) && hasProperResynchTag(affiliationTwo) &&
                affiliationOne.getResynchTag().split(Constants.SEMI_COLON)[0].equals(affiliationTwo.getResynchTag().split(Constants.SEMI_COLON)[0]);
    }

    public static boolean hasProperResynchTag(Affiliation affiliation) {
        return Objects.isNull(affiliation) ? false : StringUtils.hasText(affiliation.getResynchTag());
    }
}
