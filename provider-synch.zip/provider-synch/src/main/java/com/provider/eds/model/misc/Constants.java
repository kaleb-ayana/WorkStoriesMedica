package com.provider.eds.model.misc;

import java.util.Arrays;
import java.util.List;

public class Constants {
    public static final List<String> VALID_SPECIALTY_CODES = Arrays.asList("01","08","11","1H","37","16","3B");
    public static final String MTV="MTV";
    public static final String SEMI_COLON=";";
    public static final String A2_ADDRESS="A2";
    public static final String BA_ADDRESS="BA";
    public static final String TAX="TAX";
    public static final String MD5="MD5";
    public static final String ENTITY_SPECIALITY="SPECIALTY";
    public static final String ENTITY_ADDRESS="ADDRESS";
    public static final String ENTITY_LANGUAGE="LANGUAGE";
    public static final String ENTITY_ALTERNATIVEID="LANGUAGE";
    public static final String ENTITY_AFFILIATION="AFFILIATION";
   // public static final String ENTITY_CONTRACT="CONTRACT";
    public static final String NPI2 = "NPI2";
    public static final String PAYTO = "PAYTO";
    public static final String OPEN_END_DATE = "9999-12-31";

    public static final String NPI1 = "NPI1";
    public static final String AP_ADDRESS ="AP";
}

