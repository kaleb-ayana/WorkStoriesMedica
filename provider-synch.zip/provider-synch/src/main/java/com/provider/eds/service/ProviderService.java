package com.provider.eds.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medica.model.eds.common.ProviderNotification;
import com.medica.model.eds.common.ResynchNotification;
import com.medica.model.eds.provider.Affiliation;
import com.medica.model.eds.provider.Network;
import com.medica.model.eds.provider.Panel;
import com.medica.model.eds.provider.Provider;
import com.medica.reference.misc.InvalidObjectStateException;
import com.medica.reference.misc.PersistenceErrorException;
import com.medica.reference.model.ProviderReferenceGroup;
import com.medica.reference.model.ProviderReferenceInput;
import com.medica.reference.model.ReferenceFactory;
import com.medica.reference.model.ReferenceIdFactory;
import com.medica.reference.service.ProviderReferenceService;
import com.provider.eds.model.misc.*;
import com.provider.eds.model.utils.AddressUtil;
import com.provider.eds.model.utils.AlternateIdentifierUtil;
import com.provider.eds.repository.ProviderRepository;
import com.provider.eds.service.messagers.KafkaTemplateWrapperService;
import com.provider.eds.service.utils.ProviderNotificationEvaluator;
import com.provider.eds.service.utils.ProviderUtil;
import com.provider.eds.service.utils.Util;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProviderService {
    @Value("${schema-version}")
    private String schemaVersion;
    @Value("${enablenotification}")
    private Boolean enableNotification;
    @Autowired
    private ProviderReferenceService providerReferenceService;
    @Autowired
    private ProviderRepository providerRepository;
    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ProviderNotificationEvaluator providerNotificationEvaluator;

    @Autowired
    private KafkaTemplateWrapperService kafkaTemplateWrapperService;

    private ProviderReferenceGroup getRelatedProviderReferences (ProviderReferenceInput providerId) { // TODO: Revise for sub query or bulk query, use reference table
        try {
            return this.providerReferenceService.find(providerId);
        } catch (InvalidObjectStateException | PersistenceErrorException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Provider> getProvidersByTransactionIds(Set<String> transactionIds) {
        if(CollectionUtils.isEmpty(transactionIds))
            return null;
        return this.providerRepository.findAllByIdIn(transactionIds).collectList().retry(3).block();
    }

    public boolean hasProperResynchTags(List<Provider> toResynchProviders) {
        if(CollectionUtils.isEmpty(toResynchProviders))
            return true;
        return toResynchProviders.stream().noneMatch(provider -> ! ProviderUtil.hasProperResynchTag(provider));
    }
    public void processResynchNotification(ResynchNotification notification) throws ObjectTooBigException, ImproperDataException {
        if(Objects.isNull(notification) || (! StringUtils.hasText(notification.getSourceSystemCd())) || (!StringUtils.hasText(notification.getProviderId())))
            return;
      //  Set<String> relatedProvidersIds= this.getRelatedProviderIds(notification.getProviderId());
        ProviderReferenceInput input=new ProviderReferenceInput();
        input.addProviderId(notification.getProviderId(), notification.getSourceSystemCd());

        ProviderReferenceGroup providerRefGroup= this.getRelatedProviderReferences(input);
        if(providerRefGroup.isEmpty())
            providerRefGroup.addOrReplace(ReferenceFactory.createProviderReference(notification.getProviderId(), notification.getSourceSystemCd(), notification.getSourceSystemCd(),null, null, false,null));
        Set<String> relatedProvidersIds= providerRefGroup.getProviderReferences().stream().map(p->p.getProviderId()).collect(Collectors.toSet());

        if(CollectionUtils.isEmpty(relatedProvidersIds)) {
            log.info("No related providers to : " + notification.getProviderId());
            return;
        }
        List<Provider> allProviders= this.getProvidersByTransactionIds(this.decorateIdWithSourceSystemCd(relatedProvidersIds, notification.getSourceSystemCd()));
        if(CollectionUtils.isEmpty(allProviders) || ((allProviders.size() == 1 ) && (allProviders.get(0).getProviderId().equalsIgnoreCase(notification.getProviderId())))) {
            log.info("No related provider Objects to : " + notification.getProviderId());
            return;
        }
        // TODO: Lookup retrieval/creation for each candidate (bulk read)
        log.info("Found related providers to : " + notification.getProviderId() + " => " + allProviders.stream().map(Provider::getProviderId).filter(pid->!pid.equalsIgnoreCase(notification.getProviderId())).collect(Collectors.toList()));
        Provider updatedProvider= allProviders.stream().filter(pro-> pro.getProviderId().equalsIgnoreCase(notification.getProviderId())).findFirst().get();
        List<Provider> toResynchProviders= allProviders.stream().filter(pro-> ! pro.getProviderId().equalsIgnoreCase(notification.getProviderId())).collect(Collectors.toList());
        if(CollectionUtils.isEmpty(toResynchProviders) || Objects.isNull(updatedProvider)  ) {
            log.info("No record fetched for updated provider");
            return;
        }
        log.info("Checking if resynch tags are valid for resynch candidate providers....");
        if(! hasProperResynchTags(toResynchProviders)) {
            log.warn("One or more resynch candidate providers miss resynTag values in their affiliation, panel, or network data.");
            throw new ImproperDataException("One or more resynch candidate providers miss resynTag values in their affiliation, panel, or network data.");
        }
        this.resynchPayToAffiliations(updatedProvider, toResynchProviders, notification);
        this.resynchPanels(updatedProvider, toResynchProviders,notification);
        this.resynchNetworks(updatedProvider, toResynchProviders, notification);
        this.resynchSiteAffiliations(updatedProvider, toResynchProviders,notification);
        toResynchProviders.stream().forEach(provider-> {
            if(ProviderUtil.hasRelatedMtvProvider(provider, notification.getProviderId()))
                providerRefGroup.getProviderReference(notification.getProviderId(), notification.getSourceSystemCd()).get().addOrReplaceRelatedProvider(ReferenceIdFactory.createProviderReference(provider.getProviderId(), provider.getSourceSystemCd(),  provider.getEffDate(), provider.getTermDt(), provider.getLogicalDeleteFlg()));
        });
        try {
            this.providerReferenceService.save(providerRefGroup);
        } catch (InvalidObjectStateException | PersistenceErrorException e) {
            throw new RuntimeException(e);
        }

        //TODO: Persistence of all candidate lookup (with bulk update)
        if(! this.areWithInSizeLimit(toResynchProviders))
            throw new ObjectTooBigException("One or more objects are too big in size");
        this.persistProviders(toResynchProviders); // TODO: have this throw DataPersistenceException
        // TODO: update of all candidate lookups

        if(this.enableNotification)
            this.produceProviderNotificationTopicMessages(toResynchProviders);

    }
    private boolean areWithInSizeLimit(List<Provider> toResynchProviders) {
        for(Provider provider: toResynchProviders) {
            if(! this.isWithInSizeLimit(provider))
                return false;
        }
        return true;
    }
    private boolean isWithInSizeLimit(Provider provider) {
        String result= null;
        try {
            result= this.objectMapper.writeValueAsString(provider);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        if(Objects.isNull(result))
            throw new RuntimeException("Json string representation of non null provider should have a value.");
        return (result.getBytes().length/(1024.0 * 1024.0)) < 2.0;
    }
    public void persistProviders(Collection<Provider> providers)  { // TODO: Throw DataPersistenceException
        if(CollectionUtils.isEmpty(providers)) {
            log.warn("No providers to persist!");
            return;
        }
        List<String> providerIds= providers.stream().map(Provider::getProviderId).collect(Collectors.toList());
        log.info("Persisting ... " + providerIds);
        providers.stream().forEach(p->p.setTransactionId(p.getProviderId()+p.getSourceSystemCd()));
        this.providerRepository
            .saveAll(providers)
            .retry(2)
            .onErrorResume(throwable -> {
                log.warn("<UPINSERT ERROR> Happened for providers : " + providerIds );
                log.warn("Erred Providers Detail : " + providerIds);
                throw new RuntimeException("<UPINSERT ERROR> Happened for providers : " + providerIds, throwable);
//                    return Mono.empty(); //TODO:
            }).blockFirst(Duration.ofSeconds(30));

        log.info(String.format("Provider saved to EDS with ids: %s", providers.stream().map(p->p.getProviderId()).collect(Collectors.toList())));
    }
    private Set<String> decorateIdWithSourceSystemCd(Set<String> ids, String sourceSystemCd) {
        return ids.stream().map(id->id+sourceSystemCd).collect(Collectors.toSet());
    }

    public void resynchPanels(Provider provider, List<Provider> toResynchProviders, ResynchNotification notification) {
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(toResynchProviders) || Objects.isNull(notification)|| (! notification.isMd5ChangedFlag()))
            return;

        List<MD5Hash> updatedMD5HashList= ProviderUtil.getMD5Hashes(provider);
        if(CollectionUtils.isEmpty(updatedMD5HashList)) {
            toResynchProviders.stream().forEach(prov-> ProviderUtil.removePanelsWith(prov, provider.getProviderId()));
            return;
        }
        toResynchProviders.stream().forEach(prov -> resynchPanel(prov, provider.getProviderId(), updatedMD5HashList));
    }

    public void resynchPanel(Provider provider, String relatedProviderId, List<MD5Hash> updatedMD5List) {
        if(! ProviderUtil.hasPanelsWith(provider, relatedProviderId))
            return;
        List<Panel> existingPanels= ProviderUtil.getPrototypePanelsFor(provider, relatedProviderId);
        if(CollectionUtils.isEmpty(existingPanels))
            return;
        List<Panel> recreatedPanels= new ArrayList<>();
        for(Panel panel: existingPanels) {
            for(MD5Hash md5: updatedMD5List)
                if(panel.getAddressId().equalsIgnoreCase(md5.getAddressId()))
                    recreatedPanels.add(duplicate(panel, md5));
        }
        ProviderUtil.removePanelsWith(provider, relatedProviderId);
        ProviderUtil.addPanels(provider, recreatedPanels);
    }
    private Panel duplicate(Panel panel, MD5Hash md5Hash) {
        Panel newPanel = SerializationUtils.clone(panel);
        newPanel.setPracLocProviderId(md5Hash.md5);
        if(Objects.nonNull(newPanel.getResynchTag())) {
            newPanel.setLogicalDeleteFlg(Boolean.parseBoolean(newPanel.getResynchTag().split(Constants.SEMI_COLON)[2]) || md5Hash.logicalDeleteFlag);
        }
        return newPanel;
    }
    public void resynchNetworks(Provider updatedProvider, List<Provider> toResynchProviders, ResynchNotification notification) {
        if(Objects.isNull(updatedProvider) || CollectionUtils.isEmpty(toResynchProviders) || Objects.isNull(notification) || (! notification.isMd5ChangedFlag()))
            return;
        List<MD5Hash> updatedMD5HashList= ProviderUtil.getMD5Hashes(updatedProvider);
        if(CollectionUtils.isEmpty(updatedMD5HashList)) {
            toResynchProviders.stream().forEach(prov-> ProviderUtil.removeNetworksWith(prov, updatedProvider.getProviderId()));
            return;
        }
        toResynchProviders.stream().forEach(provider -> resynchNetwork(provider, updatedProvider.getProviderId(), updatedMD5HashList));
    }
    public void resynchNetwork(Provider provider, String relatedProviderId, List<MD5Hash> updatedMD5List) {
        if(! ProviderUtil.hasNetworkDirectoriesWith(provider, relatedProviderId))
            return;
        List<Network> existingNetworks= ProviderUtil.getPrototypeNetworksFor(provider, relatedProviderId);
        if(CollectionUtils.isEmpty(existingNetworks))
            return;
        List<Network> recreatedNetworks= new ArrayList<>();
        for(Network network: existingNetworks) {
            for(MD5Hash md5: updatedMD5List)
                if(network.getAddressId().equalsIgnoreCase(md5.getAddressId()))
                    recreatedNetworks.add(duplicate(network, md5));
        }
        ProviderUtil.removeNetworksWith(provider, relatedProviderId);
        ProviderUtil.addNetworks(provider, recreatedNetworks);
    }

    private Network duplicate(Network network, MD5Hash md5Hash) {
        Network networkNew= SerializationUtils.clone(network);
        networkNew.setPraclocProviderId(md5Hash.md5);
        if(Objects.nonNull(networkNew.getResynchTag())) {
            networkNew.setLogicalDeleteFlg(Boolean.parseBoolean(networkNew.getResynchTag().split(Constants.SEMI_COLON)[2]) || md5Hash.logicalDeleteFlag);
        }
        return networkNew;
    }

    public void resynchPayToAffiliations(Provider updatedProvider, List<Provider> toResynchProviders, ResynchNotification notification) {
        if(Objects.isNull(updatedProvider) || CollectionUtils.isEmpty(toResynchProviders) || Objects.isNull(notification) || (! notification.isTaxIdChangedFlag()))
            return;
        List<Tax> updatedTaxList= ProviderUtil.getTaxIds(updatedProvider);
        if(CollectionUtils.isEmpty(updatedTaxList)) {
            log.info("Payto affiliation taxIds are empty.... Now clearing ");
            toResynchProviders.stream().forEach(prov-> ProviderUtil.removePayToAffiliationsWith(prov, updatedProvider.getProviderId()));
            return;
        }
        toResynchProviders.stream().forEach(provider -> resynchPayToAffiliations(provider, updatedProvider.getProviderId(), updatedTaxList));
     }
    public void resynchPayToAffiliations(Provider provider, String relatedProviderId, List<Tax> updatedTaxList) {
        if(! ProviderUtil.hasPayToAffiliationsWith(provider, relatedProviderId))
            return;
        List<Affiliation> existingPaytoAffiliations= ProviderUtil.getPrototypePayToAffiliationsFor(provider, relatedProviderId);
        if(CollectionUtils.isEmpty(existingPaytoAffiliations)) {
            log.info("Existing payto affiliations are non-existent....");
            return;
        }
        List<Affiliation> recreatedPayToAffiliations= new ArrayList<>();
        for(Affiliation affiliation: existingPaytoAffiliations) {
            for(Tax tax: updatedTaxList)
                recreatedPayToAffiliations.add(duplicate(affiliation, tax));
        }
        ProviderUtil.removePayToAffiliationsWith(provider, relatedProviderId);
        ProviderUtil.addAffiliation(provider, recreatedPayToAffiliations);

    }

    private Affiliation duplicate(Affiliation affiliation, Tax tax) {
        Affiliation dupAffiliation= SerializationUtils.clone(affiliation);
        dupAffiliation.setAffiliateProviderId(tax.alternateId);
        dupAffiliation.setEffDt(Util.getMaxDate(dupAffiliation.getResynchTag().split(Constants.SEMI_COLON)[0], tax.effDt));
        dupAffiliation.setEndDt(Util.getMinDate(Util.parseDateOrDefaultString(dupAffiliation.getResynchTag().split(Constants.SEMI_COLON)[1]), Util.parseDateOrDefaultString(tax.endDt)));
        dupAffiliation.setLogicalDeleteFlg(Boolean.parseBoolean(affiliation.getResynchTag().split(Constants.SEMI_COLON)[2]) || tax.logicalDeleteFlag);
        return dupAffiliation;
    }
    private Affiliation duplicate(Affiliation affiliation, MD5Hash md5) {
        Affiliation dupAffiliation= SerializationUtils.clone(affiliation);
        dupAffiliation.setAffiliateProviderId(md5.md5);
        dupAffiliation.setEffDt(Util.getMaxDate(dupAffiliation.getResynchTag().split(Constants.SEMI_COLON)[0], md5.effDt));
        dupAffiliation.setEndDt(Util.getMinDate(Util.parseDateOrDefaultString(dupAffiliation.getResynchTag().split(Constants.SEMI_COLON)[1]), Util.parseDateOrDefaultString(md5.endDt)));
        dupAffiliation.setLogicalDeleteFlg(Boolean.parseBoolean(affiliation.getResynchTag().split(Constants.SEMI_COLON)[2]) || md5.logicalDeleteFlag);
        return dupAffiliation;
    }
    public void resynchSiteAffiliations(Provider updatedProvider, List<Provider> toResynchProviders, ResynchNotification notification) {
        if(Objects.isNull(updatedProvider) || CollectionUtils.isEmpty(toResynchProviders) || Objects.isNull(notification) || (! notification.isMd5ChangedFlag()))
            return;
        List<MD5Hash> updatedMD5HashList= ProviderUtil.getMD5Hashes(updatedProvider);
        if(CollectionUtils.isEmpty(updatedMD5HashList)) {
            toResynchProviders.stream().forEach(prov-> ProviderUtil.removeSiteAffiliationsWith(prov, updatedProvider.getProviderId()));
            return;
        }
        toResynchProviders.stream().forEach(provider -> resynchSiteAffiliation(provider, updatedProvider.getProviderId(), updatedMD5HashList));
    }

    private void resynchSiteAffiliation(Provider provider, String relatedProviderId, List<MD5Hash> updatedMD5HashList) {
        if(! ProviderUtil.hasSiteAffiliationsWith(provider, relatedProviderId))
            return;
        List<Affiliation> existingAffiliations= ProviderUtil.getPrototypeSiteAffiliationsFor(provider, relatedProviderId);
        if(CollectionUtils.isEmpty(existingAffiliations))
            return;
        List<Affiliation> recreatedAffiliations= new ArrayList<>();
        for(Affiliation affiliation: existingAffiliations) {
            for(MD5Hash md5: updatedMD5HashList)
                recreatedAffiliations.add(duplicate(affiliation, md5));
        }
        ProviderUtil.removeSiteAffiliationsWith(provider, relatedProviderId);
        ProviderUtil.addAffiliation(provider, recreatedAffiliations);
    }


    public List<ProviderNotification> processProviderNotificationMessage(Provider provider) {
        List<ProviderNotification> resultList= new ArrayList<>();
        if(Objects.isNull(provider))
            return resultList;
        if(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS) &&
                providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.NPI2) &&
                providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.TAX))        {
            providerNotificationEvaluator.getNonVoidedAlternateIdTypeOf(provider, Constants.TAX)
                    .stream()
                    .forEach(alt ->
                            resultList.add(ProviderNotification.createNotification(provider.getProviderId(),provider.getSourceSystemCd(),alt.getAlternateId(),
                                    ProviderIdType.TAX.toString(),ProviderCategoryCd.PAYTO.toString(), Util.getOrDefault(alt.getLogicalDeleteFlg()),false, this.schemaVersion )));
        }

        if(this.providerNotificationEvaluator.isPractitionerCandidate(provider)) {
            provider.getOpvProviderAlternateId()
                    .stream()
                    .filter(alternateIdentifier -> AlternateIdentifierUtil.hasType(alternateIdentifier,Constants.NPI1) && AlternateIdentifierUtil.isActive(alternateIdentifier) )
                    .forEach(alt-> resultList.add(new ProviderNotification(provider.getProviderId(),provider.getSourceSystemCd(),alt.getAlternateId(),
                            ProviderIdType.NPI1.toString(),
                            ProviderCategoryCd.PRACT.toString(),
                            alt.getLogicalDeleteFlg(),false, this.schemaVersion)));
        }
        if(this.providerNotificationEvaluator.isLocationCandidate(provider))
            provider.getOpvProviderAddress()
                    .stream()
                    .filter(AddressUtil::hasMD5Hash)
                    .forEach(address -> {
                        resultList.add(ProviderNotification.createNotification(provider.getProviderId(), provider.getSourceSystemCd(),address.getAddrMd5Hash(),
                                ProviderIdType.MD5.toString(),
                                ProviderCategoryCd.SITE.toString(),
                                Util.getOrDefault(address.getLogicalDeleteFlg()),
                                false, schemaVersion)); //TODO Calculate  PHYSICAL_DELETE_FLAG
                    });

        return resultList;
    }

    private void produceProviderNotificationTopicMessages(List<Provider> toOrchestrationEvaluatorProviders) {
        if(CollectionUtils.isEmpty(toOrchestrationEvaluatorProviders))
            return;
        try{
            List<ProviderNotification> providerNotifications = toOrchestrationEvaluatorProviders.stream()
                .map( provider -> processProviderNotificationMessage(provider)).flatMap(providerList -> providerList.stream()).collect(Collectors.toList());
            if(!CollectionUtils.isEmpty(providerNotifications))
                providerNotifications.stream()
                        .forEach(providerNotification -> {
                            log.info("Provider Notification topic produced : [" + providerNotification.getPROVIDER_ID() + " , " + providerNotification.getPROVIDER_ID_TYPE()+ " ]");
                            kafkaTemplateWrapperService.produceProviderNotificationTopicMessage(providerNotification).addCallback(
                                    result -> log.info("Provider Notification Topic message produced.")  ,  x -> log.info("Producing Provider Notification topic message failed. " + x));
                        });
            else
                log.info("Providers [ " + toOrchestrationEvaluatorProviders.stream().map(prov ->prov.getProviderId()).collect(Collectors.toList()) + " ] had no candidates for Provider Notification topic messages");
        } catch (Exception e) {
            log.error("Producing Provider Notification topic Message Error encountered : ", e);
            throw e;
        }
    }
}