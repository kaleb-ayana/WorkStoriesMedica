package com.provider.eds;

import com.provider.eds.service.ProviderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@Slf4j
@RestController
public class Controller {

    @Autowired
    private ProviderService providerService;

    @GetMapping("/health")
    public String healthTest() {
        return  "Working ...";
    }
    @GetMapping("/test")
    public Set<String> testRelatedProvider() {
        return Set.of("Test-1", "Test-2");

    }



}
