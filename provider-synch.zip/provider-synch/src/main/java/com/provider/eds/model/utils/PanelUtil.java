package com.provider.eds.model.utils;

import com.medica.model.eds.provider.Panel;
import org.springframework.util.StringUtils;

import java.util.Objects;

public class PanelUtil {

    public static boolean isMatching(Panel panelOne, Panel panelTwo) {
        if (Objects.isNull(panelOne))
            return panelOne == panelTwo;
        if(Objects.isNull(panelTwo))
            return false;

        return Objects.equals(panelOne.getMtvProviderId(), panelTwo.getMtvProviderId()) &&
                Objects.equals(panelOne.getAddressId(), panelTwo.getAddressId()) &&
                Objects.equals(panelOne.getEffDt(), panelTwo.getEffDt());
    }

    public static boolean hasProperResynchTag(Panel panel) {
        return Objects.isNull(panel) ? false : StringUtils.hasText(panel.getResynchTag());
    }
}
