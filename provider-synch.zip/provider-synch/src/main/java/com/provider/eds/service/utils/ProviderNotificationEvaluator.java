package com.provider.eds.service.utils;

import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.medica.model.eds.provider.Provider;
import com.medica.model.eds.provider.Specialty;
import com.provider.eds.model.misc.Constants;
import com.provider.eds.model.misc.ProviderCategoryCd;
import com.provider.eds.model.utils.AddressUtil;
import com.provider.eds.model.utils.AlternateIdentifierUtil;
import com.provider.eds.model.utils.SpecialtyUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ProviderNotificationEvaluator {
    @Value("${expirationdate}")
    private String expirationDate;

    public boolean hasNonVoidedAddressTypeOf(Provider provider, String addressType) {
        if( (! StringUtils.hasText(addressType)) || (Objects.isNull(provider)) )
            return false;
        return Util.hasList(provider.getOpvProviderAddress(), address -> addressType.trim().equalsIgnoreCase(address.getAddressTypeCode()) && (!address.getLogicalDeleteFlg() ));
    }

    public List<AlternateIdentifier> getAlternateIdTypeOf(Provider provider, String alternateIdOf) {
        if( (! Util.hasValue(alternateIdOf)) || (Objects.isNull(provider))  || Objects.isNull(provider.getOpvProviderAlternateId()) || provider.getOpvProviderAlternateId().isEmpty())
            return new ArrayList<>();
        return provider.getOpvProviderAlternateId()
                .stream().filter(alternateId -> alternateIdOf.equalsIgnoreCase(alternateId.getAlternateIdTypeCd()))
                .collect(Collectors.toList());
    }
    public List<AlternateIdentifier> getAlternateIdTypeOf(Provider provider, String alternateIdOf, boolean logicalDeleteFlag, boolean nonExpiredDateFlag) {
        List<AlternateIdentifier> resultList= getAlternateIdTypeOf(provider, alternateIdOf);
        if((Objects.isNull(resultList)) || (resultList.isEmpty()))
            return new ArrayList<>();
        return resultList.stream()
                .filter(alternateIdentifier -> alternateIdentifier.getLogicalDeleteFlg() == logicalDeleteFlag)
                .filter(alternateIdentifier -> Util.hasNonExpiredEndDate(alternateIdentifier.getEndDt(), this.expirationDate) == nonExpiredDateFlag)
                .collect(Collectors.toList());
    }
    public List<AlternateIdentifier> getNonVoidedAlternateIdTypeOf(Provider provider, String alternateIdOf) {
        return getAlternateIdTypeOf(provider, alternateIdOf, false, true);
    }
    public boolean hasNonVoidedAlternateIdTypeOf(Provider provider, String alternateIdOf) {
        if(  (! StringUtils.hasText(alternateIdOf))  || (Objects.isNull(provider)) )
            return false;
        List<AlternateIdentifier> result = this.getNonVoidedAlternateIdTypeOf(provider, alternateIdOf);
        return Objects.nonNull(result) && (! result.isEmpty());
    }

    public boolean isPractitionerCandidate(Provider provider) {
        if(Objects.isNull(provider))
            return false;
        Predicate<Address> addressPredicate= AddressUtil::isActive;
         Predicate<AlternateIdentifier> alternateIdentifierPredicate= AlternateIdentifierUtil::isActive;
        alternateIdentifierPredicate= alternateIdentifierPredicate.and(identifier -> AlternateIdentifierUtil.hasType(identifier, Constants.NPI1));
        alternateIdentifierPredicate= alternateIdentifierPredicate.and(identifier -> AlternateIdentifierUtil.hasMtvProviderCategoryCd(identifier,"P"));
        Predicate<Specialty> specialtyPredicate= SpecialtyUtil::isActive;
        return ProviderCategoryCd.PRACT.toString().equalsIgnoreCase(provider.getProviderCategoryCd()) &&
                ProviderUtil.hasAddress(provider, addressPredicate) &&
                ProviderUtil.hasAlternateId(provider, alternateIdentifierPredicate) &&
                ProviderUtil.hasSpecialty(provider, specialtyPredicate);
    }
    public boolean isLocationCandidate(Provider provider) {
        if(Objects.isNull(provider))
            return false;
        Predicate<Address> addressPredicate= AddressUtil::isActive;  // TODO: Revise
        addressPredicate= addressPredicate.and(address -> AddressUtil.hasType(address,Constants.A2_ADDRESS));
        addressPredicate= addressPredicate.and(AddressUtil::hasMD5Hash);

        Predicate<Specialty> specialtyPredicate= SpecialtyUtil::isActive; // TODO: Revise
        specialtyPredicate= specialtyPredicate.and(SpecialtyUtil::isPrimary);

        return StringUtils.hasText(provider.getSitePrimarySpeciality()) &&
                ProviderUtil.hasAddress(provider, addressPredicate) &&
                ProviderUtil.hasSpecialty(provider, specialtyPredicate);
    }
}
