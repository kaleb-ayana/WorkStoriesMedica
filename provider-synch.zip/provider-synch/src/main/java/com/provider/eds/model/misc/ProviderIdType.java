package com.provider.eds.model.misc;

public enum ProviderIdType {
    NPI1,
    TAX,
    MD5;
}
