package com.provider.eds.model.misc;

public class DataPersistenceException extends Exception{
    public DataPersistenceException() {
        super();
    }
    public DataPersistenceException(String message) {
        super(message);
    }
}
