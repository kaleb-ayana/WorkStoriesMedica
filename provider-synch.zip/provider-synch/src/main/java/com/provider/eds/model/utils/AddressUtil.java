package com.provider.eds.model.utils;

import com.medica.model.eds.provider.Address;
import org.springframework.util.StringUtils;

import java.util.Objects;

public class AddressUtil {

    public static boolean hasMD5Hash(Address address) {
        return Objects.isNull(address) ? false : StringUtils.hasText(address.getAddrMd5Hash());
    }

    public static boolean isActive(Address address) {
        if( Objects.isNull(address))
            return false;
        return Objects.equals(address.getLogicalDeleteFlg(), Boolean.FALSE);
    }

    public static boolean hasType(Address address, String type) {
        if(Objects.isNull(address))
            return false;
        if (!StringUtils.hasText(type))
            return address.getAddressTypeCode() == type;
        return type.trim().equalsIgnoreCase(address.getAddressTypeCode());
    }
}