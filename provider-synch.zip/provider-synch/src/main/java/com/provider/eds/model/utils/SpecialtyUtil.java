package com.provider.eds.model.utils;

import com.medica.model.eds.provider.Specialty;

import java.util.Objects;

public class SpecialtyUtil {
    public static boolean isActive(Specialty specialty) {
        return Objects.isNull(specialty) ? false : Objects.equals(specialty.getLogicalDeleteFlg(), Boolean.FALSE);
    }
    public static boolean isPrimary(Specialty specialty) {
        return Objects.isNull(specialty) || Objects.isNull(specialty.isPrimaryFlg())? false : Objects.equals(specialty.isPrimaryFlg(), Boolean.TRUE);
    }
}
