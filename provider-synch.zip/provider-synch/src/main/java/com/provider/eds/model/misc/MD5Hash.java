package com.provider.eds.model.misc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Address;
import com.provider.eds.model.utils.AddressUtil;
import com.provider.eds.service.utils.Util;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.Objects;

@Data
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class MD5Hash {
    public MD5Hash() {

    }
    public MD5Hash(Address address) {
        if(Objects.isNull(address) || (!AddressUtil.hasMD5Hash(address)))
            return;
        this.addressId = address.getMtvAddrId();
        this.md5= address.getAddrMd5Hash();
        this.effDt= address.getEffDt();
        this.endDt= address.getEndDt();
        this.logicalDeleteFlag= address.getLogicalDeleteFlg();
    }
    public String md5;
    public String addressId;
    public String effDt;
    public String endDt;
    public boolean logicalDeleteFlag;

    public boolean isMatching(MD5Hash md5Hash) {
        if(Objects.isNull(md5Hash))
            return false;
        return this.addressId.equals(md5Hash.addressId);
    }
    public void merge(MD5Hash md5Hash) {
        if(Objects.isNull(md5Hash))
            return;
        if(! this.isMatching(md5Hash))
            return;

        this.effDt= Util.getMinDate(this.effDt, md5Hash.effDt);
        this.endDt= Util.getMaxDate(this.endDt, md5Hash.endDt);
        this.logicalDeleteFlag= this.logicalDeleteFlag && md5Hash.logicalDeleteFlag;
    }
    public static MD5Hash merge(MD5Hash md5Hash1, MD5Hash md5Hash2) {
        if(Objects.isNull(md5Hash1))
            return md5Hash2;
        if(Objects.isNull(md5Hash2))
            return md5Hash1;
        if(! md5Hash1.isMatching(md5Hash2))
            return null;
        MD5Hash resultMD5= MD5Hash
                .builder()
                .md5(md5Hash1.md5)
                .addressId(md5Hash1.addressId)
                .effDt(md5Hash1.effDt)
                .endDt(md5Hash1.endDt)
                .logicalDeleteFlag(md5Hash1.logicalDeleteFlag)
                .build();
        resultMD5.merge(md5Hash2);
        return resultMD5;
    }
}
