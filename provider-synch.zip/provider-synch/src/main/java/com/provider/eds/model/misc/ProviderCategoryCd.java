package com.provider.eds.model.misc;

public enum ProviderCategoryCd {
    PAYTO,
    SITE,
    PRACT;
}
