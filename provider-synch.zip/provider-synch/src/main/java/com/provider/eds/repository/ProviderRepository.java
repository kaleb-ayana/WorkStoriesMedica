package com.provider.eds.repository;

import com.azure.spring.data.cosmos.repository.Query;
import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import com.medica.model.eds.provider.Provider;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface ProviderRepository extends ReactiveCosmosRepository<Provider, String> {

    @Query("SELECT * FROM c WHERE array_contains(@provIds, c.id, true) ")
    Flux<Provider> findAllByIdIn(Iterable<String> provIds);
}
