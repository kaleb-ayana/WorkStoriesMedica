package com.provider.eds.model.misc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.provider.eds.service.utils.Util;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.Objects;

@Data
@Builder
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Tax {
    public Tax() {

    }
    public Tax(AlternateIdentifier alternateIdentifier) {
        if(Objects.isNull(alternateIdentifier) || (! Constants.TAX.equalsIgnoreCase(alternateIdentifier.getAlternateIdTypeCd())))
            return;
        this.alternateId= alternateIdentifier.getAlternateId();
        this.effDt= alternateIdentifier.getEffDt();
        this.endDt= alternateIdentifier.getEndDt();
        this.logicalDeleteFlag= alternateIdentifier.getLogicalDeleteFlg();
    }
    public String alternateId;
    public String effDt;
    public String endDt;
    public boolean logicalDeleteFlag;

    public boolean isMatching(Tax tax) {
        if(Objects.isNull(tax))
            return false;
        return this.alternateId.equalsIgnoreCase(tax.alternateId);
    }
    public void merge(Tax tax) {
        if(Objects.isNull(tax))
            return;
        if(! this.isMatching(tax))
            return;

        this.effDt= Util.getMinDate(this.effDt, tax.effDt);
        this.endDt= Util.getMaxDate(this.endDt, tax.endDt);
        this.logicalDeleteFlag= this.logicalDeleteFlag && tax.logicalDeleteFlag;
    }
    public static Tax merge(Tax tax1, Tax tax2) {
        if(Objects.isNull(tax1))
            return tax2;
        if(Objects.isNull(tax2))
            return tax1;
        if(! tax1.isMatching(tax2))
            return null;
        Tax resultTax= Tax
                .builder()
                .alternateId(tax1.alternateId)
                .effDt(tax1.effDt)
                .endDt(tax1.endDt)
                .logicalDeleteFlag(tax1.logicalDeleteFlag)
                .build();
        resultTax.merge(tax2);
        return resultTax;
    }
}
