package com.provider.eds.model.misc;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.springframework.data.annotation.Id;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Reference {
    @Id
    @JsonProperty(value = "TRANSACTION_ID", access = JsonProperty.Access.WRITE_ONLY)
    private String transactionId;
    @JsonProperty("PROVIDER_ID")
    private String providerId;
    @JsonProperty("SOURCE_SYSTEM_CD")
    private String sourceSystemCd;
    @JsonProperty("REFERENCES")
    private Set<ReferenceEntry> references= new HashSet<>();
}