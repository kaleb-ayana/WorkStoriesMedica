package com.provider.eds.service.utils;

import com.medica.model.eds.provider.*;
import com.provider.eds.model.misc.Constants;
import com.provider.eds.model.misc.MD5Hash;
import com.provider.eds.model.misc.Tax;
import com.provider.eds.model.utils.*;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ProviderUtil {
    public static List<Panel> getPanelsWith(Provider provider, String providerId) {
        return Objects.isNull(provider) || (! StringUtils.hasText(providerId)) ? null : Util.filterList(provider.getOpvProviderPanel(), panel -> providerId.equalsIgnoreCase(panel.getMtvProviderId()));
    }

    public static boolean hasPanelsWith(Provider provider, String providerId) {
        return (!CollectionUtils.isEmpty(getPanelsWith(provider, providerId)));
    }

    public static List<Network> getNetworkDirectoriesWith(Provider provider, String providerId) {
        return Objects.isNull(provider) || (! StringUtils.hasText(providerId)) ? null :  Util.filterList(provider.getOpvProviderNetworkDirectory(), network -> providerId.equalsIgnoreCase(network.getMtvProviderId()));
    }

    public static boolean hasNetworkDirectoriesWith(Provider provider, String providerId) {
        return (!CollectionUtils.isEmpty(getNetworkDirectoriesWith(provider, providerId)));
    }

    public static List<Affiliation> getAffiliationsWith(Provider provider, String providerId) {
        return Objects.isNull(provider) || (! StringUtils.hasText(providerId)) ? null : Util.filterList(provider.getOpvProviderAffiliation(), affiliation -> providerId.equalsIgnoreCase(affiliation.getMtvAffiliateProviderId()));
    }
    public static boolean hasAffiliationsWith(Provider provider, String providerId) {
        return (!CollectionUtils.isEmpty(getAffiliationsWith(provider, providerId)));
    }

    public static List<Affiliation> getSiteAffiliationsWith(Provider provider, String providerId) {
        return Objects.isNull(provider) || (! StringUtils.hasText(providerId)) ? null :
                Util.filterList(provider.getOpvProviderAffiliation(), affiliation -> providerId.equalsIgnoreCase(affiliation.getMtvAffiliateProviderId()) &&
                        Constants.MD5.equalsIgnoreCase(affiliation.getAffiliateProviderIdType()) &&
                        "HOSP".equalsIgnoreCase(affiliation.getAffiliationType())
                        );
    }

    public static List<Affiliation> getPayToAffiliationsWith(Provider provider, String providerId) {
        return Objects.isNull(provider) || (! StringUtils.hasText(providerId)) ? null :
                Util.filterList(provider.getOpvProviderAffiliation(), affiliation -> providerId.equalsIgnoreCase(affiliation.getMtvAffiliateProviderId()) &&
                        Constants.TAX.equalsIgnoreCase(affiliation.getAffiliateProviderIdType()));
    }


    public static boolean hasSiteAffiliationsWith(Provider provider, String providerId) {
        return (!CollectionUtils.isEmpty(getSiteAffiliationsWith(provider, providerId)));
    }

    public static boolean hasPayToAffiliationsWith(Provider provider, String providerId) {
        return (!CollectionUtils.isEmpty(getPayToAffiliationsWith(provider, providerId)));
    }

    public static boolean removePanelsWith(Provider provider, String providerId) {
        if(Objects.isNull(provider))
            return false;
        if (! hasPanelsWith(provider, providerId))
            return true;
        provider.setOpvProviderPanel(provider.getOpvProviderPanel()
                .stream()
                .filter(aff -> !(providerId.equalsIgnoreCase(aff.getMtvProviderId())))
                .collect(Collectors.toList()));
        return true;
    }

    public static boolean removeNetworksWith(Provider provider, String providerId) {
        if(Objects.isNull(provider))
            return false;
        if (! hasNetworkDirectoriesWith(provider, providerId))
            return true;
        provider.setOpvProviderNetworkDirectory(provider.getOpvProviderNetworkDirectory()
                .stream()
                .filter(network -> !(providerId.equalsIgnoreCase(network.getMtvProviderId())))
                .collect(Collectors.toList()));
        return true;
    }

    public static boolean removeSiteAffiliationsWith(Provider provider, String providerId) {
        if(Objects.isNull(provider))
            return false;
        if (! hasSiteAffiliationsWith(provider, providerId))
            return true;
        provider.setOpvProviderAffiliation(provider.getOpvProviderAffiliation()
                .stream()
                .filter(aff -> !(aff.getMtvAffiliateProviderId().equalsIgnoreCase(providerId) && aff.getAffiliateProviderIdType().equalsIgnoreCase(Constants.MD5)))
                .collect(Collectors.toList()));
        return true;
    }

    public static boolean removePayToAffiliationsWith(Provider provider, String providerId) {
        if(Objects.isNull(provider) || (! StringUtils.hasText(providerId)))
            return false;
        if (! hasAffiliationsWith(provider, providerId))
            return true;
        provider.setOpvProviderAffiliation(provider.getOpvProviderAffiliation()
                .stream()
                .filter(aff -> !(aff.getMtvAffiliateProviderId().equalsIgnoreCase(providerId) && aff.getAffiliateProviderIdType().equalsIgnoreCase(Constants.TAX)))
                .collect(Collectors.toList()));
        return true;
    }

    public static boolean addAffiliation(Provider provider, List<Affiliation> affiliations) {
        if(Objects.isNull(provider))
            return false;
        if (CollectionUtils.isEmpty(affiliations))
            return true;
        if (CollectionUtils.isEmpty(provider.getOpvProviderAffiliation()))
            provider.setOpvProviderAffiliation( new ArrayList<>());

        provider.getOpvProviderAffiliation().addAll(affiliations);
        return true;
    }

    public static List<Network> getPrototypeNetworksFor(Provider provider, String providerId) {
        if (Objects.isNull(provider) || (! StringUtils.hasText(providerId)) || CollectionUtils.isEmpty(getNetworkDirectoriesWith(provider, providerId)))
            return null;
        List<Network> resultList = new ArrayList<>();
        List<Network> providerNetworkList = getNetworkDirectoriesWith(provider, providerId);
        for (Network network : providerNetworkList) {
            if (resultList.stream().anyMatch(net -> NetworkUtil.isMatching(net, network)))
                continue;
            resultList.add(network);
        }
        return resultList;
    }

    public static List<Panel> getPrototypePanelsFor(Provider provider, String providerId) {
        if (Objects.isNull(provider) || (! StringUtils.hasText(providerId)) || CollectionUtils.isEmpty(getPanelsWith(provider, providerId)))
            return null;
        List<Panel> resultList = new ArrayList<>();
        List<Panel> providerPanelList = getPanelsWith(provider, providerId);
        for (Panel panel : providerPanelList) {
            if (resultList.stream().anyMatch(pan -> PanelUtil.isMatching(pan,panel)))
                continue;
            resultList.add(panel);
        }
        return resultList;
    }

    public static List<Affiliation> getPrototypePayToAffiliationsFor(Provider provider, String providerId) {
        if (Objects.isNull(provider) || (! StringUtils.hasText(providerId)) || CollectionUtils.isEmpty(getPayToAffiliationsWith(provider, providerId)))
            return null;
        List<Affiliation> resultList = new ArrayList<>();
        List<Affiliation> providerAffiliationList = getPayToAffiliationsWith(provider, providerId);
        for (Affiliation affiliation : providerAffiliationList) {
            if (resultList.stream().anyMatch(aff -> AffiliationUtil.isMatching(aff, affiliation)))
                continue;
            resultList.add(affiliation);
        }
        return resultList;
    }

    public static List<Affiliation> getPrototypeSiteAffiliationsFor(Provider provider, String providerId) {
        if (Objects.isNull(provider) || (! StringUtils.hasText(providerId)) || CollectionUtils.isEmpty(getSiteAffiliationsWith(provider, providerId)))
            return null;
        List<Affiliation> resultList = new ArrayList<>();
        List<Affiliation> providerAffiliationList = getSiteAffiliationsWith(provider, providerId);
        for (Affiliation affiliation : providerAffiliationList) {
            if (resultList.stream().anyMatch(aff -> AffiliationUtil.isMatching(aff, affiliation)))
                continue;
            resultList.add(affiliation);
        }
        return resultList;
    }

    public static List<MD5Hash> getMD5Hashes(Provider provider) {
        if (Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return null;
        return provider.getOpvProviderAddress()
                .stream()
                .filter(AddressUtil::hasMD5Hash)
                .map(MD5Hash::new)
                .collect(Collectors.toList());
    }

    public static List<MD5Hash> getAddressMatchedMD5Hashes(Provider provider) {
        if (Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return null;
        List<MD5Hash> md5HashList = provider.getOpvProviderAddress()
                .stream()
                .filter(AddressUtil::hasMD5Hash)
                .map(MD5Hash::new)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(md5HashList) || md5HashList.size() < 2)
            return md5HashList;
        List<MD5Hash> distinctMd5List = new ArrayList<>();
        for (MD5Hash md5 : md5HashList) {
            MD5Hash matchingMd5 = getMatchingMD5Hash(md5, distinctMd5List);
            if (Objects.isNull(matchingMd5)) {
                distinctMd5List.add(md5);
                continue;
            }
            matchingMd5.merge(md5);
        }
        return distinctMd5List;
    }

    public static List<Tax> getTaxIds(Provider provider) {
        if(Objects.isNull(provider))
            return null;
        if (CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()))
            return null;
        List<Tax> taxList = provider.getOpvProviderAlternateId()
                .stream()
                .filter(AlternateIdentifierUtil::isTaxEntity)
                .map(Tax::new)
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(taxList) || taxList.size() < 2)
            return taxList;
        List<Tax> distinctTaxList = new ArrayList<>();
        for (Tax tax : taxList) {
            Tax matchingTax = getMatchingTax( tax, distinctTaxList);
            if (Objects.isNull(matchingTax)) {
                distinctTaxList.add(tax);
                continue;
            }
            matchingTax.merge(tax);
        }
        return distinctTaxList;
    }

    private static Tax getMatchingTax( Tax tax, List<Tax> list) {
        if (CollectionUtils.isEmpty(list))
            return null;
        for (Tax tx : list)
            if (tax.isMatching(tx))
                return tx;
        return null;
    }

    private static MD5Hash getMatchingMD5Hash(MD5Hash md5, List<MD5Hash> list) {
        if (CollectionUtils.isEmpty(list))
            return null;
        for (MD5Hash tx : list)
            if (md5.isMatching(tx))
                return tx;
        return null;
    }

    public static void addPanels(Provider provider, List<Panel> panels) {
        if (Objects.isNull(provider) || CollectionUtils.isEmpty(panels))
            return;
        if (CollectionUtils.isEmpty(provider.getOpvProviderPanel()))
            provider.setOpvProviderPanel(new ArrayList<>());
        provider.getOpvProviderPanel().addAll(panels);
    }

    public static void addNetworks(Provider provider, List<Network> networks) {
        if (Objects.isNull(provider) || CollectionUtils.isEmpty(networks))
            return;
        if (CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory()))
            provider.setOpvProviderNetworkDirectory(new ArrayList<>());
        provider.getOpvProviderNetworkDirectory().addAll(networks);
    }
    public static boolean hasProperResynchTag(Provider provider) {
        if(Objects.isNull(provider))
            return false;
        boolean flag = true;
        if (!CollectionUtils.isEmpty(provider.getOpvProviderAffiliation()))
            flag = flag && provider.getOpvProviderAffiliation().stream().noneMatch(affiliation -> ! AffiliationUtil.hasProperResynchTag(affiliation));
        if (!flag)
            return flag;
        if(! CollectionUtils.isEmpty(provider.getOpvProviderPanel()))
            flag= flag && provider.getOpvProviderPanel().stream().noneMatch(panel -> !PanelUtil.hasProperResynchTag(panel));
        if(! flag)
            return flag;

        if (!CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory()))
            flag = flag && provider.getOpvProviderNetworkDirectory().stream().noneMatch(network -> ! NetworkUtil.hasProperResynchTag(network));
        return flag;
    }

    public static boolean hasAddress(Provider provider, Predicate<Address> predicate) {
        if (Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()) || Objects.isNull(predicate))
            return false;
        return Util.hasList(provider.getOpvProviderAddress(), predicate);
    }

    public static boolean hasSpecialty(Provider provider, Predicate<Specialty> predicate) {
        if (Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderSpecialty()) || Objects.isNull(predicate))
            return false;
        return Util.hasList(provider.getOpvProviderSpecialty(), predicate);
    }

    public static boolean hasAlternateId(Provider provider, Predicate<AlternateIdentifier> predicate) {
        if (Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()) || Objects.isNull(predicate))
            return false;
        return Util.hasList(provider.getOpvProviderAlternateId(), predicate);
    }

    public static boolean hasRelatedMtvProvider(Provider provider, String providerId) {
        if(Objects.isNull(provider) || (! StringUtils.hasText(providerId)))
            return false;
        boolean flag=false;
        if(! CollectionUtils.isEmpty(provider.getOpvProviderPanel()))
            flag = flag || hasPanelsWith(provider, providerId);
        if(flag)
            return flag;
        if(! CollectionUtils.isEmpty(provider.getOpvProviderAffiliation()))
            flag = flag || hasAffiliationsWith(provider, providerId);
        if(flag)
            return flag;
        if(! CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory()))
            flag = flag || hasNetworkDirectoriesWith(provider, providerId);
        return flag;
    }
}
