package com.provider.eds.model.utils;

import com.medica.model.eds.provider.AlternateIdentifier;
import com.provider.eds.model.misc.Constants;
import org.springframework.util.StringUtils;

import java.util.Objects;

public class AlternateIdentifierUtil {
    public static boolean isTaxEntity(AlternateIdentifier alternateIdentifier) {
        return hasType(alternateIdentifier, Constants.TAX);
    }

    public static boolean isActive(AlternateIdentifier alternateIdentifier) {
        if( Objects.isNull(alternateIdentifier))
            return false;
        return Objects.isNull(alternateIdentifier.getLogicalDeleteFlg()) ? true : Objects.equals(alternateIdentifier.getLogicalDeleteFlg() , Boolean.FALSE);
    }

    public static boolean hasType(AlternateIdentifier alternateIdentifier, String type) {
        if(Objects.isNull(alternateIdentifier))
            return false;
        if(! StringUtils.hasText(type) )
            return alternateIdentifier.getAlternateIdTypeCd() == type;
        return type.trim().equalsIgnoreCase(alternateIdentifier.getAlternateIdTypeCd());
    }
    public static boolean hasMtvProviderCategoryCd(AlternateIdentifier alternateIdentifier, String category) {
        if(Objects.isNull(alternateIdentifier))
            return false;
        if(! StringUtils.hasText(category) )
            return alternateIdentifier.getMtvProviderCategoryCd() == category;
        return category.trim().equalsIgnoreCase(alternateIdentifier.getMtvProviderCategoryCd());
    }
}
