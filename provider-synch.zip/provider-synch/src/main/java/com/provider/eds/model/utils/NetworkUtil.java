package com.provider.eds.model.utils;

import com.medica.model.eds.provider.Network;
import org.springframework.util.StringUtils;

import java.util.Objects;

public class NetworkUtil {
    public static boolean isMatching(Network networkOne, Network networkTwo) {
        if(Objects.isNull(networkOne))
            return networkOne == networkTwo;
        if(Objects.isNull(networkTwo))
            return false;
        return Objects.equals(networkOne.getMtvProviderId(), networkTwo.getMtvProviderId()) &&
                Objects.equals(networkOne.getAddressId(), networkTwo.getAddressId()) &&
                Objects.equals(networkOne.getEffDt(), networkTwo.getEffDt());

    }
    public static boolean hasProperResynchTag(Network network) {
        return Objects.isNull(network) ? false : StringUtils.hasText(network.getResynchTag());
    }
}
