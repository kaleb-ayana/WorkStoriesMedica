package com.provider.eds.model.misc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@Getter
@Setter
@ToString
public class ReferenceEntry {
    @JsonProperty("PROVIDER_ID")
    private String providerId;
    @JsonProperty("SOURCE_SYSTEM_CD")
    private String sourceSystemCd;
    @JsonProperty("ACTIVE_STATUS")
    private boolean isActive=true;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReferenceEntry that = (ReferenceEntry) o;
        return Objects.equals(providerId, that.providerId) && Objects.equals(sourceSystemCd, that.sourceSystemCd);
    }

    @Override
    public int hashCode() {
        return Objects.hash(providerId, sourceSystemCd);
    }
}