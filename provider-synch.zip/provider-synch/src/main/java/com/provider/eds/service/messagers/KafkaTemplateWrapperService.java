package com.provider.eds.service.messagers;

import com.medica.model.eds.common.ProviderNotification;
import com.provider.eds.config.GsonCustomBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

@Service
@Slf4j
public class KafkaTemplateWrapperService {

    @Autowired
    @Qualifier("kafkaTemplateProviderNotification")
    public KafkaTemplate<String, String> kafkaTemplateProviderNotification;
    
    @Value(value = "${topics.provider.notification.outbound}")
    private String providerNotificationTopic;

    public ListenableFuture produceProviderNotificationTopicMessage(ProviderNotification provider, String topic) {
        return kafkaTemplateProviderNotification.send( topic, provider.getPROVIDER_ID(), GsonCustomBuilder.getGsonCustomAdapter().toJson(provider, ProviderNotification.class));
    }

    public ListenableFuture produceProviderNotificationTopicMessage(ProviderNotification provider) {
        return this.produceProviderNotificationTopicMessage(provider, providerNotificationTopic);
    }

}
