package com.provider.eds.model.misc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.Instant;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErroredRecord {
    private String providerId;
    private String timestamp;

    public static ErroredRecord create(String providerId, String timestamp) {
        ErroredRecord record= new ErroredRecord();
        record.setProviderId(providerId);
        record.setTimestamp(timestamp);
        return record;
    }
    public static ErroredRecord create(String providerId) {
        ErroredRecord record= new ErroredRecord();
        record.setProviderId(providerId);
        record.setTimestamp(Timestamp.from(Instant.now()).toString());
        return record;
    }
}
