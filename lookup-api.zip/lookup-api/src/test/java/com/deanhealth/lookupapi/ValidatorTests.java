package com.deanhealth.lookupapi;

import com.deanhealth.lookupapi.model.CodesetRef;
import com.deanhealth.lookupapi.service.Validator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ValidatorTests {

    @Autowired
    private Validator validator;

    @Test
    public void testValidator() {
        assertThat(this.validator.isValidOrNull(null)).isTrue();
        assertThat(this.validator.isValidOrNull(this.getCodesetRef())).isTrue();
        CodesetRef codesetRef= new CodesetRef();
        assertThat(this.validator.isValidOrNull(codesetRef)).isFalse();
    }

    private CodesetRef getCodesetRef() {
        CodesetRef codesetRef= new CodesetRef();
        codesetRef.setOCM_CDSET_REFERENCE_SK("7764");
        codesetRef.setCODESET_NAME("PROVIDER_SPECIALTY");
        codesetRef.setDESCR("OTOLARYNGOLOGY");
        codesetRef.setCD_VALUE("04");
        codesetRef.setINSERT_DTTM("2020-10-09 09:20:35.000000000");
        codesetRef.setINSERT_PROCESS_ID("DGARGG");
        codesetRef.setUPDATE_DTTM("2020-10-09 09:20:35.000000000");
        codesetRef.setUPDATE_PROCESS_ID("DGARGG");
        codesetRef.setSOURCE_SYSTEM_CD("MTV");
        codesetRef.setSTANDARDIZED_CD_VALUE("04");
        codesetRef.setSTANDARDIZED_DESCR("OTOLARYNGOLOGY");
        codesetRef.setLOGICAL_DELETE_FLG(false);
        return codesetRef;
    }

}
