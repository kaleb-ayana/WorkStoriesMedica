package com.deanhealth.lookupapi;

import com.deanhealth.lookupapi.model.CodesetRef;
import com.deanhealth.lookupapi.model.CodesetRefFire;
import com.deanhealth.lookupapi.repository.CodesetRepository;
import com.deanhealth.lookupapi.service.CodesetService;
import com.deanhealth.lookupapi.service.Validator;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.TestInputTopic;
import org.apache.kafka.streams.TopologyTestDriver;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.serializer.JsonSerde;
import reactor.core.publisher.Mono;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CodesetServiceTest {

    @InjectMocks
    CodesetService codesetService;

    @Mock
    private Validator validator;

    @Mock
    private CodesetRepository codesetRepository;

    @Test
    void testProcessCodeset() {
        final StreamsBuilder streamsBuilder = new StreamsBuilder();
        KStream<String, CodesetRefFire> codesetFireKStream;
        CodesetRefFire codesetRefFire = CodesetRefFire.builder()
                .opType("I")
                .after(CodesetRef.builder()
                        .CD_VALUE("A0")
                        .DESCR("Pediatrics")
                        .LOGICAL_DELETE_FLG(false)
                        .STANDARDIZED_CD_VALUE("A0-0001")
                        .build())
                .build();
        codesetFireKStream = streamsBuilder.stream("fire.provider.ods.common.xref.temp",Consumed.with(Serdes.String(), new JsonSerde<>(CodesetRefFire.class)));

        codesetService.processCodesetEvent(codesetFireKStream);

        try (final TopologyTestDriver testDriver = new TopologyTestDriver(streamsBuilder.build())) {
            final TestInputTopic<String, CodesetRefFire> inputTopic =
                    testDriver.createInputTopic("fire.provider.ods.common.xref.temp",
                            Serdes.String().serializer(),
                            new JsonSerde<>(CodesetRefFire.class).serializer());
            inputTopic.pipeInput("A0", codesetRefFire);
        }
    }

    @Test
    public void testFindById() {
        Mono<CodesetRef> refs= Mono.just(this.getCodesetRef());
        when(this.codesetRepository.findById("id")).thenReturn(Mono.just(this.getCodesetRef()));//.thenReturn(Mono.just(this.getCodesetRef()));

        assertThat(this.codesetService.getById("id").getOCM_CDSET_REFERENCE_SK()).isEqualTo("7764");
    }

/*    @Test
    public void testPersistMethod() {

        when(this.codesetRepository.save(any())).thenReturn(Mono.just(this.getCodesetRef()));
        when(this.validator.isValid(any())).thenReturn(true);
//        assertThat(this.codesetService.persist(this.getInsertionCodesetFire())).isEqualTo(true);

        CodesetRefFire fire= new CodesetRefFire();
        assertThat(this.codesetService.persist(fire)).isEqualTo(false);
    }*/


    private CodesetRef getCodesetRef() {
        CodesetRef codesetRef= new CodesetRef();
        codesetRef.setOCM_CDSET_REFERENCE_SK("7764");
        codesetRef.setCODESET_NAME("PROVIDER_SPECIALTY");
        codesetRef.setDESCR("OTOLARYNGOLOGY");
        codesetRef.setCD_VALUE("04");
        codesetRef.setINSERT_DTTM("2020-10-09 09:20:35.000000000");
        codesetRef.setINSERT_PROCESS_ID("DGARGG");
        codesetRef.setUPDATE_DTTM("2020-10-09 09:20:35.000000000");
        codesetRef.setUPDATE_PROCESS_ID("DGARGG");
        codesetRef.setSOURCE_SYSTEM_CD("MTV");
        codesetRef.setSTANDARDIZED_CD_VALUE("04");
        codesetRef.setSTANDARDIZED_DESCR("OTOLARYNGOLOGY");
        codesetRef.setLOGICAL_DELETE_FLG(false);
        return codesetRef;
    }
    private CodesetRefFire getUpdateCodesetFire() {
        CodesetRefFire fire= new CodesetRefFire();
        fire.setTable("ODS_COMMON.OCM_CODESET_REFERENCE");
        fire.setOpType("U");
        fire.setOpTs("2022-09-09 09:16:34.000000");
        fire.setCurrentTs("2022-09-09T09:16:39.124000");
        fire.setPos("00000020850375314304");

        CodesetRef before= this.getCodesetRef();
        fire.setBefore(before);
        CodesetRef after= new CodesetRef();
        after.setLOGICAL_DELETE_FLG(true);
        fire.setAfter(after);
        return fire;
    }
    private CodesetRefFire getDeletionCodesetFire() {
        CodesetRefFire fire= new CodesetRefFire();
        fire.setTable("ODS_COMMON.OCM_CODESET_REFERENCE");
        fire.setOpType("D");
        fire.setOpTs("2022-09-09 09:16:34.000000");
        fire.setCurrentTs("2022-09-09T09:16:39.124000");
        fire.setPos("00000020850375314304");

        CodesetRef before= this.getCodesetRef();
        fire.setBefore(before);
        return fire;
    }
    private CodesetRefFire getInsertionCodesetFire() {
        CodesetRefFire fire= new CodesetRefFire();
        fire.setTable("ODS_COMMON.OCM_CODESET_REFERENCE");
        fire.setTable("");
        fire.setOpType("U");
        fire.setOpTs("2022-09-09 09:16:34.000000");
        fire.setCurrentTs("2022-09-09T09:16:39.124000");
        fire.setPos("00000020850375314304");
        CodesetRef after= new CodesetRef();
        fire.setAfter(after);
        return fire;
    }
}