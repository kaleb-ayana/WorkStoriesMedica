package com.deanhealth.lookupapi;

import com.deanhealth.lookupapi.model.XRef;
import com.deanhealth.lookupapi.model.XRefFire;
import com.deanhealth.lookupapi.repository.XRefRepository;
import com.deanhealth.lookupapi.service.Validator;
import com.deanhealth.lookupapi.service.XRefService;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.TestInputTopic;
import org.apache.kafka.streams.TopologyTestDriver;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.springframework.kafka.support.serializer.JsonSerde;
import reactor.core.publisher.Mono;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static reactor.core.publisher.Mono.when;

@ExtendWith(MockitoExtension.class)
class XRefServiceTest {

    @InjectMocks
    XRefService xRefService;

    @Mock
    XRefRepository refRepository;

    @Mock
    Validator validator;

    @Test
    public void testfindById() {
//        when(this.refRepository.findById(anyString())).thenReturn(Mono.just(this.getXRef()));
//        assertThat(xRefService.getXRef("SomeID")).isNotNull();

    }
    @Test
    void testProcessCodeset() {
        final StreamsBuilder streamsBuilder = new StreamsBuilder();
        KStream<String, XRefFire> xRefFireKStream;
        XRefFire xRefFire = XRefFire.builder()
                .opType("I")
                .after(XRef.builder()
                        .SOURCE_VALUE_1("A0")
                        .SOURCE_VALUE_1_TYPE("Pediatrics")
                        .LOGICAL_DELETE_FLG(false)
                        .build())
                .build();
        xRefFireKStream = streamsBuilder.stream("fire.provider.ods.common.xref.temp",Consumed.with(Serdes.String(), new JsonSerde<>(XRefFire.class)));

        xRefService.processXRef(xRefFireKStream);

        try (final TopologyTestDriver testDriver = new TopologyTestDriver(streamsBuilder.build())) {
            final TestInputTopic<String, XRefFire> inputTopic =
                    testDriver.createInputTopic("fire.provider.ods.common.xref.temp",
                            Serdes.String().serializer(),
                            new JsonSerde<>(XRefFire.class).serializer());
            inputTopic.pipeInput("A0", xRefFire);
        }
    }

    private XRef getXRef() {
        XRef xRef= new XRef();
        xRef.setId("1234545342444354324543");
        xRef.setDESTINATION_SYSTEM_CD("EDS");
        xRef.setSOURCE_SYSTEM_CD("MTV");
        xRef.setSOURCE_VALUE_1_TYPE("DEST");
        xRef.setSOURCE_VALUE_1("V1");

        xRef.setDESTINATION_VALUE_1_TYPE("SP");
        xRef.setDESTINATION_VALUE_1("DEST-1");

        xRef.setDESTINATION_VALUE_2_TYPE("SP");
        xRef.setDESTINATION_VALUE_2("DEST-2");

        xRef.setDESTINATION_VALUE_3_TYPE("SP");
        xRef.setDESTINATION_VALUE_3("DEST-3");

        xRef.setDESTINATION_VALUE_4_TYPE("SP");
        xRef.setDESTINATION_VALUE_4("DEST-4");

        xRef.setDESTINATION_VALUE_5_TYPE("SP");
        xRef.setDESTINATION_VALUE_5("DEST-5");

        xRef.setDESTINATION_VALUE_5_TYPE("SP");
        xRef.setDESTINATION_VALUE_5("DEST-6");

        xRef.setDESTINATION_VALUE_5_TYPE("SP");
        xRef.setDESTINATION_VALUE_5("DEST-7");

        xRef.setDESTINATION_VALUE_5_TYPE("SP");
        xRef.setDESTINATION_VALUE_5("DEST-8");

        xRef.setDESTINATION_VALUE_5_TYPE("SP");
        xRef.setDESTINATION_VALUE_5("DEST-9");

        xRef.setDESTINATION_VALUE_5_TYPE("SP");
        xRef.setDESTINATION_VALUE_5("DEST-10");

        return xRef;
    }
}