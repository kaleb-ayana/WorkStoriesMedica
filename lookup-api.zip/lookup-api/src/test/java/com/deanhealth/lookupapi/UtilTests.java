package com.deanhealth.lookupapi;

import com.deanhealth.lookupapi.util.Util;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

public class UtilTests {

    @Test
    public void testDate() {
        assertThat(Util.getISO8601(null)).isNull();
        assertThat(Util.getISO8601("78")).isEqualTo("78");
        assertThat(Util.getISO8601("2020-12-31 00:00:00")).isEqualTo("2020-12-31T00:00:00.0000000Z");

        assertThat((Util.upperCaseOrNull(null))).isNull();
        assertThat((Util.upperCaseOrNull("NULL"))).isEqualTo("NULL");
        assertThat((Util.upperCaseOrNull("null"))).isEqualTo("NULL");
        assertThat((Util.upperCaseOrNull(""))).isEqualTo("");
    }

}
