package com.deanhealth.lookupapi.util;

public class Constants {
    public static final String SYMFACT = "SYMFACT";
    public static String MTV = "MTV";
    public static String EDS = "EDS";
    public static String XREF_CD_TYPE_SPECIALTY_CD = "SPECIALTY_CD";
    public static String XREF_CD_TYPE_DEGREE = "DEGREE_CD";
    public static String XREF_CD_TYPE_LANGUAGE = "LANGUAGE_CD";

    public static final String XREF_CD_TYPE_DEGREE_N_SPEC = "DEGREE_N_SPEC";

    public static String CODESET_NAM_SPECIALTY = "PROVIDER_SPECIALTY";
    public static final String X_REF_TYPE_SPECiALTY = "EDS_PROVIDER_PRIMARY_SPECIALTY_SITE_KEY";
    public static final String X_REF_TYPE_PRACTITIONER_SPECiALTY = "PRACTITIONER_SPECIALTY";
    public static final String X_REF_TYPE_LANGUAGE = "PROVIDER_LANGUAGE";
    public static final String X_REF_TYPE_DEGREE = "PROVIDER_DEGREE";

    public static final String X_REF_TYPE_EDS_PRACTITIONER_SPECIALTY = "EDS_PRACTITIONER_SPECIALTY";

}
