package com.deanhealth.lookupapi.model;

import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
public class LookUpBulkRequest {
    private List<String> practitionerSpecialties;
    private List<String> edsPractitionerSpecialties;
    private List<String> specialties;
    private List<String> degreeCodes;
    private List<String> languages;
    private List<String> countyCodes;

    public void addPractitonerSpecialty(String practitionerSpecialtyCd) {
        if(Objects.isNull(this.practitionerSpecialties))
            practitionerSpecialties= new ArrayList<>();
        practitionerSpecialties.add(practitionerSpecialtyCd);
    }

    public void addEdsPractitonerSpecialty(String degreeNSpec) {
        if(Objects.isNull(this.edsPractitionerSpecialties))
            edsPractitionerSpecialties= new ArrayList<>();
        edsPractitionerSpecialties.add(degreeNSpec);
    }
    public void addSpecialty(String specialtyCd) {
        if(Objects.isNull(this.specialties))
            specialties= new ArrayList<>();
        specialties.add(specialtyCd);
    }
    public void addDegree(String degreeCd) {
        if(Objects.isNull(this.degreeCodes))
            degreeCodes= new ArrayList<>();
        degreeCodes.add(degreeCd);
    }
    public void addLanguage(String languageCd) {
        if(Objects.isNull(this.languages))
            languages= new ArrayList<>();
        languages.add(languageCd);
    }
    public void addCounty(String countyCodeCd) {
        if(Objects.isNull(this.countyCodes))
            countyCodes= new ArrayList<>();
        countyCodes.add(countyCodeCd);
    }
    public void addSpecialties(List<String> specialtyCodes) {
        if(CollectionUtils.isEmpty(specialtyCodes))
            return;
        if(CollectionUtils.isEmpty(this.specialties)) {
            this.specialties = specialtyCodes;
            return;
        }
        specialties.addAll(specialtyCodes);
    }
    public void addDegrees(List<String> degreeCodes) {
        if(CollectionUtils.isEmpty(degreeCodes))
            return;
        if(CollectionUtils.isEmpty(this.degreeCodes)) {
            this.degreeCodes = degreeCodes;
            return;
        }
        this.degreeCodes.addAll(degreeCodes);
    }
    public void addLanguages(List<String> languageCodes) {
        if(CollectionUtils.isEmpty(languageCodes))
            return;
        if(CollectionUtils.isEmpty(this.languages)) {
            this.languages = languageCodes;
            return;
        }
        this.languages.addAll(languageCodes);

    }
    public void addCounties(List<String> countyCodes) {
        if(CollectionUtils.isEmpty(countyCodes))
            return;
        if(CollectionUtils.isEmpty(this.countyCodes)) {
            this.countyCodes = countyCodes;
            return;
        }
        this.countyCodes.addAll(countyCodes);
    }

    public boolean hasPayload() {
        return (! CollectionUtils.isEmpty(this.degreeCodes)) ||
                (! CollectionUtils.isEmpty(this.specialties)) ||
                (! CollectionUtils.isEmpty(this.practitionerSpecialties)) ||
                (! CollectionUtils.isEmpty(this.edsPractitionerSpecialties)) ||
                (! CollectionUtils.isEmpty(this.languages))   ||
                (! CollectionUtils.isEmpty(this.countyCodes)) ;
    }

}
