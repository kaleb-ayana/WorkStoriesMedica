package com.deanhealth.lookupapi.model;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.deanhealth.lookupapi.config.constraints.MandatoryDateTime;
import com.deanhealth.lookupapi.util.Util;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.apache.commons.lang3.builder.ToStringSummary;
import org.springframework.util.DigestUtils;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Container(containerName = "XRef")
@ToString
//@Container(containerName = "Provider")
public class XRef {
    @NotBlank(message = "xRef.id can not be blank.")
    @JsonProperty("id")
    private String id;

    @NotBlank(message = "XREF.XREF_TYPE can not be blank.")
    @JsonProperty("XREF_TYPE")
    private String XREF_TYPE;

    @NotBlank(message = "xRef.SOURCE_SYSTEM_CD can not be blank.")
    @JsonProperty("SOURCE_SYSTEM_CD")
    private String SOURCE_SYSTEM_CD;

    @NotBlank(message = "xRef.DESTINATION_SYSTEM_CD can not be blank.")
    @JsonProperty("DESTINATION_SYSTEM_CD")
    private String DESTINATION_SYSTEM_CD;

    @NotBlank(message = "xRef.EFF_DT can not be blank.")
//    @MandatoryDate(message = "XREF.EFF_DT is null or improperly formatted date.")
    @JsonProperty("EFF_DT")
    private String EFF_DT;

    @NotBlank(message = "xRef.END_DT can not be blank.")
//    @MandatoryDate(message = "XREF.END_DT is null or improperly formatted date.")
    @JsonProperty("END_DT")
    private String END_DT;

    @NotBlank(message = "xRef.SOURCE_VALUE_1_TYPE can not be blank.")
    @JsonProperty("SOURCE_VALUE_1_TYPE")
    private String SOURCE_VALUE_1_TYPE;

    @NotBlank(message = "xRef.SOURCE_VALUE_1 can not be blank.")
    @JsonProperty("SOURCE_VALUE_1")
    private String SOURCE_VALUE_1;

    @JsonProperty("SOURCE_VALUE_2_TYPE")
    private String SOURCE_VALUE_2_TYPE;

    @JsonProperty("SOURCE_VALUE_2")
    private String SOURCE_VALUE_2;

    @JsonProperty("SOURCE_VALUE_3_TYPE")
    private String SOURCE_VALUE_3_TYPE;

    @JsonProperty("SOURCE_VALUE_3")
    private String SOURCE_VALUE_3;

    @JsonProperty("SOURCE_VALUE_4_TYPE")
    private String SOURCE_VALUE_4_TYPE;

    @JsonProperty("SOURCE_VALUE_4")
    private String SOURCE_VALUE_4;

    @JsonProperty("SOURCE_VALUE_5_TYPE")
    private String SOURCE_VALUE_5_TYPE;

    @JsonProperty("SOURCE_VALUE_5")
    private String SOURCE_VALUE_5;

    @JsonProperty("SOURCE_VALUE_6_TYPE")
    private String SOURCE_VALUE_6_TYPE;

    @JsonProperty("SOURCE_VALUE_6")
    private String SOURCE_VALUE_6;

    @JsonProperty("SOURCE_VALUE_7_TYPE")
    private String SOURCE_VALUE_7_TYPE;

    @JsonProperty("SOURCE_VALUE_7")
    private String SOURCE_VALUE_7;

    @JsonProperty("SOURCE_VALUE_8_TYPE")
    private String SOURCE_VALUE_8_TYPE;

    @JsonProperty("SOURCE_VALUE_8")
    private String SOURCE_VALUE_8;

    @JsonProperty("SOURCE_VALUE_9_TYPE")
    private String SOURCE_VALUE_9_TYPE;

    @JsonProperty("SOURCE_VALUE_9")
    private String SOURCE_VALUE_9;

    @JsonProperty("SOURCE_VALUE_10_TYPE")
    private String SOURCE_VALUE_10_TYPE;

    @JsonProperty("SOURCE_VALUE_10")
    private String SOURCE_VALUE_10;

    @NotBlank(message = "xRef.DESTINATION_VALUE_1_TYPE can not be blank.")
    @JsonProperty("DESTINATION_VALUE_1_TYPE")
    private String DESTINATION_VALUE_1_TYPE;

    @NotBlank(message = "xRef.DESTINATION_VALUE_1 can not be blank.")
    @JsonProperty("DESTINATION_VALUE_1")
    private String DESTINATION_VALUE_1;

    @JsonProperty("DESTINATION_VALUE_2_TYPE")
    private String DESTINATION_VALUE_2_TYPE;

    @JsonProperty("DESTINATION_VALUE_2")
    private String DESTINATION_VALUE_2;

    @JsonProperty("DESTINATION_VALUE_3_TYPE")
    private String DESTINATION_VALUE_3_TYPE;

    @JsonProperty("DESTINATION_VALUE_3")
    private String DESTINATION_VALUE_3;

    @JsonProperty("DESTINATION_VALUE_4_TYPE")
    private String DESTINATION_VALUE_4_TYPE;

    @JsonProperty("DESTINATION_VALUE_4")
    private String DESTINATION_VALUE_4;

    @JsonProperty("DESTINATION_VALUE_5_TYPE")
    private String DESTINATION_VALUE_5_TYPE;

    @JsonProperty("DESTINATION_VALUE_5")
    private String DESTINATION_VALUE_5;

    @JsonProperty("DESTINATION_VALUE_6_TYPE")
    private String destinationValue6Type;

    @JsonProperty("DESTINATION_VALUE_6")
    private String DESTINATION_VALUE_6;

    @JsonProperty("DESTINATION_VALUE_7_TYPE")
    private String DESTINATION_VALUE_7_TYPE;

    @JsonProperty("DESTINATION_VALUE_7")
    private String DESTINATION_VALUE_7;

    @JsonProperty("DESTINATION_VALUE_8_TYPE")
    private String DESTINATION_VALUE_8_TYPE;

    @JsonProperty("DESTINATION_VALUE_8")
    private String DESTINATION_VALUE_8;

    @JsonProperty("DESTINATION_VALUE_9_TYPE")
    private String destinationValue9Type;

    @JsonProperty("DESTINATION_VALUE_9")
    private String DESTINATION_VALUE_9;

    @JsonProperty("DESTINATION_VALUE_10_TYPE")
    private String DESTINATION_VALUE_10_TYPE;

    @JsonProperty("DESTINATION_VALUE_10")
    private String DESTINATION_VALUE_10;

    @MandatoryDateTime(message = "xRef.INSERT_DTTM is null or improperly formatted date.")
    @JsonProperty("INSERT_DTTM")
    private String INSERT_DTTM;

    @NotBlank(message = "xRef.INSERT_PROCESS_ID can not be blank.")
    @JsonProperty("INSERT_PROCESS_ID")
    private String INSERT_PROCESS_ID;

    @MandatoryDateTime(message = "xRef.INSERT_DTTM is null or improperly formatted date.")
    @JsonProperty("UPDATE_DTTM")
    private String UPDATE_DTTM;

    @NotBlank(message = "xRef.UPDATE_PROCESS_ID can not be blank.")
    @JsonProperty("UPDATE_PROCESS_ID")
    private String UPDATE_PROCESS_ID;

    @JsonProperty("LOGICAL_DELETE_FLG")
    private boolean LOGICAL_DELETE_FLG;

    @JsonIgnore
    public void decorateDate() {
        this.setEFF_DT(Util.getISO8601(this.getEFF_DT()));
        this.setEND_DT(Util.getISO8601(this.getEND_DT()));
    }
    public void buildId() {
        this.decorateDate();
        this.setId(this.computeMd5());
    }
    private String computeMd5 () {
        StringBuilder combinedString= new StringBuilder();
        combinedString.append(this.getXREF_TYPE());
        combinedString.append(this.getSOURCE_SYSTEM_CD());
        combinedString.append(this.getDESTINATION_SYSTEM_CD());
        combinedString.append(this.getEFF_DT());
        combinedString.append(this.getSOURCE_VALUE_1_TYPE());
        combinedString.append(this.getSOURCE_VALUE_1());
        return DigestUtils.md5DigestAsHex(combinedString.toString().getBytes()).toUpperCase();
    }
}