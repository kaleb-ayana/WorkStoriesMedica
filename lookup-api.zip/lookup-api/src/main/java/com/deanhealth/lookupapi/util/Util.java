package com.deanhealth.lookupapi.util;

import java.time.LocalDate;
import java.util.Objects;

public class Util {
    public static String getISO8601(String dateString) {
        try {
            if(Objects.isNull(dateString))
                return null;
            return dateString.length() < 9 ? dateString : dateString.substring(0, 10) + "T00:00:00.0000000Z";
        } catch (Exception e) {
            return null;
        }
    }
    public static String upperCaseOrNull(String value) {
        return Objects.nonNull(value) && (! value.isBlank()) ? value.toUpperCase().trim() : value;
    }

/*    public static String matchesDate(String date) {
        if(Objects.isNull(date) || date.isBlank())
            return null;
        date= date.length() < 9 ? date : date.substring(0, 10);
        if(! date.matches("\\d{4}-\\d{2}-\\d{2}") )
            return getTodayDateInISO8601Format();




    }*/

    /*    public String getCompliantDate(String value) {
            if(Objects.isNull(value) || value.isBlank())
                return
        }*/
    public static String getTodayDateInISO8601Format() {
        return LocalDate.now().toString()+"T00:00:00.0000000Z";
    }

}
