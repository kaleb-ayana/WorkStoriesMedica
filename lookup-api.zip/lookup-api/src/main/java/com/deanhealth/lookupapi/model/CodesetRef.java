package com.deanhealth.lookupapi.model;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Container(containerName = "Codeset")
public class CodesetRef {

    @Id
    @NotBlank(message = "Codeset.OCM_CDSET_REFERENCE_SK can not be blank.")
    @JsonProperty("OCM_CDSET_REFERENCE_SK")
    private String OCM_CDSET_REFERENCE_SK;

    @NotBlank(message = "Codeset.CODESET_NAME can not be blank.")
    @JsonProperty("CODESET_NAME")
    private String CODESET_NAME;

    @NotBlank(message = "Codeset.DESCR can not be blank.")
    @JsonProperty("DESCR")
    private String DESCR;

    @NotBlank(message = "Codeset.CD_VALUE can not be blank.")
    @JsonProperty("CD_VALUE")
    private String CD_VALUE;

    @NotBlank(message = "Codeset.INSERT_DTTM can not be blank.")
    @JsonProperty("INSERT_DTTM")
    private String INSERT_DTTM;

    @NotBlank(message = "Codeset.INSERT_PROCESS_ID can not be blank.")
    @JsonProperty("INSERT_PROCESS_ID")
    private String INSERT_PROCESS_ID;

    @NotBlank(message = "Codeset.id can not be blank.")
    @JsonProperty("UPDATE_DTTM")
    private String UPDATE_DTTM;

    @NotBlank(message = "Codeset.UPDATE_PROCESS_ID can not be blank.")
    @JsonProperty("UPDATE_PROCESS_ID")
    private String UPDATE_PROCESS_ID;

    @NotBlank(message = "Codeset.SOURCE_SYSTEM_CD can not be blank.")
    @JsonProperty("SOURCE_SYSTEM_CD")
    private String SOURCE_SYSTEM_CD;

    @NotBlank(message = "Codeset.STANDARDIZED_CD_VALUE can not be blank.")
    @JsonProperty("STANDARDIZED_CD_VALUE")
    private String STANDARDIZED_CD_VALUE;

    @NotBlank(message = "Codeset.STANDARDIZED_DESCR can not be blank.")
    @JsonProperty("STANDARDIZED_DESCR")
    private String STANDARDIZED_DESCR;

    @JsonProperty("LOGICAL_DELETE_FLG")
    private boolean LOGICAL_DELETE_FLG;
}
