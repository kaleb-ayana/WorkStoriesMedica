package com.deanhealth.lookupapi.model;

import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Data
public class LookUpBulkResponse {
    private List<XRefDto> resultList;
    private List<CodesetRef> codesetRefs;
    public void addAll(List<XRefDto> list) {
        if(CollectionUtils.isEmpty(list))
            return;
        if(CollectionUtils.isEmpty(this.resultList)) {
            this.resultList= list;
            return;
        }
        this.resultList.addAll(list);
    }

    public void addCodeSetRef(List<CodesetRef> list) {
        if(CollectionUtils.isEmpty(list))
            return;
        if(CollectionUtils.isEmpty(this.codesetRefs)) {
            this.codesetRefs= list;
            return;
        }
        this.codesetRefs.addAll(list);
    }

}
