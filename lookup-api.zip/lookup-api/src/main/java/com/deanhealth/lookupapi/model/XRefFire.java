package com.deanhealth.lookupapi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import java.util.Objects;

@ToString
@Slf4j
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class XRefFire {
    @JsonProperty("table")
    private String table;
    @JsonProperty("op_type")
    private String opType;
    @JsonProperty("op_ts")
    private String opTs;
    @JsonProperty("current_ts")
    private String currentTs;
    @JsonProperty("pos")
    private String pos;
    @JsonProperty("before")
    private XRef before;
    @JsonProperty("after")
    private XRef after;

    @JsonIgnore
    public XRef getGetPrevailingXRef() {
        if(Objects.nonNull(this.opType) && opType.equals("D")) {
            if(Objects.nonNull(before)) {
                before.setLOGICAL_DELETE_FLG(true);
                this.before.decorateDate();
            }
            return before;
        }
        if(Objects.nonNull(after)) {
            after.setLOGICAL_DELETE_FLG(false);
            this.after.decorateDate();
        }
        return after;
    }

    @JsonIgnore
    public void decorateDate() {
        if(Objects.nonNull(this.before))
            before.decorateDate();
        if(Objects.nonNull(this.after))
            after.decorateDate();
    }
    @JsonIgnore
    public boolean isUpdate() {
        return Objects.nonNull(this.before) && Objects.nonNull(this.after) && "U".equalsIgnoreCase(opType);
    }
    @JsonIgnore
    public boolean isDeletion() {
        return (Objects.nonNull(this.opType) && (Objects.nonNull(this.before)) && opType.equals("D"));
    }
    @JsonIgnore
    public boolean isInsertion() {
        return !(this.isUpdate() || this.isDeletion());
    }
    @JsonIgnore
    public void buildId() {
        this.decorateDate();
        if(Objects.nonNull(this.before))
            before.buildId();
        if(Objects.nonNull(this.after))
            after.buildId();
    }
}