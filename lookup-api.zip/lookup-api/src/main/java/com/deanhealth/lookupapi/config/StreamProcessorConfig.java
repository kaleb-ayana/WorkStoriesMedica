package com.deanhealth.lookupapi.config;

import com.deanhealth.lookupapi.model.CodesetRefFire;
import com.deanhealth.lookupapi.model.XRefFire;
import com.deanhealth.lookupapi.service.CodesetService;
import com.deanhealth.lookupapi.service.XRefService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.support.serializer.JsonSerde;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class StreamProcessorConfig {
    final JsonSerde<CodesetRefFire> FIRE_CODESET_REF_JSON_SERDE = new JsonSerde<>(CodesetRefFire.class);
    final JsonSerde<XRefFire> FIRE_X_REF_JSON_SERDE = new JsonSerde<>(XRefFire.class);

    @Value("${topics.codeset_ref}")
    public String CODESET_REF_TOPIC;

    @Value("${topics.xref}")
    public String X_REF_TOPIC;

    @Autowired
    CodesetService codesetService;

    @Autowired
    XRefService xRefService;

    @Autowired
    public void ProviderStreamBuilder(StreamsBuilder streamsBuilder) {
        codesetService.processCodesetEvent(streamsBuilder.stream(CODESET_REF_TOPIC, Consumed.with(Serdes.String(), FIRE_CODESET_REF_JSON_SERDE)));
        xRefService.processXRef(streamsBuilder.stream(X_REF_TOPIC, Consumed.with(Serdes.String(), FIRE_X_REF_JSON_SERDE)));
    }
}
