package com.deanhealth.lookupapi.repository;

import com.azure.spring.data.cosmos.repository.Query;
import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import com.deanhealth.lookupapi.model.XRef;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface XRefRepository extends ReactiveCosmosRepository<XRef, String> {
    @Query("SELECT * FROM c where c.XREF_TYPE=@xRefType AND c.SOURCE_SYSTEM_CD=@srcSysCd AND c.DESTINATION_SYSTEM_CD=@srcDestSysCd AND c.EFF_DT<=@effDate AND c.END_DT>=@endDate AND c.SOURCE_VALUE_1_TYPE=@srcVal1Type AND c.SOURCE_VALUE_1=@srcVal1 AND c.LOGICAL_DELETE_FLG=@logicalDeleteFlag")
    Flux<XRef> findByXRefTypeAndSourceSystemCdAndDestinationSystemCdAndEffDateAndEndDateAndSourceValue1TypeAndSourceValue1AndLOGICAL_DELETE_FLG(String xRefType,
                                                                                                                           String srcSysCd, String srcDestSysCd, String effDate, String endDate, String srcVal1Type, String srcVal1, Boolean logicalDeleteFlag);
    @Query("SELECT * FROM c where c.XREF_TYPE=@xRefType AND c.SOURCE_SYSTEM_CD=@srcSysCd AND c.DESTINATION_SYSTEM_CD=@srcDestSysCd AND c.SOURCE_VALUE_1_TYPE=@srcVal1Type AND c.SOURCE_VALUE_1=@srcVal1")
    Flux<XRef> findByXRefTypeAndSourceSystemCdAndDestinationSystemCdAndSourceValue1TypeAndSourceValue1(String xRefType, String srcSysCd, String srcDestSysCd, String srcVal1Type, String srcVal1);

    @Query("SELECT * FROM c where c.LOGICAL_DELETE_FLG=False AND c.XREF_TYPE=@xRefType AND c.SOURCE_SYSTEM_CD=@srcSysCd AND c.DESTINATION_SYSTEM_CD=@srcDestSysCd AND c.EFF_DT<=@effDate AND c.END_DT>=@endDate AND c.SOURCE_VALUE_1_TYPE=@srcVal1Type AND array_contains(@srcValues, c.SOURCE_VALUE_1, true) ")
    Flux<XRef> findByXRefTypeAndSourceSystemCdAndDestinationSystemCdAndEffDateAndEndDateAndSourceValue1TypeAndSOURCE_VALUE_1In(String xRefType,
                                                                                                                                         String srcSysCd, String srcDestSysCd, String effDate, String endDate, String srcVal1Type, Iterable<String> srcValues);

    @Query("SELECT * FROM c where c.XREF_TYPE!=''")
    Flux<XRef> findAllByIdIsNot();

    @Query("SELECT * FROM c WHERE c.XREF_TYPE=@xRefType AND c.SOURCE_SYSTEM_CD=@srcSysCd AND c.DESTINATION_SYSTEM_CD=@destSysCd AND c.EFF_DT<=@currDt AND c.END_DT>=@currDt AND c.SOURCE_VALUE_1_TYPE=@cdType AND array_contains(@srcValues, c.SOURCE_VALUE_1, true) ")
    Flux<XRef> batchSearch(String xRefType, String srcSysCd, String destSysCd, String currDt, String cdType, Iterable<String> srcValues);

    @Query("SELECT * FROM c WHERE c.XREF_TYPE=@xRefType AND c.SOURCE_SYSTEM_CD=@srcSysCd AND c.DESTINATION_SYSTEM_CD=@destSysCd AND c.EFF_DT<=@currDt AND c.END_DT>=@currDt AND c.SOURCE_VALUE_1_TYPE=@cdType")
    Flux<XRef> batchSearchByType(String xRefType, String srcSysCd, String destSysCd, String currDt, String cdType);

    @Query("SELECT * FROM c WHERE c.XREF_TYPE=@xRefType")
    Flux<XRef> findByXRefType(String xRefType);
}