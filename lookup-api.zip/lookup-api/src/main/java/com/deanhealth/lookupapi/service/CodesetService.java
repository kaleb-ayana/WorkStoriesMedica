package com.deanhealth.lookupapi.service;

import com.deanhealth.lookupapi.model.CodesetRef;
import com.deanhealth.lookupapi.model.CodesetRefFire;
import com.deanhealth.lookupapi.repository.CodesetRepository;
import com.deanhealth.lookupapi.util.Constants;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@Slf4j
public class CodesetService {

    @Value("${codeset.eds.name.degree}")
    private String degreeCodesetName;

    @Value("${codeset.eds.name.specialty}")
    private String specialtyCodesetName;

    @Value("${codeset.eds.name.county}")
    private String countyCodesetName;
    @Value("${codeset.eds.name.language}")
    private String languageCodesetName;

    @Autowired
    private CodesetRepository codesetRepository;

    @Autowired
    private Validator validator;

    public CodesetRef getActiveMtvCodeset(String codesetName, String code) {
        return this.getCodeset(Constants.MTV, codesetName, code, Boolean.FALSE);
    }
    public CodesetRef getCodeset(String srcSysCode, String codesetName, String code, Boolean deleteFlag) {
        return this.codesetRepository.findBySOURCE_SYSTEM_CDAndCODESET_NAMEAAndCD_VALUEAAndLOGICAL_DELETE_FLG(srcSysCode, codesetName, code, deleteFlag).blockFirst();
    }
    public List<CodesetRef> getCodeset(String srcSysCode, String codesetName, Boolean deleteFlag) {
        return this.codesetRepository.findBySOURCE_SYSTEM_CDAndCODESET_NAMEAAndLOGICAL_DELETE_FLG(srcSysCode, codesetName, deleteFlag).collectList().block();
    }
    public void processCodesetEvent(KStream<String, CodesetRefFire> codesetRefFireStream ) {
        codesetRefFireStream
                .peek((key, value) -> log.info(key+""))
                .filter((key, value) -> Objects.nonNull(key) && Objects.nonNull(value) )
                .foreach((key, value) -> this.persist(value));
    }

    public CodesetRef getById(String id) {
        return this.codesetRepository.findById(id).block();
    }
    public boolean persist(CodesetRefFire fire) {
        if(Objects.isNull(fire) || ((Objects.isNull(fire.getBefore()) && (Objects.isNull(fire.getAfter())))))
            return false;
        CodesetRef codeset= fire.getCodeset();

        if((Objects.isNull(codeset)) || (! this.validator.isValid(codeset))) {
            log.warn("Unable to persist codeset due to reason that it could be null or invalid.");
            return false;
        }
        if( !(this.specialtyCodesetName.equalsIgnoreCase(codeset.getCODESET_NAME()) || this.degreeCodesetName.equalsIgnoreCase(codeset.getCODESET_NAME()) || this.countyCodesetName.equalsIgnoreCase(codeset.getCODESET_NAME())  || this.languageCodesetName.equalsIgnoreCase(codeset.getCODESET_NAME()) ))
            return false;
        log.info("Persisting ... " + codeset);
        this.codesetRepository.save(codeset).block();
        log.info("Codeset Successfully persisted !");
        return true;
    }

    public List<CodesetRef> getCodesets(String srcSysCode, String codesetName, Iterable<String> code, Boolean deleteFlag) {
        return this.codesetRepository.findBySOURCE_SYSTEM_CDAndCODESET_NAMEAAndCD_VALUEAAndLOGICAL_DELETE_FLG_BULK(srcSysCode, codesetName, code, deleteFlag).collectList().block();
    }
}
