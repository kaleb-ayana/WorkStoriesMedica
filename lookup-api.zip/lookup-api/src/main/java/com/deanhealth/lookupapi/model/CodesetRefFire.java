package com.deanhealth.lookupapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import java.util.Objects;

@ToString
@Slf4j
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CodesetRefFire {
    @JsonProperty("table")
    private String table;
    @JsonProperty("op_type")
    private String opType;
    @JsonProperty("op_ts")
    private String opTs;
    @JsonProperty("current_ts")
    private String currentTs;
    @JsonProperty("pos")
    private String pos;
    @JsonProperty("before")
    private CodesetRef before;
    @JsonProperty("after")
    private CodesetRef after;

    public CodesetRef getCodeset() {
        if(Objects.nonNull(this.opType) && opType.equals("D")) {
            if(Objects.nonNull(before))
                before.setLOGICAL_DELETE_FLG(true);
            return before;
        }
        if(Objects.nonNull(after))
            after.setLOGICAL_DELETE_FLG(false);
        return after;
    }

}