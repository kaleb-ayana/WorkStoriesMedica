package com.deanhealth.lookupapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class XRefDto {
    @JsonProperty("XREF_TYPE")
    private String xRefType;

    @JsonProperty("SOURCE_SYSTEM_CD")
    private String sourceSystemCd;

    @JsonProperty("DESTINATION_SYSTEM_CD")
    private String destinationSystemCd;

    @JsonProperty("EFF_DT")
    private String effDate;

    @JsonProperty("END_DT")
    private String endDate;

    @JsonProperty("SOURCE_VALUE_1_TYPE")
    private String sourceValue1Type;

    @JsonProperty("SOURCE_VALUE_1")
    private String sourceValue1;

    @JsonProperty("SOURCE_VALUE_2_TYPE")
    private String sourceValue2Type;

    @JsonProperty("SOURCE_VALUE_2")
    private String sourceValue2;

    @JsonProperty("SOURCE_VALUE_3_TYPE")
    private String sourceValue3Type;

    @JsonProperty("SOURCE_VALUE_3")
    private String sourceValue3;

    @JsonProperty("SOURCE_VALUE_4_TYPE")
    private String sourceValue4Type;

    @JsonProperty("SOURCE_VALUE_4")
    private String sourceValue4;

    @JsonProperty("SOURCE_VALUE_5_TYPE")
    private String sourceValue5Type;

    @JsonProperty("SOURCE_VALUE_5")
    private String sourceValue5;

    @JsonProperty("SOURCE_VALUE_6_TYPE")
    private String sourceValue6Type;

    @JsonProperty("SOURCE_VALUE_6")
    private String sourceValue6;

    @JsonProperty("SOURCE_VALUE_7_TYPE")
    private String sourceValue7Type;

    @JsonProperty("SOURCE_VALUE_7")
    private String sourceValue7;

    @JsonProperty("SOURCE_VALUE_8_TYPE")
    private String sourceValue8Type;

    @JsonProperty("SOURCE_VALUE_8")
    private String sourceValue8;

    @JsonProperty("SOURCE_VALUE_9_TYPE")
    private String sourceValue9Type;

    @JsonProperty("SOURCE_VALUE_9")
    private String sourceValue9;

    @JsonProperty("SOURCE_VALUE_10_TYPE")
    private String sourceValue10Type;

    @JsonProperty("SOURCE_VALUE_10")
    private String sourceValue10;

    @JsonProperty("DESTINATION_VALUE_1_TYPE")
    private String destinationValue1Type;

    @JsonProperty("DESTINATION_VALUE_1")
    private String destinationValue1;

    @JsonProperty("DESTINATION_VALUE_2_TYPE")
    private String destinationValue2Type;

    @JsonProperty("DESTINATION_VALUE_2")
    private String destinationValue2;

    @JsonProperty("DESTINATION_VALUE_3_TYPE")
    private String destinationValue3Type;

    @JsonProperty("DESTINATION_VALUE_3")
    private String destinationValue3;

    @JsonProperty("DESTINATION_VALUE_4_TYPE")
    private String destinationValue4Type;

    @JsonProperty("DESTINATION_VALUE_4")
    private String destinationValue4;

    @JsonProperty("DESTINATION_VALUE_5_TYPE")
    private String destinationValue5Type;

    @JsonProperty("DESTINATION_VALUE_5")
    private String destinationValue5;

    @JsonProperty("DESTINATION_VALUE_6_TYPE")
    private String destinationValue6Type;

    @JsonProperty("DESTINATION_VALUE_6")
    private String destinationValue6;

    @JsonProperty("DESTINATION_VALUE_7_TYPE")
    private String destinationValue7Type;

    @JsonProperty("DESTINATION_VALUE_7")
    private String destinationValue7;

    @JsonProperty("DESTINATION_VALUE_8_TYPE")
    private String destinationValue8Type;

    @JsonProperty("DESTINATION_VALUE_8")
    private String destinationValue8;

    @JsonProperty("DESTINATION_VALUE_9_TYPE")
    private String destinationValue9Type;

    @JsonProperty("DESTINATION_VALUE_9")
    private String destinationValue9;

    @JsonProperty("DESTINATION_VALUE_10_TYPE")
    private String destinationValue10Type;

    @JsonProperty("DESTINATION_VALUE_10")
    private String destinationValue10;

}
