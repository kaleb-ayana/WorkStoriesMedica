package com.deanhealth.lookupapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LookupApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LookupApiApplication.class, args);
	}

}
