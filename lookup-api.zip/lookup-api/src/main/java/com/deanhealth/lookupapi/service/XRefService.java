package com.deanhealth.lookupapi.service;

import com.deanhealth.lookupapi.model.*;
import com.deanhealth.lookupapi.repository.XRefRepository;
import com.deanhealth.lookupapi.util.Constants;
import com.deanhealth.lookupapi.util.Util;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class XRefService {

    @Value("${xref.eds.type.specialty}")
    private String specialtyXRefType;
    @Value("${xref.eds.type.practitioner-specialty}")
    private String practitionerSpecialtyXRefType;

    @Value("${xref.eds.type.language}")
    private String languageXRefType;

    @Value("${xref.eds.type.degree}")
    private String degreeXRefType;


    @Autowired
    private XRefRepository xRefRepository;

    @Autowired
    private Validator validator;

    public void processXRef(KStream<String, XRefFire> xRefFireStream ) {
        xRefFireStream
                .peek((key, value) -> log.info(key+""))
                .filter((key, value) -> Objects.nonNull(key) && Objects.nonNull(value))
//                .filter((key, value) -> List.of(specialtyXRefType, languageXRefType, degreeXRefType).contains(value.getGetPrevailingXRef().getXREF_TYPE()))
                .foreach((key, value) -> {
                    boolean flag= this.persist(value);
                    if(flag)
                        log.info("Persisting XRef was successful !");
                    else
                        log.warn("Persisting XRef failed.");
                });
    }
    public XRef getXRef(String xRefType, String srcSysCd, String destSysCd, String srcVal1Type, String srcVal1) {
        XRef xRef = this.getXRef(xRefType, srcSysCd, destSysCd, srcVal1Type, srcVal1, Util.getTodayDateInISO8601Format(), Util.getTodayDateInISO8601Format(), Boolean.FALSE);
        return xRef;
    }
    public XRef getXRef(String xRefType, String srcSysCd, String destSysCd, String srcVal1Type, String srcVal1, String effDate, String endDate, Boolean logicalDeleteFlag) {
        return this.xRefRepository.findByXRefTypeAndSourceSystemCdAndDestinationSystemCdAndEffDateAndEndDateAndSourceValue1TypeAndSourceValue1AndLOGICAL_DELETE_FLG(
                xRefType, srcSysCd, destSysCd, Util.getISO8601(effDate), Util.getISO8601(endDate), srcVal1Type, srcVal1, logicalDeleteFlag).blockFirst();
    }
    public LookUpBulkResponse getBulkXRefs(LookUpBulkRequest request) {
        LookUpBulkResponse lookUpBulkResponse= new LookUpBulkResponse();
        List<XRef> resultList= null;
        if(! CollectionUtils.isEmpty(request.getSpecialties()))
            resultList= this.xRefRepository.batchSearch(Constants.X_REF_TYPE_SPECiALTY, Constants.MTV, Constants.EDS,
                                                                    Util.getISO8601(Util.getTodayDateInISO8601Format()),Constants.XREF_CD_TYPE_SPECIALTY_CD,
                                                                    request.getSpecialties()).collectList().block();
        if(! CollectionUtils.isEmpty(resultList))
            lookUpBulkResponse.addAll(resultList.stream().map(xRef -> this.mapXRefToXRefDto(xRef)).collect(Collectors.toList()));
        if(! CollectionUtils.isEmpty(request.getPractitionerSpecialties()))
            resultList= this.xRefRepository.batchSearch(Constants.X_REF_TYPE_PRACTITIONER_SPECiALTY, Constants.MTV, Constants.SYMFACT,
                                                                    Util.getISO8601(Util.getTodayDateInISO8601Format()),Constants.XREF_CD_TYPE_SPECIALTY_CD,
                                                                    request.getPractitionerSpecialties()).collectList().block();
        if(! CollectionUtils.isEmpty(resultList))
            lookUpBulkResponse.addAll(resultList.stream().map(xRef -> this.mapXRefToXRefDto(xRef)).collect(Collectors.toList()));
        resultList=null;
        if(! CollectionUtils.isEmpty(request.getDegreeCodes()))
            resultList= this.xRefRepository.batchSearch(Constants.X_REF_TYPE_DEGREE, Constants.MTV, Constants.EDS,
                    Util.getISO8601(Util.getTodayDateInISO8601Format()),Constants.XREF_CD_TYPE_DEGREE,
                    request.getDegreeCodes()).collectList().block();
        if(! CollectionUtils.isEmpty(resultList))
            lookUpBulkResponse.addAll(resultList.stream().map(xRef -> this.mapXRefToXRefDto(xRef)).collect(Collectors.toList()));
        resultList= null;
        if(! CollectionUtils.isEmpty(request.getLanguages()))
            resultList= this.xRefRepository.batchSearch(Constants.X_REF_TYPE_LANGUAGE, Constants.MTV, Constants.EDS,
                    Util.getISO8601(Util.getTodayDateInISO8601Format()),Constants.XREF_CD_TYPE_LANGUAGE,
                    request.getLanguages()).collectList().block();
        if(! CollectionUtils.isEmpty(resultList))
            lookUpBulkResponse.addAll(resultList.stream().map(xRef -> this.mapXRefToXRefDto(xRef)).collect(Collectors.toList()));
        return lookUpBulkResponse;
    }

    public Optional<XRef> getXRef(String xRefId) {
        return Optional.ofNullable(xRefRepository.findById(xRefId).block());
    }
    public boolean persist(XRefFire xRefFire) {
        if(Objects.isNull(xRefFire) || (Objects.isNull(xRefFire.getAfter()) && Objects.isNull(xRefFire.getBefore())))
            return false;
        xRefFire.buildId();
        log.info("About to persist ... " + xRefFire);
        if( ( !this.validator.isValidOrNull(xRefFire.getBefore())) || ( ! this.validator.isValidOrNull(xRefFire.getAfter())))
            return false;
        XRef candidateXRef= xRefFire.getGetPrevailingXRef();
        if(xRefFire.isInsertion()) {
            this.xRefRepository.save(candidateXRef).block();
            log.info("Insertion of XRef was successful!");
            return true;
        }
        if(xRefFire.isDeletion()) {
            XRef resultXRef= this.xRefRepository.findById(candidateXRef.getId()).block();
            if(Objects.isNull(resultXRef)) {
                log.warn("XRef for deletion does not exist priori.");
                return false;
            }
            candidateXRef.setLOGICAL_DELETE_FLG(true);
            this.xRefRepository.save(candidateXRef).block();
            log.info("Deletion of XRef was successful!");
        }
        if(Objects.isNull(xRefFire.getBefore()) || Objects.isNull(xRefFire.getAfter())) {
            log.warn("XRef update failed because of improper message.");
            return false;
        }
        XRef existingXRef= this.xRefRepository.findById(xRefFire.getBefore().getId()).block();
        if(Objects.isNull(existingXRef)) {
            this.xRefRepository.save(candidateXRef).block();
            log.info("Update/Insertion of XRef was successful!");
            return true;
        }
        if(! candidateXRef.getId().equalsIgnoreCase(existingXRef.getId())) {
            existingXRef.setLOGICAL_DELETE_FLG(false);
            this.xRefRepository.save(existingXRef).block();
            log.info("Update/Replacement of XRef was successful. Old record was deleted!");
        }
        this.xRefRepository.save(candidateXRef).block();
        log.info("Update/Replacement of XRef was successful.!");
        return true;
    }

    public XRefDto mapXRefToXRefDto(XRef xRef) {
        if(Objects.isNull(xRef))
            return null;
        XRefDto xRefDto= new XRefDto();
        xRefDto.setXRefType(xRef.getXREF_TYPE());
        xRefDto.setSourceSystemCd(xRef.getSOURCE_SYSTEM_CD());
        xRefDto.setDestinationSystemCd(xRef.getDESTINATION_SYSTEM_CD());
        xRefDto.setEffDate(xRef.getEFF_DT());
        xRefDto.setEndDate(xRef.getEND_DT());
        xRefDto.setSourceValue1Type(xRef.getSOURCE_VALUE_1_TYPE());
        xRefDto.setSourceValue1(xRef.getSOURCE_VALUE_1());
        xRefDto.setSourceValue2Type(xRef.getSOURCE_VALUE_2_TYPE());
        xRefDto.setSourceValue2(xRef.getSOURCE_VALUE_2());
        xRefDto.setSourceValue3Type(xRef.getSOURCE_VALUE_3_TYPE());
        xRefDto.setSourceValue3(xRef.getSOURCE_VALUE_3());
        xRefDto.setSourceValue4Type(xRef.getSOURCE_VALUE_4_TYPE());
        xRefDto.setSourceValue4(xRef.getSOURCE_VALUE_4());

        xRefDto.setSourceValue5(xRef.getSOURCE_VALUE_5_TYPE());
        xRefDto.setSourceValue5(xRef.getSOURCE_VALUE_5());
        xRefDto.setSourceValue6Type(xRef.getSOURCE_VALUE_6_TYPE());
        xRefDto.setSourceValue6(xRef.getSOURCE_VALUE_6());
        xRefDto.setSourceValue7Type(xRef.getSOURCE_VALUE_7_TYPE());
        xRefDto.setSourceValue7(xRef.getSOURCE_VALUE_7());
        xRefDto.setSourceValue8Type(xRef.getSOURCE_VALUE_8_TYPE());
        xRefDto.setSourceValue8(xRef.getSOURCE_VALUE_8());
        xRefDto.setSourceValue9Type(xRef.getSOURCE_VALUE_9_TYPE());
        xRefDto.setSourceValue9(xRef.getSOURCE_VALUE_9());
        xRefDto.setSourceValue10Type(xRef.getSOURCE_VALUE_10_TYPE());
        xRefDto.setSourceValue10(xRef.getSOURCE_VALUE_10());

        xRefDto.setDestinationValue1Type(xRef.getDESTINATION_VALUE_1_TYPE());
        xRefDto.setDestinationValue1(xRef.getDESTINATION_VALUE_1());
        xRefDto.setDestinationValue2Type(xRef.getDESTINATION_VALUE_2_TYPE());
        xRefDto.setDestinationValue2(xRef.getDESTINATION_VALUE_2());
        xRefDto.setDestinationValue3Type(xRef.getDESTINATION_VALUE_3_TYPE());
        xRefDto.setDestinationValue3(xRef.getDESTINATION_VALUE_3());
        xRefDto.setDestinationValue4Type(xRef.getDESTINATION_VALUE_4_TYPE());
        xRefDto.setDestinationValue4(xRef.getDESTINATION_VALUE_4());

        xRefDto.setDestinationValue5Type(xRef.getDESTINATION_VALUE_5_TYPE());
        xRefDto.setDestinationValue5(xRef.getDESTINATION_VALUE_5());
        xRefDto.setDestinationValue6Type(xRef.getDestinationValue6Type());
        xRefDto.setDestinationValue6(xRef.getDESTINATION_VALUE_6());
        xRefDto.setDestinationValue7Type(xRef.getDESTINATION_VALUE_7_TYPE());
        xRefDto.setDestinationValue7(xRef.getDESTINATION_VALUE_7());
        xRefDto.setDestinationValue8Type(xRef.getDESTINATION_VALUE_8_TYPE());
        xRefDto.setDestinationValue8(xRef.getDESTINATION_VALUE_8());
        xRefDto.setDestinationValue9Type(xRef.getDestinationValue9Type());
        xRefDto.setDestinationValue9(xRef.getDESTINATION_VALUE_9());
        xRefDto.setDestinationValue10Type(xRef.getDESTINATION_VALUE_10_TYPE());
        xRefDto.setDestinationValue10(xRef.getDESTINATION_VALUE_10());
        return xRefDto;
    }

    public List<XRef> getXRefs(String XRefType, String sourceSystemCd, String destinationSystemCd, String xrefCdType) {
        return this.xRefRepository.batchSearchByType(XRefType, sourceSystemCd, destinationSystemCd,Util.getISO8601(Util.getTodayDateInISO8601Format()), xrefCdType).collectList().block();
    }

}
