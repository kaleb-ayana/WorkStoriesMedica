package com.deanhealth.lookupapi.repository;

import com.azure.spring.data.cosmos.repository.Query;
import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import com.deanhealth.lookupapi.model.CodesetRef;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface CodesetRepository  extends ReactiveCosmosRepository<CodesetRef, String> {
    @Query("SELECT * FROM c where c.CD_VALUE=@cdValue")
    Flux<CodesetRef> findByCD_VALUE(String cdValue);

    @Query("SELECT * FROM c where c.SOURCE_SYSTEM_CD=@srcSysCode AND c.CODESET_NAME=@codesetName AND c.CD_VALUE=@cdValue AND c.LOGICAL_DELETE_FLG=@logicalDeleteFlag")
    Flux<CodesetRef> findBySOURCE_SYSTEM_CDAndCODESET_NAMEAAndCD_VALUEAAndLOGICAL_DELETE_FLG(String srcSysCode, String codesetName, String cdValue, Boolean logicalDeleteFlag);

    @Query("SELECT * FROM c where c.SOURCE_SYSTEM_CD=@srcSysCode AND c.CODESET_NAME=@codesetName AND c.LOGICAL_DELETE_FLG=@logicalDeleteFlag")
    Flux<CodesetRef> findBySOURCE_SYSTEM_CDAndCODESET_NAMEAAndLOGICAL_DELETE_FLG(String srcSysCode, String codesetName, Boolean logicalDeleteFlag);

    @Query("SELECT * FROM c where c.SOURCE_SYSTEM_CD=@srcSysCode AND c.CODESET_NAME=@codesetName AND array_contains(@cdValues, c.CD_VALUE, true) AND c.LOGICAL_DELETE_FLG=@logicalDeleteFlag")
    Flux<CodesetRef> findBySOURCE_SYSTEM_CDAndCODESET_NAMEAAndCD_VALUEAAndLOGICAL_DELETE_FLG_BULK(String srcSysCode, String codesetName, Iterable<String> cdValues, Boolean logicalDeleteFlag);
}