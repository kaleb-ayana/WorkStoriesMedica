package com.deanhealth.lookupapi.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import java.util.Objects;

@Service
@Slf4j
public class Validator {
    final static javax.validation.Validator validator = Validation
            .buildDefaultValidatorFactory()
            .getValidator();
    public boolean isValid(Object domainObject) {
        return ((Objects.nonNull(domainObject)) && (! validator.validate(domainObject)
                .stream()
                .map(ConstraintViolation::getMessage)
                .peek(log::warn)
                .findAny()
                .isPresent()));
    }
    public boolean isValidOrNull(Object domainObject) {
        return Objects.isNull(domainObject) || this.isValid(domainObject);
    }
}