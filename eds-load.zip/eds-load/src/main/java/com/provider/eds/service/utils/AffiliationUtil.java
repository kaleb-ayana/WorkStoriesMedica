package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Affiliation;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;
@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)

public class AffiliationUtil {

    public static boolean equals(Affiliation affiliation1, Affiliation affiliation2) {
        if(Objects.isNull(affiliation1))
            return Objects.isNull(affiliation2);
        if(Objects.isNull(affiliation2))
            return Objects.isNull(affiliation1);
        return Objects.equals(affiliation1.getAffiliateProviderId(), affiliation2.getAffiliateProviderId()) &&
                Objects.equals(affiliation1.getAffiliationType(), affiliation2.getAffiliationType()) &&
                Objects.equals(affiliation1.getAffiliateProviderIdType(), affiliation2.getAffiliateProviderIdType()) &&
                Objects.equals(affiliation1.getHospitalAffiliationType(), affiliation2.getHospitalAffiliationType()) &&
                Objects.equals(affiliation1.getEffDt(), affiliation2.getEffDt());
    }


    public static boolean matches(Affiliation affiliation1, Affiliation affiliation2) {
        return equals(affiliation1, affiliation2 );
    }

    public static boolean merge(Affiliation affiliation1, Affiliation affiliation2) {
        if(! matches(affiliation1,affiliation2))
            return false;
        affiliation1.setEndDt(Util.getMaxDate(affiliation1.getEndDt(), affiliation2.getEndDt()));
        affiliation1.setPrimaryFlg(Util.getDisjunction(affiliation1.isPrimaryFlg(), affiliation2.isPrimaryFlg()));
//        affiliation1.setPcpFlg(Util.mergeB(affiliation1.getPcpFlg(), affiliation2.getPcpFlg()));
        affiliation1.setLogicalDeleteFlg(Util.getConjunction(affiliation1.getLogicalDeleteFlg(), affiliation2.getLogicalDeleteFlg())); // Revise
        affiliation1.setSourceSystemCd(Util.mergeString(affiliation1.getSourceSystemCd(), affiliation2.getSourceSystemCd()));
        affiliation1.setSourceSystemInsertDttm(Util.getMinLong(affiliation1.getSourceSystemInsertDttm(), affiliation2.getSourceSystemInsertDttm()));
        affiliation1.setSourceSystemUpdateDttm(Util.getMaxLong(affiliation1.getSourceSystemUpdateDttm(), affiliation2.getSourceSystemUpdateDttm()));
        return true;
    }

    public static void tagForResynch(Affiliation affiliation) {
        affiliation.setResynchTag(affiliation.getEffDt() + ";" + affiliation.getEndDt() + ";" + (Objects.isNull(affiliation.getLogicalDeleteFlg())? false : affiliation.getLogicalDeleteFlg()));
    }
}
