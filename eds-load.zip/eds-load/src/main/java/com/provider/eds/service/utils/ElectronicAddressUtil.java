package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.ElectronicAddress;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ElectronicAddressUtil {

    public static boolean equals(ElectronicAddress electronicAddress1, ElectronicAddress electronicAddress2) {
        if(Objects.isNull(electronicAddress1))
            return Objects.isNull(electronicAddress2);
        if(Objects.isNull(electronicAddress2))
            return Objects.isNull(electronicAddress1);
        return Objects.equals(electronicAddress1.getElecAddressTypeCd(), electronicAddress2.getElecAddressTypeCd())  &&
                Objects.equals(electronicAddress1.getElectronicAddress(), electronicAddress2.getElectronicAddress());
    }

    public static boolean matches(ElectronicAddress electronicAddress1, ElectronicAddress electronicAddress2) {
        return equals(electronicAddress1, electronicAddress2);
    }

    public  static boolean merge(ElectronicAddress electronicAddress1,ElectronicAddress electronicAddress2) {
        if(! matches(electronicAddress1,electronicAddress2))
            return false;
        electronicAddress1.setPrimaryFlg(Util.getDisjunction(electronicAddress1.isPrimaryFlg(), electronicAddress2.isPrimaryFlg()));
        electronicAddress1.setSalutation(Util.mergeString(electronicAddress1.getSalutation(), electronicAddress2.getSalutation()));
        electronicAddress1.setSourceSystemCd(Util.mergeString(electronicAddress1.getSourceSystemCd(), electronicAddress2.getSourceSystemCd()));
        electronicAddress1.setLogicalDeleteFlg(Util.getConjunction(electronicAddress1.getLogicalDeleteFlg(), electronicAddress2.getLogicalDeleteFlg()));
        electronicAddress1.setSourceSystemInsertDttm(Util.getMinLong(electronicAddress1.getSourceSystemInsertDttm(), electronicAddress2.getSourceSystemInsertDttm()));
        electronicAddress1.setSourceSystemUpdateDttm(Util.getMaxLong(electronicAddress1.getSourceSystemUpdateDttm(), electronicAddress2.getSourceSystemUpdateDttm()));
        return true;
    }
}
