package com.provider.eds.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Tax {
    private String taxId;
    private String effectiveDt;
    private String endDt;
    private boolean logicalDeleteFlag;

}
