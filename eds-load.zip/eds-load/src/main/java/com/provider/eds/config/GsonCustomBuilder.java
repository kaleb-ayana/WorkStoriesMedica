package com.provider.eds.config;

import com.google.gson.*;

import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class GsonCustomBuilder {
    public static Gson getGsonCustomAdapter() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(LocalDate.class, new JsonSerializer<LocalDate>() {
            private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            @Override
            public JsonElement serialize(LocalDate localDate, Type typeOfSrc, JsonSerializationContext context) {
                return new JsonPrimitive(formatter.format(localDate));
            }
        });
        gsonBuilder.registerTypeAdapter(LocalDate.class, new JsonDeserializer <LocalDate>() {
            @Override
            public LocalDate deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
                    throws JsonParseException {
                return LocalDate.parse(json.getAsString(),
                        DateTimeFormatter.ofPattern("yyyy-MM-dd").withLocale(Locale.ENGLISH));
            }
        });
        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new JsonSerializer<LocalDateTime>() {
            private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSSSS");
            @Override
            public JsonElement serialize(LocalDateTime localDate, Type typeOfSrc, JsonSerializationContext context) {
                return new JsonPrimitive(formatter.format(localDate));
            }
        });
        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new JsonDeserializer <LocalDateTime>() {
            @Override
            public LocalDateTime deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
                    throws JsonParseException {
                return LocalDateTime.parse(json.getAsString(),
                        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSSSS").withLocale(Locale.ENGLISH));
            }
        });
        gsonBuilder.registerTypeAdapter(ByteBuffer.class, new JsonSerializer<ByteBuffer>() {
            @Override
            public JsonElement serialize(ByteBuffer src, Type typeOfSrc, JsonSerializationContext context) {
                return new JsonPrimitive(StandardCharsets.UTF_8.decode(src).toString());
            }
        });

        ExclusionStrategy exclusionStrategy = new ExclusionStrategy() {
            @Override
            public boolean shouldSkipClass(Class<?> clazz) {
                return false;
            }

            @Override
            public boolean shouldSkipField(FieldAttributes field) {
                return "".equals(field.getName());
/*                return "OPV_PROVIDER_EDUCATION".equals(field.getName()) ||
                        "OPV_PROVIDER_DEGREE".equals(field.getName()) ||
                        "OPV_PROVIDER_PANEL".equals(field.getName()) ||
                        "OPV_PROVIDER_NETWORK_DIRECTORY".equals(field.getName()) ||
                        "OPV_PROVIDER_ELEC_ADDRESS".equals(field.getName()) ||
                        "OPV_PROVIDER_REMARK".equals(field.getName()) ||
                        "OPV_PROVIDER_LANGUAGE".equals(field.getName()) ||
                        "OPV_PROVIDER_TAXONOMY".equals(field.getName()) ||
                        "OPV_PROVIDER_LICENSE".equals(field.getName()) ||
                        "OPV_PROVIDER_CERTIFICATION".equals(field.getName())*/
            }
        };
        return gsonBuilder
                .serializeNulls()
                .excludeFieldsWithModifiers(Modifier.STATIC)
                .addSerializationExclusionStrategy(exclusionStrategy)
                .setPrettyPrinting().create();
    }
}
