package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Specialty;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SpecialtyUtil {
    public static boolean equals(Specialty specialty1, Specialty specialty2) {
        if (Objects.isNull(specialty1))
            return Objects.isNull(specialty2);
        if (Objects.isNull(specialty2))
            return Objects.isNull(specialty1);
        return Objects.equals(specialty1.getSpecialtyCode(), specialty2.getSpecialtyCode()) &&
                Objects.equals(specialty1.getEffDt(), specialty2.getEffDt()) &&
                Objects.equals(specialty1.isPrimaryFlg(), specialty2.isPrimaryFlg());
    }

    public static boolean matches(Specialty specialty1, Specialty specialty2) {
        return equals(specialty1, specialty2);
    }

    public static boolean merge(Specialty specialty1, Specialty specialty2) {
        if (!matches(specialty1, specialty2))
            return false;
        specialty1.setEndDt(Util.getMaxDate(specialty1.getEndDt(), specialty2.getEndDt()));
        specialty1.setLogicalDeleteFlg(Util.getConjunction(specialty1.getLogicalDeleteFlg(), specialty2.getLogicalDeleteFlg()));
        specialty1.setBoardCertifiedCd(Util.getDisjunction(specialty1.getBoardCertifiedCd(), specialty2.getBoardCertifiedCd()));
//        specialty1.setSpecialtyDescription(Util.mergeString(specialty1.getSpecialtyDescription(), specialty2.getSpecialtyDescription()));
        specialty1.setSourceSystemCd(Util.mergeString(specialty1.getSourceSystemCd(), specialty2.getSourceSystemCd()));
        specialty1.setSourceSystemInsertDttm(Util.getMinLong(specialty1.getSourceSystemInsertDttm(), specialty2.getSourceSystemInsertDttm()));
        specialty1.setSourceSystemUpdateDttm(Util.getMaxLong(specialty1.getSourceSystemUpdateDttm(), specialty2.getSourceSystemUpdateDttm()));
        return true;
    }
    public static boolean isActive(Specialty specialty) {
        return specialty.getLogicalDeleteFlg() == false;
    }


    public static boolean isPrimary(Specialty specialty) {
        return specialty.isPrimaryFlg() == true;
    }
}
