package com.provider.eds.service.utils;

import com.medica.model.eds.provider.Affiliation;
import com.medica.model.eds.provider.Network;
import com.medica.model.eds.provider.Panel;
import com.provider.eds.model.Constants;
import org.apache.commons.lang3.SerializationUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

public class CloningUtils {
    public static Affiliation cloneAffiliation(Affiliation originalAffiliation, String affiliateProvTypeId, String affiliateProvId, List<LocalDate> effDates, List<LocalDate> endDates, boolean relatedlogicaldelteflag) {
        if(Objects.isNull(originalAffiliation))
            return null;
        Affiliation affiliation = SerializationUtils.clone(originalAffiliation);
        affiliation.setAffiliateProviderIdType(affiliateProvTypeId);
        affiliation.setAffiliateProviderId(affiliateProvId);
        affiliation.setEffDt(effDates.stream().max(LocalDate :: compareTo).get().toString());
        affiliation.setEndDt(endDates.stream().min(LocalDate :: compareTo).get().toString());
        affiliation.setLogicalDeleteFlg(affiliation.getLogicalDeleteFlg() || relatedlogicaldelteflag);
        return affiliation;
    }

    public static Panel clonePanel(Panel originalPanel, String mtvProvId, boolean logicalDltFlg, String md5Hash) {
        if(Objects.isNull(originalPanel))
            return null;
        Panel panel =  SerializationUtils.clone(originalPanel);
        panel.setAddressId(originalPanel.getPracLocProviderId());
        panel.setPracLocProviderId(md5Hash);
        panel.setPracLocProviderIdType(Constants.MD5);
        panel.setLogicalDeleteFlg((Objects.isNull(panel.getLogicalDeleteFlg()) ? false : panel.getLogicalDeleteFlg()) || logicalDltFlg);
        panel.setMtvProviderId(mtvProvId);
        return panel;
    }
    public static Network cloneNetwork(Network originalNetwork, String networkProvTypeId, String networkProvId, String mtvProviderId, boolean logicalDeleteFlag) {
        if(Objects.isNull(originalNetwork))
            return null;
        Network network = SerializationUtils.clone(originalNetwork);
        network.setAddressId(originalNetwork.getPraclocProviderId());
        network.setPraclocProviderId(networkProvId);
        network.setPraclocProviderIdType(networkProvTypeId);
        network.setMtvProviderId(mtvProviderId);
        network.setLogicalDeleteFlg((Objects.isNull(network.getLogicalDeleteFlg()) ? false : network.getLogicalDeleteFlg()) || logicalDeleteFlag);
        return network;
    }
}
