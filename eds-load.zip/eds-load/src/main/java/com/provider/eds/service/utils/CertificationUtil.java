package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Certification;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CertificationUtil {

    public static boolean equals(Certification certification1, Certification certification2) {
        if (Objects.isNull(certification1))
            return Objects.isNull(certification2);
        if (Objects.isNull(certification2))
            return Objects.isNull(certification1);
        return Objects.equals(certification1.getCertificationCd(), certification2.getCertificationCd()) &&
                Objects.equals(certification1.getEffDt(), certification2.getEffDt());
    }


    public static boolean matches(Certification certification1, Certification certification2) {
        return equals(certification1, certification2);
    }

    public static boolean merge(Certification certification1, Certification certification2) {
        if (!matches(certification1, certification2))
            return false;
        certification1.setCertNum(Util.mergeString(certification1.getCertNum(), certification2.getCertNum()));
        certification1.setEndDt(Util.getMaxDate(certification1.getEndDt(), certification2.getEndDt()));
//        certification1.setLifeTmCertFlg(Util.getDisjunction(certification1.isLifeTmCertFlg(), certification2.isLifeTmCertFlg())); // TODO Revise
//        certification1.setMeetsMocRequirementsFlg(Util.getDisjunction(certification1.isMeetsMocRequirementsFlg(), certification2.isMeetsMocRequirementsFlg())); // TODO Revise
        certification1.setRecertDt(Util.getMaxDate(certification1.getRecertDt(), certification2.getRecertDt()));
        certification1.setReverificationDt(Util.getMaxDate(certification1.getReverificationDt(), certification2.getReverificationDt()));
        certification1.setSourceSystemCd(Util.mergeString(certification1.getSourceSystemCd(), certification2.getSourceSystemCd()));
        certification1.setLogicalDeleteFlg(Util.getConjunction(certification1.getLogicalDeleteFlg(), certification2.getLogicalDeleteFlg()));
        certification1.setSourceSystemInsertDttm(Util.getMinLong(certification1.getSourceSystemInsertDttm(), certification2.getSourceSystemInsertDttm()));
        certification1.setSourceSystemUpdateDttm(Util.getMaxLong(certification1.getSourceSystemUpdateDttm(), certification2.getSourceSystemUpdateDttm()));
        return true;
    }
}
