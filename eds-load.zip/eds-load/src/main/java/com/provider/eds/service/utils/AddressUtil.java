package com.provider.eds.service.utils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.Phone;
import com.provider.eds.model.Constants;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AddressUtil {

    public static boolean equals(Address address1, Address address2) {
        if(Objects.isNull(address1))
            return Objects.isNull(address2);
        if(Objects.isNull(address2))
            return Objects.isNull(address1);

        return Objects.equals(address1.getAddressTypeCode(), address2.getAddressTypeCode()) &&
                Objects.equals(address1.getMtvAddrId(), address2.getMtvAddrId()) &&
                Objects.equals(address1.getSymfactAddrId(), address2.getSymfactAddrId()) &&
                Objects.equals(address1.getName(), address2.getName()) &&
                Objects.equals(address1.getAddressLine1(), address2.getAddressLine1()) &&
                Objects.equals(address1.getAddressLine2(), address2.getAddressLine2()) &&
                Objects.equals(address1.getAddressLine3(), address2.getAddressLine3()) &&
                Objects.equals(address1.getCity(), address2.getCity()) &&
                Objects.equals(address1.getStateCd(), address2.getStateCd()) &&
                Objects.equals(address1.getZipCd4(), address2.getZipCd4()) &&
                Objects.equals(address1.getZipCd5(), address2.getZipCd5() ) &&
                Objects.equals(address1.getEffDt(), address2.getEffDt());
    }

    public  static boolean merge(Address address1, Address address2) {
        if(! matches(address1,address2))
            return false;
        address1.setEndDt(Util.getMaxDate(address1.getEndDt(), address2.getEndDt()));
        address1.setLogicalDeleteFlg(Util.getConjunction(address1.getLogicalDeleteFlg(), address2.getLogicalDeleteFlg()));
        address1.setCounty(Util.mergeString(address1.getCounty(), address2.getCounty()));
        address1.setRegion(Util.mergeString(address1.getRegion(), address2.getRegion()));
        address1.setPrimaryFlag(Util.getDisjunction(address1.isPrimaryFlag(), address2.isPrimaryFlag()));
        address1.setMtvHandicapAccessFlg(Util.getDisjunction(address1.getMtvHandicapAccessFlg(), address2.getMtvHandicapAccessFlg()));

        if(CollectionUtils.isEmpty(address2.getOpvProviderPhone()))
            return true;
        address2.getOpvProviderPhone().stream().forEach(phone -> addPhone(address1,phone));
        return true;
    }


    public static boolean matches(Address address1,Address address2) {
        return equals(address1, address2 );
    }

    public static boolean hasMtvAddressId(Address address) {
        return StringUtils.hasText(address.getMtvAddrId());
    }

    private static void addPhone(Address address, Phone phone) {
        if(Objects.isNull(phone))
            return;
        if(CollectionUtils.isEmpty(address.getOpvProviderPhone()))
            address.setOpvProviderPhone(new ArrayList<>());
        for(Phone ph: address.getOpvProviderPhone()) {
            if(PhoneUtil.equals(ph, phone)) {
                PhoneUtil.merge(ph,phone);
                return;
            }
        }
        address.getOpvProviderPhone().add(phone);
    }


    public static boolean hasType(Address address, String type) {
        if(! StringUtils.hasText(type))
            return false;
        return type.trim().equalsIgnoreCase(address.getAddressTypeCode());
    }

    public static boolean isPracticeLocation(Address address) {
        return AddressUtil.hasType(address,Constants.A2_ADDRESS);
    }


    public static boolean hasMD5Hash(Address address) {
        return !Objects.isNull(address) && StringUtils.hasText(address.getAddrMd5Hash());
    }

    public static boolean hasMD5Hash(Address address,String md5) {
        if(! hasMD5Hash(address))
            return false;
        return address.getAddrMd5Hash().equals(md5);
    }
    public static List<String> getPhoneNumberStrings(Address address) {
        if(CollectionUtils.isEmpty(address.getOpvProviderPhone()))
            return null;
        return address.getOpvProviderPhone().stream().map(Phone::getPhoneNum).filter(StringUtils::hasText).distinct().collect(Collectors.toList());
    }


    public static boolean isValid(Address address) {
        return true;
        //return !address.logicalDeleteFlg;
    }

    public static boolean hasLogicalDeleteFlag(Address address,boolean logicalDeleteFlg) {
        return   Objects.isNull(address.getLogicalDeleteFlg()) ? (false == logicalDeleteFlg) : (address.getLogicalDeleteFlg() == logicalDeleteFlg);
    }

    public static boolean isActive(Address address) {
        return (Objects.isNull(address.getLogicalDeleteFlg()) ? false : address.getLogicalDeleteFlg()) == false;
    }



}
