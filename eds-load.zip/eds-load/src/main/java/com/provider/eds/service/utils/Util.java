package com.provider.eds.service.utils;

import com.provider.eds.model.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
public class Util {
    public static final String YYYY_MM_DD_HH_MM_SS_SSSSSSSSS = "yyyy-MM-dd HH:mm:ss.SSSSSSSSS";

    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static boolean hasValue(String field) {
        return Objects.nonNull(field) && (! field.isBlank());
    }
    public static <T> boolean hasList(List<T> list, Predicate<T> condition) {
        return nonEmpty(selectFromList(list, condition));
    }
    public static <T> List<T> selectFromList(List<T> list, Predicate<T> condition) {
        if(Objects.isNull(list) || list.isEmpty())
            return list;
        if(Objects.isNull(condition))
            return null;
        return list.stream().filter(condition).collect(Collectors.toList());
    }
    public static <T> boolean nonEmpty(List<T> list) {
        return ! nullOrEmpty(list);
    }
    public static boolean isActive(boolean logicalDeleteFlag, String endDate) {
        if(logicalDeleteFlag)
            return false;
        return hasNonExpiredEndDate(endDate, LocalDate.now().toString());
    }
    public static boolean hasNonExpiredEndDate(String endDate, String expirationDate) {
        if(endDate == null || endDate.isBlank()) {
            endDate = Constants.OPEN_END_DATE;
        }
        LocalDate expiryDate = null;
        LocalDate endDateFormatted=null;
        try {
            expiryDate= LocalDate.parse(expirationDate, formatter);
            endDateFormatted = LocalDate.parse(endDate, formatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return endDateFormatted.isAfter(expiryDate);
    }

    public static String convertContractTimeStamp(String timestamp) {
        try {
            return Timestamp.valueOf(LocalDateTime.parse(timestamp)).getTime()+"";
        } catch (Exception e) {
            return null;
        }
    }
    public static LocalDateTime parseTimeStamp(String timeStamp) {
        try{
            return LocalDateTime.ofInstant(Instant.ofEpochMilli(Long.parseLong(timeStamp)),TimeZone.getDefault().toZoneId());
        } catch( Exception e) {
            return null;
        }
    }
    public static Long strToLong(String str) {
        if(! StringUtils.hasText(str))
            return null;
        try {
            return Long.parseLong(str);
        } catch (Exception e) {
            return null;
        }
    }
    public static Long stringDateToLong(String dateString) {
        if(! StringUtils.hasText(dateString))
            return null;
        try {
            LocalDate resultDate= parseDate(dateString);
            Long resultLong= Objects.isNull(resultDate) ? null : resultDate.toEpochDay();
            return resultLong;
        } catch (Exception e) {
            return null;
        }
    }
    public static LocalDate parseDate(String dateString) {
        LocalDate date = null;
        try {
            date = LocalDate.parse(dateString, formatter);
        } catch (DateTimeParseException e) {
            log.info("Error parsing date.");
        } finally {
            return date;
        }
    }
    public static String getSmallerDate(String date1, String date2) {
        LocalDate localDate1= parseDate(date1);
        LocalDate localDate2= parseDate(date2);
        LocalDate result= getSmallerDate(localDate1, localDate2);
        return Objects.isNull(result) ? null : result.toString().substring(0, 10);
    }
    public static LocalDate getSmallerDate(LocalDate localDate1, LocalDate localDate2) {
        if(Objects.isNull(localDate1))
            return localDate2;
        if(Objects.isNull(localDate2))
            return localDate1;
        return localDate1.isBefore(localDate2) ? localDate1 : localDate2;
    }
    public static String getBiggerDate(String date1, String date2) {
        LocalDate localDate1= parseDate(date1);
        LocalDate localDate2= parseDate(date2);
        LocalDate result= getBiggerDate(localDate1, localDate2);
        return Objects.isNull(result) ? null : result.toString().substring(0, 10);
    }
    public static LocalDate getBiggerDate(LocalDate localDate1, LocalDate localDate2) {
        if(Objects.isNull(localDate1))
            return localDate2;
        if(Objects.isNull(localDate2))
            return localDate1;
        return localDate1.isAfter(localDate2) ? localDate1 : localDate2;
    }
    public static Boolean isBetweenDate(LocalDate d, LocalDate effDate, LocalDate endDate) {
        if(Objects.isNull(d) || Objects.isNull(effDate) || Objects.isNull(endDate)){
            return false;
        }

        if((d.isAfter(effDate) || d.isEqual(effDate)) && (d.isBefore(endDate) || d.isEqual(endDate))){
            return true;
        }
        return false;
    }
    public static LocalDate parseDateOrDefault(String dateString) {
        if(! StringUtils.hasText(dateString))
            dateString = Constants.OPEN_END_DATE;
        return parseDate(dateString);
    }

    public static <T> List<T> filterList(List<T> list, Predicate<T> condition) {
        if(Objects.isNull(list) || list.isEmpty())
            return list;
        return list.stream().filter(condition).collect(Collectors.toList());
    }
    public static <T> boolean isNonNullNonEmpty(List<T> list) {
        return (! nullOrEmpty(list));
    }
    public static <T> boolean nullOrEmpty(List<T> list) {
        return Objects.isNull(list) || list.isEmpty();
    }

    public static <T, String> List<String> filterFieldValues(List<T> list, Function<T, String> mapFunction) {
        return filterFieldValues(list, mapFunction, false);
    }
    public static <T, String> List<String> filterFieldValues(List<T> list, Function<T, String> mapFunction, boolean uniqueFlag) {
        if(Objects.isNull(list) || list.isEmpty())
            return null;
        List<String> stringList= list.stream().map(mapFunction).filter(item -> Objects.nonNull(item) && ! item.toString().isBlank()).collect(Collectors.toList());
        if(! uniqueFlag || nullOrEmpty(stringList))
            return stringList;

        return new ArrayList<>(new HashSet<String>(stringList));
    }

    public static boolean isProperDateString(String dateString) {
        if(Objects.isNull(dateString) || dateString.isBlank())
            return false;
        try {
            return Objects.nonNull(LocalDate.parse(dateString, formatter));
        } catch(DateTimeParseException e) {
            return false;
        }
    }
    public static boolean isDigits(String dateString) {
        if(Objects.isNull(dateString) || dateString.isBlank())
            return false;
        try {
            return Objects.nonNull(Long.parseLong (dateString));
        } catch (NumberFormatException e) {
            return false;
        }
    }
    public static String convertToDate(String intDate) {
        String calcDate = "";
        if (intDate == null) {
            return intDate;
        }
        calcDate = String.valueOf(LocalDate.ofEpochDay(Long.parseLong(intDate)));
        return calcDate;
    }

    public static LocalDate convertIntDateStrToLocalDate(String intDate) {
        String calcDate = "";
        if (intDate == null || intDate.isBlank() || ! isDigits(intDate)) {
            return null;
        }
        return LocalDate.ofEpochDay(Long.parseLong(intDate));
    }
    public static LocalDate convertDateStrToLocalDate(String dateString) {
        if(Objects.isNull(dateString) || dateString.isBlank())
            return null;
        try {
            return LocalDate.parse(dateString, formatter);
        } catch(DateTimeParseException e) {
            return null;
        }
    }
    public static String convertToTimeStamp(String intDate) {
        String calcDate = "";
        if (intDate == null) {
            return calcDate;
        }
        calcDate = String.valueOf(LocalDateTime.ofEpochSecond(Long.parseLong(intDate), 0 , ZoneOffset.UTC));
        return calcDate;
    }
    public static boolean convertStringToBoolean(String str) {
        if(! StringUtils.hasText(str))
            return false;
        try {
            return Boolean.parseBoolean(str);
        } catch (Exception e) {
            return false;
        }
    }


    public static boolean getConjunction(boolean operand1, boolean operand2) {
        return operand1 && operand2;
    }
    public static boolean getDisjunction(boolean operand1, boolean operand2) {
        return operand1 || operand2;
    }
    public static Boolean getDisjunction(Boolean operand1, Boolean operand2) {
        if(Objects.isNull(operand1))
            return operand2;
        if(Objects.isNull(operand2))
            return operand1;

        return operand1 || operand2;
    }
    public static Boolean getConjunction(Boolean operand1, Boolean operand2) {
        if(Objects.isNull(operand1))
            return operand2;
        if(Objects.isNull(operand2))
            return operand1;
        return operand1 && operand2;
    }
    public static String getMinDate(String date1, String date2) {
        LocalDate localDate1= parseToLocalDate(date1);
        LocalDate localDate2= parseToLocalDate(date2);
        if(Objects.isNull(localDate1))
            return date2;
        if(Objects.isNull(localDate2))
            return date1;
        return localDate1.isBefore(localDate2) ? date1 : date2;
    }

    public static String getMaxDate(String date1, String date2) {
        LocalDate localDate1= parseToLocalDate(date1);
        LocalDate localDate2= parseToLocalDate(date2);
        if(Objects.isNull(localDate1))
            return date2;
        if(Objects.isNull(localDate2))
            return date1;
        return localDate1.isAfter(localDate2) ? date1 : date2;
    }

    public static String getMinTimestamp(String timestamp1, String timestamp2) {
        Long dataOne= parseToLong(timestamp1);
        Long dataTwo= parseToLong(timestamp2);
        if(Objects.isNull(dataOne))
            return timestamp2;
        if(Objects.isNull(dataTwo))
            return timestamp1;
        return dataOne.compareTo(dataTwo) > 1 ? timestamp2 : timestamp1;
    }
    public static Long getMinLong(Long timestamp1, Long timestamp2) {
        if(Objects.isNull(timestamp1))
            return timestamp2;
        if(Objects.isNull(timestamp2))
            return timestamp1;
        return Long.min(timestamp1, timestamp2);
    }
    public static Long getMaxLong(Long timestamp1, Long timestamp2) {
        if(Objects.isNull(timestamp1))
            return timestamp2;
        if(Objects.isNull(timestamp2))
            return timestamp1;
        return Long.max(timestamp1, timestamp2);
    }

    public static String getMaxTimestamp(String timestamp1, String timestamp2) {
        Long dataOne= parseToLong(timestamp1);
        Long dataTwo= parseToLong(timestamp2);
        if(Objects.isNull(dataOne))
            return timestamp2;
        if(Objects.isNull(dataTwo))
            return timestamp1;
        return dataOne.compareTo(dataTwo) > 1 ? timestamp1 : timestamp2;
    }
    public static String mergeString(String existingString, String newString) {
        if(Objects.isNull(existingString))
            return newString;
        if(Objects.isNull(newString) || (! StringUtils.hasText(newString)))
            return existingString;

        return newString;
    }
    private static Long parseToLong(String dataOrDateTime) {
        try {
            return Long.parseLong(dataOrDateTime);
        } catch(NumberFormatException e) {
            return null;
        }
    }
    private static LocalDate parseToLocalDate(String date) {
        try {
            return LocalDate.parse(date);
        } catch (Throwable throwable) {
            return null;
        }
    }

    public static Set<String> getSetDifference(Set<String> newSet, Set<String> oldSet) {
        Set<String> resultSet= new HashSet<>();
        if(CollectionUtils.isEmpty(oldSet))
            return resultSet;
        if(CollectionUtils.isEmpty(newSet))
            return CollectionUtils.isEmpty(oldSet) ? resultSet : oldSet;

        for(String oldVal: oldSet) {
            if(! newSet.contains(oldVal))
                resultSet.add(oldVal);
        }
        return resultSet;
    }

}