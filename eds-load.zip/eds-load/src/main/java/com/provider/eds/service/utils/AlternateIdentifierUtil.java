package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.AlternateIdentifier;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.StringUtils;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlternateIdentifierUtil {


    public static boolean isActive(AlternateIdentifier alternateIdentifier) {
        return alternateIdentifier.getLogicalDeleteFlg() == false;
    }

    public static boolean equals(AlternateIdentifier alternateIdentifier1, AlternateIdentifier alternateIdentifier2) {
        if (Objects.isNull(alternateIdentifier1))
            return Objects.isNull(alternateIdentifier2);
        if (Objects.isNull(alternateIdentifier2))
            return Objects.isNull(alternateIdentifier1);
        return Objects.equals(alternateIdentifier1.getAlternateId(), alternateIdentifier2.getAlternateId()) &&
                Objects.equals(alternateIdentifier1.getAlternateIdTypeCd(), alternateIdentifier2.getAlternateIdTypeCd()) &&
                Objects.equals(alternateIdentifier1.getEffDt(), alternateIdentifier2.getEffDt());
    }

    public static boolean isValid(AlternateIdentifier alternateIdentifier) {
        return true;
        //return !alternateIdentifier.logicalDeleteFlg;
    }

    public static boolean hasType(AlternateIdentifier alternateIdentifier,String type) {
        return ( ! StringUtils.hasText(type)) ? alternateIdentifier.getAlternateIdTypeCd() == type : type.trim().equalsIgnoreCase(alternateIdentifier.getAlternateIdTypeCd());
    }

    public static boolean hasAlternateId(AlternateIdentifier alternateIdentifier,String alternateId) {
        return ( ! StringUtils.hasText(alternateId)) ? alternateIdentifier.getAlternateId() == alternateId : alternateId.trim().equalsIgnoreCase(alternateIdentifier.getAlternateId());
    }

    public static boolean hasEffectiveDate(AlternateIdentifier alternateIdentifier, String effDt) {
        return (!StringUtils.hasText(effDt)) ? alternateIdentifier.getEffDt() == effDt : effDt.trim().equalsIgnoreCase(alternateIdentifier.getEffDt());
    }

    public static boolean hasEndDate(AlternateIdentifier alternateIdentifier, String endDt) {
        return (!StringUtils.hasText(endDt)) ? alternateIdentifier.getEndDt() == endDt : endDt.trim().equalsIgnoreCase(alternateIdentifier.getEndDt());
    }

    public static boolean hasLogicalDeleteFlag(AlternateIdentifier alternateIdentifier, boolean logicalDeleteFlg) {
        return Objects.isNull(alternateIdentifier.getLogicalDeleteFlg()) ? !logicalDeleteFlg : alternateIdentifier.getLogicalDeleteFlg() == logicalDeleteFlg;
    }

    public static boolean isTaxEntity(AlternateIdentifier alternateIdentifier) {
        return "TAX".equalsIgnoreCase(alternateIdentifier.getAlternateIdTypeCd());
    }


    public static boolean matches(AlternateIdentifier alternateIdentifier1, AlternateIdentifier alternateIdentifier2) {
        return equals(alternateIdentifier1, alternateIdentifier2);
    }

    public static boolean merge(AlternateIdentifier alternateIdentifier1, AlternateIdentifier alternateIdentifier2) {
        if (!matches(alternateIdentifier1, alternateIdentifier2))
            return false;
        alternateIdentifier1.setEndDt(Util.getMaxDate(alternateIdentifier1.getEndDt(), alternateIdentifier2.getEndDt()));
        alternateIdentifier1.setIssuingStateCd(Util.mergeString(alternateIdentifier1.getIssuingStateCd(), alternateIdentifier2.getIssuingStateCd()));
        alternateIdentifier1.setEntityName(Util.mergeString(alternateIdentifier1.getEntityName(), alternateIdentifier2.getEntityName()));
        alternateIdentifier1.setLogicalDeleteFlg(Util.getConjunction(alternateIdentifier1.getLogicalDeleteFlg(), alternateIdentifier2.getLogicalDeleteFlg()));
        alternateIdentifier1.setSourceSystemCd(Util.mergeString(alternateIdentifier1.getSourceSystemCd(), alternateIdentifier2.getSourceSystemCd()));
        alternateIdentifier1.setSourceSystemInsertDttm(Util.getMinLong(alternateIdentifier1.getSourceSystemInsertDttm(), alternateIdentifier2.getSourceSystemInsertDttm()));
        alternateIdentifier1.setSourceSystemUpdateDttm(Util.getMaxLong(alternateIdentifier1.getSourceSystemUpdateDttm(), alternateIdentifier2.getSourceSystemUpdateDttm()));
        return true;
    }

    public static boolean isVoided(AlternateIdentifier alternateIdentifier) {
        return Objects.nonNull(alternateIdentifier.getLogicalDeleteFlg()) && alternateIdentifier.getLogicalDeleteFlg() == true;
    }

    public static boolean hasMtvProviderCategoryCd(AlternateIdentifier alternateIdentifier,String category) {
        if(! StringUtils.hasText(category) )
            return alternateIdentifier.getMtvProviderCategoryCd() == category;
        return category.trim().equalsIgnoreCase(alternateIdentifier.getMtvProviderCategoryCd());
    }
}
