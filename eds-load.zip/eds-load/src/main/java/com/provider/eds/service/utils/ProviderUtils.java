package com.provider.eds.service.utils;

import com.medica.model.eds.provider.*;
import com.provider.eds.model.Constants;
import com.provider.eds.model.PracticeLocation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.provider.eds.service.utils.CloningUtils.*;

@Service
@Slf4j
public class ProviderUtils {


    public List<Address> getMD5s(Provider provider){
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return new ArrayList<>();
        return provider.getOpvProviderAddress().stream()
                .filter(addr -> AddressUtil.hasMD5Hash(addr) && Constants.A2_ADDRESS.equals(addr.getAddressTypeCode())).collect(Collectors.toList());

    }

    public List<AlternateIdentifier> getNPI1s(Provider provider){
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()))
            return new ArrayList<>();
        return provider.getOpvProviderAlternateId().stream().filter(p-> AlternateIdentifierUtil.hasType(p,Constants.NPI1)).collect(Collectors.toList());

    }

    public List<AlternateIdentifier> getTAXTypes(Provider provider){
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()))
            return new ArrayList<>();
        return  provider.getOpvProviderAlternateId().stream().filter(p->AlternateIdentifierUtil.hasType(p,Constants.TAX)).collect(Collectors.toList());

    }

    public Set<String> getSelfAndAffiliatedMTVProviderIds(Provider provider) {
        Set<String> resultList= new HashSet<>();
        if(Objects.isNull(provider))
            return resultList;
        resultList.add(provider.getProviderId());
        Set<String> affliationMtvIds= ProviderUtil.getAffiliationRelatedMtvProvIds(provider);
        if(! CollectionUtils.isEmpty(affliationMtvIds))
            resultList.addAll(affliationMtvIds);
        return resultList
            .stream()
            .filter(s -> Objects.nonNull(s) && StringUtils.hasText(s))
            .map(s -> s.trim()+ provider.getSourceSystemCd())
            .collect(Collectors.toSet());
    }


    public boolean hasFullfilledDependencies(Provider provider, List<Provider> relatedAfflContrctProvidersList) {
        Set<String> affliationRelatedMtvProvIds= ProviderUtil.getAffiliationRelatedMtvProvIds(provider);
        if(CollectionUtils.isEmpty(affliationRelatedMtvProvIds))
            affliationRelatedMtvProvIds= new HashSet<>();
        affliationRelatedMtvProvIds= affliationRelatedMtvProvIds.stream().map(s -> s+ provider.getSourceSystemCd()).collect(Collectors.toSet());
        if(CollectionUtils.isEmpty(relatedAfflContrctProvidersList))
            return CollectionUtils.isEmpty(affliationRelatedMtvProvIds);
        boolean flag= relatedAfflContrctProvidersList
                .stream()
                .filter(Objects::nonNull)
                .map(prov -> prov.getProviderId() + provider.getSourceSystemCd())
                .collect(Collectors.toSet())
                .containsAll(affliationRelatedMtvProvIds);
        return flag;
    }

    public Map<String, Provider> makeProvidersMap(List<Provider> providerList) {
        if(CollectionUtils.isEmpty(providerList))
            return new HashMap<>();
        final String sourceSystem= providerList.stream().findFirst().get().getSourceSystemCd();
        return providerList.stream().collect(Collectors.toMap(prov -> prov.getProviderId()+sourceSystem, prov -> prov));
    }

    public ArrayList<Affiliation> buildAffiliation(Provider provider, Map<String, Provider> relatedProviders) {
        ArrayList<Affiliation> resultAffiliation= new ArrayList<>();

        if(Objects.isNull(provider) || Objects.isNull(provider.getOpvProviderAffiliation()) || provider.getOpvProviderAffiliation().isEmpty()){
            provider.setOpvProviderAffiliation(resultAffiliation);
            return resultAffiliation;
        }

        for(Affiliation affiliation: provider.getOpvProviderAffiliation()) {
            if(! StringUtils.hasText(affiliation.getMtvAffiliateProviderId()) || ! StringUtils.hasText(affiliation.getAffiliateProviderIdType())){
                continue;
            }

            Provider mtvProvider= relatedProviders.get(affiliation.getMtvAffiliateProviderId()+"MTV");

            if(Objects.isNull(mtvProvider)) {
                continue;
            }

            if(!Objects.isNull(affiliation.getAffiliationType())) {
                if(affiliation.getAffiliationType().equalsIgnoreCase("HOSP")) {
                    Predicate<Address> addressPredicate= address -> AddressUtil.hasType(address,"A2");
                    addressPredicate= addressPredicate.and(address -> AddressUtil.hasMD5Hash(address));
                    List<Address> physicalAddresses= ProviderUtil.getAddresses(mtvProvider,addressPredicate);

                    if(Objects.nonNull(physicalAddresses) && ! physicalAddresses.isEmpty()) {
                        physicalAddresses
                                .stream()
                                .forEach(address -> {
                                    LocalDate addressEffDate = Util.parseDateOrDefault(address.getEffDt());
                                    LocalDate addressEndDate = Util.parseDateOrDefault(address.getEndDt());
                                    LocalDate afflEffDate = Util.parseDateOrDefault(affiliation.getEffDt());
                                    LocalDate afflEndDate = Util.parseDateOrDefault(affiliation.getEndDt());

                                    if((Util.isBetweenDate(afflEndDate, addressEffDate, addressEndDate) || Util.isBetweenDate(addressEndDate, afflEffDate, afflEndDate))
                                            && (Util.isBetweenDate(afflEffDate, addressEffDate, addressEndDate) || Util.isBetweenDate(addressEffDate, afflEffDate, afflEndDate))) {
                                        Affiliation tempAffil = cloneAffiliation(affiliation, "MD5", address.getAddrMd5Hash(),
                                                List.of(addressEffDate, afflEffDate), List.of(addressEndDate, afflEndDate), (Objects.isNull(address.getLogicalDeleteFlg())? false : address.getLogicalDeleteFlg()));
                                        resultAffiliation.add(tempAffil);
                                    }
                                });
                    }
                }
                else{
                    List<AlternateIdentifier> providerAlternateIds = ProviderUtil.getAlternateIds(mtvProvider,alternateIdentifier -> AlternateIdentifierUtil.hasType(alternateIdentifier,"TAX"));

                    if(Objects.nonNull(providerAlternateIds) && ! providerAlternateIds.isEmpty()) {
                        providerAlternateIds
                                .stream()
                                .forEach(altId -> {
                                    LocalDate altEffDate  = Util.parseDateOrDefault(altId.getEffDt());
                                    LocalDate altEndDate  = Util.parseDateOrDefault(altId.getEndDt());
                                    LocalDate afflEffDate = Util.parseDateOrDefault(affiliation.getEffDt());
                                    LocalDate afflEndDate = Util.parseDateOrDefault(affiliation.getEndDt());

                                    if((Util.isBetweenDate(afflEndDate, altEffDate, altEndDate) || Util.isBetweenDate(altEndDate, afflEffDate, afflEndDate))
                                            && (Util.isBetweenDate(afflEffDate, altEffDate, altEndDate) || Util.isBetweenDate(altEffDate, afflEffDate, afflEndDate))) {
                                        Affiliation tempAffil = cloneAffiliation(affiliation, "TAX", altId.getAlternateId(),
                                                List.of(altEffDate, afflEffDate), List.of(altEndDate, afflEndDate), altId.getLogicalDeleteFlg());
                                        resultAffiliation.add(tempAffil);
                                    }
                                });
                    }
                }
            }
        }
        provider.setOpvProviderAffiliation(resultAffiliation);
        return resultAffiliation;
    }

    public ArrayList<Network> buildNetwork(Provider provider, Map<String, List<PracticeLocation>> practiceLocationMap) {

        ArrayList<Network> resultNetwork= new ArrayList<>();

        if(Objects.isNull(provider) || Objects.isNull(practiceLocationMap) || practiceLocationMap.isEmpty() || (! ProviderUtil.hasNetworkDirectory(provider))){
            provider.setOpvProviderNetworkDirectory(resultNetwork);
            return resultNetwork;
        }

        provider.getOpvProviderNetworkDirectory().stream().forEach(network -> {
            List<PracticeLocation> practiceLocations=practiceLocationMap.get(network.getPraclocProviderId());

            if(! CollectionUtils.isEmpty(practiceLocations)){
                practiceLocations
                    .stream()
                    .forEach(pracLoc ->
                            resultNetwork.add(cloneNetwork(network, "MD5", pracLoc.getMd5Hash(), pracLoc.getMtvProviderId(), pracLoc.isLogicalDeleteFlg())));
            }
        });

        provider.setOpvProviderNetworkDirectory(resultNetwork);
        return resultNetwork;
    }




    public void buildPanel(Provider provider, Map<String, List<PracticeLocation>> practiceLocationMap) {
        List<Panel> panelList= new ArrayList<>();
        if(Objects.isNull(provider) || Objects.isNull(practiceLocationMap) || practiceLocationMap.isEmpty() || (! ProviderUtil.hasPanels(provider))){
            provider.setOpvProviderPanel(panelList);
            return;
        }
        provider.getOpvProviderPanel().stream().filter(pl -> Constants.MTV.equalsIgnoreCase(pl.getPracLocProviderIdType())).forEach(panel -> {
            List<PracticeLocation> practiceLocations= practiceLocationMap.get(panel.getPracLocProviderId());
            if(! CollectionUtils.isEmpty(practiceLocations)) {
                practiceLocations
                    .stream()
                    .forEach(practLoc ->
                        panelList.add(clonePanel(panel, practLoc.getMtvProviderId(), practLoc.isLogicalDeleteFlg(), practLoc.getMd5Hash()) ));
            }
        });
        provider.setOpvProviderPanel(panelList);
    }



    public boolean hasTaxUpdate(Provider newProvider, Provider existingProvider ) {
        if(Objects.isNull(newProvider) && Objects.isNull(existingProvider))
            return false;
        if(Objects.isNull(newProvider))
            return true;
        if(Objects.isNull(existingProvider))
            return true;
        if(Objects.isNull(newProvider.getProviderId()) || Objects.isNull(existingProvider.getProviderId()))
            return false;
        if(! newProvider.getProviderId().equalsIgnoreCase(existingProvider.getProviderId()))
            return false;
        List<AlternateIdentifier> existingTaxEntities= Util.filterList(existingProvider.getOpvProviderAlternateId(), AlternateIdentifierUtil::isTaxEntity);
        List<AlternateIdentifier> newTaxEntities= Util.filterList(newProvider.getOpvProviderAlternateId(), AlternateIdentifierUtil::isTaxEntity);
        existingTaxEntities= CollectionUtils.isEmpty(existingTaxEntities) ? new ArrayList<>() : existingTaxEntities;
        newTaxEntities= CollectionUtils.isEmpty(newTaxEntities) ? new ArrayList<>() : newTaxEntities;
        if(existingTaxEntities.isEmpty() && newTaxEntities.isEmpty())
            return false;
        if((existingTaxEntities.isEmpty() && (! newTaxEntities.isEmpty() ) || (existingTaxEntities.size() != newTaxEntities.size())))
            return true;
        for(AlternateIdentifier currTax: newTaxEntities) {
            List<AlternateIdentifier> resultList= Util.filterList(existingTaxEntities, alt->
                 AlternateIdentifierUtil.hasEffectiveDate(alt, currTax.getEffDt()) &&
                         AlternateIdentifierUtil.hasEndDate(alt, currTax.getEndDt()) &&
                         AlternateIdentifierUtil.hasAlternateId(alt, currTax.getAlternateId()) &&
                         AlternateIdentifierUtil.hasLogicalDeleteFlag(alt, currTax.getLogicalDeleteFlg())
            );
            if( CollectionUtils.isEmpty(resultList))
                return true;
        }
        return false;
    }
    public boolean hasSiteMD5Update(Provider newProvider, Provider existingProvider ) {
        if(Objects.isNull(newProvider) && Objects.isNull(existingProvider))
            return false;
        if(Objects.isNull(newProvider))
            return true;
        if(Objects.isNull(existingProvider))
            return true;
        if(Objects.isNull(newProvider.getProviderId()) || Objects.isNull(existingProvider.getProviderId()))
            return false;
        if(! newProvider.getProviderId().equalsIgnoreCase(existingProvider.getProviderId()))
            return false;
        List<Address> existingPractLocEntities= Util.filterList(existingProvider.getOpvProviderAddress(), AddressUtil::hasMD5Hash);
        List<Address> newPractLocEntities= Util.filterList(newProvider.getOpvProviderAddress(), AddressUtil::hasMD5Hash);
        existingPractLocEntities= CollectionUtils.isEmpty(existingPractLocEntities) ? new ArrayList<>() : existingPractLocEntities;
        newPractLocEntities= CollectionUtils.isEmpty(newPractLocEntities) ? new ArrayList<>() : newPractLocEntities;
        if(existingPractLocEntities.isEmpty() && newPractLocEntities.isEmpty())
            return false;
        if((existingPractLocEntities.isEmpty() && (! newPractLocEntities.isEmpty() ) || (existingPractLocEntities.size() != newPractLocEntities.size())))
            return true;
        for(Address currAdd: newPractLocEntities) {
            List<Address> resultList= Util.filterList(existingPractLocEntities, add->
                    AddressUtil.hasMD5Hash(add, currAdd.getAddrMd5Hash()) && AddressUtil.hasLogicalDeleteFlag(add, currAdd.getLogicalDeleteFlg())
            );
            if( CollectionUtils.isEmpty(resultList))
                return true;
        }
        return false;
    }

}
