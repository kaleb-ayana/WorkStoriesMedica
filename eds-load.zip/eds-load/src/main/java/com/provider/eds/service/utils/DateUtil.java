package com.provider.eds.service.utils;

import com.medica.model.eds.provider.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.time.LocalDate;
import java.util.Objects;

@Slf4j
public class DateUtil {
    public static void stringfyDates(Provider provider) {
        if(Objects.isNull(provider))
            return;
        provider.setEffDate(convertToDate(provider.getEffDate()));
        provider.setTermDt(convertToDate(provider.getTermDt()));
        provider.setDirectorySuppressDt(convertToDate(provider.getDirectorySuppressDt()));
        provider.setDirectoryDivisionEffDt(convertToDate(provider.getDirectoryDivisionEffDt()));
        provider.setW9Dt(convertToDate(provider.getW9Dt()));
        provider.setMocCompletedDt(provider.getMocCompletedDt());
        strinfyDates(provider.getDmeOps());
        if(! CollectionUtils.isEmpty(provider.getOpvProviderPanel()))
            provider.getOpvProviderPanel().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory()))
            provider.getOpvProviderNetworkDirectory().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderRemarks()))
            provider.getOpvProviderRemarks().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderTaxonomy()))
            provider.getOpvProviderTaxonomy().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderAffiliation()))
            provider.getOpvProviderAffiliation().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderLicence()))
            provider.getOpvProviderLicence().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderCertification()))
            provider.getOpvProviderCertification().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            provider.getOpvProviderAddress().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderSpecialty()))
            provider.getOpvProviderSpecialty().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()))
            provider.getOpvProviderAlternateId().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderEducation()))
            provider.getOpvProviderEducation().stream().forEach(item -> strinfyDates(item));
        if(! CollectionUtils.isEmpty(provider.getGlobalBillings()))
            provider.getGlobalBillings().stream().forEach(item -> strinfyDates(item));
    }

    public static void strinfyDates(DmeOps item) {
        if(Objects.isNull(item))
            return;
        item.setIssueDt(convertToDate(item.getIssueDt()));
        item.setTermDt(convertToDate(item.getTermDt()));
    }
    public static void strinfyDates(Panel item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(Network item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
        item.setDirectorySuppressDt(convertToDate(item.getDirectorySuppressDt()));
    }
    public static void strinfyDates(Remark item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(Taxonomy item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(Affiliation item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
        if(! CollectionUtils.isEmpty(item.getAffiliationSpecialtyList()))
            item.getAffiliationSpecialtyList().stream().forEach(affiliationSpecialty -> strinfyDates(affiliationSpecialty));
    }

    public static void strinfyDates(AffiliationSpecialty item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(License item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(Certification item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
        item.setReverificationDt(convertToDate(item.getReverificationDt()));
        item.setRecertDt(convertToDate(item.getRecertDt()));
    }
    public static void strinfyDates(Address item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(Specialty item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(AlternateIdentifier item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }
    public static void strinfyDates(Education item) {
        if(Objects.isNull(item))
            return;
        item.setEffDt(convertToDate(item.getEffDt()));
        item.setEndDt(convertToDate(item.getEndDt()));
    }

    public static void strinfyDates(GlobalBilling item) {
        if(Objects.isNull(item))
            return;
        item.setDirectoryDt(convertToDate(item.getDirectoryDt()));
        item.setTermDt(convertToDate(item.getTermDt()));
        item.setDirectorySuppressDt(convertToDate(item.getDirectorySuppressDt()));
        item.setMspDt(convertToDate(item.getMspDt()));
        item.setMecDt(convertToDate(item.getMecDt()));
    }

    public static String convertToDate(String intDate) {
        if (Objects.isNull(intDate) ||  (! isDigits(intDate))) {
            return intDate;
        }

        return String.valueOf(LocalDate.ofEpochDay(Long.parseLong(intDate)));
    }
    private static boolean isDigits(String dateString) {
        if(Objects.isNull(dateString) || dateString.isBlank())
            return false;
        try {
            return Objects.nonNull(Long.parseLong (dateString));
        } catch (NumberFormatException e) {
            return false;
        }
    }

}
