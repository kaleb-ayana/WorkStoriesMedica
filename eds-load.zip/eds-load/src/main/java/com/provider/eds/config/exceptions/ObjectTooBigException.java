package com.provider.eds.config.exceptions;

public class ObjectTooBigException extends Exception{
    public ObjectTooBigException() {
        super();
    }
    public ObjectTooBigException(String message) {
        super(message);
    }
}
