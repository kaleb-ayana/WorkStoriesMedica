package com.provider.eds.service;

import com.medica.model.eds.common.ProviderNotification;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.config.GsonCustomBuilder;
import com.provider.eds.model.Constants;
import com.provider.eds.model.ProviderCategoryCd;
import com.provider.eds.model.ProviderIdType;
import com.provider.eds.service.utils.AddressUtil;
import com.provider.eds.service.utils.AlternateIdentifierUtil;
import com.provider.eds.service.utils.ProviderNotificationEvaluator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.medica.model.eds.common.ProviderNotification.createNotification;


@Slf4j
@Component
public class UpdateNotificationService {

    @Value(value = "${schema-version}")
    private String schemaVersion;

    @Autowired
    private ProviderNotificationEvaluator providerNotificationEvaluator;

    @Autowired
    @Qualifier("kafkaTemplateProviderNotification")
    public KafkaTemplate<String, String> kafkaTemplateProviderNotification;

    @Value(value = "${topics.provider.notification.outbound}")
    private String providerNotificationTopic;


    public ListenableFuture produceProviderNotificationTopicMessage(ProviderNotification provider, String topic) {
        return kafkaTemplateProviderNotification.send( topic, provider.getPROVIDER_ID(), GsonCustomBuilder.getGsonCustomAdapter().toJson(provider, ProviderNotification.class));
    }

    public ListenableFuture produceProviderNotificationTopicMessage(ProviderNotification provider) {
        return this.produceProviderNotificationTopicMessage(provider, providerNotificationTopic);
    }

    public List<ProviderNotification> processProviderNotificationMessage(Provider provider) {
        List<ProviderNotification> resultList= new ArrayList<>();
        if(Objects.isNull(provider) )
            return resultList;
        if(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS) &&  providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.NPI2) &&  providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(provider, Constants.TAX))        {
            providerNotificationEvaluator.getNonVoidedAlternateIdTypeOf(provider, Constants.TAX)
                    .stream()
                    .forEach(alt ->
                            resultList.add(createNotification(provider.getProviderId(), provider.getSourceSystemCd(), alt.getAlternateId(), ProviderIdType.TAX.toString(), ProviderCategoryCd.PAYTO.toString(), alt.getLogicalDeleteFlg(), alt.getLogicalDeleteFlg(), this.schemaVersion)));
        }
        if(this.providerNotificationEvaluator.isPractitionerCandidate(provider)) {
            provider.getOpvProviderAlternateId()
                    .stream()
                    .filter(alternateIdentifier -> AlternateIdentifierUtil.hasType(alternateIdentifier,Constants.NPI1) && AlternateIdentifierUtil.isActive(alternateIdentifier) )
                    .forEach(alt-> resultList.add(createNotification(provider.getProviderId(), provider.getSourceSystemCd(),alt.getAlternateId(),
                            ProviderIdType.NPI1.toString(),
                            ProviderCategoryCd.PRACT.toString(),
                            alt.getLogicalDeleteFlg(),false, this.schemaVersion)));
        }
        if(this.providerNotificationEvaluator.isLocationCandidate(provider))
            provider.getOpvProviderAddress()
                    .stream()
                    .filter(address -> AddressUtil.hasMD5Hash(address))
                    .forEach(address -> {
                        resultList.add(createNotification(provider.getProviderId(), provider.getSourceSystemCd(),address.getAddrMd5Hash(),
                                ProviderIdType.MD5.toString(),
                                ProviderCategoryCd.SITE.toString(),
                                address.getLogicalDeleteFlg(), false, this.schemaVersion));
                    });

        return resultList;
    }

}