package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.model.PracticeLocation;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PracticeLocationUtil {
    public static List<PracticeLocation> buildPracticeLocations(Provider provider, String practLocId) {
        List<PracticeLocation> resPracLocs = new ArrayList<>();
        List<String> matchingMd5Hashes = ProviderUtil.getMD5s(provider,practLocId);
        if (CollectionUtils.isEmpty(matchingMd5Hashes))
            return resPracLocs;
        for (String md5 : matchingMd5Hashes) {
            PracticeLocation practiceLocation = new PracticeLocation();
            practiceLocation.setLogicalDeleteFlg(provider.getLogicalDeleteFlg());
            practiceLocation.setPractLocId(practLocId);
            practiceLocation.setMd5Hash(md5);
            practiceLocation.setMtvProviderId(provider.getProviderId());
            practiceLocation.setSourceSystemCd(provider.getSourceSystemCd());
            resPracLocs.add(practiceLocation);
        }
        return resPracLocs;
    }

    public static PracticeLocation buildPracticeLocation(Provider provider, Address address) {
        PracticeLocation practiceLocation = new PracticeLocation();
        practiceLocation.setLogicalDeleteFlg(Objects.isNull(provider.getLogicalDeleteFlg()) ? false: provider.getLogicalDeleteFlg());
        practiceLocation.setPractLocId(address.getMtvAddrId());
        practiceLocation.setMd5Hash(address.getAddrMd5Hash());
        practiceLocation.setMtvProviderId(provider.getProviderId());
        practiceLocation.setSourceSystemCd(provider.getSourceSystemCd());
        return practiceLocation;
    }
}
