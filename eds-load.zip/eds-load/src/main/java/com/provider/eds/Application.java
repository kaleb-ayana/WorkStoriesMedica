package com.provider.eds;

import com.azure.spring.data.cosmos.repository.config.EnableReactiveCosmosRepositories;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.provider.eds", "com.medica.reference"})
@EnableReactiveCosmosRepositories({"com.provider.eds.repository", "com.medica.reference.repository", "com.medica.reference.contract.repository"})
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
