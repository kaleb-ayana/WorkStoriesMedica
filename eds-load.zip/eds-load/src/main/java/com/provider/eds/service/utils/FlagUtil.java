package com.provider.eds.service.utils;

import com.medica.model.eds.provider.*;
import org.springframework.util.CollectionUtils;

import java.util.Objects;

public class FlagUtil {
    public static void defaultFlagValue(Provider provider) {
        if(Objects.isNull(provider))
            return;
        provider.setLogicalDeleteFlg(getOrDefault(provider.getLogicalDeleteFlg()));
        if(!CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            provider.getOpvProviderAddress().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderAffiliation()))
            provider.getOpvProviderAffiliation().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()))
            provider.getOpvProviderAlternateId().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderCertification()))
            provider.getOpvProviderCertification().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderDegree()))
            provider.getOpvProviderDegree().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderElectronicAddress()))
            provider.getOpvProviderElectronicAddress().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderLanguage()))
            provider.getOpvProviderLanguage().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderLicence()))
            provider.getOpvProviderLicence().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory()))
            provider.getOpvProviderNetworkDirectory().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderPanel()))
            provider.getOpvProviderPanel().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderRemarks()))
            provider.getOpvProviderRemarks().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderSpecialty()))
            provider.getOpvProviderSpecialty().stream().forEach(FlagUtil::defaultFlagValue);
        if(!CollectionUtils.isEmpty(provider.getOpvProviderTaxonomy()))
            provider.getOpvProviderTaxonomy().stream().forEach(FlagUtil::defaultFlagValue);


    }

    public static void defaultFlagValue(Taxonomy taxonomy) {
        if(Objects.isNull(taxonomy))
            return;
        taxonomy.setLogicalDeleteFlg(getOrDefault(taxonomy.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(Specialty specialty) {
        if(Objects.isNull(specialty))
            return;
        specialty.setLogicalDeleteFlg(getOrDefault(specialty.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(Remark remark) {
        if(Objects.isNull(remark))
            return;
        remark.setLogicalDeleteFlg(getOrDefault(remark.getLogicalDeleteFlg()));
    }

    public static void defaultFlagValue(Panel panel) {
        if(Objects.isNull(panel))
            return;
        panel.setLogicalDeleteFlg(getOrDefault(panel.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(Network network) {
        if(Objects.isNull(network))
            return;
        network.setLogicalDeleteFlg(getOrDefault(network.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(License license) {
        if(Objects.isNull(license))
            return;
        license.setLogicalDeleteFlg(getOrDefault(license.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(Language language) {
        if(Objects.isNull(language))
            return;
        language.setLogicalDeleteFlg(getOrDefault(language.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(ElectronicAddress electronicAddress) {
        if(Objects.isNull(electronicAddress))
            return;
        electronicAddress.setLogicalDeleteFlg(getOrDefault(electronicAddress.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(Degree degree) {
        if(Objects.isNull(degree))
            return;
        degree.setLogicalDeleteFlg(getOrDefault(degree.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(Certification certification) {
        if(Objects.isNull(certification))
            return;
        certification.setLogicalDeleteFlg(getOrDefault(certification.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(AlternateIdentifier alternateIdentifier) {
        if(Objects.isNull(alternateIdentifier))
            return;
        alternateIdentifier.setLogicalDeleteFlg(getOrDefault(alternateIdentifier.getLogicalDeleteFlg()));
    }

    public static void defaultFlagValue(Affiliation affiliation) {
        if(Objects.isNull(affiliation))
            return;
        affiliation.setLogicalDeleteFlg(getOrDefault(affiliation.getLogicalDeleteFlg()));
        if(! CollectionUtils.isEmpty(affiliation.getAffiliationSpecialtyList()))
            affiliation.getAffiliationSpecialtyList().stream().forEach(FlagUtil::defaultFlagValue);
    }
    public static void defaultFlagValue(AffiliationSpecialty affiliationSpecialty) {
        if(Objects.isNull(affiliationSpecialty))
            return;
        affiliationSpecialty.setLogicalDeleteFlg(getOrDefault(affiliationSpecialty.getLogicalDeleteFlg()));
    }
    public static void defaultFlagValue(Address address) {
        if(Objects.isNull(address))
            return;
        address.setLogicalDeleteFlg(getOrDefault(address.getLogicalDeleteFlg()));
        if(! CollectionUtils.isEmpty(address.getOpvProviderPhone()))
            address.getOpvProviderPhone().stream().forEach(FlagUtil::defaultFlagValue);
    }
    public static void defaultFlagValue(Phone phone) {
        if(Objects.isNull(phone))
            return;
        phone.setLogicalDeleteFlg(getOrDefault(phone.getLogicalDeleteFlg()));
    }
    public static boolean getOrDefault(Boolean flag) {
        return Objects.isNull(flag) ? false : flag.booleanValue();
    }
}
