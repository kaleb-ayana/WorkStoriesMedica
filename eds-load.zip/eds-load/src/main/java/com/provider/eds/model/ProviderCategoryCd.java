package com.provider.eds.model;

public enum ProviderCategoryCd {
    PAYTO,
    SITE,
    PRACT;
}
