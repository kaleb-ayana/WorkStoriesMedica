package com.provider.eds.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PracticeLocation {
    protected String mtvProviderId;
    protected String sourceSystemCd;
    protected String md5Hash;
    protected String practLocId;
    protected boolean logicalDeleteFlg;

}
