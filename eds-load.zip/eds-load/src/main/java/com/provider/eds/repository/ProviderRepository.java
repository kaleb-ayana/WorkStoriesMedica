package com.provider.eds.repository;

import com.azure.spring.data.cosmos.repository.Query;
import com.azure.spring.data.cosmos.repository.ReactiveCosmosRepository;
import com.medica.model.eds.provider.Provider;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

@Repository
public interface ProviderRepository extends ReactiveCosmosRepository<Provider, String> {

    @Query("SELECT * FROM c WHERE array_contains(@provIds, c.id, true) ")
    Flux<Provider> findAllByIdIn(Iterable<String> provIds);

    @Query("SELECT c.PROVIDER_ID, c.SOURCE_SYSTEM_CD, c.LOGICAL_DELETE_FLG, c.OPV_PROVIDER_ADDRESS, c.OPV_PROVIDER_ALTERNATE_ID FROM c WHERE array_contains(@provIds, c.id, true) ")
    Flux<Provider> findByIds(Iterable<String> provIds);

    @Query("SELECT DISTINCT c.PROVIDER_ID, c.EFF_DT, c.TERM_DT, c.SOURCE_SYSTEM_CD, c.PROVIDER_CATEGORY_CD, c.PROVIDER_ID_TYPE, c.LOGICAL_DELETE_FLG, c.OPV_PROVIDER_ADDRESS FROM c JOIN ADDRESS in c.OPV_PROVIDER_ADDRESS WHERE c.PROVIDER_CATEGORY_CD <> 'PRACT' AND array_contains(@pracLocIds, ADDRESS.ADDRESS_ID, true) AND ADDRESS.ADDRESS_TYPE_CD = 'A2'")
    Flux<Provider> findPracticeLocationProviders(Iterable<String> pracLocIds);

}
