package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Network;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class NetworkUtil {
    public static boolean isActive(Network network) {
        return Util.isActive(network.getLogicalDeleteFlg(), network.getEndDt());
    }

    public static boolean areEqual(Network network1, Network network2) {
        if (Objects.isNull(network1))
            return Objects.isNull(network2);
        if (Objects.isNull(network2))
            return Objects.isNull(network1);
        return Objects.equals(network1.getPraclocProviderId(), network2.getPraclocProviderId()) &&
                Objects.equals(network1.getNetworkId(), network2.getNetworkId()) &&
                Objects.equals(network1.getEffDt(), network2.getEffDt());
    }

    public static boolean matches(Network network1, Network network2) {
        return areEqual(network1, network2);
    }

    public static boolean merge(Network network1, Network network2) {
        if (!matches(network1, network2))
            return false;
        network1.setEndDt(Util.getMaxDate(network1.getEndDt(), network2.getEndDt()));
        network1.setLogicalDeleteFlg(Util.getConjunction(network1.getLogicalDeleteFlg(), network2.getLogicalDeleteFlg()));
        network1.setSourceSystemCd(Util.mergeString(network1.getSourceSystemCd(), network2.getSourceSystemCd()));
        network1.setSourceSystemInsertDttm(Util.getMinLong(network1.getSourceSystemInsertDttm(), network2.getSourceSystemInsertDttm()));
        network1.setSourceSystemUpdateDttm(Util.getMaxLong(network1.getSourceSystemUpdateDttm(), network2.getSourceSystemUpdateDttm()));
        return true;
    }

    public static void tagForResynch(Network network) {
        network.setResynchTag(network.getEffDt() + ";" + network.getEndDt() + ";" + (Objects.isNull(network.getLogicalDeleteFlg()) ? false : network.getLogicalDeleteFlg()));
        network.setAddressId(network.getPraclocProviderId());
    }
}
