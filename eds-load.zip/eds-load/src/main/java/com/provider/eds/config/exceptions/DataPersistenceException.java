package com.provider.eds.config.exceptions;

public class DataPersistenceException extends Exception{
    public DataPersistenceException() {
        super();
    }
    public DataPersistenceException(String message) {
        super(message);
    }
}
