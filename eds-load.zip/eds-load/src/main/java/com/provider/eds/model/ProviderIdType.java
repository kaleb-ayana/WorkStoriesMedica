package com.provider.eds.model;

public enum ProviderIdType {
    NPI1,
    TAX,
    MD5;
}
