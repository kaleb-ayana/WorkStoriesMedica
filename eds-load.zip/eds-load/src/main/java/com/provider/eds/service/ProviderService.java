package com.provider.eds.service;

import com.medica.model.eds.common.ResynchNotification;
import com.medica.model.eds.provider.Provider;
import com.medica.reference.misc.InvalidObjectStateException;
import com.medica.reference.misc.PersistenceErrorException;
import com.medica.reference.model.ProviderReferenceGroup;
import com.medica.reference.model.ProviderReferenceInput;
import com.medica.reference.service.ProviderReferenceService;
import com.provider.eds.config.GsonCustomBuilder;
import com.provider.eds.config.exceptions.DataPersistenceException;
import com.provider.eds.model.ErroredRecord;
import com.provider.eds.model.PracticeLocation;
import com.provider.eds.repository.ProviderRepository;
import com.provider.eds.service.utils.AddressUtil;
import com.provider.eds.service.utils.ProviderUtil;
import com.provider.eds.service.utils.ProviderUtils;
import com.provider.eds.service.utils.Util;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Component
@Slf4j
public class ProviderService {
    @Autowired
    @Qualifier("kafkaTemplateError")
    public KafkaTemplate<String, ErroredRecord> kafkaTemplate;
    @Autowired
    @Qualifier("kafkaTemplateResynch")
    public KafkaTemplate<String, ResynchNotification> kafkaTemplateResych;

    @Value(value = "${topics.orchestration.db-error}")
    String DB_ERROR_TOPIC;

    @Value(value = "${topics.resynch}")
    String RESYNCH_TOPIC;

    ProviderRepository repository;
    ProviderUtils providerUtils;

    @Autowired
    private ProviderReferenceService providerReferenceService;


    @Autowired
    public ProviderService(ProviderRepository repository, ProviderUtils providerUtils) {
        this.repository = repository;
        this.providerUtils = providerUtils;
    }

    public ProviderReferenceGroup getProviderReferences(ProviderReferenceInput providerId) {
        try {
            return this.providerReferenceService.find(providerId);
        } catch (InvalidObjectStateException | PersistenceErrorException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean saveReference(ProviderReferenceGroup providerReferenceGroup) {
        try {
            return this.providerReferenceService.save(providerReferenceGroup);
        } catch (InvalidObjectStateException | PersistenceErrorException e) {
            throw new RuntimeException(e);
        }
    }

    public String saveProvider(Provider provider) {
        repository
                .save(provider)
                .retry(2)
                .onErrorResume(throwable -> {
                    log.warn("<UPINSERT ERROR> Happened for provider : " + provider.getProviderId() );
                    log.warn("Erred Provider Detail : " + provider.toString());
                    this.kafkaTemplate.send(this.DB_ERROR_TOPIC, provider.getProviderId(), ErroredRecord.create(provider.getProviderId()));
                    return Mono.just(provider);
                })
                .block(Duration.ofSeconds(30));
        return String.format("Provider saved to EDS with id: %s", provider.getProviderId());
    }

    public Map<String, List<PracticeLocation>> getPractLocMap(Set<String> practiceLocIds) throws DataPersistenceException {
        if(CollectionUtils.isEmpty(practiceLocIds))
            return null;
        List<Provider> providerList=  this.getPracticeLocationProviders(practiceLocIds);
        if(CollectionUtils.isEmpty(providerList))
            return null;
        List<PracticeLocation> practiceLocations= new ArrayList<>();
        providerList.stream().forEach(provider -> {
            List<PracticeLocation> resultList= ProviderUtil.getMatchingPLs(provider,practiceLocIds);
            if(! CollectionUtils.isEmpty(resultList))
                practiceLocations.addAll(resultList);
        });
        if(CollectionUtils.isEmpty(practiceLocations))
            return null;
        return practiceLocations.stream().collect(Collectors.groupingBy(PracticeLocation::getPractLocId));
    }

    public List<Provider> getPracticeLocationProviders(Set<String> practiceLocIds) throws DataPersistenceException{
        try {
            return this.repository.findPracticeLocationProviders(practiceLocIds).collectList().retry(2).block(Duration.ofSeconds(30));
        } catch (Throwable throwable) {
            throw new DataPersistenceException("Persistence Exception Happened. Error retrieving practice location providers.");
        }
    }
    public void removeNonPracticeLocationAddresses(Provider provider, Set<String> practiceLocIds) {
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(practiceLocIds) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return;
        provider.setOpvProviderAddress(Util.filterList(provider.getOpvProviderAddress(), address ->
             AddressUtil.isPracticeLocation(address) && practiceLocIds.contains(address.getMtvAddrId())
        ));
    }

    public void resynch(Provider provider, Provider existingProvider) {
        if(Objects.isNull(existingProvider) || Objects.isNull(provider))
            return;
        boolean taxIdsUpdated= this.providerUtils.hasTaxUpdate(provider, existingProvider);
        boolean md5Updated= this.providerUtils.hasSiteMD5Update(provider, existingProvider);

        if((! taxIdsUpdated) && (! md5Updated))
            return;
        this.kafkaTemplateResych.send(this.RESYNCH_TOPIC, provider.getProviderId(), ResynchNotification.create(provider.getProviderId(), provider.getSourceSystemCd(), taxIdsUpdated, md5Updated));
    }

    public List<Provider> getProvidersById(Set<String> ids) {
        return this.repository.findByIds(ids).collectList().retry(3).block();
    }
}