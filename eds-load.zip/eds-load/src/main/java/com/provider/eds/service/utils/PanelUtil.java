package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Panel;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PanelUtil {
    public static void tagForResynch(Panel panel) {
        panel.setResynchTag(panel.getEffDt() + ";" + panel.getEndDt() + ";" + (Objects.isNull(panel.getLogicalDeleteFlg()) ? false : panel.getLogicalDeleteFlg()));
        panel.setAddressId(panel.getPracLocProviderId());
    }

    public static boolean equals(Panel panel1, Panel panel2) {
        if (Objects.isNull(panel1))
            return Objects.isNull(panel2);
        if (Objects.isNull(panel2))
            return Objects.isNull(panel1);
        return Objects.equals(panel1.getPracLocProviderId(), panel2.getPracLocProviderId()) &&
                Objects.equals(panel1.getEffDt(), panel2.getEffDt());
    }

    public static boolean matches(Panel panel1, Panel panel2) {
        return equals(panel1, panel2);
    }

    public static boolean merge(Panel panel1, Panel panel2) {
        if (!matches(panel1, panel2))
            return false;
        panel1.setEndDt(Util.getMaxDate(panel1.getEndDt(), panel2.getEndDt()));
        panel1.setLogicalDeleteFlg(Util.getConjunction(panel1.getLogicalDeleteFlg(), panel2.getLogicalDeleteFlg()));
        panel1.setSourceSystemCd(Util.mergeString(panel1.getSourceSystemCd(), panel2.getSourceSystemCd()));
        panel1.setSourceSystemInsertDttm(Util.getMinLong(panel1.getSourceSystemInsertDttm(), panel2.getSourceSystemInsertDttm()));
        panel1.setSourceSystemUpdateDttm(Util.getMaxLong(panel1.getSourceSystemUpdateDttm(), panel2.getSourceSystemUpdateDttm()));
        return true;
    }
}
