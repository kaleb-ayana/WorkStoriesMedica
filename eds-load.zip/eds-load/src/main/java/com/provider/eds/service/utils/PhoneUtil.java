package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Phone;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PhoneUtil {
    public static boolean equals(Phone phone1, Phone phone2) {
        if (Objects.isNull(phone1))
            return Objects.isNull(phone2);
        if (Objects.isNull(phone2))
            return Objects.isNull(phone1);
        return Objects.equals(phone1.getPhoneNum(), phone2.getPhoneNum()) &&
                Objects.equals(phone1.getPhoneTypeCd(), phone2.getPhoneTypeCd()) &&
                Objects.equals(phone1.getExtension(), phone2.getExtension()) /*&&
                Objects.equals(phone1.getEffDt(), phone2.getEffDt())*/;
    }

    public static boolean matches(Phone phone1, Phone phone2) {
        return equals(phone1, phone2);
    }

    public static boolean merge(Phone phone1, Phone phone2) {
        if (!matches(phone1, phone2))
            return false;
        phone1.setPrimaryFlag(Util.getDisjunction(phone1.isPrimaryFlag(), phone2.isPrimaryFlag()));
        phone1.setSourceSystemCd(Util.mergeString(phone1.getSourceSystemCd(), phone2.getSourceSystemCd()));
        phone1.setLogicalDeleteFlg(Util.getConjunction(phone1.getLogicalDeleteFlg(), phone2.getLogicalDeleteFlg()));
        phone1.setSourceSystemInsertDttm(Util.getMinLong(phone1.getSourceSystemInsertDttm(), phone2.getSourceSystemInsertDttm()));
        phone1.setSourceSystemUpdateDttm(Util.getMaxLong(phone1.getSourceSystemUpdateDttm(), phone2.getSourceSystemUpdateDttm()));
        return true;
    }
}
