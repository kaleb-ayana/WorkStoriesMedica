package com.provider.eds.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.medica.model.eds.provider.Message;
import com.medica.model.eds.provider.Provider;
import com.medica.reference.model.*;
import com.provider.eds.config.exceptions.DataPersistenceException;
import com.provider.eds.config.exceptions.MissingDataException;
import com.provider.eds.config.exceptions.ObjectTooBigException;
import com.provider.eds.model.Constants;
import com.provider.eds.model.PracticeLocation;
import com.provider.eds.service.utils.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

import static com.provider.eds.service.utils.ProviderUtil.getMentionedProviderIds;

@Service
@Slf4j
public class ProcessingOrchestrator {

    @Value(value = "${operating-mode}")
    String operatingMode;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private ProviderUtils providerUtils;

    @Autowired
    private ProviderService providerService;

    public String persist(Message message) throws DataPersistenceException, MissingDataException, ObjectTooBigException {
        if(Objects.isNull(message) || Objects.isNull(message.getMetadata()) || Objects.isNull(message.getPayload()))
            throw new DataPersistenceException("<DataPersistenceException> Message or its contents are null. Can not process.");

        Provider provider= message.getPayload();
        FlagUtil.defaultFlagValue(provider);
        DateUtil.stringfyDates(provider);
        ProviderUtil.buildTagsForResynch(provider);
        List<Provider> relatedMtvProviders= this.providerService.getProvidersById(this.providerUtils.getSelfAndAffiliatedMTVProviderIds(provider));
        Map<String, Provider> relatedMtvProvidersMap= this.providerUtils.makeProvidersMap(relatedMtvProviders);
        Map<String, List<PracticeLocation>> practiceLocationMap= this.providerService.getPractLocMap(ProviderUtil.getCombinedMtvPractLocIds(provider));

        if(! this.providerUtils.hasFullfilledDependencies(provider, relatedMtvProviders))
            throw new MissingDataException("<MissingDataException> One or more dependent (affilation, contract, or practice location) providers are missing for Provider ID : " + provider.getProviderId());
        if(ProviderUtil.hasAffiliations(provider))
            this.providerUtils.buildAffiliation(provider, relatedMtvProvidersMap);
        if(ProviderUtil.hasNetworkDirectory(provider)) {
            this.providerUtils.buildNetwork(provider, practiceLocationMap);
        }
        if(ProviderUtil.hasPanels(provider)) {
            this.providerUtils.buildPanel(provider, practiceLocationMap);
        }
        if(! this.isWithInSizeLimit(provider))
            throw new ObjectTooBigException("Provider ID : " + provider.getProviderId() + " Has too big of a size that is Greater than or equal to 2MB.");
        String operationMessage= this.providerService.saveProvider(provider);

        if(this.operatingMode.equalsIgnoreCase(Constants.REALTIME))
            this.providerService.resynch(provider, relatedMtvProvidersMap.get(provider.getProviderId()+provider.getSourceSystemCd()));
        log.info(operationMessage);
        providerService.saveReference(processProviderReferences(provider, relatedMtvProvidersMap.get(provider.getProviderId()+provider.getSourceSystemCd())));

        return operationMessage;
    }

    public ProviderReferenceGroup processProviderReferences(Provider provider, Provider existingProvider) {
        log.info("Processing references for .... " + provider.getProviderId());
        ProviderReferenceInput input=new ProviderReferenceInput();
        Set<String> relatedProviderIds= getMentionedProviderIds(provider);
        log.info("Related Providers : " + relatedProviderIds);
        Set<String> oldRelatedProviderIds= getMentionedProviderIds(existingProvider);
        log.info("Previously Related Providers : " + oldRelatedProviderIds);
        Set<String> deprecatedProviderIds= Util.getSetDifference(relatedProviderIds, oldRelatedProviderIds);
        log.info("Deprecated Related Providers : " + deprecatedProviderIds);
        relatedProviderIds.add(provider.getProviderId());
        log.info("All Related Provider IDs : " + deprecatedProviderIds);
        input.addProviderIds(relatedProviderIds, provider.getSourceSystemCd());
        if(! CollectionUtils.isEmpty(deprecatedProviderIds))
            input.addProviderIds(deprecatedProviderIds, provider.getSourceSystemCd());
        log.info("Total Query Candidate IDS = " + input.getAllIds());
        List<Address> md5s = providerUtils.getMD5s(provider);
        List<AlternateIdentifier>  taxTypes = providerUtils.getTAXTypes(provider);
        List<AlternateIdentifier>  npi1s = providerUtils.getNPI1s(provider);
        List<Address> oldMd5s = providerUtils.getMD5s(existingProvider);
        Set<String> deprecatedMD5s= Util.getSetDifference(md5s.stream().map(Address::getAddrMd5Hash).filter(StringUtils::hasText).collect(Collectors.toSet()),
                oldMd5s.stream().map(Address::getAddrMd5Hash).filter(StringUtils::hasText).collect(Collectors.toSet()));

        if(! CollectionUtils.isEmpty(md5s)) {
            input.addMD5Ids(md5s.stream().map(md5 -> md5.getAddrMd5Hash()).collect(Collectors.toSet()));
            log.info("MD5s :-> " + (md5s.stream().map(md5 -> md5.getAddrMd5Hash()).collect(Collectors.toSet())));
        }

        if(! CollectionUtils.isEmpty(npi1s)) {
            input.addNPI1Ids(npi1s.stream().map(npi -> npi.getAlternateId()).collect(Collectors.toSet()));
            log.info("NPI1s :-> " + npi1s.stream().map(npi -> npi.getAlternateId()).collect(Collectors.toSet()));
        }

        if(! CollectionUtils.isEmpty(taxTypes)) {
            input.addTaxIds(taxTypes.stream().map(taxid -> taxid.getAlternateId()).collect(Collectors.toSet()));
            log.info("TAX-IDs :-> " + (taxTypes.stream().map(taxid -> taxid.getAlternateId()).collect(Collectors.toSet())));
        }

        if(Objects.nonNull(existingProvider) && (!CollectionUtils.isEmpty(oldMd5s)) && (! CollectionUtils.isEmpty(deprecatedMD5s) )) {
            input.addMD5Ids(deprecatedMD5s);
        }

        log.info("Deprecated MD5s :-> " + deprecatedMD5s);
        ProviderReferenceGroup providerRefGroup= this.providerService.getProviderReferences(input);

        ReferenceId relatedProviderReferenceId =  ReferenceIdFactory.createMTVProviderReference(provider.getProviderId(), provider.getEffDate(), provider.getTermDt(), FlagUtil.getOrDefault(provider.getLogicalDeleteFlg()));
        List<ReferenceId> providerReferenceIdList= new ArrayList<>();
        providerReferenceIdList.add(relatedProviderReferenceId);

        relatedProviderIds.stream().filter(prov -> ! Objects.equals(provider.getProviderId(),prov)).forEach(id-> {
            if( ! providerRefGroup.hasProviderReference(id, provider.getSourceSystemCd())) {
                ProviderReference reference= ReferenceFactory.createProviderReference(id, provider.getSourceSystemCd(), provider.getSourceSystemCd(),null, null, false,null);
                reference.addOrReplaceRelatedProviders(providerReferenceIdList);
                providerRefGroup.addOrReplace(reference);
            } else
                providerRefGroup.getProviderReference(id, provider.getSourceSystemCd()).get().addOrReplaceRelatedProviders(providerReferenceIdList);
        });
        Optional<ProviderReference> providerReferenceOptional= providerRefGroup.getProviderReference(provider.getProviderId(), provider.getSourceSystemCd());
        ProviderReference providerReference= providerReferenceOptional.isPresent() ? providerReferenceOptional.get() : ReferenceFactory.createProviderReference(provider.getProviderId(), provider.getSourceSystemCd(), provider.getSourceSystemCd(), provider.getEffDate(), provider.getTermDt(), FlagUtil.getOrDefault(provider.getLogicalDeleteFlg()), null);;
        providerRefGroup.addOrReplace(providerReference);

        providerReference.clearMD5s();
        providerReference.clearNPI1s();
        providerReference.clearTaxes();
        if(!CollectionUtils.isEmpty(md5s))
            providerReference.addOrReplaceMD5s(md5s.stream().map(addr -> ReferenceIdFactory.createMD5Reference(addr.getAddrMd5Hash(), provider.getSourceSystemCd(), addr.getEffDt() ,addr.getEndDt(), FlagUtil.getOrDefault(addr.getLogicalDeleteFlg()))).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(npi1s))
            providerReference.addOrReplaceNPI1s(npi1s.stream().map(npi1 -> ReferenceIdFactory.createNPI1Reference(npi1.getAlternateId(), provider.getSourceSystemCd(), npi1.getEffDt() ,npi1.getEndDt(), FlagUtil.getOrDefault(npi1.getLogicalDeleteFlg()))).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(taxTypes))
            providerReference.addOrReplaceTaxes(taxTypes.stream().map(tax -> ReferenceIdFactory.createTaxIdReference(tax.getAlternateId(), provider.getSourceSystemCd(), tax.getEffDt() ,tax.getEndDt(), FlagUtil.getOrDefault(tax.getLogicalDeleteFlg()))).collect(Collectors.toList()));

        if(!CollectionUtils.isEmpty(npi1s))
            npi1s.stream().forEach(npi1 -> {
                if(providerRefGroup.hasNPI1Reference(npi1.getAlternateId())){
                    providerRefGroup.getNPI1Reference(npi1.getAlternateId()).get().addOrReplaceRelatedProvider(relatedProviderReferenceId);
                } else {
                    providerRefGroup.addOrReplace(ReferenceFactory.createNPI1Reference(
                            npi1.getAlternateId(),provider.getSourceSystemCd(),provider.getSourceSystemCd(), npi1.getEffDt(), npi1.getEndDt(),
                            FlagUtil.getOrDefault(npi1.getLogicalDeleteFlg()),providerReferenceIdList));
                }
            });

        if(!CollectionUtils.isEmpty(taxTypes))
            taxTypes.stream().forEach(taxId -> {
                if(providerRefGroup.hasTaxReference(taxId.getAlternateId())){
                    providerRefGroup.getTaxIdReference(taxId.getAlternateId()).get().addOrReplaceRelatedProvider(relatedProviderReferenceId);
                }else{
                    providerRefGroup.addOrReplace(ReferenceFactory.createTaxIdReference(
                            taxId.getAlternateId(),provider.getSourceSystemCd(), taxId.getEffDt(), taxId.getEndDt(),
                            FlagUtil.getOrDefault(taxId.getLogicalDeleteFlg()),null,providerReferenceIdList));
                }
            });

        if(!CollectionUtils.isEmpty(md5s))
            md5s.stream().forEach(md5 -> {
                FieldCombo fieldCombo = deduceSiteTaxId(md5.getAddrMd5Hash(), provider.getSitePrimarySpeciality(),md5, provider.getLastNameOrgName(),ProviderUtil.getLocTaxIds(provider));
                String relatedTaxId =fieldCombo.taxId;
                if(providerRefGroup.hasMD5Reference(md5.getAddrMd5Hash())){
                    ProviderReference existingMD5Reference = providerRefGroup.getMD5Reference(md5.getAddrMd5Hash()).get();
                    existingMD5Reference.addOrReplaceRelatedProvider(relatedProviderReferenceId);
                    existingMD5Reference.setRelatedTaxId(relatedTaxId);
                }else{
                    providerRefGroup.addOrReplace(ReferenceFactory.createMD5IdReference(
                            md5.getAddrMd5Hash(),provider.getSourceSystemCd(),provider.getSourceSystemCd(), md5.getEffDt(), md5.getEndDt(),
                            FlagUtil.getOrDefault(md5.getLogicalDeleteFlg()),false,false,relatedTaxId,providerReferenceIdList));
                }
            });

        if(!CollectionUtils.isEmpty(deprecatedMD5s))
            for(String md5: deprecatedMD5s ) {
                Optional<ProviderReference> md5ProviderReference= providerRefGroup.getMD5Reference(md5);

                if(! md5ProviderReference.isPresent())
                    continue;
                md5ProviderReference.get().setPhysicalDeleteFlg(Boolean.TRUE);
                md5ProviderReference.get().addOrReplaceRelatedProviders(providerReferenceIdList);
                md5ProviderReference.get().getRelatedProvider(provider.getProviderId(), provider.getSourceSystemCd()).get().setLogicalDeleteFlg(true);
            }

        if(!CollectionUtils.isEmpty(deprecatedProviderIds)) {
            deprecatedProviderIds.stream().forEach(providerId -> {
                providerRefGroup.getProviderReference(providerId, provider.getSourceSystemCd()).get().removeFromRelatedProviderReferences(provider.getProviderId(), provider.getSourceSystemCd());
            });
        }

        return providerRefGroup;
    }

    private boolean isWithInSizeLimit(Provider provider) {
        String result= null;
        try {
            result= this.objectMapper.writeValueAsString(provider);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        if(Objects.isNull(result))
            throw new RuntimeException("Json string representation of non null provider should have a value.");
        return (result.getBytes().length/(1024.0 * 1024.0)) < 2.0;
    }

    public FieldCombo deduceSiteTaxId(String md5Hash, String primarySpecialty, Address address, String lastName, List<String> taxIds) {
        if(CollectionUtils.isEmpty(taxIds)) {
            taxIds= new ArrayList<>();
        }
        List<String> phones= AddressUtil.getPhoneNumberStrings(address);
        if(CollectionUtils.isEmpty(phones)) {
            phones= new ArrayList<>();
        }
        taxIds.add(0, null);
        phones.add(0, null);

        for(String taxId: taxIds) {
            for(String phone: phones) {
                if(md5Hash.equals(this.computeMd5Hash(lastName, address.getAddressLine1(), address.getAddressLine2(),
                        address.getAddressLine3(), address.getCity(), address.getStateCd(), address.getZipCd5(),phone,
                        primarySpecialty, taxId))) {
                    return new FieldCombo(taxId, phone);
                }
            }
        }
        return new FieldCombo();
    }

    private String computeMd5Hash(String name, String addressLine1, String addressLine2, String addressLine3, String city,
                                  String state, String zip, String phone, String specialty, String taxId) {
        String combinedString= Objects.nonNull(name) ? name.trim() : null ;
        combinedString += addressLine1;
        combinedString += addressLine2;
        combinedString += addressLine3;
        combinedString += city;
        combinedString += state;
        combinedString += zip;
        combinedString += phone;
        combinedString += specialty;
        combinedString += Objects.nonNull(taxId) ? taxId.trim() : null;
        return DigestUtils.md5DigestAsHex(combinedString.getBytes()).toUpperCase();
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private static class FieldCombo {
        private String taxId;
        private String phone;
    }
}