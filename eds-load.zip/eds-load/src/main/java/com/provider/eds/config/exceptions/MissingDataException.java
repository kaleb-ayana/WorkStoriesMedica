package com.provider.eds.config.exceptions;

public class MissingDataException extends Exception{
    public MissingDataException() {
        super();
    }
    public MissingDataException(String message) {
        super(message);
    }
}
