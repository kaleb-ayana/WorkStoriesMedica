package com.provider.eds.service.utils;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.Language;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Objects;

@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class LanguageUtil {


    public static boolean equals(Language language1, Language language2) {
        if (Objects.isNull(language1))
            return Objects.isNull(language2);
        if (Objects.isNull(language2))
            return Objects.isNull(language1);
        return Objects.equals(language1.getLanguageCd(), language2.getLanguageCd());
    }

    public static boolean matches(Language language1, Language language2) {
        return equals(language1, language2);
    }


    public static boolean merge(Language language1, Language language2) {
        if (!matches(language1,language2))
            return false;
        language1.setPrimaryFlg(Util.getDisjunction(language1.isPrimaryFlg(), language2.isPrimaryFlg()));
        language1.setSourceSystemCd(Util.mergeString(language1.getSourceSystemCd(), language2.getSourceSystemCd()));
        language1.setLogicalDeleteFlg(Util.getConjunction(language1.getLogicalDeleteFlg(), language2.getLogicalDeleteFlg()));
        language1.setSourceSystemInsertDttm(Util.getMinLong(language1.getSourceSystemInsertDttm(), language2.getSourceSystemInsertDttm()));
        language1.setSourceSystemUpdateDttm(Util.getMaxLong(language1.getSourceSystemUpdateDttm(), language2.getSourceSystemUpdateDttm()));
        return true;
    }
}
