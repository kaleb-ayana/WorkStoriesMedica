package com.provider.eds.model;

public class Constants {
    public static final String MTV="MTV";
    public static final String A2_ADDRESS="A2";
    public static final String BA_ADDRESS="BA";
    public static final String AP_ADDRESS="AP";
    public static final String TAX="TAX";
    public static final String MD5="MD5";
    public static final String NPI2 = "NPI2";
    public static final String NPI1 = "NPI1";
    public static final String PAYTO = "PAYTO";
    public static final String OPEN_END_DATE = "9999-12-31";
    public static final String REALTIME = "realtime";
}
