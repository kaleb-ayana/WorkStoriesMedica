package com.provider.eds.service.utils;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.medica.model.eds.provider.*;
import com.provider.eds.model.PracticeLocation;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.provider.eds.service.utils.Util.nullOrEmpty;
@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Container(containerName = "ProviderDemographic")
public class ProviderUtil {

    public static Set<String> getMentionedProviderIds(Provider provider) {
        Set<String>  ids= new HashSet<>();
        if(Objects.isNull(provider))
            return ids;
        if(! CollectionUtils.isEmpty(provider.getOpvProviderAffiliation()))
            ids.addAll(provider.getOpvProviderAffiliation().stream().map(p->p.getMtvAffiliateProviderId()).collect(Collectors.toSet()));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderPanel()))
            ids.addAll(provider.getOpvProviderPanel().stream().map(p->p.getMtvProviderId()).collect(Collectors.toSet()));
        if(! CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory()))
            ids.addAll(provider.getOpvProviderNetworkDirectory().stream().map(p->p.getMtvProviderId()).collect(Collectors.toSet()));
        return ids.stream().filter(StringUtils::hasText).collect(Collectors.toSet());
    }

    public static List<Address> getAddresses(Provider provider, Predicate<Address> additionalPredicate) {
        Predicate<Address> addressPredicate = AddressUtil::isValid;
        if (Objects.nonNull(additionalPredicate))
            addressPredicate = addressPredicate.and(additionalPredicate);
        return Util.filterList(provider.getOpvProviderAddress(), addressPredicate);
    }

    public static List<AlternateIdentifier> getAlternateIds(Provider provider, Predicate<AlternateIdentifier> additionalPredicate) {
        Predicate<AlternateIdentifier> alternateIdentifierPredicate = AlternateIdentifierUtil::isValid;
        if (Objects.nonNull(additionalPredicate))
            alternateIdentifierPredicate = alternateIdentifierPredicate.and(additionalPredicate);
        return Util.filterList(provider.getOpvProviderAlternateId(), alternateIdentifierPredicate);
    }

    public static Set<String> getMtvProviderIdsAffiliated(Provider provider) {
        if (!ProviderUtil.hasAffiliations(provider))
            return null;
        List<String> resultList = Util.filterFieldValues(provider.getOpvProviderAffiliation(), affiliation -> affiliation.getMtvAffiliateProviderId(), true);
        return nullOrEmpty(resultList) ? null : new HashSet<>(resultList);
    }

    public static boolean hasPanels(Provider provider) {
        return (!CollectionUtils.isEmpty(provider.getOpvProviderPanel()));
    }

    public static boolean hasNetworkDirectory(Provider provider) {
        return Objects.nonNull(provider.getOpvProviderNetworkDirectory()) && !provider.getOpvProviderNetworkDirectory().isEmpty();
    }

    public static Set<String> getMtvNetworkDirPractLocIds(Provider provider) {

        if (!ProviderUtil.hasNetworkDirectory(provider))
            return null;
        List<String> resultList = Util.filterFieldValues(provider.getOpvProviderNetworkDirectory(), network -> network.getPraclocProviderId(), true);
        return nullOrEmpty(resultList) ? null : new HashSet<>(resultList);
    }

    public static Set<String> getMtvPanelPractLocIds(Provider provider) {
        if (!ProviderUtil.hasPanels(provider))
            return null;
        List<String> resultList = Util.filterFieldValues(provider.getOpvProviderPanel(), panel -> panel.getPracLocProviderId(), true);
        return nullOrEmpty(resultList) ? null : new HashSet<>(resultList);
    }

    public static Set<String> getAffiliationRelatedMtvProvIds(Provider provider) {
        Set<String> affiliatedMtvIds = new HashSet<>();
        if (Objects.nonNull(ProviderUtil.getMtvProviderIdsAffiliated(provider)))
            affiliatedMtvIds.addAll(ProviderUtil.getMtvProviderIdsAffiliated(provider));
        return affiliatedMtvIds.stream().filter(id -> StringUtils.hasText(id)).collect(Collectors.toSet());
    }

    public static Set<String> getCombinedMtvPractLocIds(Provider provider) {
        Set<String> networkDirPractLocIds= ProviderUtil.getMtvNetworkDirPractLocIds(provider);
        Set<String> panelPractLocIds= ProviderUtil.getMtvPanelPractLocIds(provider);
        Set<String> combinedList = new HashSet<>();
        if (Objects.nonNull(networkDirPractLocIds) && (!networkDirPractLocIds.isEmpty()))
            combinedList.addAll(networkDirPractLocIds);
        if (Objects.nonNull(panelPractLocIds) && (!panelPractLocIds.isEmpty()))
            combinedList.addAll(panelPractLocIds);

        return combinedList.stream().filter(StringUtils::hasText).collect(Collectors.toSet());
    }

    public static boolean hasAffiliations(Provider provider) {
        return Objects.nonNull(provider.getOpvProviderAffiliation()) && !provider.getOpvProviderAffiliation().isEmpty();
    }

    public static void addAddress(Provider provider, Address address) {
        if (Objects.isNull(address))
            return;
        if (Objects.isNull(provider.getOpvProviderAddress()))
            provider.setOpvProviderAddress(new ArrayList<>());
        provider.getOpvProviderAddress().add(address);
    }


    public static List<String> getLocTaxIds(Provider provider) {
        if (CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()))
            return null;
        return provider.getOpvProviderAlternateId()
                .stream()
                .filter(alt -> AlternateIdentifierUtil.isTaxEntity(alt) && (!AlternateIdentifierUtil.isVoided(alt)))
                .map(AlternateIdentifier::getAlternateId)
                .distinct()
                .collect(Collectors.toList());
    }


    public static boolean hasAddressLocationId(Provider provider,String addressId) {
        if (!StringUtils.hasText(addressId))
            return false;
        return (!CollectionUtils.isEmpty(ProviderUtil.getAddresses(provider,addr -> AddressUtil.isPracticeLocation(addr) && addressId.equalsIgnoreCase(addr.getMtvAddrId()))));
    }


    public static String getMatchingPractLocMD5(Provider provider,String addressId) {
        if (!StringUtils.hasText(addressId) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return null;
        Optional<Address> address =
                provider.getOpvProviderAddress()
                        .stream()
                        .filter(addr -> AddressUtil.isPracticeLocation(addr) && addressId.equalsIgnoreCase(addr.getMtvAddrId()))
                        .findFirst();
        return address.isEmpty() ? null : address.get().getAddrMd5Hash();
    }


    public static List<String> getMD5s (Provider provider,String addressId) {
        if ((!StringUtils.hasText(addressId)) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return null;
        return provider.getOpvProviderAddress()
                .stream()
                .filter(addr -> AddressUtil.isPracticeLocation(addr) && addressId.equalsIgnoreCase(addr.getMtvAddrId()))
                .map(Address::getAddrMd5Hash)
                .filter(StringUtils::hasText)
                .distinct()
                .collect(Collectors.toList());
    }

    public static void buildTagsForResynch(Provider provider) {
        if (!CollectionUtils.isEmpty(provider.getOpvProviderPanel()))
            provider.getOpvProviderPanel().stream().forEach(PanelUtil::tagForResynch);
        if (!CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory()))
            provider.getOpvProviderNetworkDirectory().stream().forEach(NetworkUtil::tagForResynch);
        if (!CollectionUtils.isEmpty(provider.getOpvProviderAffiliation()))
            provider.getOpvProviderAffiliation().stream().forEach(AffiliationUtil::tagForResynch);
    }

    public static void cleanDuplicates(Provider provider) {
        if(! CollectionUtils.isEmpty(provider.getOpvProviderNetworkDirectory())) {
            List<Network> distinctList= new ArrayList<>();
            for(Network network: provider.getOpvProviderNetworkDirectory()) {
                if(CollectionUtils.isEmpty(distinctList)) {
                    distinctList.add(network);
                    continue;
                }
                Network matchingNetwork=null;
                for(Network existingNetwork: distinctList) {
                    if(NetworkUtil.matches(existingNetwork,network)) {
                        matchingNetwork= network;
                        break;
                    }
                }
                if(Objects.nonNull(matchingNetwork))
                    NetworkUtil.merge(matchingNetwork,network);
                else
                    distinctList.add(network);
            }
            provider.setOpvProviderNetworkDirectory(distinctList);
        }
        if(! CollectionUtils.isEmpty(provider.getOpvProviderPanel())) {
            List<Panel> distinctList= new ArrayList<>();
            for(Panel panel: provider.getOpvProviderPanel()) {
                if(CollectionUtils.isEmpty(distinctList)) {
                    distinctList.add(panel);
                    continue;
                }
                Panel matchingPanel=null;
                for(Panel existingPanel: distinctList) {
                    if(PanelUtil.matches(existingPanel,panel)) {
                        matchingPanel= panel;
                        break;
                    }
                }
                if(Objects.nonNull(matchingPanel))
                    PanelUtil.merge(matchingPanel,panel);
                else
                    distinctList.add(panel);
            }
            provider.setOpvProviderPanel(distinctList);
        }
        if(! CollectionUtils.isEmpty(provider.getOpvProviderAffiliation())) {
            List<Affiliation> distinctList= new ArrayList<>();
            for(Affiliation affiliation: provider.getOpvProviderAffiliation()) {
                if(CollectionUtils.isEmpty(distinctList)) {
                    distinctList.add(affiliation);
                    continue;
                }
                Affiliation matchingAffiliation=null;
                for(Affiliation existingPanel: distinctList) {
                    if(AffiliationUtil.matches(existingPanel,affiliation)) {
                        matchingAffiliation= affiliation;
                        break;
                    }
                }
                if(Objects.nonNull(matchingAffiliation))
                    AffiliationUtil.merge(matchingAffiliation,affiliation);
                else
                    distinctList.add(affiliation);
            }
            provider.setOpvProviderAffiliation(distinctList);
        }
    }


    public static boolean hasPracticeLocation(Provider provider) {
        if(CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return false;
        return provider.getOpvProviderAddress().stream().anyMatch(addr -> AddressUtil.isPracticeLocation(addr) && AddressUtil.hasMD5Hash(addr) && AddressUtil.hasMtvAddressId(addr));
    }

    public static List<PracticeLocation> getMatchingPLs(Provider provider, Set<String> practLocIds) {

        if(CollectionUtils.isEmpty(practLocIds) || CollectionUtils.isEmpty(provider.getOpvProviderAddress()) || (!ProviderUtil.hasPracticeLocation(provider)))
            return null;
        List<Address> plList= provider.getOpvProviderAddress()
                .stream()
                .filter(addr -> AddressUtil.isPracticeLocation(addr) && AddressUtil.hasMD5Hash(addr) && AddressUtil.hasMtvAddressId(addr))
                .filter(addr->practLocIds.contains(addr.getMtvAddrId()))
                .collect(Collectors.toList());
        if(CollectionUtils.isEmpty(plList))
            return null;
        return plList.stream().map(add -> PracticeLocationUtil.buildPracticeLocation(provider,add)).collect(Collectors.toList());

    }


    public static boolean hasAddress(Provider provider, Predicate<Address> predicate) {
        if(CollectionUtils.isEmpty(provider.getOpvProviderAddress()))
            return false;
        return Util.hasList(provider.getOpvProviderAddress(), predicate);
    }

    public static boolean hasSpecialty(Provider provider, Predicate<Specialty> predicate) {
        if(CollectionUtils.isEmpty(provider.getOpvProviderSpecialty()))
            return false;
        return Util.hasList(provider.getOpvProviderSpecialty(), predicate);
    }


    public static boolean hasAlternateId(Provider provider, Predicate<AlternateIdentifier> predicate) {
        if(CollectionUtils.isEmpty(provider.getOpvProviderAlternateId()))
            return false;
        return Util.hasList(provider.getOpvProviderAlternateId(), predicate);
    }
  /* @JsonIgnore
    public boolean hasRelatedMtvProvider(String providerId) {
        boolean flag = false;
        if (!CollectionUtils.isEmpty(this.opvProviderPanel))
            for (Panel panel : this.opvProviderPanel)
                if (providerId.equalsIgnoreCase(panel.mtvProviderId)) {
                    return true;} else if (!CollectionUtils.isEmpty(this.opvProviderAffiliation))
                    for (Affiliation affiliation : this.opvProviderAffiliation)
                        if (providerId.equalsIgnoreCase(affiliation.mtvAffiliateProviderId)) {
                            return true;
                        } else if (!CollectionUtils.isEmpty(this.opvProviderContract))
                            for (Contract contract : this.opvProviderContract)
                                if (providerId.equalsIgnoreCase(contract.mtvPayToProviderId)) {
                                    return true;
                                } else if (!CollectionUtils.isEmpty(this.opvProviderNetworkDirectory))
                                    for (Network network : this.opvProviderNetworkDirectory)
                                        if (providerId.equalsIgnoreCase(network.mtvProviderId)) {
                                            return true;
                                        }
        return flag;
    }*/
}
