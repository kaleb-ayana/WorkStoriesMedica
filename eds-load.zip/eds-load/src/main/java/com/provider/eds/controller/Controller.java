package com.provider.eds.controller;

import com.provider.eds.config.exceptions.DataPersistenceException;
import com.provider.eds.config.exceptions.MissingDataException;
import com.provider.eds.model.PracticeLocation;
import com.provider.eds.service.ProviderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Slf4j
@RestController
public class Controller {

    @Autowired
    private ProviderService providerService;

    public enum ProviderTypes {
        NPI1, TAX, MD5;
    }

    @GetMapping("/test")
    public Map<String, List<PracticeLocation>>  getHealthTest() throws MissingDataException, DataPersistenceException {
        Map<String, List<PracticeLocation>> resultMap= this.providerService.getPractLocMap(Set.of("15615333697","779115365965","951015382275"));
        Set<String> keys= resultMap.keySet();
        for(String key: resultMap.keySet()) {
            log.info(" Key : " + key + " , " + resultMap.get(key));
        }
        return null;
    }

}