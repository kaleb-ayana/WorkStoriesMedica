package com.provider.eds;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medica.model.eds.common.ProviderNotification;
import com.medica.model.eds.provider.Message;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.config.exceptions.DataPersistenceException;
import com.provider.eds.config.exceptions.MissingDataException;
import com.provider.eds.config.exceptions.ObjectTooBigException;
import com.provider.eds.service.ProcessingOrchestrator;
import com.provider.eds.service.UpdateNotificationService;
import io.confluent.kafka.streams.serdes.avro.GenericAvroSerde;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Branched;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
@Slf4j
public class StreamProcessor {
    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    @Qualifier("kafkaTemplateMessage")
    public KafkaTemplate<String, Message> kafkaTemplate;

    @Value("${topics.inbound}")
    private String INBOUND_TOPIC;

    @Value("${spring.kafka.streams.schema-registry}")
    private String SCHEMA_REGISTRY;

    @Value("${topics.orchestration.error}")
    private String ORCHESTRATION_ERROR_TOPIC;

    @Autowired
    private ProcessingOrchestrator processor;

    @Autowired
    private UpdateNotificationService  updateNotificationService;

    @Value(value = "${topics.provider.notification.outbound}")
    private String providerNotificationTopic;

    @Value("${enablenotification}")
    private Boolean enableNotification;

    @Autowired
    void providerTopology(StreamsBuilder streamsBuilder) {
        final Serde<String> STRING_SERDE = Serdes.String();
        final Map<String, String> serdesConfig = Collections.singletonMap("schema.registry.url", SCHEMA_REGISTRY);
        final Serde<GenericRecord> GENERIC_AVRO_SERDE = new GenericAvroSerde();
        GENERIC_AVRO_SERDE.configure(serdesConfig, false);
        KStream<String, GenericRecord> consumerKStream = streamsBuilder.stream(INBOUND_TOPIC, Consumed.with(STRING_SERDE, GENERIC_AVRO_SERDE));

        consumerKStream
            .split()
            .branch((key, record) -> {
                    GenericRecord metadata = (GenericRecord) record.get("Metadata");
                    String sourceSystemCd = (String) metadata.get("SourceSystem");
                    return "MTV".equalsIgnoreCase(sourceSystemCd);
                },
                 Branched.withConsumer(ks->ks
                .peek(((key, value) -> log.info("Received avro message with key [" + key + "]" + "-".repeat(20))))
                .mapValues((key, value) -> {
                    Message message = null;
                    try {
                        message = this.parseAndMessage(value.toString(), key);
                        String response = this.processor.persist(message);
                        log.info(response);
                    } catch (MissingDataException | DataPersistenceException | JsonProcessingException |
                             ObjectTooBigException e) {
                        log.error("Error encountered Processing Provider identified by : [ " + key + "]. Detail :" + e.getMessage());
                        Message tempMessage= null;
                        try {
                            tempMessage= this.parseAndMessage(value.toString(), key);
                        } catch (JsonProcessingException ex) {
                            log.error("Error parsing AVRO message with key " + key);
    //                        throw new RuntimeException(ex);
                        }
                        this.kafkaTemplate.send(this.ORCHESTRATION_ERROR_TOPIC, key, tempMessage);
                    }
                    return message;
            })
            .filter((key, value) -> Objects.nonNull(key) && Objects.nonNull(value))
                .foreach((key ,value) ->{
                    try {
                        Provider provider = value.getPayload();
                        List<ProviderNotification> notificationProviders= updateNotificationService.processProviderNotificationMessage(provider);
                        if(!CollectionUtils.isEmpty(notificationProviders)) {
                            notificationProviders.stream()
                                    .forEach(notificationProvider -> {
                                        log.info("Provider Notification topic produced : [" + notificationProvider.getPROVIDER_ID() + " , " + notificationProvider.getPROVIDER_ID_TYPE() + " ]");
                                        if (this.enableNotification) {
                                            updateNotificationService.produceProviderNotificationTopicMessage(notificationProvider).addCallback(
                                                    result -> log.info("Provider Notification Topic message produced."),
                                                    x -> log.info("Producing Provider Notification topic message failed. " + x));
                                        }
                                    });
                        }
                        else
                            log.info("Provider [ " + provider.getProviderId() + " ] had no candidates for Provider Notification topic messages");
                    } catch (Exception e) {
                        log.error("Producing Provider Notification topic Message Error encountered : ", e);
                        this.kafkaTemplate.send(providerNotificationTopic+".dlt", key, value);
                    }

                })))
                .branch((key, record) -> {
                            GenericRecord metadata = (GenericRecord) record.get("Metadata");
                            String sourceSystemCd = (String) metadata.get("SourceSystem");
                            return "SYMFACT".equalsIgnoreCase(sourceSystemCd);
                        },
                Branched.withConsumer(ks->{
                            log.info("in SYMFACT data");
                        }))
                .defaultBranch();
}

    public Message parseAndMessage(String value, String key) throws JsonProcessingException {
        Message message;
        try {
            message = objectMapper.readValue(value, Message.class);
            message.getPayload().setTransactionId(message.getPayload().getProviderId() + message.getMetadata().getSourceSystem()); // TODO:
            Provider provider = message.getPayload();
            provider.setMetadata(message.getMetadata());
            return message;
        } catch (JsonProcessingException e) {
            log.error("Error parsing avro message with key " + key);
            throw e;
        }
    }
}