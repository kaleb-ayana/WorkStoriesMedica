package com.provider.eds.service.utils;


import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.medica.model.eds.provider.Provider;
import com.medica.model.eds.provider.Specialty;
import com.provider.eds.model.Constants;
import com.provider.eds.model.ProviderCategoryCd;
import com.provider.eds.model.ProviderIdType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ProviderNotificationEvaluatorTests {
    @Autowired
    private ProviderNotificationEvaluator evaluator;

    @Test
    public void testIsPractitionerTest() {
        Provider provider=
                Provider
                        .builder()
                        .providerId("12")
                        .providerIdType(ProviderIdType.NPI1.toString())
                        .providerCategoryCd(ProviderCategoryCd.PRACT.toString())
                        .build();
        provider.setOpvProviderAddress(new ArrayList<>());
        provider.setOpvProviderAlternateId(new ArrayList<>());
        provider.setOpvProviderSpecialty(new ArrayList<>());
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        Address address= Address
                .builder()
                .logicalDeleteFlg(false)
                .addressTypeCode(Constants.AP_ADDRESS)
                .build();
        AlternateIdentifier alternateId= AlternateIdentifier
                .builder()

                .alternateIdTypeCd(Constants.NPI1)
                .logicalDeleteFlg(false)
                .mtvProviderCategoryCd("P")
                .build();
        Specialty specialty= Specialty
                .builder()
                .logicalDeleteFlg(false)
                .primaryFlg(true)
                .build();
        provider.getOpvProviderAddress().add(address);
        provider.getOpvProviderAlternateId().add(alternateId);
        provider.getOpvProviderSpecialty().add(specialty);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
        address.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        address.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
        specialty.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        specialty.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
        alternateId.setLogicalDeleteFlg(true);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isFalse();
        alternateId.setLogicalDeleteFlg(false);
        assertThat(this.evaluator.isPractitionerCandidate(provider)).isTrue();
   }
    @BeforeEach
    public void beforeAllM(){
        ReflectionTestUtils.setField(evaluator, "expirationDate", "2021-12-31");
    }
    @Test
    public void testHasAlternateIdTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.hasAlternateIdTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        ArrayList<AlternateIdentifier> alternateIdentifiers =new ArrayList<>();
        provider.setOpvProviderAlternateId(alternateIdentifiers);
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, false));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, true));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.NPI1, true));
        assertThat(this.evaluator.hasAlternateIdTypeOf(provider, Constants.TAX)).isTrue();
        assertThat(this.evaluator.hasAlternateIdTypeOf(provider, Constants.NPI1)).isTrue();
        assertThat(this.evaluator.hasAlternateIdTypeOf(provider, Constants.NPI2)).isFalse();
    }
    @Test
    public void testGetAlternateIdTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.A2_ADDRESS)).isNullOrEmpty();
        ArrayList<AlternateIdentifier> alternateIdentifiers =new ArrayList<>();
        provider.setOpvProviderAlternateId(alternateIdentifiers);
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, false));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.TAX, true));
        alternateIdentifiers.add(this.createAlternativeIdentifier(Constants.NPI1, true));
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.TAX)).hasSize(2);
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.NPI1)).hasSize(1);
        assertThat(this.evaluator.getAlternateIdTypeOf(provider, Constants.NPI2)).hasSize(0);
    }
    @Test
    public void testGetNonVoidedAddressTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.getNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isNullOrEmpty();
        ArrayList<Address> addressArrayList =new ArrayList<>();
        provider.setOpvProviderAddress(addressArrayList);
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, false));
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, false));
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, null, true));
        assertThat(this.evaluator.getNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS).size()).isEqualTo(2);
        assertThat(this.evaluator.getNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isNullOrEmpty();
        assertThat(this.evaluator.getNonVoidedAddressTypeOf(provider, Constants.AP_ADDRESS)).isNullOrEmpty();
        assertThat(this.evaluator.getNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS)).hasSize(2);

    }
    @Test
    public void testgetAddressTypeOf2() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.A2_ADDRESS)).isNullOrEmpty();
        ArrayList<Address> addressArrayList =new ArrayList<>();
        provider.setOpvProviderAddress(addressArrayList);
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, false));
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, null, true));
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.BA_ADDRESS).size()).isEqualTo(2);
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.A2_ADDRESS, false)).isNullOrEmpty();
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.AP_ADDRESS, true)).isNullOrEmpty();
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.AP_ADDRESS, false)).isNullOrEmpty();
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.BA_ADDRESS, false)).hasSize(1);
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.BA_ADDRESS, true)).hasSize(1);

    }
    @Test
    public void testgetAddressTypeOf1() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.A2_ADDRESS)).isNullOrEmpty();
        ArrayList<Address> addressArrayList =new ArrayList<>();
        provider.setOpvProviderAddress(addressArrayList);
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, null, true));
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.BA_ADDRESS).size()).isEqualTo(2);
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.A2_ADDRESS).size()).isEqualTo(1);
        assertThat(this.evaluator.getAddressTypeOf(provider, Constants.AP_ADDRESS)).isNullOrEmpty();

    }
    @Test
    public void testhasNonVoidedAddressTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        ArrayList<Address> addressArrayList =new ArrayList<>();
        provider.setOpvProviderAddress(addressArrayList);
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();;
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, null, true));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.AP_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.AP_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, false));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.BA_ADDRESS)).isTrue();
        addressArrayList.add(this.createAddress(Constants.AP_ADDRESS, null, false));
        assertThat(this.evaluator.hasNonVoidedAddressTypeOf(provider, Constants.AP_ADDRESS)).isTrue();

    }
    @Test
    public void testHasAddressTypeOf() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        ArrayList<Address> addressArrayList =new ArrayList<>();
        provider.setOpvProviderAddress(addressArrayList);
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();;
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, null, true));
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.A2_ADDRESS)).isTrue();
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.BA_ADDRESS)).isTrue();
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.AP_ADDRESS)).isFalse();
        addressArrayList.clear();
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.A2_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.BA_ADDRESS)).isFalse();
        assertThat(this.evaluator.hasAddressTypeOf(provider, Constants.AP_ADDRESS)).isFalse();

    }

    @Test
    public void testGetA2AddressesWithMDHash5() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.getA2AddressesWithMDHash5(provider)).isNullOrEmpty();
        ArrayList<Address> addressArrayList =new ArrayList<>();
        provider.setOpvProviderAddress(addressArrayList);
        addressArrayList.add(this.createAddress(Constants.BA_ADDRESS, null, true));
        assertThat(this.evaluator.getA2AddressesWithMDHash5(provider)).isNullOrEmpty();
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, null, true));
        assertThat(this.evaluator.getA2AddressesWithMDHash5(provider)).isNullOrEmpty();
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, "32545", true));
        assertThat(this.evaluator.getA2AddressesWithMDHash5(provider)).isNotEmpty();
        assertThat(this.evaluator.getA2AddressesWithMDHash5(provider).size()).isEqualTo(1);
        addressArrayList.add(this.createAddress(Constants.A2_ADDRESS, "324656545", false));
        assertThat(this.evaluator.getA2AddressesWithMDHash5(provider).size()).isEqualTo(2);
    }
    @Test
    public void testHasPrimarySpecialty() {
        Provider provider= this.createProvider("LN",null);
        assertThat(this.evaluator.hasPrimarySpecialty(provider)).isFalse();
        provider.setSitePrimarySpeciality(" ");
        assertThat(this.evaluator.hasPrimarySpecialty(provider)).isFalse();
        provider.setSitePrimarySpeciality("");
        assertThat(this.evaluator.hasPrimarySpecialty(provider)).isFalse();
    }
    @Test
    public void test() {
        assertThat(this.evaluator.hasAddressTypeOf(null, "er")).isFalse();
    }

    private Specialty createSpecialty(String cd, boolean isPrimary, boolean logicalDeleteFlag) {
        return Specialty
                .builder()
                .specialtyCode(cd)
                .primaryFlg(isPrimary)
                .logicalDeleteFlg(logicalDeleteFlag)
                .effDt("2021-01-01")
                .build();
    }
    private Address createAddress(String typeCode, String md5Hash, boolean logicalDeleteFlag) {
        return Address
                .builder()
                .addressTypeCode(typeCode)
                .addrMd5Hash(md5Hash)
                .effDt("2021-01-01")
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
    private Provider createProvider(String lastName, String primarySpecialtyCd) {
        return Provider
                .builder()
                .lastNameOrgName(lastName)
                .sitePrimarySpeciality(primarySpecialtyCd)
                .build();
    }
    private AlternateIdentifier createAlternativeIdentifier(String cdType, boolean logicalDeleteFlag ) {
        return AlternateIdentifier
                .builder()
                .alternateIdTypeCd(cdType)
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
}
