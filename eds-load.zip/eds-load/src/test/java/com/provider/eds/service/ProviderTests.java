package com.provider.eds.service;

import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.model.PracticeLocation;
import com.provider.eds.service.utils.ProviderUtil;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class ProviderTests {

    @Test
    public void hasPracticeLocationTest() {
        List<Address> addressList= new ArrayList<>();
        Provider provider= Provider
                .builder()
                .providerId("provId")
                .opvProviderAddress(addressList)
                .build();
        assertThat(ProviderUtil.hasPracticeLocation(provider)).isFalse();
        provider.getOpvProviderAddress().add(Address.builder().addressTypeCode("BA").build());
        assertThat(ProviderUtil.hasPracticeLocation(provider)).isFalse();
        provider.getOpvProviderAddress().add(Address.builder().addressTypeCode("A2").build());
        assertThat(ProviderUtil.hasPracticeLocation(provider)).isFalse();
        provider.getOpvProviderAddress().get(1).setAddrMd5Hash("");
        assertThat(ProviderUtil.hasPracticeLocation(provider)).isFalse();
        provider.getOpvProviderAddress().get(1).setAddrMd5Hash("234556");
        provider.getOpvProviderAddress().get(1).setMtvAddrId("234556");
        assertThat(ProviderUtil.hasPracticeLocation(provider)).isTrue();
        provider.getOpvProviderAddress().add(Address.builder().addressTypeCode("A2").mtvAddrId("1234").addrMd5Hash("DFHJKLH").build());

        List<PracticeLocation> plList= ProviderUtil.getMatchingPLs(provider,Set.of("XX", "YYY"));
        assertThat(plList).isNull();

        plList= ProviderUtil.getMatchingPLs(provider,Set.of("234556"));
        assertThat(plList).isNotNull();
        assertThat(plList.size()).isEqualTo(1);

        plList= ProviderUtil.getMatchingPLs(provider,Set.of("234556", "1234"));
        assertThat(plList).isNotNull();
        assertThat(plList.size()).isEqualTo(2);

        assertThat(plList.get(0).getMtvProviderId()).isEqualTo("provId");
        assertThat(plList.get(0).getPractLocId()).isEqualTo("234556");
        assertThat(plList.get(0).getMd5Hash()).isEqualTo("234556");

        assertThat(plList.get(1).getMtvProviderId()).isEqualTo("provId");
        assertThat(plList.get(1).getPractLocId()).isEqualTo("1234");
        assertThat(plList.get(1).getMd5Hash()).isEqualTo("DFHJKLH");

    }

    @Test
    public void testHasAddressLocationId() {
        Provider provider= Provider
            .builder()
            .providerId("PROVIDER-ID-1")
            .build();
        assertThat(ProviderUtil.hasAddressLocationId(provider,null)).isFalse();
        assertThat(ProviderUtil.hasAddressLocationId(provider,"")).isFalse();
        assertThat(ProviderUtil.hasAddressLocationId(provider,"LocId-1")).isFalse();

        ProviderUtil.addAddress(provider,Address
            .builder()
                    .addressTypeCode("AP")
                    .mtvAddrId("LocId-1")
            .build());
        assertThat(ProviderUtil.hasAddressLocationId(provider,null)).isFalse();
        assertThat(ProviderUtil.hasAddressLocationId(provider,"")).isFalse();
        assertThat(ProviderUtil.hasAddressLocationId(provider,"LocId-1")).isFalse();
        provider.getOpvProviderAddress().get(0).setAddressTypeCode("A2");
        assertThat(ProviderUtil.hasAddressLocationId(provider,"LocId-1")).isTrue();
        assertThat(ProviderUtil.hasAddressLocationId(provider,"LocId-2")).isFalse();
        ProviderUtil.addAddress(provider,Address
            .builder()
            .addressTypeCode("AP")
            .mtvAddrId("LocId-2")
            .build());
        assertThat(ProviderUtil.hasAddressLocationId(provider,"LocId-2")).isFalse();
        provider.getOpvProviderAddress().get(1).setAddressTypeCode("A2");
        assertThat(ProviderUtil.hasAddressLocationId(provider,"LocId-2")).isTrue();

        assertThat(ProviderUtil.getMatchingPractLocMD5(provider,"")).isEqualTo(null);
        assertThat(ProviderUtil.getMatchingPractLocMD5(provider,"")).isEqualTo(null);
        assertThat(ProviderUtil.getMatchingPractLocMD5(provider,"LocId-2")).isEqualTo(null);
        assertThat(ProviderUtil.getMatchingPractLocMD5(provider,"LocId-1")).isEqualTo(null);
        provider.getOpvProviderAddress().get(0).setAddrMd5Hash("MD5-1");
        provider.getOpvProviderAddress().get(1).setAddrMd5Hash("MD5-2");
        assertThat(ProviderUtil.getMatchingPractLocMD5(provider,"LocId-2")).isEqualTo("MD5-2");
        assertThat(ProviderUtil.getMatchingPractLocMD5(provider,"LocId-1")).isEqualTo("MD5-1");
    }
}
