package com.provider.eds.service;

import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.Message;
import com.medica.model.eds.provider.Metadata;
import com.medica.model.eds.provider.Provider;
import com.medica.reference.service.ProviderReferenceService;
import com.provider.eds.config.exceptions.DataPersistenceException;
import com.provider.eds.model.PracticeLocation;
import com.provider.eds.repository.ProviderRepository;
import com.provider.eds.service.utils.ProviderUtil;
import com.provider.eds.service.utils.ProviderUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Flux;

import java.util.*;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProviderServiceTest {

    @Mock
    ProviderUtils providerUtils = Mockito.mock(ProviderUtils.class, Mockito.RETURNS_DEEP_STUBS);

    @Mock
    ProviderRepository providerRepository = Mockito.mock(ProviderRepository.class, Mockito.RETURNS_DEEP_STUBS);

    ProviderService providerService = new ProviderService(providerRepository, providerUtils);

    @InjectMocks
    ProviderReferenceService providerReferenceService;

    Provider provider = Provider.builder()
            .providerId("1871118992")
            .providerIdType("NPI1")
            .sourceSystemCd("MTV")
            .providerCategoryCd("P")
            .opvProviderAddress(new ArrayList())
            .opvProviderAlternateId(new ArrayList())
            .build();

    Metadata metadata = Metadata.builder()
            .transactionId("1871118991")
            .sourceSystem("MTV")
            .build();

    Message message = Message.builder()
            .metadata(metadata)
            .payload(provider)
            .build();



  //  @Test
    public void testGetPractLocMap2() throws DataPersistenceException {
        List<Provider> providerList= new ArrayList<>();
        providerList.add(
                Provider
                    .builder()
                    .providerId("provider-1")
                    .opvProviderAddress(List.of(
                        Address.builder().addressTypeCode("A2").mtvAddrId("pa1").addrMd5Hash("pm11").build(),
                        Address.builder().addressTypeCode("A2").mtvAddrId("pa2").addrMd5Hash("pm12").build(),
                        Address.builder().addressTypeCode("A2").mtvAddrId("pa3").addrMd5Hash("pm13").build()
                    ))
                    .build());
        providerList.add(
                Provider
                        .builder()
                        .providerId("provider-2")
                        .opvProviderAddress(List.of(
                            Address.builder().addressTypeCode("A2").mtvAddrId("pa1").addrMd5Hash("pm21").build(),
                            Address.builder().addressTypeCode("A2").mtvAddrId("pa2").addrMd5Hash("pm22").build(),
                            Address.builder().addressTypeCode("A2").mtvAddrId("pa3").addrMd5Hash("pm13").build()
                        ))
                        .build());
        providerList.add(
                Provider
                        .builder()
                        .providerId("provider-3")
                        .opvProviderAddress(List.of(
                            Address.builder().addressTypeCode("A2").mtvAddrId("pa1").addrMd5Hash("pm31").build(),
                            Address.builder().addressTypeCode("A2").mtvAddrId("pa32").addrMd5Hash("pm32").build(),
                            Address.builder().addressTypeCode("A2").mtvAddrId("pa3").addrMd5Hash("pm33").build()
                        ))
                        .build());
        Set<String> practLocIds= new HashSet<>();
        practLocIds.add("pa1");
        practLocIds.add("pa2");

        when(this.providerRepository.findPracticeLocationProviders(any())).thenReturn(Flux.fromIterable(providerList));
        Map<String, List<PracticeLocation>> practiceLocations= this.providerService.getPractLocMap(practLocIds);
        assertThat(practiceLocations).isNotNull();
        assertThat(practiceLocations.get("pa1").size()).isEqualTo(3);
        assertThat(practiceLocations.get("pa1").get(0).getPractLocId()).isEqualTo("pa1");
        assertThat(practiceLocations.get("pa1").get(0).getMtvProviderId()).isEqualTo("provider-1");
        assertThat(practiceLocations.get("pa1").get(0).getMd5Hash()).isEqualTo("pm11");

        assertThat(practiceLocations.get("pa1").get(1).getPractLocId()).isEqualTo("pa1");
        assertThat(practiceLocations.get("pa1").get(1).getMtvProviderId()).isEqualTo("provider-2");
        assertThat(practiceLocations.get("pa1").get(1).getMd5Hash()).isEqualTo("pm21");

        assertThat(practiceLocations.get("pa1").get(2).getPractLocId()).isEqualTo("pa1");
        assertThat(practiceLocations.get("pa1").get(2).getMtvProviderId()).isEqualTo("provider-3");
        assertThat(practiceLocations.get("pa1").get(2).getMd5Hash()).isEqualTo("pm31");

        practLocIds.add("pa32");
        when(this.providerRepository.findPracticeLocationProviders(any())).thenReturn(Flux.fromIterable(providerList));
        practiceLocations= this.providerService.getPractLocMap(practLocIds);
        assertThat(practiceLocations.size()).isEqualTo(3);
        assertThat(practiceLocations.get("pa32").size()).isEqualTo(1);
        assertThat(practiceLocations.get("pa32").get(0).getPractLocId()).isEqualTo("pa32");
        assertThat(practiceLocations.get("pa32").get(0).getMtvProviderId()).isEqualTo("provider-3");
        assertThat(practiceLocations.get("pa32").get(0).getMd5Hash()).isEqualTo("pm32");
    }

    @Test
    public void testRemoveAddressesNotMatchingAddressIds() {
        Provider provider1= this.getPractLocProvider1();
        this.getPractLocProvider2().getOpvProviderAddress().stream().forEach(address -> ProviderUtil.addAddress(provider1,address));
        assertThat(provider1.getOpvProviderAddress().size()).isEqualTo(5);
        this.providerService.removeNonPracticeLocationAddresses(provider1, Set.of("ADDRESS-ID-2"));
        assertThat(provider1.getOpvProviderAddress().size()).isEqualTo(2);
    }
    private Provider getPractLocProvider1() {
        Provider provider= Provider
                .builder()
                .providerId("PROVIDER-ID-1")
                .build();
        ProviderUtil.addAddress(provider,Address
                .builder()
                        .mtvAddrId("ADDRESS-ID-1")
                        .addressTypeCode("A2")
                        .addrMd5Hash("MD5-1")
                .build());
        ProviderUtil.addAddress(provider,Address
                .builder()
                .mtvAddrId("ADDRESS-ID-1")
                .addressTypeCode("A2")
                .addrMd5Hash("MD5-11")
                .build());
        ProviderUtil.addAddress(provider,Address
                .builder()
                .mtvAddrId("ADDRESS-ID-2")
                .addressTypeCode("A2")
                .addrMd5Hash("MD5-2")
                .build());
        return provider;
    }
    private Provider getPractLocProvider2() {
        Provider provider= Provider
                .builder()
                .providerId("PROVIDER-ID-2")
                .build();
        ProviderUtil.addAddress(provider,Address
                .builder()
                .mtvAddrId("ADDRESS-ID-3")
                .addressTypeCode("A2")
                .addrMd5Hash("MD5-3")
                .build());
        ProviderUtil.addAddress(provider,Address
                .builder()
                .mtvAddrId("ADDRESS-ID-2")
                .addressTypeCode("A2")
                .addrMd5Hash("MD5-5")
                .build());
        return provider;
    }

}