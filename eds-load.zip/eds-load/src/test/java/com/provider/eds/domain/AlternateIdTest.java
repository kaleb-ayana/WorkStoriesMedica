package com.provider.eds.domain;

import com.medica.model.eds.provider.AlternateIdentifier;
import com.provider.eds.service.utils.AlternateIdentifierUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AlternateIdTest {
    @Test
    public void testHasMd5Hash() {
        AlternateIdentifier alternateIdentifier= AlternateIdentifier
                .builder()
                .build();
        assertThat(AlternateIdentifierUtil.isTaxEntity(alternateIdentifier)).isFalse();
        alternateIdentifier.setAlternateIdTypeCd("TAX");
        assertThat(AlternateIdentifierUtil.isTaxEntity(alternateIdentifier)).isTrue();
    }
    @Test
    public void testhasLogicalDeleteFlag() {
        AlternateIdentifier alternateIdentifier= AlternateIdentifier
                .builder()
                .alternateId("344")
                .build();
        assertThat(AlternateIdentifierUtil.hasLogicalDeleteFlag(alternateIdentifier,true)).isFalse();
        assertThat(AlternateIdentifierUtil.hasLogicalDeleteFlag(alternateIdentifier,false)).isTrue();
    }
    @Test
    public void testhasEndDate() {
        AlternateIdentifier alternateIdentifier= AlternateIdentifier
                .builder()
                .endDt("2020-01-01")
                .build();
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,null)).isFalse();
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,"2020-02-02")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,"2020-01-01")).isTrue();
        alternateIdentifier.setEndDt(null);
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,null)).isTrue();
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,"2020-02-02")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEndDate(alternateIdentifier,"2020-01-01")).isFalse();
    }
    @Test
    public void testhasEffectiveDate() {
        AlternateIdentifier alternateIdentifier= AlternateIdentifier
                .builder()
                .effDt("2020-01-01")
                .build();
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,null)).isFalse();
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,"2020-02-02")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,"2020-01-01")).isTrue();
        alternateIdentifier.setEffDt(null);
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,null)).isTrue();
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,"2020-02-02")).isFalse();
        assertThat(AlternateIdentifierUtil.hasEffectiveDate(alternateIdentifier,"2020-01-01")).isFalse();
    }
    @Test
    public void testhasAlternativeId() {
        AlternateIdentifier alternateIdentifier= AlternateIdentifier
                .builder()
                .alternateId("2020-01-01")
                .build();
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,null)).isFalse();
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,"2020-02-02")).isFalse();
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,"2020-01-01")).isTrue();
        alternateIdentifier.setAlternateId(null);
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,null)).isTrue();
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,"")).isFalse();
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,"2020-02-02")).isFalse();
        assertThat(AlternateIdentifierUtil.hasAlternateId(alternateIdentifier,"2020-01-01")).isFalse();
    }
//    @Test
//    public void testhasLogicalDeleteFlag() {
//        AlternateIdentifier alternateIdentifier= AlternateIdentifier
//                .builder()
//                .build();
//        assertThat(alternateIdentifier.hasLogicalDeleteFlag(true)).isFalse();
//        assertThat(alternateIdentifier.hasLogicalDeleteFlag(false)).isTrue();
//    }
}
