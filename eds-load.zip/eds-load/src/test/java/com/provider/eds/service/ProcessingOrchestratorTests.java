package com.provider.eds.service;

import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.medica.model.eds.provider.Provider;
import com.medica.reference.model.*;
import com.provider.eds.service.utils.ProviderUtil;
import com.provider.eds.service.utils.ProviderUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@ExtendWith(MockitoExtension.class)
public class ProcessingOrchestratorTests {
    @InjectMocks
    ProcessingOrchestrator processingOrchestrator;
    @Spy
    ProviderUtils providerUtils;
    @Mock
    ProviderService providerService;

    @Test
    public void testMD5ProviderReferences(){
        List<Provider> providerList = new ArrayList<>();
        providerList.add(getPractLocProvider1());

        ProviderReferenceGroup mockedProviderRefGroup = new ProviderReferenceGroup();

        ReferenceId relatedProviderReferenceId =  ReferenceIdFactory.createMTVProviderReference("PROVIDER-ID-2", "2021-01-01", "2022-01-01", false);
        List<ReferenceId> relatedProviderReferenceList = new ArrayList<>();
        relatedProviderReferenceList.add(relatedProviderReferenceId);

        ProviderReference mockedMD5Reference_MD5_2 = ReferenceFactory.createMD5IdReference(
                "MD5-2","MTV","MTV","2019-01-01","2021-01-01",
                true,false,false,"",relatedProviderReferenceList);

        mockedProviderRefGroup.addOrReplace(mockedMD5Reference_MD5_2);

        Mockito.when(providerService.getProviderReferences(Mockito.any())).thenReturn(mockedProviderRefGroup);
//        Mockito.when(providerService.decorateIdWithSourceSystemCd(Mockito.any(),Mockito.any())).thenReturn(new HashSet<>());
//        Mockito.when(providerService.getProvidersByTransactionIds(Mockito.any())).thenReturn(providerList);

        ProviderReferenceGroup providerReferenceGroup = processingOrchestrator.processProviderReferences(providerList.get(0), null);

        ProviderReference md5Reference1 = providerReferenceGroup.getMD5Reference("MD5-1").get();
        ReferenceId relatedMtvProviderIdReference1 = md5Reference1.getRelatedProviderIds().stream().findFirst().get();
        assertThat(md5Reference1.getProviderId()).isEqualTo("MD5-1");
        assertThat(md5Reference1.getEffDt()).isEqualTo("2021-01-01");
        assertThat(md5Reference1.getEndDt()).isEqualTo("2022-01-01");
        assertThat(md5Reference1.isLogicalDeleteFlg()).isEqualTo(false);
        assertThat(relatedMtvProviderIdReference1.getSourceSystemId()).isEqualTo("PROVIDER-ID-1");
        assertThat(relatedMtvProviderIdReference1.getEffDt()).isEqualTo("2021-01-01");
        assertThat(relatedMtvProviderIdReference1.getEndDt()).isEqualTo("2022-01-01");
        assertThat(relatedMtvProviderIdReference1.isLogicalDeleteFlg()).isEqualTo(false);

        ProviderReference md5Reference2 = providerReferenceGroup.getMD5Reference("MD5-2").get();
        List<ReferenceId> relatedMtvProviderIdList = md5Reference2.getRelatedProviderIds().stream().collect(Collectors.toList());
        ReferenceId md5_2_relatedMtvProviderIdReference1 = relatedMtvProviderIdList.get(0);
        ReferenceId md5_2_relatedMtvProviderIdReference2 = relatedMtvProviderIdList.get(1);
        assertThat(relatedMtvProviderIdList.size()).isEqualTo(2);
        assertThat(md5_2_relatedMtvProviderIdReference1.getSourceSystemId()).isEqualTo("PROVIDER-ID-2");
        assertThat(md5_2_relatedMtvProviderIdReference2.getSourceSystemId()).isEqualTo("PROVIDER-ID-1");
        assertThat(md5Reference2.isLogicalDeleteFlg()).isEqualTo(true);

        ProviderReference md5Reference3 = providerReferenceGroup.getMD5Reference("6D74C3B5BC5B9C5CAACA4B6EB33502DC").get();
        assertThat(md5Reference3).isNotNull();
        assertThat(md5Reference3.getRelatedTaxId()).isEqualTo("158153123");
    }

    @Test
    public void testTaxIdProviderReferences(){

        List<Provider> providerList = new ArrayList<>();
        providerList.add(getPayTOProvider1());

        ProviderReferenceGroup mockedProviderRefGroup = new ProviderReferenceGroup();

        ReferenceId relatedProviderReferenceId =  ReferenceIdFactory.createMTVProviderReference("PROVIDER-ID-2", "2021-01-01", "2022-01-01", false);
        List<ReferenceId> relatedProviderReferenceList = new ArrayList<>();
        relatedProviderReferenceList.add(relatedProviderReferenceId);

        ProviderReference mockedTaxReference_222 = ReferenceFactory.createTaxIdReference(
                "222","MTV","2019-01-01","2021-01-01",false,"",relatedProviderReferenceList);

        mockedProviderRefGroup.addOrReplace(mockedTaxReference_222);
//
        Mockito.when(providerService.getProviderReferences(Mockito.any())).thenReturn(mockedProviderRefGroup);
//        Mockito.when(providerService.decorateIdWithSourceSystemCd(Mockito.any(),Mockito.any())).thenReturn(new HashSet<>());
//        Mockito.when(providerService.getProvidersByTransactionIds(Mockito.any())).thenReturn(providerList);

        ProviderReferenceGroup providerReferenceGroup = processingOrchestrator.processProviderReferences(providerList.get(0), null);

        ProviderReference taxIdReference_111 = providerReferenceGroup.getTaxIdReference("111").get();
        ReferenceId relatedMtvProviderIdReference1 = taxIdReference_111.getRelatedProviderIds().stream().findFirst().get();
        assertThat(taxIdReference_111.getProviderId()).isEqualTo("111");
        assertThat(taxIdReference_111.getEffDt()).isEqualTo("2022-01-01");
        assertThat(taxIdReference_111.getEndDt()).isEqualTo("2022-04-30");
        assertThat(taxIdReference_111.isLogicalDeleteFlg()).isEqualTo(false);
        assertThat(relatedMtvProviderIdReference1.getSourceSystemId()).isEqualTo("PROVIDER-ID-1");
        assertThat(relatedMtvProviderIdReference1.getEffDt()).isEqualTo("2021-01-01");
        assertThat(relatedMtvProviderIdReference1.getEndDt()).isEqualTo("2022-01-01");
        assertThat(relatedMtvProviderIdReference1.isLogicalDeleteFlg()).isEqualTo(false);

        ProviderReference taxIdReference_222 = providerReferenceGroup.getTaxIdReference("222").get();
        List<ReferenceId> relatedMtvProviderIdList = taxIdReference_222.getRelatedProviderIds().stream().collect(Collectors.toList());
        ReferenceId tax_222_relatedMtvProviderIdReference1 = relatedMtvProviderIdList.get(0);
        ReferenceId tax_222_relatedMtvProviderIdReference2 = relatedMtvProviderIdList.get(1);
        assertThat(relatedMtvProviderIdList.size()).isEqualTo(2);
        assertThat(tax_222_relatedMtvProviderIdReference1.getSourceSystemId()).isEqualTo("PROVIDER-ID-2");
        assertThat(tax_222_relatedMtvProviderIdReference2.getSourceSystemId()).isEqualTo("PROVIDER-ID-1");
        //TODO check if this supposed to be true , if so tweak logic to update existing reference to use values from provider being loaded
        assertThat(taxIdReference_222.isLogicalDeleteFlg()).isEqualTo(false);

    }

    @Test
    public void testNPI1ProviderReferences(){

        List<Provider> providerList = new ArrayList<>();
        providerList.add(getNPI1Provider1());

        ProviderReferenceGroup mockedProviderRefGroup = new ProviderReferenceGroup();

        ReferenceId relatedProviderReferenceId =  ReferenceIdFactory.createMTVProviderReference("PROVIDER-ID-2", "2021-01-01", "2022-01-01", false);
        List<ReferenceId> relatedProviderReferenceList = new ArrayList<>();
        relatedProviderReferenceList.add(relatedProviderReferenceId);

        ProviderReference mockedNPI1Reference_222 =   ReferenceFactory.createNPI1Reference("222","MTV","MTV","2019-01-01","2022-12-31",false,relatedProviderReferenceList);

        mockedProviderRefGroup.addOrReplace(mockedNPI1Reference_222);

        Mockito.when(providerService.getProviderReferences(Mockito.any())).thenReturn(mockedProviderRefGroup);
//        Mockito.when(providerService.decorateIdWithSourceSystemCd(Mockito.any(),Mockito.any())).thenReturn(new HashSet<>());
//        Mockito.when(providerService.getProvidersByTransactionIds(Mockito.any())).thenReturn(providerList);

        ProviderReferenceGroup providerReferenceGroup = processingOrchestrator.processProviderReferences(providerList.get(0), null);
        ProviderReference npi1Reference_111 = providerReferenceGroup.getNPI1Reference("111").get();
        ReferenceId relatedMtvProviderIdReference1 = npi1Reference_111.getRelatedProviderIds().stream().findFirst().get();
        assertThat(npi1Reference_111.getProviderId()).isEqualTo("111");
        assertThat(npi1Reference_111.getEffDt()).isEqualTo("2020-01-01");
        assertThat(npi1Reference_111.getEndDt()).isEqualTo("2021-12-31");
        assertThat(npi1Reference_111.isLogicalDeleteFlg()).isEqualTo(false);
        assertThat(relatedMtvProviderIdReference1.getSourceSystemId()).isEqualTo("PROVIDER-ID-1");
        assertThat(relatedMtvProviderIdReference1.getEffDt()).isEqualTo("2021-01-01");
        assertThat(relatedMtvProviderIdReference1.getEndDt()).isEqualTo("2022-01-01");
        assertThat(relatedMtvProviderIdReference1.isLogicalDeleteFlg()).isEqualTo(false);

        ProviderReference npi1Reference_222 = providerReferenceGroup.getNPI1Reference("222").get();
        List<ReferenceId> relatedMtvProviderIdList = npi1Reference_222.getRelatedProviderIds().stream().collect(Collectors.toList());
        ReferenceId npi1_222_relatedMtvProviderIdReference1 = relatedMtvProviderIdList.get(0);
        ReferenceId npi1_222_relatedMtvProviderIdReference2 = relatedMtvProviderIdList.get(1);
        assertThat(relatedMtvProviderIdList.size()).isEqualTo(2);
        assertThat(npi1_222_relatedMtvProviderIdReference1.getSourceSystemId()).isEqualTo("PROVIDER-ID-2");
        assertThat(npi1_222_relatedMtvProviderIdReference2.getSourceSystemId()).isEqualTo("PROVIDER-ID-1");
        //TODO check if this supposed to be true , if so tweak logic to update existing reference to use values from provider being loaded
        assertThat(npi1Reference_222.isLogicalDeleteFlg()).isEqualTo(false);

    }

    private Provider getNPI1Provider1(){
        Provider provider= Provider
                .builder()
                .providerId("PROVIDER-ID-1")
                .effDate("2021-01-01")
                .termDt("2022-01-01")
                .logicalDeleteFlg(false)
                .opvProviderAlternateId(new ArrayList<>())
                .build();
        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("111","NPI1"
                ,"MTV",false,"2020-01-01","2021-12-31","DHP","PAYTO"
                ,"TAX"));
        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("222","NPI1"
                ,"MTV",true,"2019-01-01","2022-12-31","DHP","PAYTO"
                ,"TAX"));
        return provider;
    }
    private static AlternateIdentifier buildAlternateIdentifier(String alternateId, String alternateIdTypeCd, String sourceSystemCd, Boolean logicalDeleteFlg
            , String effDt, String endDt, String entityName, String mtvProviderCategoryCd, String mtvProviderTypeCd) {
        return AlternateIdentifier
                .builder()
                .alternateId(alternateId)
                .alternateIdTypeCd(alternateIdTypeCd)
                .sourceSystemCd(sourceSystemCd)
                .logicalDeleteFlg(logicalDeleteFlg)
                .effDt(effDt)
                .endDt(endDt)
                .entityName(entityName)
                .mtvProviderCategoryCd(mtvProviderCategoryCd)
                .mtvProviderTypeCd(mtvProviderTypeCd)
                .build();
    }

    private Provider getPayTOProvider1() {
        Provider provider= Provider
                .builder()
                .providerId("PROVIDER-ID-1")
                .effDate("2021-01-01")
                .termDt("2022-01-01")
                .logicalDeleteFlg(false)
                .opvProviderAlternateId(new ArrayList<>())
                .build();
        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("111")
                .alternateIdTypeCd("TAX")
                .sourceSystemCd("MTV")
                .logicalDeleteFlg(false)
                .effDt("2022-01-01")
                .endDt("2022-04-30")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());
        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("222")
                .alternateIdTypeCd("TAX")
                .logicalDeleteFlg(true)
                .sourceSystemCd("MTV")
                .effDt("2022-05-01")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());

        return provider;
    }

    private Provider getPractLocProvider1() {
        Provider provider= Provider
                .builder()
                .providerId("PROVIDER-ID-1")
                .effDate("2021-01-01")
                .termDt("2022-01-01")
                .logicalDeleteFlg(false)
                .opvProviderSpecialty(new ArrayList<>())
                .opvProviderAlternateId(new ArrayList<>())
                .lastNameOrgName("Test LocFAc July13")
                .sitePrimarySpeciality("SK005")
                .build();
        ProviderUtil.addAddress(provider,Address
                .builder()
                .mtvAddrId("ADDRESS-ID-1")
                .addressTypeCode("A2")
                .addrMd5Hash("MD5-1")
                .sourceSystemCd("MTV")
                .effDt("2021-01-01")
                .endDt("2022-01-01")
                .logicalDeleteFlg(false)
                .build());
        ProviderUtil.addAddress(provider,Address
                .builder()
                .mtvAddrId("ADDRESS-ID-1")
                .addressTypeCode("A2")
                .addressLine1("PO BOX 102")
                .addressLine2("")
                .addressLine3("")
                .stateCd("WI")
                .zipCd5("53577")
                .city("PLAIN")
                .county("SAUK")
                .addrMd5Hash("6D74C3B5BC5B9C5CAACA4B6EB33502DC")
                .sourceSystemCd("MTV")
                .effDt("2021-01-01")
                .endDt("2022-01-01")
                .build());
        ProviderUtil.addAddress(provider,Address
                .builder()
                .mtvAddrId("ADDRESS-ID-2")
                .addressTypeCode("A2")
                .addrMd5Hash("MD5-2")
                .sourceSystemCd("MTV")
                .effDt("2019-01-01")
                .endDt("2021-01-01")
                .logicalDeleteFlg(true)
                .build());

        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("158153123")
                .alternateIdTypeCd("TAX")
                .logicalDeleteFlg(false)
                .sourceSystemCd("MTV")
                .effDt("2023-07-13")
                .mtvProviderCategoryCd("O")
                .mtvProviderTypeCd("CN")
                .build());
        return provider;
    }

}
