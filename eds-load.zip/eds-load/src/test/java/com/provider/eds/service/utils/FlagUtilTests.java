package com.provider.eds.service.utils;

import com.medica.model.eds.provider.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

public class FlagUtilTests {
    @Test
    public void testTaxonomyGetDefaultValue() {
        Taxonomy item= Taxonomy.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Taxonomy.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Taxonomy.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Taxonomy.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Taxonomy.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testSpecialtyGetDefaultValue() {
        Specialty item= Specialty.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Specialty.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Specialty.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Specialty.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Specialty.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testRemarkGetDefaultValue() {
        Remark item= Remark.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Remark.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Remark.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Remark.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Remark.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testPanelGetDefaultValue() {
        Panel item= Panel.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Panel.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Panel.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Panel.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Panel.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testNetworkGetDefaultValue() {
        Network item= Network.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Network.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Network.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Network.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Network.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testLicenseGetDefaultValue() {
        License item= License.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= License.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= License.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= License.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= License.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testLanguageGetDefaultValue() {
        Language item= Language.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Language.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Language.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Language.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Language.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testElectronicAddressGetDefaultValue() {
        ElectronicAddress item= ElectronicAddress.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= ElectronicAddress.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= ElectronicAddress.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= ElectronicAddress.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= ElectronicAddress.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testDegreeGetDefaultValue() {
        Degree item= Degree.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Degree.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Degree.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Degree.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Degree.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testCertificationGetDefaultValue() {
        Certification item= Certification.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Certification.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Certification.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Certification.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Certification.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testAlternateIdentifierGetDefaultValue() {
        AlternateIdentifier item= AlternateIdentifier.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= AlternateIdentifier.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= AlternateIdentifier.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= AlternateIdentifier.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= AlternateIdentifier.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testAffiliationGetDefaultValue() {
        Affiliation item= Affiliation.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Affiliation.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Affiliation.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Affiliation.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Affiliation.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item.setAffiliationSpecialtyList(new ArrayList<>());
        item.getAffiliationSpecialtyList().add(AffiliationSpecialty.builder().logicalDeleteFlg(null).build());
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getAffiliationSpecialtyList().get(0).getLogicalDeleteFlg()).isFalse();

        item.getAffiliationSpecialtyList().get(0).setLogicalDeleteFlg(false);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getAffiliationSpecialtyList().get(0).getLogicalDeleteFlg()).isFalse();

        item.getAffiliationSpecialtyList().get(0).setLogicalDeleteFlg(true);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getAffiliationSpecialtyList().get(0).getLogicalDeleteFlg()).isTrue();

        item.getAffiliationSpecialtyList().get(0).setLogicalDeleteFlg(Boolean.FALSE);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getAffiliationSpecialtyList().get(0).getLogicalDeleteFlg()).isFalse();

        item.getAffiliationSpecialtyList().get(0).setLogicalDeleteFlg(Boolean.TRUE);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getAffiliationSpecialtyList().get(0).getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testAffiliationSpecialtyGetDefaultValue() {
        AffiliationSpecialty item= AffiliationSpecialty.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= AffiliationSpecialty.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= AffiliationSpecialty.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= AffiliationSpecialty.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= AffiliationSpecialty.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testPhoneGetDefaultValue() {
        Phone item= Phone.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Phone.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Phone.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Phone.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Phone.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();
    }
    @Test
    public void testAddressGetDefaultValue() {
        Address item= Address.builder().logicalDeleteFlg(null).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Address.builder().logicalDeleteFlg(false).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Address.builder().logicalDeleteFlg(true).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item= Address.builder().logicalDeleteFlg(Boolean.FALSE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isFalse();

        item= Address.builder().logicalDeleteFlg(Boolean.TRUE).build();
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getLogicalDeleteFlg()).isTrue();

        item.setOpvProviderPhone(new ArrayList<>());
        item.getOpvProviderPhone().add(Phone.builder().logicalDeleteFlg(null).build());
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getOpvProviderPhone().get(0).getLogicalDeleteFlg()).isFalse();

        item.getOpvProviderPhone().get(0).setLogicalDeleteFlg(false);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getOpvProviderPhone().get(0).getLogicalDeleteFlg()).isFalse();

        item.getOpvProviderPhone().get(0).setLogicalDeleteFlg(true);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getOpvProviderPhone().get(0).getLogicalDeleteFlg()).isTrue();

        item.getOpvProviderPhone().get(0).setLogicalDeleteFlg(Boolean.FALSE);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getOpvProviderPhone().get(0).getLogicalDeleteFlg()).isFalse();

        item.getOpvProviderPhone().get(0).setLogicalDeleteFlg(Boolean.TRUE);
        FlagUtil.defaultFlagValue(item);
        assertThat(item.getOpvProviderPhone().get(0).getLogicalDeleteFlg()).isTrue();
    }
}
