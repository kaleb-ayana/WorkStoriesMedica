package com.provider.eds;

import com.provider.eds.controller.Controller;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
@ExtendWith(MockitoExtension.class)
class ControllerTest {
    @InjectMocks
    Controller controller;

/*    @Test
    void getHealth() {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        String responseEntity = controller.getHealth();
        assertEquals(responseEntity, "healthy");
    }*/
}