package com.provider.eds.domain;

import com.medica.model.eds.provider.Address;
import com.provider.eds.service.utils.AddressUtil;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class AddressTest {
    @Test
    public void testHasMd5Hash() {
        Address address= Address
                .builder()
                .build();
        assertThat(AddressUtil.hasMD5Hash(address)).isFalse();
        address.setAddrMd5Hash("");
        assertThat(AddressUtil.hasMD5Hash(address)).isFalse();
        address.setAddrMd5Hash(null);
        assertThat(AddressUtil.hasMD5Hash(address)).isFalse();
        address.setAddrMd5Hash("9999999999999999");
        assertThat(AddressUtil.hasMD5Hash(address)).isTrue();

        assertThat(AddressUtil.hasMD5Hash(null)).isFalse();
        assertThat(AddressUtil.hasMD5Hash(address,"")).isFalse();
        assertThat(AddressUtil.hasMD5Hash(address,"9999999999999999")).isTrue();
        assertThat(AddressUtil.hasMD5Hash(address,"999999999999")).isFalse();
        address.setAddrMd5Hash(null);
        assertThat(AddressUtil.hasMD5Hash(address,null)).isFalse();
        assertThat(AddressUtil.hasMD5Hash(address,"")).isFalse();
    }
    @Test
    public void testhasLogicalDeleteFlag() {
        Address address= Address
                .builder()
                .build();
        assertThat(AddressUtil.hasLogicalDeleteFlag(address,true)).isFalse();
        assertThat(AddressUtil.hasLogicalDeleteFlag(address,false)).isTrue();
    }
}
