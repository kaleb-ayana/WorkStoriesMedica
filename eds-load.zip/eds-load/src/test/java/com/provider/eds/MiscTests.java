package com.provider.eds;

import com.medica.model.eds.provider.*;
import com.provider.eds.model.ErroredRecord;
import com.provider.eds.service.utils.*;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class MiscTests {
    @Test
    public void testProvidercleanDuplicates_1() {
        List<Panel> panels= new ArrayList<>();
        panels.add(Panel
            .builder()
            .pracLocProviderId("pid1")
            .effDt("2020-01-01")
            .endDt("2021-01-01")
            .build()
        );
        panels.add(Panel
                .builder()
                .pracLocProviderId("pid1")
                .effDt("2020-01-01")
                .endDt("2021-01-01")
                .build()
        );
        panels.add(Panel
                .builder()
                .pracLocProviderId("pid1")
                .effDt("2021-01-01")
                .endDt("2022-01-01")
                .build()
        );
        Provider provider= Provider
                .builder()
                .opvProviderPanel(panels)
                .build();
        ProviderUtil.cleanDuplicates(provider);
        assertThat(provider.getOpvProviderPanel().size()).isEqualTo(2);
        assertThat(provider.getOpvProviderPanel().get(0).getPracLocProviderId()).isEqualTo("pid1");
        assertThat(provider.getOpvProviderPanel().get(0).getEffDt()).isEqualTo("2020-01-01");
        assertThat(provider.getOpvProviderPanel().get(1).getPracLocProviderId()).isEqualTo("pid1");
        assertThat(provider.getOpvProviderPanel().get(1).getEffDt()).isEqualTo("2021-01-01");
        provider.getOpvProviderPanel().add(Panel
                .builder()
                .pracLocProviderId("pid3")
                .effDt("2020-01-01")
                .endDt("2022-01-01")
                .build()
        );
        ProviderUtil.cleanDuplicates(provider);
        assertThat(provider.getOpvProviderPanel().size()).isEqualTo(3);

    }

    @Test
    public void panelMatchesTest() {
        Panel panel1= Panel
                .builder()
                .build();
        Panel panel2= Panel
                .builder()
                .build();
        assertThat(PanelUtil.equals(panel1, panel2)).isTrue();
        panel1.setPracLocProviderId("001");
        assertThat(PanelUtil.equals(panel1, panel2)).isFalse();
        panel2.setPracLocProviderId("001");
        assertThat(PanelUtil.equals(panel1, panel2)).isTrue();
        panel1.setEffDt("2022-01-01");
        assertThat(PanelUtil.equals(panel1, panel2)).isFalse();
        panel2.setEffDt("2022-01-01");
        assertThat(PanelUtil.equals(panel1, panel2)).isTrue();
    }
    @Test
    public void networkMatchesTest() {
        Network network1= Network
                .builder()
                .build();
        Network network2= Network
                .builder()
                .build();
        assertThat(NetworkUtil.areEqual(network1, network2)).isTrue();
        network1.setPraclocProviderId("001");
        assertThat(NetworkUtil.areEqual(network1, network2)).isFalse();
        network2.setPraclocProviderId("001");
        assertThat(NetworkUtil.areEqual(network1, network2)).isTrue();
        network1.setEffDt("2022-01-01");
        assertThat(NetworkUtil.areEqual(network1, network2)).isFalse();
        network2.setEffDt("2022-01-01");
        assertThat(NetworkUtil.areEqual(network1, network2)).isTrue();
        network1.setNetworkId("n1");
        assertThat(NetworkUtil.areEqual(network1, network2)).isFalse();
        network2.setNetworkId("n1");
        assertThat(NetworkUtil.areEqual(network1, network2)).isTrue();
    }
    @Test
    public void testResynchTags() {
        Panel panel= Panel
                .builder()
                .effDt("2020-01-01")
                .pracLocProviderId("add-1")
                .endDt("2021-01-01")
                .build();
        PanelUtil.tagForResynch(panel);
        String tag= panel.getResynchTag();
        assertThat(panel.getResynchTag()).isEqualTo("2020-01-01;2021-01-01;false");
        assertThat(panel.getAddressId()).isEqualTo("add-1");
        assertThat(Boolean.parseBoolean("true")).isTrue();
        assertThat(Boolean.parseBoolean("false")).isFalse();
        Network network= Network
                .builder()
                .effDt("2020-01-01")
                .praclocProviderId("add-1")
                .endDt("2021-01-01")
                .build();
        NetworkUtil.tagForResynch(network);
        tag= network.getResynchTag();
        assertThat(network.getResynchTag()).isEqualTo("2020-01-01;2021-01-01;false");
        assertThat(network.getAddressId()).isEqualTo("add-1");
        Affiliation affiliation= Affiliation
                .builder()
                .effDt("2020-01-01")
                .endDt("2021-01-01")
                .build();
        AffiliationUtil.tagForResynch(affiliation);
        tag= affiliation.getResynchTag();
        assertThat(affiliation.getResynchTag()).isEqualTo("2020-01-01;2021-01-01;false");


        affiliation.setResynchTag(null);
        panel.setResynchTag(null);
        panel.setAddressId(null);

        network.setResynchTag(null);
        network.setAddressId(null);

        List<Network> networks= new ArrayList<>();
        networks.add(network);
        List<Panel> panels= new ArrayList<>();
        panels.add(panel);

        List<Affiliation> affiliations= new ArrayList<>();
        affiliations.add(affiliation);
        Provider provider= Provider
                .builder()
                .opvProviderPanel(panels)
                .opvProviderAffiliation(affiliations)
                .opvProviderNetworkDirectory(networks)
                .build();
        ProviderUtil.buildTagsForResynch(provider);
        assertThat(provider.getOpvProviderPanel().get(0).getResynchTag()).isEqualTo("2020-01-01;2021-01-01;false");
        assertThat(provider.getOpvProviderPanel().get(0).getAddressId()).isEqualTo("add-1");
        assertThat(provider.getOpvProviderNetworkDirectory().get(0).getResynchTag()).isEqualTo("2020-01-01;2021-01-01;false");
        assertThat(provider.getOpvProviderNetworkDirectory().get(0).getAddressId()).isEqualTo("add-1");
        assertThat(provider.getOpvProviderAffiliation().get(0).getResynchTag()).isEqualTo("2020-01-01;2021-01-01;false");
    }
    @Test
    public void testCreateErroredRecord() {
        ErroredRecord record= ErroredRecord.create("345", Timestamp.from(Instant.now()).toString());
        assertThat(record.getTimestamp()).isNotNull();

        record= ErroredRecord.create("123");
        assertThat(record.getTimestamp()).isNotNull();
    }

    @Test
    public void testAddressTypeCheck() {
        Address address= Address
                .builder()
                .addressTypeCode("A2")
                .build();
        assertThat(AddressUtil.isPracticeLocation(address)).isTrue();
        address.setAddressTypeCode("");

        assertThat(AddressUtil.hasType(address,"")).isFalse();
        assertThat(AddressUtil.isPracticeLocation(address)).isFalse();
        address.setAddressTypeCode("AP");
        assertThat(AddressUtil.isPracticeLocation(address)).isFalse();
        assertThat(AddressUtil.hasType(address,"AP")).isTrue();

    }
}
