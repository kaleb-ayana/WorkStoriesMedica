package com.provider.eds.service.utils;

import com.medica.model.eds.provider.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.assertj.core.api.Assertions.assertThat;

public class DateUtilTests {

    @Test
    public void testConvertToDate() {
        assertThat(DateUtil.convertToDate(null)).isNull();
        assertThat(DateUtil.convertToDate("")).isEqualTo("");
        assertThat(DateUtil.convertToDate(" ")).isEqualTo(" ");
        assertThat(DateUtil.convertToDate("XXX")).isEqualTo("XXX");
        assertThat(DateUtil.convertToDate("19476")).isNotEmpty();
        assertThat(DateUtil.convertToDate("19476")).isNotBlank();
        assertThat(DateUtil.convertToDate("2932896")).isEqualTo("9999-12-31");
    }
    @Test
    public void testProviderDates() {
        Provider provider= this.getProvider("2932896", null, null, null, null, null);
        DateUtil.stringfyDates(provider);
        assertThat(provider.getEffDate()).isEqualTo("9999-12-31");
        assertThat(provider.getTermDt()).isEqualTo(null);
        assertThat(provider.getDirectorySuppressDt()).isEqualTo(null);
        assertThat(provider.getDirectoryDivisionEffDt()).isEqualTo(null);
        assertThat(provider.getW9Dt()).isEqualTo(null);
        assertThat(provider.getMocCompletedDt()).isEqualTo(null);

        provider.getOpvProviderPanel().add( this.getPanel("2932896", "2932896"));
        provider.getGlobalBillings().add(this.getGlobalBilling("2932896", "2932896", "2932896", "2932896","2932896"));
        provider.getOpvProviderEducation().add(this.getEducation("2932896", "2932896"));
        provider.getOpvProviderSpecialty().add(this.getSpecialty("2932896", "2932896"));
        provider.getOpvProviderAlternateId().add(this.getAlternateIdentifier("2932896", "2932896"));
        provider.getOpvProviderAddress().add(this.getAddress("2932896", "2932896"));
        provider.getOpvProviderCertification().add(this.getCertification("2932896", "2932896"));
        provider.getOpvProviderLicence().add(this.getLicense("2932896", "2932896"));
        provider.getOpvProviderNetworkDirectory().add(this.getNetwork("2932896", "2932896",null));
        provider.getOpvProviderRemarks().add(this.getRemark("2932896", "2932896"));
        provider.getOpvProviderTaxonomy().add(this.getTaxonomy("2932896", "2932896"));
        provider.getOpvProviderAffiliation().add(this.getAffiliation("2932896", "2932896"));

        DateUtil.stringfyDates(provider);

        assertThat(provider.getOpvProviderPanel().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getGlobalBillings().get(0).getMecDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderEducation().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderSpecialty().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderAlternateId().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderAddress().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderCertification().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderLicence().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderNetworkDirectory().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderRemarks().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderTaxonomy().get(0).getEffDt()).isEqualTo("9999-12-31");
        assertThat(provider.getOpvProviderAffiliation().get(0).getEffDt()).isEqualTo("9999-12-31");
    }

    @Test
    public void testAffiliation() {
        Affiliation affiliation= this.getAffiliation(null, null);
        DateUtil.strinfyDates(affiliation);
        assertThat(affiliation.getEffDt()).isEqualTo(null);
        assertThat(affiliation.getEndDt()).isEqualTo(null);

        affiliation= this.getAffiliation("2932896", null);
        DateUtil.strinfyDates(affiliation);
        assertThat(affiliation.getEffDt()).isEqualTo("9999-12-31");
        assertThat(affiliation.getEndDt()).isEqualTo(null);

        affiliation= this.getAffiliation("2932896", "2932896");
        DateUtil.strinfyDates(affiliation);
        assertThat(affiliation.getEffDt()).isEqualTo("9999-12-31");
        assertThat(affiliation.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testAffiliationSpecialty() {
        AffiliationSpecialty affiliationSpecialty= this.getAffiliationSpecialty(null, null);
        DateUtil.strinfyDates(affiliationSpecialty);
        assertThat(affiliationSpecialty.getEffDt()).isEqualTo(null);
        assertThat(affiliationSpecialty.getEndDt()).isEqualTo(null);

        affiliationSpecialty= this.getAffiliationSpecialty("2932896", null);
        DateUtil.strinfyDates(affiliationSpecialty);
        assertThat(affiliationSpecialty.getEffDt()).isEqualTo("9999-12-31");
        assertThat(affiliationSpecialty.getEndDt()).isEqualTo(null);

        affiliationSpecialty= this.getAffiliationSpecialty("2932896", "2932896");
        DateUtil.strinfyDates(affiliationSpecialty);
        assertThat(affiliationSpecialty.getEffDt()).isEqualTo("9999-12-31");
        assertThat(affiliationSpecialty.getEndDt()).isEqualTo("9999-12-31");
    }

    @Test
    public void testTaxonomyDates() {
        Taxonomy taxonomy= this.getTaxonomy(null, null);
        DateUtil.strinfyDates(taxonomy);
        assertThat(taxonomy.getEffDt()).isEqualTo(null);
        assertThat(taxonomy.getEndDt()).isEqualTo(null);

        taxonomy= this.getTaxonomy("2932896", null);
        DateUtil.strinfyDates(taxonomy);
        assertThat(taxonomy.getEffDt()).isEqualTo("9999-12-31");
        assertThat(taxonomy.getEndDt()).isEqualTo(null);

        taxonomy= this.getTaxonomy("2932896", "2932896");
        DateUtil.strinfyDates(taxonomy);
        assertThat(taxonomy.getEffDt()).isEqualTo("9999-12-31");
        assertThat(taxonomy.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testRemarkDates() {
        Remark remark= this.getRemark(null, null);
        DateUtil.strinfyDates(remark);
        assertThat(remark.getEffDt()).isEqualTo(null);
        assertThat(remark.getEndDt()).isEqualTo(null);

        remark= this.getRemark("2932896", null);
        DateUtil.strinfyDates(remark);
        assertThat(remark.getEffDt()).isEqualTo("9999-12-31");
        assertThat(remark.getEndDt()).isEqualTo(null);

        remark= this.getRemark("2932896", "2932896");
        DateUtil.strinfyDates(remark);
        assertThat(remark.getEffDt()).isEqualTo("9999-12-31");
        assertThat(remark.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testNetworkDatesDates() {
        Network network= this.getNetwork(null, null, null);
        DateUtil.strinfyDates(network);
        assertThat(network.getEffDt()).isEqualTo(null);
        assertThat(network.getEndDt()).isEqualTo(null);
        assertThat(network.getDirectorySuppressDt()).isEqualTo(null);

        network= this.getNetwork("2932896", null, null);
        DateUtil.strinfyDates(network);
        assertThat(network.getEffDt()).isEqualTo("9999-12-31");
        assertThat(network.getEndDt()).isEqualTo(null);
        assertThat(network.getDirectorySuppressDt()).isEqualTo(null);

        network= this.getNetwork("2932896", "2932896", null);
        DateUtil.strinfyDates(network);
        assertThat(network.getEffDt()).isEqualTo("9999-12-31");
        assertThat(network.getEndDt()).isEqualTo("9999-12-31");
        assertThat(network.getDirectorySuppressDt()).isEqualTo(null);

        network= this.getNetwork("2932896", "2932896", "2932896");
        DateUtil.strinfyDates(network);
        assertThat(network.getEffDt()).isEqualTo("9999-12-31");
        assertThat(network.getEndDt()).isEqualTo("9999-12-31");
        assertThat(network.getDirectorySuppressDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testDmeOpsDates() {
        DmeOps dmeOps= this.getDmeOps(null, null);
        DateUtil.strinfyDates(dmeOps);
        assertThat(dmeOps.getIssueDt()).isEqualTo(null);
        assertThat(dmeOps.getTermDt()).isEqualTo(null);

        dmeOps= this.getDmeOps("2932896", null);
        DateUtil.strinfyDates(dmeOps);
        assertThat(dmeOps.getIssueDt()).isEqualTo("9999-12-31");
        assertThat(dmeOps.getTermDt()).isEqualTo(null);

        dmeOps= this.getDmeOps("2932896", "2932896");
        DateUtil.strinfyDates(dmeOps);
        assertThat(dmeOps.getIssueDt()).isEqualTo("9999-12-31");
        assertThat(dmeOps.getTermDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testPanelDates() {
        Panel panel= this.getPanel(null, null);
        DateUtil.strinfyDates(panel);
        assertThat(panel.getEffDt()).isEqualTo(null);
        assertThat(panel.getEndDt()).isEqualTo(null);

        panel= this.getPanel("2932896", null);
        DateUtil.strinfyDates(panel);
        assertThat(panel.getEffDt()).isEqualTo("9999-12-31");
        assertThat(panel.getEndDt()).isEqualTo(null);

        panel= this.getPanel("2932896", "2932896");
        DateUtil.strinfyDates(panel);
        assertThat(panel.getEffDt()).isEqualTo("9999-12-31");
        assertThat(panel.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testLicense() {
        License license= this.getLicense(null, null);
        DateUtil.strinfyDates(license);
        assertThat(license.getEffDt()).isEqualTo(null);
        assertThat(license.getEndDt()).isEqualTo(null);

        license= this.getLicense("2932896", null);
        DateUtil.strinfyDates(license);
        assertThat(license.getEffDt()).isEqualTo("9999-12-31");
        assertThat(license.getEndDt()).isEqualTo(null);

        license= this.getLicense("2932896", "2932896");
        DateUtil.strinfyDates(license);
        assertThat(license.getEffDt()).isEqualTo("9999-12-31");
        assertThat(license.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testCertification() {
        Certification certification= this.getCertification(null, null);
        DateUtil.strinfyDates(certification);
        assertThat(certification.getEffDt()).isEqualTo(null);
        assertThat(certification.getEndDt()).isEqualTo(null);

        certification= this.getCertification("2932896", null);
        DateUtil.strinfyDates(certification);
        assertThat(certification.getEffDt()).isEqualTo("9999-12-31");
        assertThat(certification.getEndDt()).isEqualTo(null);

        certification= this.getCertification("2932896", "2932896");
        DateUtil.strinfyDates(certification);
        assertThat(certification.getEffDt()).isEqualTo("9999-12-31");
        assertThat(certification.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testAddress() {
        Address address= this.getAddress(null, null);
        DateUtil.strinfyDates(address);
        assertThat(address.getEffDt()).isEqualTo(null);
        assertThat(address.getEndDt()).isEqualTo(null);

        address= this.getAddress("2932896", null);
        DateUtil.strinfyDates(address);
        assertThat(address.getEffDt()).isEqualTo("9999-12-31");
        assertThat(address.getEndDt()).isEqualTo(null);

        address= this.getAddress("2932896", "2932896");
        DateUtil.strinfyDates(address);
        assertThat(address.getEffDt()).isEqualTo("9999-12-31");
        assertThat(address.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testAlternateIdentifier() {
        AlternateIdentifier alternateIdentifier= this.getAlternateIdentifier(null, null);
        DateUtil.strinfyDates(alternateIdentifier);
        assertThat(alternateIdentifier.getEffDt()).isEqualTo(null);
        assertThat(alternateIdentifier.getEndDt()).isEqualTo(null);

        alternateIdentifier= this.getAlternateIdentifier("2932896", null);
        DateUtil.strinfyDates(alternateIdentifier);
        assertThat(alternateIdentifier.getEffDt()).isEqualTo("9999-12-31");
        assertThat(alternateIdentifier.getEndDt()).isEqualTo(null);

        alternateIdentifier= this.getAlternateIdentifier("2932896", "2932896");
        DateUtil.strinfyDates(alternateIdentifier);
        assertThat(alternateIdentifier.getEffDt()).isEqualTo("9999-12-31");
        assertThat(alternateIdentifier.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testSpeciality() {
        Specialty specialty= this.getSpecialty(null, null);
        DateUtil.strinfyDates(specialty);
        assertThat(specialty.getEffDt()).isEqualTo(null);
        assertThat(specialty.getEndDt()).isEqualTo(null);

        specialty= this.getSpecialty("2932896", null);
        DateUtil.strinfyDates(specialty);
        assertThat(specialty.getEffDt()).isEqualTo("9999-12-31");
        assertThat(specialty.getEndDt()).isEqualTo(null);

        specialty= this.getSpecialty("2932896", "2932896");
        DateUtil.strinfyDates(specialty);
        assertThat(specialty.getEffDt()).isEqualTo("9999-12-31");
        assertThat(specialty.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testEducation() {
        Education education= this.getEducation(null, null);
        DateUtil.strinfyDates(education);
        assertThat(education.getEffDt()).isEqualTo(null);
        assertThat(education.getEndDt()).isEqualTo(null);

        education= this.getEducation("2932896", null);
        DateUtil.strinfyDates(education);
        assertThat(education.getEffDt()).isEqualTo("9999-12-31");
        assertThat(education.getEndDt()).isEqualTo(null);

        education= this.getEducation("2932896", "2932896");
        DateUtil.strinfyDates(education);
        assertThat(education.getEffDt()).isEqualTo("9999-12-31");
        assertThat(education.getEndDt()).isEqualTo("9999-12-31");
    }
    @Test
    public void testGlobalBilling() {
        GlobalBilling globalBilling= this.getGlobalBilling(null, null, null, null,null);
        DateUtil.strinfyDates(globalBilling);
        assertThat(globalBilling.getMecDt()).isEqualTo(null);
        assertThat(globalBilling.getDirectoryDt()).isEqualTo(null);
        assertThat(globalBilling.getMspDt()).isEqualTo(null);
        assertThat(globalBilling.getDirectorySuppressDt()).isEqualTo(null);
        assertThat(globalBilling.getTermDt()).isEqualTo(null);

        globalBilling= this.getGlobalBilling("2932896", null, null, null,null);
        DateUtil.strinfyDates(globalBilling);
        assertThat(globalBilling.getMecDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectoryDt()).isEqualTo(null);
        assertThat(globalBilling.getMspDt()).isEqualTo(null);
        assertThat(globalBilling.getDirectorySuppressDt()).isEqualTo(null);
        assertThat(globalBilling.getTermDt()).isEqualTo(null);

        globalBilling= this.getGlobalBilling("2932896", "2932896", null, null,null);
        DateUtil.strinfyDates(globalBilling);
        assertThat(globalBilling.getMecDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectoryDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getMspDt()).isEqualTo(null);
        assertThat(globalBilling.getDirectorySuppressDt()).isEqualTo(null);
        assertThat(globalBilling.getTermDt()).isEqualTo(null);

        globalBilling= this.getGlobalBilling("2932896", "2932896", "2932896", null,null);
        DateUtil.strinfyDates(globalBilling);
        assertThat(globalBilling.getMecDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectoryDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getMspDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectorySuppressDt()).isEqualTo(null);
        assertThat(globalBilling.getTermDt()).isEqualTo(null);

        globalBilling= this.getGlobalBilling("2932896", "2932896", "2932896", "2932896",null);
        DateUtil.strinfyDates(globalBilling);
        assertThat(globalBilling.getMecDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectoryDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getMspDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectorySuppressDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getTermDt()).isEqualTo(null);

        globalBilling= this.getGlobalBilling("2932896", "2932896", "2932896", "2932896","2932896");
        DateUtil.strinfyDates(globalBilling);
        assertThat(globalBilling.getMecDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectoryDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getMspDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getDirectorySuppressDt()).isEqualTo("9999-12-31");
        assertThat(globalBilling.getTermDt()).isEqualTo("9999-12-31");


    }
    private Provider getProvider(String effDt, String trmDt, String dirSuppressFlg, String dirDivEffDt, String w9Dt, String mocCompleteDt) {
        return Provider
            .builder()
            .effDate(effDt)
            .termDt(trmDt)
            .directorySuppressDt(dirSuppressFlg)
            .directoryDivisionEffDt(dirDivEffDt)
            .w9Dt(w9Dt)
            .mocCompletedDt(mocCompleteDt)
                .opvProviderPanel(new ArrayList<>())
                .opvProviderNetworkDirectory(new ArrayList<>())
                .opvProviderRemarks(new ArrayList<>())
                .opvProviderTaxonomy(new ArrayList<>())
                .opvProviderAffiliation(new ArrayList<>())
                .opvProviderLicence(new ArrayList<>())
                .opvProviderCertification(new ArrayList<>())
                .opvProviderAddress(new ArrayList<>())
                .opvProviderSpecialty(new ArrayList<>())
                .opvProviderAlternateId(new ArrayList<>())
                .opvProviderEducation(new ArrayList<>())
                .globalBillings(new ArrayList<>())
            .build();

    }
    private Panel getPanel(String effDt, String endDt) {
        return Panel.builder().effDt(effDt).endDt(endDt).build();
    }
    private DmeOps getDmeOps(String issDt, String trmDt) {
        return DmeOps.builder().issueDt(issDt).termDt(trmDt).build();
    }
    private Network getNetwork(String effDt, String endDt, String dirSuppFlag) {
        return Network.builder().effDt(effDt).endDt(endDt).directorySuppressDt(dirSuppFlag).build();
    }
    private Remark getRemark(String effDt, String endDt) {
        return Remark.builder().effDt(effDt).endDt(endDt).build();
    }
    private Taxonomy getTaxonomy(String effDt, String endDt) {
        return Taxonomy.builder().effDt(effDt).endDt(endDt).build();
    }
    private AffiliationSpecialty getAffiliationSpecialty(String effDt, String endDt) {
        return AffiliationSpecialty.builder().effDt(effDt).endDt(endDt).build();
    }
    private Affiliation getAffiliation(String effDt, String endDt) {
        return Affiliation.builder().effDt(effDt).endDt(endDt).affiliationSpecialtyList(new ArrayList<>()).build();
    }
    private License getLicense(String effDt, String endDt) {
        return License.builder().effDt(effDt).endDt(endDt).build();
    }
    private Certification getCertification(String effDt, String endDt) {
        return Certification.builder().effDt(effDt).endDt(endDt).build();
    }
    private Address getAddress(String effDt, String endDt) {
        return Address.builder().effDt(effDt).endDt(endDt).build();
    }
    private Specialty getSpecialty(String effDt, String endDt) {
        return Specialty.builder().effDt(effDt).endDt(endDt).build();
    }
    private Education getEducation(String effDt, String endDt) {
        Education education= new Education();
        education.setEffDt(effDt);
        education.setEndDt(endDt);
        return education;
    }
    private GlobalBilling getGlobalBilling(String mecDt, String directoryDt, String mspDt, String dirSuppressDt,  String termDt) {
        GlobalBilling globalBilling= new GlobalBilling();
        globalBilling.setMecDt(mecDt);
        globalBilling.setDirectoryDt(directoryDt);
        globalBilling.setDirectorySuppressDt(dirSuppressDt);
        globalBilling.setMspDt(mspDt);
        globalBilling.setTermDt(termDt);
        return globalBilling;
    }
    private AlternateIdentifier getAlternateIdentifier(String effDt, String endDt) {
        return AlternateIdentifier.builder().effDt(effDt).endDt(endDt).build();
    }

}
