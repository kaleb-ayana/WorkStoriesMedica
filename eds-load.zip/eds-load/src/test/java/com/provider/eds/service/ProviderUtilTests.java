package com.provider.eds.service;

import com.medica.model.eds.provider.*;
import com.provider.eds.model.Constants;
import com.provider.eds.model.PracticeLocation;
import com.provider.eds.service.utils.ProviderUtil;
import com.provider.eds.service.utils.ProviderUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ProviderUtilTests {
    @Autowired
    private ProviderUtils providerUtils;

    @Test
    public void testHasSiteMD5Update() {
        Provider newProvider= null;
        Provider existingProvider= Provider.builder().build();
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isTrue();
        existingProvider=null;
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();
        newProvider= Provider.builder().build();
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isTrue();
        existingProvider= Provider.builder().build();
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();
        newProvider.setProviderId("123");
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();
        newProvider.setProviderId(null);
        existingProvider.setProviderId("123");
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();
        newProvider.setProviderId("123");
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();
    }
    @Test
    public void testHasSiteMD5Update2() {
        Provider newProvider= new Provider();
        Provider existingProvider= new Provider();
        newProvider.setProviderId("123");
        existingProvider.setProviderId("123");
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();
        assertThat(this.providerUtils.hasSiteMD5Update(newProvider, existingProvider)).isFalse();

    }
    @Test
    public void testHasTaxUpdate() {
        Provider newProvider= null;
        Provider existingProvider= Provider.builder().build();
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isTrue();
        existingProvider=null;
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        newProvider= Provider.builder().build();
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isTrue();
        existingProvider= Provider.builder().build();
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        newProvider.setProviderId("123");
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        newProvider.setProviderId(null);
        existingProvider.setProviderId("123");
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        newProvider.setProviderId("123");
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();

    }
/*    @Test
    public void testHasTaxUpdate2() {
        Provider newProvider= new Provider();
        Provider existingProvider= new Provider();
        newProvider.setProviderId("123");
        existingProvider.setProviderId("123");

        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();

        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        ProviderUtil.addOrMerge(newProvider,this.createTaxEntity("TX-1", "2022-01-01", "2023-01-01", false));
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isTrue();
        ProviderUtil.addOrMerge(existingProvider,this.createTaxEntity("TX-1", "2022-01-01", "2023-01-01", false));
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        newProvider.getOpvProviderAlternateId().get(0).setEffDt("2023-01-01");
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isTrue();
        newProvider.getOpvProviderAlternateId().get(0).setEffDt("2022-01-01");
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        newProvider.getOpvProviderAlternateId().get(0).setLogicalDeleteFlg(true);
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isTrue();
        newProvider.getOpvProviderAlternateId().get(0).setLogicalDeleteFlg(false);
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isFalse();
        ProviderUtil.addOrMerge(newProvider,this.createTaxEntity("TX-2", "2022-01-01", "2023-01-01", false));
        assertThat(this.providerUtils.hasTaxUpdate(newProvider, existingProvider)).isTrue();

    }*/
    private Address createPLAddress(String md5, boolean logicalDeleteFlag) {
        return Address
                .builder()
                .addressTypeCode("A2")
                .addrMd5Hash(md5)
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
    private AlternateIdentifier createTaxEntity(String taxId, String effDt, String endDt, boolean logicalDeleteFlag) {
        return AlternateIdentifier
                .builder()
                .alternateId(taxId)
                .effDt(effDt)
                .alternateIdTypeCd("TAX")
                .endDt(endDt)
                .logicalDeleteFlg(logicalDeleteFlag)
                .build();
    }
    @Test
    public void testNaturalizePanel() {
        List<Address> addresses=List.of(Address
                .builder()
                .mtvAddrId("ADDRESSID-1")
                .addrMd5Hash("MD5-1")
                .build());
        Panel panel= Panel
                .builder()
                .pracLocProviderIdType("MTV")
                .pracLocProviderId("ADDRESSID-1")
                .build();
        List<Panel> panels= new ArrayList<>();
        panels.add(panel);
        Provider provider= Provider
                .builder()
                .providerId("PRVID-1")
                .opvProviderAddress(addresses)
                .opvProviderPanel(panels)
                .build();

        Map<String, List<PracticeLocation>> practiceLocationMap= new HashMap<>();
        PracticeLocation practiceLocation= new PracticeLocation();
        practiceLocation.setMtvProviderId("PRVID-2");
        practiceLocation.setMd5Hash("MD5-1");
        practiceLocation.setPractLocId("ADDRESSID-1");
        practiceLocationMap.put("ADDRESSID-1", List.of(practiceLocation));

        this.providerUtils.buildPanel(provider, practiceLocationMap);

        Panel panelProcessed= provider.getOpvProviderPanel().get(0);
        assertThat(panelProcessed.getPracLocProviderId()).isEqualTo("MD5-1");
        assertThat(panelProcessed.getPracLocProviderIdType()).isEqualTo("MD5");
        assertThat(panelProcessed.getMtvProviderId()).isEqualTo("PRVID-2");
        this.providerUtils.buildPanel(provider, practiceLocationMap);
        assertThat(provider.getOpvProviderPanel()).isNullOrEmpty();
        provider.getOpvProviderPanel().clear();
        panel.setPracLocProviderId("ADDRESS-X");
        panel.setMtvProviderId("MTV");
        provider.setOpvProviderPanel(panels);
        this.providerUtils.buildPanel(provider, practiceLocationMap);
        assertThat(provider.getOpvProviderPanel()).isNullOrEmpty();
    }


    private AlternateIdentifier alternateIdentifier() {
        return AlternateIdentifier
                .builder()
                .alternateId("111")
                .alternateIdTypeCd("BA")
                .effDt("18993")
                .endDt("2932896")
                .sourceSystemCd("MTV")
                .build();
    }
    private Address address() {
        return Address
                .builder()
                .mtvAddrId("234 Random")
                .effDt("18993")
                .endDt("2932896")
                .build();
    }
    private Affiliation affiliation() {
        return Affiliation
                .builder()
                .effDt("18993")
                .endDt("2932896")
                .build();
    }
    private Provider getPersistedMockedProvider() {
        Provider provider= new Provider();
        provider.setProviderId("112233");
        provider.setSourceSystemCd("MTV");
        provider.setOpvProviderAlternateId(new ArrayList<>());
        provider.setOpvProviderAddress(new ArrayList<>());

        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("111")
                .alternateIdTypeCd("TAX")
                .sourceSystemCd("MTV")
                .logicalDeleteFlg(false)
                .effDt("2022-01-01")
                .endDt("2022-04-30")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());
        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("222")
                .alternateIdTypeCd("TAX")
                .logicalDeleteFlg(false)
                .sourceSystemCd("MTV")
                .effDt("2022-05-01")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());
        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("001")
                .alternateIdTypeCd("TAX")
                .logicalDeleteFlg(false)
                .sourceSystemCd("MTV")
                .effDt("2020-01-01")
                .endDt("2021-12-31")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());

        provider.getOpvProviderAddress()
            .add(
                Address.builder()
                    .addrMd5Hash("1243534sdf232433545rdgv2")
                    .name("DHP Address")
                    .addressLine1("Demignway ")
                    .addressTypeCode("A2")
                    .city("Madison")
                    .stateCd("WI")
                    .effDt("2022-01-01")
                    .zipCd4("345")
                    .build());
        provider.getOpvProviderAddress()
            .add(
                Address.builder()
                    .addrMd5Hash("1243534sdf232432")
                    .name("DHP Address")
                    .addressLine1("Demignway ")
                    .addressTypeCode("A2")
                    .city("Madison")
                    .stateCd("WI")
                    .effDt("2022-01-01")
                    .zipCd4("345")
                    .build());
        return provider;
    }
    private Provider getPersistedMockedProviderWithInactiveAddressAndAltId() {
        Provider provider= this.getPersistedMockedProvider();
        provider.getOpvProviderAddress().get(0).setLogicalDeleteFlg(true);
        provider.getOpvProviderAddress().get(0).setEndDt("2021-01-01");
        provider.getOpvProviderAlternateId().get(0).setLogicalDeleteFlg(true);
        provider.getOpvProviderAlternateId().get(0).setEndDt("2021-01-01");
        return provider;
    }

    private PracticeLocation createPracticeLoc(String practLocId, String mtvProvId, String md5) {
        PracticeLocation practiceLocation= new PracticeLocation();
        practiceLocation.setPractLocId(practLocId);
        practiceLocation.setSourceSystemCd(Constants.MTV);
        practiceLocation.setMtvProviderId(mtvProvId);
        practiceLocation.setMd5Hash(md5);

        return practiceLocation;
    }
    private Network createNetworkDir(String practLocId){
        Network network= new Network();
        network.setPraclocProviderId(practLocId);
        network.setPraclocProviderIdType(Constants.MTV);
        return network;
    }
/*    @Test
    public void testBuildNetwork() {
        Provider provider= Provider.builder().build();
        provider.setProviderId("123");

        assertThat(this.providerUtils.buildNetwork(provider,null)).isNullOrEmpty();
        assertThat(this.providerUtils.buildNetwork(provider,null)).hasSize(0);
        ProviderUtil.addOrMerge(provider,createNetworkDir("2345"));
        List<PracticeLocation> practiceLocations= new ArrayList<>();
        practiceLocations.add(this.createPracticeLoc("2345", "OTHER-MTV-ID-111", "MD5-XXXYYY"));
        Map<String, List<PracticeLocation>> practLocMap= new HashMap<>();
        practLocMap.put("2345", practiceLocations);
        practLocMap.put("234566", List.of(this.createPracticeLoc("234566", "OTHER-MTV-ID-222", "MD5-XXXZZZ")));

        List<Network> resultNetworks= this.providerUtils.buildNetwork(provider, practLocMap);
        assertThat(resultNetworks.size()).isEqualTo(1);
        assertThat(resultNetworks.get(0).getPraclocProviderId()).isEqualTo("MD5-XXXYYY");
        assertThat(resultNetworks.get(0).getPraclocProviderIdType()).isEqualTo(Constants.MD5);
        assertThat(resultNetworks.get(0).getMtvProviderId()).isEqualTo("OTHER-MTV-ID-111");

        provider.getOpvProviderNetworkDirectory().clear();
        ProviderUtil.addOrMerge(provider,createNetworkDir("X345X"));
        resultNetworks= this.providerUtils.buildNetwork(provider, practLocMap);
        assertThat(resultNetworks.size()).isZero();

        provider.getOpvProviderNetworkDirectory().clear();
        practiceLocations.add(this.createPracticeLoc("2345", "OTHER-MTV-ID-11Z", "MD5-XXXYYYXX"));
        ProviderUtil.addOrMerge(provider,createNetworkDir("2345"));
        resultNetworks= this.providerUtils.buildNetwork(provider, practLocMap);
        assertThat(resultNetworks.size()).isEqualTo(2);
        provider.getOpvProviderNetworkDirectory().clear();
        ProviderUtil.addOrMerge(provider,createNetworkDir("2345"));
        ProviderUtil.addOrMerge(provider,createNetworkDir("234566"));
        resultNetworks= this.providerUtils.buildNetwork(provider, practLocMap);
        assertThat(resultNetworks.size()).isEqualTo(3);

        assertThat(provider.getOpvProviderNetworkDirectory().get(0).getMtvProviderId()).isEqualTo("OTHER-MTV-ID-111");
        assertThat(provider.getOpvProviderNetworkDirectory().get(0).getPraclocProviderId()).isEqualTo("MD5-XXXYYY");

        assertThat(provider.getOpvProviderNetworkDirectory().get(1).getMtvProviderId()).isEqualTo("OTHER-MTV-ID-11Z");
        assertThat(provider.getOpvProviderNetworkDirectory().get(1).getPraclocProviderId()).isEqualTo("MD5-XXXYYYXX");

        assertThat(provider.getOpvProviderNetworkDirectory().get(2).getMtvProviderId()).isEqualTo("OTHER-MTV-ID-222");
        assertThat(provider.getOpvProviderNetworkDirectory().get(2).getPraclocProviderId()).isEqualTo("MD5-XXXZZZ");

    }*/
}
