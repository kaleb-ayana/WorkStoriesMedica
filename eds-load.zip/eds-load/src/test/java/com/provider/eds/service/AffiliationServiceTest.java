package com.provider.eds.service;

import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.Affiliation;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.service.utils.ProviderUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class AffiliationServiceTest {

    @Autowired
    private ProviderUtils providerUtils;

    @Test
    public void testAffiliationCreation2() {
        Provider provider= this.getTargetProvider();
        Map<String, Provider> providerMap= new HashMap<>();
        providerMap.put("112233MTV", getPersistedMockedProvider());

        List<Affiliation> resultList= providerUtils.buildAffiliation(provider, providerMap);
        assertThat(resultList).isNotNull();
        assertThat(resultList.size()).isEqualTo(4);
    }

    private Provider getPersistedMockedProvider() {
        Provider provider= new Provider();
        provider.setProviderId("112233");
        provider.setSourceSystemCd("MTV");
        provider.setOpvProviderAlternateId(new ArrayList<>());
        provider.setOpvProviderAddress(new ArrayList<>());

        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("111")
                .alternateIdTypeCd("TAX")
                .sourceSystemCd("MTV")
                .logicalDeleteFlg(false)
                .effDt("2022-01-01")
                .endDt("2022-04-30")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());
        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("222")
                .alternateIdTypeCd("TAX")
                .logicalDeleteFlg(false)
                .sourceSystemCd("MTV")
                .effDt("2022-05-01")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());
        provider.getOpvProviderAlternateId().add(AlternateIdentifier
                .builder()
                .alternateId("333")
                .alternateIdTypeCd("TAX")
                .logicalDeleteFlg(false)
                .sourceSystemCd("MTV")
                .effDt("2020-01-01")
                .endDt("2021-12-31")
                .entityName("DHP")
                .mtvProviderCategoryCd("PAYTO")
                .mtvProviderTypeCd("TAX")
                .build());

        provider.getOpvProviderAddress()
                .add(
                    Address.builder()
                        .addrMd5Hash("1243534sdf232433545rdgv2")
                        .name("DHP Address")
                        .addressLine1("Demignway ")
                        .addressTypeCode("A2")
                        .city("Madison")
                        .stateCd("WI")
                        .effDt("2020-01-01")
                        .endDt("2020-04-30")
                        .zipCd4("345")
                        .build());
        provider.getOpvProviderAddress()
                .add(
                    Address.builder()
                        .addrMd5Hash("1243534sdf232432")
                        .name("DHP Address")
                        .addressLine1("Demignway ")
                        .addressTypeCode("A2")
                        .city("Madison")
                        .stateCd("WI")
                        .effDt("2020-05-01")
                        .zipCd4("345")
                        .build());
        return provider;
    }
    private Provider getPersistedMockedProviderWithInactiveAddressAndAltId() {
        Provider provider= this.getPersistedMockedProvider();
        provider.getOpvProviderAddress().get(0).setLogicalDeleteFlg(true);
        provider.getOpvProviderAddress().get(0).setEndDt("2021-01-01");
        provider.getOpvProviderAlternateId().get(0).setLogicalDeleteFlg(true);
        provider.getOpvProviderAlternateId().get(0).setEndDt("2021-01-01");
        return provider;
    }
    private Provider getTargetProvider() {
        Provider provider= new Provider();
        provider.setProviderId("11223344");
        provider.setSourceSystemCd("MTV");
        provider.setOpvProviderAffiliation(new ArrayList<>());
        provider.getOpvProviderAffiliation().add(Affiliation
                .builder()
                .affiliationType("PAYTO")
                .affiliateProviderIdType("TAX")
                .mtvAffiliateProviderId("112233")
                .logicalDeleteFlg(false)
                .effDt("2022-01-01")
                .endDt("2022-12-31")
                .build());
        provider.getOpvProviderAffiliation().add(Affiliation
                .builder()
                .affiliationType("HOSP")
                .affiliateProviderIdType("MD5")
                .mtvAffiliateProviderId("112233")
                .logicalDeleteFlg(false)
                .effDt("2020-01-01")
                .endDt("2021-12-31")
                .build());
        return provider;
    }
}

