package com.provider.eds.service;

import com.medica.model.eds.common.ProviderNotification;
import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.AlternateIdentifier;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.model.Constants;
import com.provider.eds.service.utils.ProviderNotificationEvaluator;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class UpdateNotificationServiceTest {

    @InjectMocks
    UpdateNotificationService updateNotificationService;

    @Mock
    ProviderNotificationEvaluator providerNotificationEvaluator;


    @Test
    public void testProcessOrchestrationMessage(){

        Provider provider= Provider
                .builder()
                .providerId("12345678")
                .sourceSystemCd("MTV")
                .opvProviderAddress(new ArrayList<>())
                .opvProviderAlternateId(new ArrayList<>())
                .build();

        provider.getOpvProviderAddress().add(buildAddress("1243534sdf232433545rdgv2","DHP Address","Demignway "
                ,"BA","Madison","WI","2020-01-01","2020-04-30","345"));

        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("112233","TAX"
                ,"MTV",false,"2022-01-01","2024-04-30","DHP","PAYTO"
                ,"TAX"));
        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("222","NPI2"
                ,"MTV",false,"2022-05-01","9999-12-31","DHP","PAYTO"
                ,"NPI2"));
        provider.getOpvProviderAlternateId().add(buildAlternateIdentifier("333","NPI1"
                ,"MTV",false,"2020-01-01","2021-12-31","DHP","PAYTO"
                ,"TAX"));

        Mockito.when(providerNotificationEvaluator.getNonVoidedAlternateIdTypeOf(Mockito.any(), Mockito.eq(Constants.TAX))).thenReturn(provider.getOpvProviderAlternateId());


        List<ProviderNotification> notificationProviderList = updateNotificationService.processProviderNotificationMessage(null);
        assertThat(notificationProviderList.size()).isEqualTo(0);

        Mockito.when(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(false);
        Mockito.when(providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        notificationProviderList = updateNotificationService.processProviderNotificationMessage(provider);
        assertThat(notificationProviderList.size()).isEqualTo(0);


        Mockito.when(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(false);
        notificationProviderList = updateNotificationService.processProviderNotificationMessage(provider);
        assertThat(notificationProviderList.size()).isEqualTo(0);

        Mockito.when(providerNotificationEvaluator.hasNonVoidedAddressTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.hasNonVoidedAlternateIdTypeOf(Mockito.any(),Mockito.anyString())).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.isPractitionerCandidate(provider)).thenReturn(false);
        notificationProviderList = updateNotificationService.processProviderNotificationMessage(provider);
        assertThat(notificationProviderList.size()).isEqualTo(3);

        assertThat(notificationProviderList.get(0).getSOURCE_SYSTEM_ID()).isEqualTo("12345678");
        assertThat(notificationProviderList.get(0).getSOURCE_SYSTEM_CD()).isEqualTo("MTV");
        assertThat(notificationProviderList.get(1).getSOURCE_SYSTEM_ID()).isEqualTo("12345678");
        assertThat(notificationProviderList.get(1).getSOURCE_SYSTEM_CD()).isEqualTo("MTV");
        assertThat(notificationProviderList.get(2).getSOURCE_SYSTEM_ID()).isEqualTo("12345678");
        assertThat(notificationProviderList.get(2).getSOURCE_SYSTEM_CD()).isEqualTo("MTV");

        Mockito.when(providerNotificationEvaluator.isPractitionerCandidate(provider)).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.isLocationCandidate(provider)).thenReturn(false);
        notificationProviderList = updateNotificationService.processProviderNotificationMessage(provider);
        assertThat(notificationProviderList.size()).isEqualTo(4);

        Mockito.when(providerNotificationEvaluator.isLocationCandidate(provider)).thenReturn(true);
        notificationProviderList = updateNotificationService.processProviderNotificationMessage(provider);
        assertThat(notificationProviderList.size()).isEqualTo(5);

        provider.setProviderId("7891234");
        provider.setSourceSystemCd("SYM");

        Mockito.when(providerNotificationEvaluator.isLocationCandidate(provider)).thenReturn(true);
        Mockito.when(providerNotificationEvaluator.isPractitionerCandidate(provider)).thenReturn(false);
        notificationProviderList = updateNotificationService.processProviderNotificationMessage(provider);
        assertThat(notificationProviderList.size()).isEqualTo(4);

        assertThat(notificationProviderList.get(0).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(notificationProviderList.get(0).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");
        assertThat(notificationProviderList.get(1).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(notificationProviderList.get(1).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");
        assertThat(notificationProviderList.get(2).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(notificationProviderList.get(2).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");
        assertThat(notificationProviderList.get(3).getSOURCE_SYSTEM_ID()).isEqualTo("7891234");
        assertThat(notificationProviderList.get(3).getSOURCE_SYSTEM_CD()).isEqualTo("SYM");

    }

    private static Address buildAddress(String addrMd5Hash, String name, String addressLine1, String addressTypeCode, String city, String stateCd, String effDt, String endDt, String zipCd4) {
        return Address.builder()
                .addrMd5Hash(addrMd5Hash)
                .name(name)
                .addressLine1(addressLine1)
                .addressTypeCode(addressTypeCode)
                .city(city)
                .stateCd(stateCd)
                .effDt(effDt)
                .endDt(endDt)
                .zipCd4(zipCd4)
                .build();
    }

    private static AlternateIdentifier buildAlternateIdentifier(String alternateId, String alternateIdTypeCd, String sourceSystemCd, Boolean logicalDeleteFlg
            , String effDt, String endDt, String entityName, String mtvProviderCategoryCd, String mtvProviderTypeCd) {
        return AlternateIdentifier
                .builder()
                .alternateId(alternateId)
                .alternateIdTypeCd(alternateIdTypeCd)
                .sourceSystemCd(sourceSystemCd)
                .logicalDeleteFlg(logicalDeleteFlg)
                .effDt(effDt)
                .endDt(endDt)
                .entityName(entityName)
                .mtvProviderCategoryCd(mtvProviderCategoryCd)
                .mtvProviderTypeCd(mtvProviderTypeCd)
                .build();
    }
}
