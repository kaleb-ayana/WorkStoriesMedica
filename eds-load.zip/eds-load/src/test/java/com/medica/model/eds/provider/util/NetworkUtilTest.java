package com.medica.model.eds.provider.util;

import com.medica.model.eds.provider.Network;
import com.provider.eds.service.utils.NetworkUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class NetworkUtilTest {
    @Test
    public void testEquals() {
        Network network1 = createNetwork("23456","767876","mtv","889786","pracLocType","networkId","networkSourceSystemCd","2023-07-25","2023-07-30",true,true,true,7589397687L,7586575897687L,null);
        Network network2 = createNetwork("23456","767876","mtv","889786","pracLocType","networkId","networkSourceSystemCd","2023-07-25","2023-07-30",true,true,true,7589397687L,7586575897687L,null);
        Assertions.assertTrue(NetworkUtil.areEqual(network1, network2));

        Network network3 = createNetwork("23456344","7678766456","mtv456","8897865646","pracLocTypetryr","networkIddd","networkSourceSystemCddd","2023-07-29","2023-07-10",true,false,true,7589397687L,7586575897687L,null);
        Assertions.assertFalse(NetworkUtil.areEqual(network1, network3));

        Assertions.assertFalse(NetworkUtil.areEqual(network1, null));
        Assertions.assertFalse(NetworkUtil.areEqual(null, network2));
        Assertions.assertTrue(NetworkUtil.areEqual(null, null));
    }

    @Test
    public void testMatches() {
        Network network1 = createNetwork("23456","767876","mtv","889786","pracLocType","networkId","networkSourceSystemCd","2023-07-25","2023-07-30",true,false,true,7589397687L,7586575897687L,null);
        Network network2 = createNetwork("23456","767876","mtv","889786","pracLocType","networkId","networkSourceSystemCd","2023-07-25","2023-07-30",true,false,true,7589397687L,7586575897687L,null);
        Assertions.assertTrue(NetworkUtil.matches(network1, network2));

        Network network3 = createNetwork("23456344","7678766456","mtv456","8897865646","pracLocTypetryr","networkIddd","networkSourceSystemCddd","2023-07-29","2023-07-10",true,false,true,7589397687L,7586575897687L,null);
        Assertions.assertFalse(NetworkUtil.matches(network1, network3));

        Assertions.assertFalse(NetworkUtil.matches(network1, null));
        Assertions.assertFalse(NetworkUtil.matches(null, network2));
        Assertions.assertTrue(NetworkUtil.matches(null, null));
    }

    @Test
    public void testMerge() {
        Network network1 = createNetwork("23456","767876","mtv","889786","pracLocType","networkId","networkSourceSystemCd","2023-07-25","2023-07-30",true,false,true,7589397687L,7586575897687L,null);
        Network network2 = createNetwork("23456","767876","mtv","889786","pracLocType","networkId","networkSourceSystemCd","2023-07-25","2023-07-30",true,false,true,7589397687L,7586575897687L,null);

        Assertions.assertTrue(NetworkUtil.merge(network1, network2));

        Assertions.assertEquals("networkSourceSystemCd", network1.getSourceSystemCd());
        Assertions.assertTrue(network1.getLogicalDeleteFlg());


        Network network3 = createNetwork("23456344","7678766456","mtv456","8897865646","pracLocTypetryr","networkIddd","networkSourceSystemCddd","2023-07-29","2023-07-10",true,false,true,7589397687L,7586575897687L,null);
        Assertions.assertFalse(NetworkUtil.merge(network1, network3));

        Assertions.assertEquals("networkSourceSystemCddd", network3.getSourceSystemCd());
        Assertions.assertTrue(network1.getLogicalDeleteFlg());

    }

    private Network createNetwork(String addressId, String mtvProvid, String srcSysCd, String practLocProvId, String practLocProvTypeId, String networkid, String networkSrcSysCd, String effDt, String endDt, Boolean dirSuppressFlg,
                                  Boolean includeInterfaceFlg, Boolean logicalDelFlg, Long insertDttm, Long updateDttm, String resynchTag
                                  ) {
        return Network
                .builder()
                .addressId(addressId)
                .mtvProviderId(mtvProvid)
                .sourceSystemCd(srcSysCd)
                .praclocProviderId(practLocProvId)
                .praclocProviderIdType(practLocProvTypeId)
                .networkId(networkid)
                .sourceSystemCd(networkSrcSysCd)
                .effDt(effDt)
                .endDt(endDt)
//                .directorySuppressFlg(dirSuppressFlg)
                .includeInInterfacesFlg(includeInterfaceFlg)
                .logicalDeleteFlg(logicalDelFlg)
                .sourceSystemInsertDttm(insertDttm)
                .sourceSystemUpdateDttm(updateDttm)
                .resynchTag(resynchTag)
                .build();
    }
}

