package com.medica.model.eds.provider.util;

import com.medica.model.eds.provider.Specialty;
import com.provider.eds.service.utils.SpecialtyUtil;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SpecialtyUtilTest {
    @Test
    void testEquals_BothSpecialtiesNull_ReturnsTrue() {
        Specialty specialty1 = null;
        Specialty specialty2 = null;

        boolean result = SpecialtyUtil.equals(specialty1, specialty2);

        assertTrue(result);
    }

    @Test
    void testEquals_OneSpecialtyNull_ReturnsFalse() {
        Specialty specialty1 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        Specialty specialty2 = null;

        boolean result = SpecialtyUtil.equals(specialty1, specialty2);

        assertFalse(result);
    }

    @Test
    void testEquals_DifferentSpecialtyCodes_ReturnsFalse() {
        Specialty specialty1 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        Specialty specialty2 = this.createSpecialty("code2", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");

        boolean result = SpecialtyUtil.equals(specialty1, specialty2);

        assertFalse(result);
    }

    @Test
    void testEquals_DifferentEffectiveDates_ReturnsFalse() {
        Specialty specialty1 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        Specialty specialty2 = this.createSpecialty("code1", "taxanomyCode", "2022-01-02","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");

        boolean result = SpecialtyUtil.equals(specialty1, specialty2);

        assertFalse(result);
    }

    @Test
    void testEquals_DifferentPrimaryFlags_ReturnsFalse() {
        Specialty specialty1 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        Specialty specialty2 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,true,"mtv",false,2287179649719572419L,3387179649719572419L,"");

        boolean result = SpecialtyUtil.equals(specialty1, specialty2);

        assertFalse(result);
    }

    @Test
    void testEquals_IdenticalSpecialties_ReturnsTrue() {
        Specialty specialty1 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        Specialty specialty2 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");

        boolean result = SpecialtyUtil.equals(specialty1, specialty2);

        assertTrue(result);
    }

    @Test
    void testMatches_IdenticalSpecialties_ReturnsTrue() {
        Specialty specialty1 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        Specialty specialty2 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");

        boolean result = SpecialtyUtil.matches(specialty1, specialty2);

        assertTrue(result);
    }
   /* @Test
    void testMerge_MatchingSpecialties_ReturnsTrue() {
        Specialty specialty1 = new Specialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"description1");
        specialty1.setEndDt("2023-07-25");
        specialty1.setLogicalDeleteFlg(false);
        specialty1.setBoardCertifiedCd(true);
        specialty1.setSpecialtyDescription("description1");
        specialty1.setSourceSystemCd("mtv");
        specialty1.setSourceSystemInsertDttm(123456789L);
        specialty1.setSourceSystemUpdateDttm(987654321L);

        Specialty specialty2 = new Specialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"description1");
        specialty2.setEndDt("2023-07-24");
        specialty2.setLogicalDeleteFlg(true);
        specialty2.setBoardCertifiedCd(false);
        specialty2.setSpecialtyDescription("description2");
        specialty2.setSourceSystemCd("mtv");
        specialty2.setSourceSystemInsertDttm(987654321L);
        specialty2.setSourceSystemUpdateDttm(123456789L);

        boolean result = SpecialtyUtil.merge(specialty1, specialty2);

        assertTrue(result);
        assertEquals("2023-07-25", specialty1.getEndDt());
        assertFalse(specialty1.isLogicalDeleteFlg());
        assertTrue(specialty1.isBoardCertifiedCd());
        assertEquals("description1 description2", specialty1.getSpecialtyDescription());
        assertEquals("mtv mtv", specialty1.getSourceSystemCd());
        assertEquals(123456789L, specialty1.getSourceSystemInsertDttm());
        assertEquals(987654321L, specialty1.getSourceSystemUpdateDttm());
    }*/

    @Test
    void testMerge_NonMatchingSpecialties_ReturnsFalse() {
        Specialty specialty1 = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        Specialty specialty2 = this.createSpecialty("code2", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");

        boolean result = SpecialtyUtil.merge(specialty1, specialty2);

        assertFalse(result);
    }

    @Test
    void testIsActive_LogicalDeleteFlagFalse_ReturnsTrue() {
        Specialty specialty = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        specialty.setLogicalDeleteFlg(false);

        boolean result = SpecialtyUtil.isActive(specialty);

        assertTrue(result);
    }

    @Test
    void testIsActive_LogicalDeleteFlagTrue_ReturnsFalse() {
        Specialty specialty = this.createSpecialty("code1", "taxanomyCode", "2022-01-01","2029-01-01", true,false,"mtv",false,2287179649719572419L,3387179649719572419L,"");
        specialty.setLogicalDeleteFlg(true);

        boolean result = SpecialtyUtil.isActive(specialty);

        assertFalse(result);
    }

    private Specialty createSpecialty(String code, String taxonomyCode, String effDt, String endDt, Boolean boardCertified, Boolean isPrimary, String sourceSysCd, Boolean taxonomyOverrideFlg, Long insertDttm, Long updateDttm, String taxonomyDescription){
        return Specialty
                .builder()
                .specialtyCode(code)
                .taxonomyCd(taxonomyCode)
                .effDt(effDt)
                .endDt(endDt)
                .boardCertifiedCd(boardCertified)
                .primaryFlg(isPrimary)
                .sourceSystemCd(sourceSysCd)
                .taxonomyOverrideFlg(taxonomyOverrideFlg)
                .sourceSystemInsertDttm(insertDttm)
                .sourceSystemUpdateDttm(updateDttm)
                .taxonomyDesc(taxonomyDescription)
                .build();
    }

}