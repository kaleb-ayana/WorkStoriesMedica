package com.medica.model.eds.provider.util;

import com.medica.model.eds.provider.Phone;
import com.provider.eds.service.utils.PhoneUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class PhoneUtilTest {
    @Test
    public void testEquals() {
        Phone phone1 = createPhone("8897863199","home",false,"ext","mtv",true,7589397687L,7586575897687L);
        Phone phone2 = createPhone("8897863199","home",false,"ext","mtv",true,7589397687L,7586575897687L);
        Assertions.assertTrue(PhoneUtil.equals(phone1, phone2));

        Phone phone3 = createPhone("8897863179","office",true,"extention","mtv1",false,75893777687L,7586566897687L);
        Assertions.assertFalse(PhoneUtil.equals(phone1, phone3));

        Assertions.assertFalse(PhoneUtil.equals(phone1, null));
        Assertions.assertFalse(PhoneUtil.equals(null, phone2));
        Assertions.assertTrue(PhoneUtil.equals(null, null));
    }

    @Test
    public void testMatches() {
        Phone phone1 = createPhone("8897863199","home",false,"ext","mtv",true,7589397687L,7586575897687L);
        Phone phone2 = createPhone("8897863199","home",false,"ext","mtv",true,7589397687L,7586575897687L);
        Assertions.assertTrue(PhoneUtil.matches(phone1, phone2));

        Phone phone3 = createPhone("8897863179","office",true,"extention","mtv1",false,75893777687L,7586566897687L);
        Assertions.assertFalse(PhoneUtil.matches(phone1, phone3));

        Assertions.assertFalse(PhoneUtil.matches(phone1, null));
        Assertions.assertFalse(PhoneUtil.matches(null, phone2));
        Assertions.assertTrue(PhoneUtil.matches(null, null));
    }

    @Test
    public void testMerge() {
        Phone phone1 = createPhone("8897863199","home",true,"ext","mtv",true,7589397687L,7586575897687L);
        Phone phone2 = createPhone("8897863199","home",true,"ext","mtv",true,7589397687L,7586575897687L);

        Assertions.assertTrue(PhoneUtil.merge(phone1, phone2));
        Assertions.assertTrue(phone1.isPrimaryFlag());
        Assertions.assertEquals("mtv", phone1.getSourceSystemCd());
        Assertions.assertTrue(phone1.getLogicalDeleteFlg());


        Phone phone3 = createPhone("8897863179","office",true,"extention","mtv1",true,75893777687L,7586566897687L);
        Assertions.assertFalse(PhoneUtil.merge(phone1, phone3));

        Assertions.assertTrue(phone1.isPrimaryFlag());
        Assertions.assertEquals("mtv", phone1.getSourceSystemCd());
        Assertions.assertTrue(phone1.getLogicalDeleteFlg());

    }

    private Phone createPhone(String phoneNum,String phoneTypeCd, boolean primaryFlag, String extension, String sourceSystemCd, boolean logicalDeleteFlg, Long sourceSystemInsertDttm, Long sourceSystemUpdateDttm) {
        return Phone
                .builder()
                .phoneNum(phoneNum)
                .phoneTypeCd(phoneTypeCd)
                .primaryFlag(primaryFlag)
                .extension(extension)
                .sourceSystemCd(sourceSystemCd)
                .logicalDeleteFlg(logicalDeleteFlg)
                .sourceSystemInsertDttm(sourceSystemInsertDttm)
                .sourceSystemUpdateDttm(sourceSystemUpdateDttm)
                .build();
    }

}