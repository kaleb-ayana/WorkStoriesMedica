package com.medica.model.eds.provider.util;

import com.medica.model.eds.provider.Language;
import com.provider.eds.service.utils.LanguageUtil;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LanguageUtilTest {
    @Test
    public void testEquals() {
        Language language1 = this.createLanguage("lanCd",true,"mtv",true,7589397687L,7586575897687L);
        Language language2 = this.createLanguage("lanCd",true,"mtv",true,7589397687L,7586575897687L);
        Assertions.assertTrue(LanguageUtil.equals(language1, language2));

        Language language3 = this.createLanguage("lanCddd",false,"mtv1",false,7589397687L,7586575897687L);
        Assertions.assertFalse(LanguageUtil.equals(language1, language3));

        Assertions.assertFalse(LanguageUtil.equals(language1, null));
        Assertions.assertFalse(LanguageUtil.equals(null, language2));
        Assertions.assertTrue(LanguageUtil.equals(null, null));
    }

    @Test
    public void testMatches() {
        Language language1 = this.createLanguage("lanCd",true,"mtv",true,7589397687L,7586575897687L);
        Language language2 = this.createLanguage("lanCd",true,"mtv",true,7589397687L,7586575897687L);
        Assertions.assertTrue(LanguageUtil.matches(language1, language2));

        Language language3 = this.createLanguage("lanCddd",false,"mtv1",false,7589397687L,7586575897687L);
        Assertions.assertFalse(LanguageUtil.matches(language1, language3));

        Assertions.assertFalse(LanguageUtil.matches(language1, null));
        Assertions.assertFalse(LanguageUtil.matches(null, language2));
        Assertions.assertTrue(LanguageUtil.matches(null, null));
    }

    @Test
    public void testMerge() {
        Language language1 = this.createLanguage("lanCd",true,"mtv",true,7589397687L,7586575897687L);
        Language language2 = this.createLanguage("lanCd",true,"mtv",true,7589397687L,7586575897687L);
        Assertions.assertTrue(LanguageUtil.merge(language1, language2));
        Assertions.assertEquals("mtv", language1.getSourceSystemCd());
        Assertions.assertTrue(language1.getLogicalDeleteFlg());


        Language language3 = Language
                .builder()
                .languageCd("lanCddd")
                .primaryFlg(true)
                .sourceSystemCd("mtv1")
                .sourceSystemInsertDttm(7589397687L)
                .sourceSystemUpdateDttm(7586575897687L)
                .build();

        Assertions.assertFalse(LanguageUtil.merge(language1, language3));

        Assertions.assertEquals("mtv", language1.getSourceSystemCd());
        Assertions.assertTrue(language1.getLogicalDeleteFlg());

    }

    private Language createLanguage(String languageCd, boolean primaryFlag, String sourceSystemCd, boolean logicalDeleteFlg, Long insertDttm, Long updateDttm) {
        return Language
                .builder()
                .languageCd(languageCd)
                .primaryFlg(primaryFlag)
                .sourceSystemCd(sourceSystemCd)
                .sourceSystemInsertDttm(insertDttm)
                .sourceSystemUpdateDttm(updateDttm)
                .logicalDeleteFlg(logicalDeleteFlg)
                .build();
    }
}