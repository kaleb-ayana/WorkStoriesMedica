package com.medica.model.eds.provider.util;

class ProviderUtilTest {

//    @Test
//    public void getMtvProviderIdsAffiliated_NoAffiliations() {
//        Provider provider = new Provider();
//        Set<String> result = ProviderUtil.getMtvProviderIdsAffiliated(provider);
//        Assertions.assertNull(result);
//    }
//
//    @Test
//    public void getMtvProviderIdsAffiliated_AffiliationsExist() {
//        Provider provider = new Provider();
//        List<Affiliation> affiliations = new ArrayList<>();
//
//        Affiliation affiliation= new Affiliation("12345676","affilationId","mtvAffiliatedId","affiliationType","hospitalAffiliationType","2022-01-01","2029-01-01",false,"pcpFlag",false,"MTV",2287179649719572419L,3387179649719572419L,"resyncTag",null);
//        affiliations.add(affiliation);
//        provider.setOpvProviderAffiliation(affiliations);
//
//        Set<String> result = ProviderUtil.getMtvProviderIdsAffiliated(provider);
//        Assertions.assertNotNull(result);
//        Assertions.assertEquals(1, result.size());
//
//    }
//
//    @Test
//    public void getMtvNetworkDirPractLocIds_null() {
//        Provider provider = new Provider();
//        Set<String> result = ProviderUtil.getMtvNetworkDirPractLocIds(provider);
//        Assertions.assertNull(result);
//    }
//
//    @Test
//    public void getMtvNetworkDirPractLocIds_values() {
//        Provider provider = new Provider();
//        List<Network> networks = new ArrayList<>();
//
//        Network network= new Network("12345676","123456","mtv","123456789","locationIdType","987654","mtv","2022-01-01","2029-01-01",false,false,false,false,2287179649719572419L,3387179649719572419L,"resyncTag");
//        networks.add(network);
//        provider.setOpvProviderNetworkDirectory(networks);
//
//        Set<String> result = ProviderUtil.getMtvNetworkDirPractLocIds(provider);
//        Assertions.assertNotNull(result);
//        Assertions.assertEquals(1, result.size());
//    }
//    @Test
//    public void getMtvPanelPractLocIds_null() {
//        Provider provider = new Provider();
//        Set<String> result = ProviderUtil.getMtvPanelPractLocIds(provider);
//        Assertions.assertNull(result);
//    }
//
//    @Test
//    public void getMtvPanelPractLocIds_values() {
//        Provider provider = new Provider();
//        List<Panel> panels = new ArrayList<>();
//
//        Panel panel= new Panel("12345676","123456","mtv","123456789","locationIdType","2022-01-01",1234,false,"Yes","2029-01-01",2287179649719572419L,3387179649719572419L,false,"resyncTag",true);
//        panels.add(panel);
//        provider.setOpvProviderPanel(panels);
//
//        Set<String> result = ProviderUtil.getMtvPanelPractLocIds(provider);
//        Assertions.assertNotNull(result);
//        Assertions.assertEquals(1, result.size());
//    }
}