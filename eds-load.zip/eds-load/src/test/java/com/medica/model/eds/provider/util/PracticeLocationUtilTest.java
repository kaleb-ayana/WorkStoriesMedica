package com.medica.model.eds.provider.util;

import com.medica.model.eds.provider.Address;
import com.medica.model.eds.provider.Provider;
import com.provider.eds.model.PracticeLocation;
import com.provider.eds.service.utils.PracticeLocationUtil;
import com.provider.eds.service.utils.ProviderUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class PracticeLocationUtilTest {
    private Provider mockProvider;
    private Address mockAddress;

    @BeforeEach
    public void setUp() {
        mockProvider = Mockito.mock(Provider.class);
        mockAddress = Mockito.mock(Address.class);

        Mockito.when(mockProvider.getLogicalDeleteFlg()).thenReturn(false);
        Mockito.when(mockProvider.getProviderId()).thenReturn("provider123");
        Mockito.when(mockProvider.getSourceSystemCd()).thenReturn("source123");
        Mockito.when(mockAddress.getMtvAddrId()).thenReturn("address123");
        Mockito.when(mockAddress.getAddrMd5Hash()).thenReturn("md5hash123");
    }

    /*@Test
    public void testBuildPracticeLocations_WithMatchingMd5Hashes() {
        // Arrange
        String practLocId = "location123";
        List<String> matchingMd5Hashes = new ArrayList<>();
        matchingMd5Hashes.add("md5hash1");
        matchingMd5Hashes.add("md5hash2");

        ProviderUtil providerUtilMock = Mockito.mock(ProviderUtil.class);
        Mockito.when(providerUtilMock.getMD5s(mockProvider, practLocId)).thenReturn(matchingMd5Hashes);
        List<PracticeLocation> practiceLocations = PracticeLocationUtil.buildPracticeLocations(mockProvider, practLocId);

        assertEquals(2, practiceLocations.size());
        for (PracticeLocation practiceLocation : practiceLocations) {
            assertFalse(practiceLocation.isLogicalDeleteFlg());
            assertEquals(practLocId, practiceLocation.getPractLocId());
            assertTrue(matchingMd5Hashes.contains(practiceLocation.getMd5Hash()));
            assertEquals(mockProvider.getProviderId(), practiceLocation.getMtvProviderId());
            assertEquals(mockProvider.getSourceSystemCd(), practiceLocation.getSourceSystemCd());
        }
    }*/

    @Test
    public void testBuildPracticeLocations_WithNoMatchingMd5Hashes() {
        String practLocId = "location123";
        List<String> matchingMd5Hashes = new ArrayList<>();
        ProviderUtil providerUtilMock = Mockito.mock(ProviderUtil.class);
        Mockito.when(providerUtilMock.getMD5s(mockProvider, practLocId)).thenReturn(matchingMd5Hashes);

        List<PracticeLocation> practiceLocations = PracticeLocationUtil.buildPracticeLocations(mockProvider, practLocId);
        assertTrue(practiceLocations.isEmpty());
    }

    @Test
    public void testBuildPracticeLocation() {
        PracticeLocation practiceLocation = PracticeLocationUtil.buildPracticeLocation(mockProvider, mockAddress);
        assertFalse(practiceLocation.isLogicalDeleteFlg());
        assertEquals(mockAddress.getMtvAddrId(), practiceLocation.getPractLocId());
        assertEquals(mockAddress.getAddrMd5Hash(), practiceLocation.getMd5Hash());
        assertEquals(mockProvider.getProviderId(), practiceLocation.getMtvProviderId());
        assertEquals(mockProvider.getSourceSystemCd(), practiceLocation.getSourceSystemCd());
    }

}