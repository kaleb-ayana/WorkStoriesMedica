package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import com.healthplan.ods.provider.transformation.config.validation.OptionalDate;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Panel  implements Serializable {
    private static final long serialVersionUID = 8645795032631356905L;
    @JsonProperty("ACCUM_TYPE")
    public String accumType;
    @JsonProperty("MAX_MBR_COUNT")
    public int maxMbrCount;
    @JsonProperty("MAX_PAT_CNT_EFF_DT")
    public String maxPatCntEffDt;
    @JsonProperty("PAT_CUTOFF_PCT_NUM")
    public int patCutOffPctNum;
    @JsonProperty("MAX_PAT_CUTOFF_NBR")
    public int maxPatCutOffNbr;
    @JsonProperty("PATIENT_COUNT")
    public int patientCount;
    @JsonProperty("PAT_CNT_AS_OF_TS")
    public String patCntAsOfTs;
    @JsonProperty("PATIENT_TYPE_CODE")
    public String patientTypeCode;
    @JsonProperty("PAT_SEX_AGE_CODE")
    public String patSexAgeCode;
    @JsonProperty("PAT_TYPE_SEXAGE_DT")
    public String patTypeSexAgeDt;
    @NotBlank(message = "Panel.pat_acceptance_cd should have a non-blank value")
    @JsonProperty("PAT_ACCEPTANCE_CD")
    public String patAcceptanceCd;
    @MandatoryDate(message = "Panel.effectiveDate is null or invalid format.")
    @JsonProperty("EFFECTIVE_DATE")
    public String effectiveDate;
    @OptionalDate(message = "Panel.end_date has invalid format.")
    @JsonProperty("END_DATE")
    public String endDate;
    @NotBlank(message = "Panel.provider_id should have a non-blank value")
    @JsonProperty("PROVIDER_ID")
    public String providerId;
    @JsonProperty("BUS_LEVEL_4_ID")
    public String busLevel4Id;
    @JsonProperty("BUS_LEVEL_5_ID")
    public String busLevel5Id;
    @JsonProperty("BUS_LEVEL_6_ID")
    public String busLevel6Id;
    @JsonProperty("PROVIDER_GROUP_ID")
    public String providerGroupId;
    @NotBlank(message = "Panel.practice_loc_id should have a non-blank value")
    @JsonProperty("PRACTICE_LOC_ID")
    public String practiceLocId;
    @JsonProperty("CREATION_TS")
    public String creationTs;
    @JsonProperty("LAST_MAINT_TS")
    public String lastMaintTs;
    @JsonProperty("OPERATOR_ID")
    public String operatorId;
    @JsonProperty("PROVIDER_ORG_ID")
    public String providerOrgId;
    @JsonProperty("DISEASE_MGMT_CODE")
    public String diseaseMgmtCode;
    @JsonProperty("IDENTIFIER")
    public String identifier;
    @JsonProperty("BUS_LEVEL_1_ID")
    public String busLevel1Id;
    @JsonProperty("BUS_LEVEL_2_ID")
    public String busLevel2Id;
    @JsonProperty("BUS_LEVEL_3_ID")
    public String busLevel3Id;
    @JsonProperty("BUS_LEVEL_7_ID")
    public String busLevel7Id;
    @JsonProperty("NETWORK_ID")
    public String networkId;
    @JsonProperty("ADDRESS_ID")
    public String addressId;

    @JsonProperty("PATIENTS_ONCE_PER_WEEK_FLG")
    public boolean patientsOncePerWeekFlg;

    @JsonIgnore
    private boolean logicalDeleteFlag;

    @JsonIgnore
    private boolean acceptingNewPatientFlag;

    @JsonIgnore
    public boolean getAcceptingNewPatientFlag() {
        return this.acceptingNewPatientFlag;
    }
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        this.logicalDeleteFlag= Constants.VOID.equalsIgnoreCase(this.patAcceptanceCd);
    }
    @JsonIgnore
    private String md5Hash;

    @JsonIgnore
    public String getMd5hash() {
        return this.md5Hash;
    }
    public void setMd5Hash(String md5Hash) {
        this.md5Hash= md5Hash;
    }

    @JsonIgnore
    public boolean isVoided() {
        return true == this.logicalDeleteFlag;
    }
}
