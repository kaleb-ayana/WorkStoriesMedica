package com.healthplan.ods.provider.transformation.service.messagers;

import com.deancare.fsa.provider.Provider;
import com.healthplan.ods.provider.transformation.config.kafka.AppConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;

@Service
@Slf4j
public class KafkaTemplateWrapperService {

    @Autowired
    @Qualifier("kafkaTemplateProduceConsumer")
    private KafkaTemplate<String, Provider> kafkaTemplateProduceConsumer;

    @Autowired
    AppConfig appConfig;

    public ListenableFuture produceConsumerTopicMessage(Provider provider) {
        return this.produceConsumerTopicMessage(provider, appConfig.getEnvSpecificTargetTopic());
    }
    public ListenableFuture produceConsumerTopicDltMessage(Provider provider) {
        return this.produceConsumerTopicMessage(provider, appConfig.getEnvSpecificTargetTopic()+".dlt");
    }
    public ListenableFuture produceConsumerTopicMessage(Provider provider, String topic) {
            return kafkaTemplateProduceConsumer.send(topic, provider.getPayload().getPROVIDERID(), provider);
    }

}
