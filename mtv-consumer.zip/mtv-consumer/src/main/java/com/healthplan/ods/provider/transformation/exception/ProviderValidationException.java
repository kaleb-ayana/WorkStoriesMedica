package com.healthplan.ods.provider.transformation.exception;

public class ProviderValidationException extends Exception {
    private static final long serialVersionUID = 2892608684290288042L;

    public ProviderValidationException(String s) {
        super(s);
    }
}
