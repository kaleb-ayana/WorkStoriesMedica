package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Affiliation  implements Serializable {
    private static final long serialVersionUID = 9169481037484085673L;

    @JsonProperty("SURROGATE_ID")
    public long surrogateId;

    @NotBlank(message = "Affiliation.AFFL_TYPE field should have a non-blank value")
    @JsonProperty("AFFL_TYPE")
    private String affiliation_type = Constants.AFFILIATION_TYPE;

    @JsonProperty("SPECIALTY_CODE")
    public String specialtyCode;

    @MandatoryDate(message = "Affiliation.Effective Date field should have a non-blank and valid value")
    @JsonProperty("EFFECTIVE_DATE")
    public String effectiveDate;

    @JsonProperty("END_DATE")
    public String endDate;

    @JsonProperty("CREATION_TS")
    public String creationTs;

    @JsonProperty("LAST_MAINT_TS")
    public String lastMaintTs;

    @JsonProperty("OPERATOR_ID")
    public String operatorId;

    @NotBlank(message = "Affiliation.FK_JOINING_PROV_ID field should have a non-blank value")
    @JsonProperty("FK_JOINING_PROV_ID")
    public String fkJoiningProId;

    @NotBlank(message = "Affiliation.FK_JOINED_PROV_ID field should have a non-blank value")
    @JsonProperty("FK_JOINED_PROV_ID")
    public String fkJoinedProvId;

    @JsonProperty("PRIVILEGE_TYPE")
    public String privilegeType;

    @JsonProperty("VOID_FLAG")
    public String voidFlag;

    @NotBlank(message = "Affiliation.AFFILIATION_CODE field should have a non-blank value")
    @JsonProperty("AFFILIATION_CODE")
    public String affiliationCode;

    @JsonProperty("PCP_FLG")
    private String pcpFlg = Constants.BLANK;

    @JsonProperty("PRIMARY_FLG")
    private String primaryFlg = Constants.BLANK;

    @JsonProperty("SOURCE_SYSTEM_CD")
    private String sourceSystemCd = Constants.SERVICE_NAME;

    @JsonProperty("HOSPITAL_AFFILIATION_TYPE")
    private String hospitalAffiliationType = Constants.BLANK;

    @JsonIgnore
    private boolean logicalDeleteFlag;

    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        logicalDeleteFlag = TransformationUtil.convertStringToBoolean(this.voidFlag);
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.logicalDeleteFlag;
    }
}
