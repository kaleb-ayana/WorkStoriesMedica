
package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import com.healthplan.ods.provider.transformation.config.validation.OptionalDate;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Specialty  implements Serializable {

    private static final long serialVersionUID = -5585462352414760095L;
    @MandatoryDate(message = "Specialty.effctive Date is null or formatted invalid.")
    @JsonProperty("EFFECTIVE_DATE")
    private String effectiveDate;

    @OptionalDate(message = "Specialty.enddate field has invalid format.")
    @JsonProperty("END_DATE")
    private String endDate;

    @NotBlank(message = "Specialty.specialty_code field should have a non-blank value")
    @JsonProperty("SPECIALTY_CODE")
    private String specialtyCode;

    @JsonProperty("LAST_MAINT_TS")
    private String lastMaintTs;

    @JsonProperty("CREATION_TS")
    private String creationTs;

    @JsonProperty("OPERATOR_ID")
    private String operatorId;

    @JsonProperty("PRIMARY_FLAG")
    private String primaryFlag;

    @JsonProperty("FK_PROV_ID")
    private String fkProvId;

    @JsonProperty("BOARD_CERT_FLAG")
    private String boardCertFlag;

    @JsonProperty("VOID_FLAG")
    private String voidFlag;

    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        logicalDeleteFlag= TransformationUtil.convertStringToBoolean(this.voidFlag);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Specialty specialty = (Specialty) o;
        return Objects.equals(specialtyCode, specialty.specialtyCode) &&
                Objects.equals(fkProvId, specialty.fkProvId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(specialtyCode, fkProvId);
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
}
