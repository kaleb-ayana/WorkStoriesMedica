package com.healthplan.ods.provider.transformation.config;

import com.medica.reference.service.NetworkStatusReferenceService;
import com.medica.reference.service.ProviderReferenceService;
import org.springframework.context.annotation.Bean;

@org.springframework.context.annotation.Configuration
public class Configuration {
    @Bean
    public ProviderReferenceService getProviderReferenceService() {
        return new ProviderReferenceService();
    }

    @Bean
    public NetworkStatusReferenceService getNetworkStatusReferenceService() {
        return new NetworkStatusReferenceService();
    }

}
