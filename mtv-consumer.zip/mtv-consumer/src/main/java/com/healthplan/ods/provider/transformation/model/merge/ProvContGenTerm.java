package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.*;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProvContGenTerm   implements Serializable {
    private static final long serialVersionUID = 3470404355535836506L;
    @JsonProperty("IDENTIFIER")
    private String identifier;

    @JsonProperty("EFFECTIVE_DATE")
    private String effective_Date;

    @JsonProperty("END_DATE")
    private String end_Date;

    @JsonProperty("PROV_STAT_CODE")
    private String prov_Stat_Code;

    @JsonProperty("PAY_LESS_IND")
    private String pay_Less_Ind;

    @JsonProperty("CLASS_CODE")
    private String class_Code;

    @JsonProperty("MED_SVC_AREA_CD")
    private String med_Svc_Area_Cd;

    @JsonProperty("SVC_AREA_BLOCK_CD")
    private String svc_Area_Block_Cd;

    @JsonProperty("CREATION_TS")
    private String creation_Ts;

    @JsonProperty("LAST_MAINT_TS")
    private String last_Maint_Ts;

    @JsonProperty("OPERATOR_ID")
    private String operator_Id;

    @JsonProperty("VOID_FLAG")
    private String void_Flag;

    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        this.logicalDeleteFlag= TransformationUtil.convertStringToBoolean(this.void_Flag);
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
}
