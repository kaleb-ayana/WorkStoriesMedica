package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import com.healthplan.ods.provider.transformation.config.validation.OptionalDate;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.service.utils.ListUtil;
import lombok.*;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.healthplan.ods.provider.transformation.service.utils.TransformationUtil.*;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)

public class Address implements Serializable  {

    private static final long serialVersionUID = 7709255719156943000L;
    @JsonProperty("WHO_TYPE_IND")
    private String whoTypeInd;

    @JsonProperty("NAME")
    private String name;

    @JsonProperty("WHO_IDENTIFIER")
    private String whoIdentifier;

    @JsonProperty("IDENTIFIER")
    private String identifier;

    @JsonProperty("WHO_IDENTIFIER1")
    private String whoIdentifer1;

    @NotBlank(message = "Address.Address1 field should have a non-blank value")
    @JsonProperty("ADDRESS_1")
    private String address1;

    @JsonProperty("UC_ADDRESS_1")
    private String ucAddress;

    @JsonProperty("ADDRESS_2")
    private String address2;

    @JsonProperty("ADDRESS_3")
    private String address3;

    @NotBlank(message = "Address.City field should have a non-blank value")
    @JsonProperty("CITY")
    private String city;

    @JsonProperty("UC_CITY")
    private String ucCity;

    @NotBlank(message = "Address.State Code field should have a non-blank value")
    @JsonProperty("STATE_CODE")
    private String stateCode;

    @NotBlank(message = "Address.Zip field should have a non-blank value")
    @JsonProperty("ZIP")
    private String zip;

    private String countyCrossWalk;
    @JsonProperty("COUNTY_CODE")
    private String countyCode;

    @JsonProperty("COUNTRY_CODE")
    private String countryCode;

    @JsonProperty("GEO_CODE")
    private String geoCode;

    @MandatoryDate(message = "Address.Effective Date field should have a non-blank and valid value")
    @JsonProperty("EFFECTIVE_DATE")
    private String effectiveDate;

    @OptionalDate(message = "Address.enddate field has invalid format.")
    @JsonProperty("END_DATE")
    public String endDate;

    @JsonProperty("EFF_PROCESS_DATE")
    private String effProcessDate;

    @JsonProperty("VOID_FLAG")
    private String voidFlag;

    @JsonProperty("VERSION_NUMBER")
    private Integer versionNumber;

    @JsonProperty("AUDIT_FLAG")
    private String auditFlag;

    @JsonProperty("OPERATOR_ID")
    private String operatorId;

    @JsonProperty("LAST_MAINT_TS")
    private String lastMaintTs;

    @JsonProperty("CREATION_TS")
    private String creationTs;

    @JsonProperty("RECON_DATE")
    private String reconDate;

    @JsonProperty("ADDRESS_STATUS_CD")
    private String addressStatusCd;

    @JsonProperty("ADDRESS_CODE")
    private String addressCode;

    @JsonProperty("PURGE_FLAG")
    private String purgeFlag;

    @JsonProperty("LATITUDE_COORDINATE")
    private Double latitudeCoordinate;

    @JsonProperty("LONGITUDE_COORDINATE")
    private Double longitudeCoordinate;

    @JsonProperty("PRIMARY_FLAG")
    public String primaryFlag;

    @JsonProperty("PHONES")
    private List<Phone> phoneList;

    @JsonProperty("LOCATION_ID")
    private String locationId;

    @JsonProperty("HANDICAPPED_ACC_CD")
    private String handicappedAcctCd;

    @JsonProperty("ELECT_ADDRESS")
    public String electAddress;

    @JsonIgnore
    private String md5Hash;

    @JsonIgnore
    private boolean logicalDeleteFlag;

    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }

    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        logicalDeleteFlag= convertStringToBoolean(this.voidFlag);
        if(CollectionUtils.isEmpty(this.phoneList))
            return;
        this.phoneList.stream().forEach(Phone::buildLogicalDeleteFlag);
    }

    public void addPhone(Phone phone) {
        if(Objects.isNull(phone))
            return;
        if(this.phoneList == null)
            this.phoneList = new ArrayList<>();
        if(this.phoneList.contains(phone))
            return;
        this.phoneList.add(phone);
    }


    @JsonIgnore
    public boolean hasPrimaryPhone() {
        if(CollectionUtils.isEmpty(this.phoneList))
            return false;
        return Objects.isNull(this.getPrimaryPhone()) ? false : this.getPrimaryPhone().isPresent();
    }
    @JsonIgnore
    public Optional<Phone> getPrimaryPhone() {
        if(CollectionUtils.isEmpty(this.phoneList))
            return null;
        return this.phoneList.stream()
                .filter(phone -> convertStringToBoolean(phone.getPrimaryFlag()))
                .findFirst();
    }
    @JsonIgnore
    public Phone getSitePhone() {
        if(CollectionUtils.isEmpty(this.phoneList))
            return null;
        Optional<Phone> sitePhone= this.phoneList.stream().filter(phone -> "AD".equalsIgnoreCase(phone.getWhoTypeIndicator())).findFirst();
        return Objects.nonNull(sitePhone) && sitePhone.isPresent() ? sitePhone.get() : null;
    }
    @JsonIgnore
    public boolean hasSitePhone() {
        return Objects.nonNull(this.getSitePhone());
    }
    public void cleanWhiteSpaces() {
        this.address1= Objects.nonNull(this.address1) ? this.address1.trim() : null;
        this.address2= Objects.nonNull(this.address2) ? this.address2.trim() : null;
        this.address3= Objects.nonNull(this.address3) ? this.address3.trim() : null;
        this.city= Objects.nonNull(this.city) ? this.city.trim() : null;
        this.stateCode= Objects.nonNull(this.stateCode) ? this.stateCode.trim() : null;
        this.zip= Objects.nonNull(this.zip) ? this.zip.trim() : null;
        if(CollectionUtils.isEmpty(this.phoneList))
            return;

        this.phoneList.stream().forEach(Phone::cleanWhiteSpaces);
    }
    @JsonIgnore
    public boolean hasAddressCode(String addressCode) {
        if(! StringUtils.hasText(addressCode) )
            return this.addressCode == addressCode;
        return addressCode.trim().equalsIgnoreCase(this.addressCode);
    }

    @JsonIgnore
    public boolean isSitePracticeLocation() {
        return Constants.ADDRESS_TYPE_PHYSICAL_A2.equalsIgnoreCase(this.addressCode);
    }

    @JsonIgnore
    public List<Phone> getPhonesOfWhoType(String type) {
        if(! StringUtils.hasText(type) || CollectionUtils.isEmpty(this.phoneList))
            return null;
        return ListUtil.selectFromList(this.phoneList, phone -> type.equalsIgnoreCase(phone.getWhoTypeIndicator()));
    }

    public void removePhonesOfWhoType(String type) {
        this.phoneList= ListUtil.selectFromList(this.phoneList, phone -> ! type.equalsIgnoreCase(phone.getWhoTypeIndicator()));
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
    @JsonIgnore
    public boolean hasElectronicAddress() {
        return StringUtils.hasText(this.electAddress);
    }
    @JsonIgnore
    public boolean isPermutedA2() {
        return this.isSitePracticeLocation() && this.hasUtmostOnePhone();
    }

    @JsonIgnore
    private boolean hasUtmostOnePhone() {
        return CollectionUtils.isEmpty(this.phoneList) || this.phoneList.size() <= 1;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address = (Address) o;
        boolean flag= Objects.equals(this.whoTypeInd, address.whoTypeInd) &&
                Objects.equals(this.addressCode, address.addressCode) &&
                Objects.equals(this.identifier, address.identifier) &&
                Objects.equals(this.effectiveDate, address.effectiveDate) &&
                Objects.equals(this.address1, address.address1) &&
                Objects.equals(this.address2, address.address2) &&
                Objects.equals(this.address3, address.address3) &&
                Objects.equals(this.city, address.city) &&
                Objects.equals(this.stateCode, address.stateCode) &&
                Objects.equals(this.zip, address.zip);
        if((! this.isPermutedA2()) || (! address.isPermutedA2()))
            return flag;
        if(CollectionUtils.isEmpty(this.phoneList))
            return flag && CollectionUtils.isEmpty(address.phoneList);
        if(CollectionUtils.isEmpty(address.phoneList))
            return flag && CollectionUtils.isEmpty(this.phoneList);
        return flag && this.phoneList.get(0).equals(address.phoneList.get(0));
    }

    @Override
    public int hashCode() {
        return Objects.hash(identifier);
    }

    public void mergeAddress(Address address) {
        if(Objects.isNull(address) || (! this.equals(address)))
            return;
//        LocalDate selfEffectiveDate= LocalDate.parse()
        LocalDate selfEffectiveDate= parseMTVDate(this.effectiveDate);
        LocalDate targetEffectiveDate= parseMTVDate(address.getEffectiveDate());
        if(Objects.isNull(selfEffectiveDate)) {
            mergeAddress(address, this);
            return;
        }

        if(Objects.isNull(targetEffectiveDate)) {
            mergeAddress(this, address);
            return;
        }
        if(selfEffectiveDate.isBefore(targetEffectiveDate)) {
            mergeAddress(address, this);
            return ;
        }
        mergeAddress(this, address);
    }

    private static void mergeAddress(Address baseAddress, Address targetAddress) {
        baseAddress.setEffectiveDate(getMinMTVDateString(baseAddress.effectiveDate, targetAddress.effectiveDate));
        baseAddress.setEndDate(getMaxMTVDateString(baseAddress.effectiveDate, targetAddress.effectiveDate));
    }

    @JsonIgnore
    public boolean isFlaggedForAudit(){
        return  "Y".equalsIgnoreCase(auditFlag);
    }

}
