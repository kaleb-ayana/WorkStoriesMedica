package com.healthplan.ods.provider.transformation.config.validation;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Objects;

public class OptionalDateValidator implements ConstraintValidator<OptionalDate, String> {
    public static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.US);

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        try{
            return Objects.isNull(value) || value.isBlank() || Objects.nonNull(LocalDate.parse(value, formatter));
        } catch( Exception e) {
            return false;
        }
    }

}