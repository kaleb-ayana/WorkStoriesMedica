package com.healthplan.ods.provider.transformation.service.products;

import com.healthplan.ods.provider.transformation.exception.ProviderValidationException;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Objects;

@Slf4j
public class Validator implements Serializable {
    private static final long serialVersionUID = 7456147825769603341L;

    public void validate(ProviderDto provider)  throws ProviderValidationException {
        if (Objects.isNull(provider))
            throw new ProviderValidationException("Provider instance for validation is NULL");
        if(! ConstraintValidator.isValidProvider(provider)) {
            log.warn("Provider has one or more missing required or inappropriately formatted field(s).");
            throw new ProviderValidationException("Provider has one or more missing required or inappropriately formatted field(s).");
        }
    }
    public boolean isWellFormed(ProviderDto provider) {
        return Objects.nonNull(provider) &&
                StringUtils.hasText(provider.getIdentifier()) &&
                StringUtils.hasText(provider.getProvType()) &&
                StringUtils.hasText(provider.getCategory()) &&
                StringUtils.hasText(provider.getLastName()) &&
                StringUtils.hasText(provider.getEffectiveDate()) ;
    }

}
