package com.healthplan.ods.provider.transformation.model.merge;

import com.deancare.fsa.provider.GENDER_IND;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import com.healthplan.ods.provider.transformation.config.validation.StringInListOrBlank;
import com.healthplan.ods.provider.transformation.exception.ProviderConversionException;
import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.exception.ProviderValidationException;
import com.healthplan.ods.provider.transformation.service.products.Converter;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.service.utils.ListUtil;
import com.healthplan.ods.provider.transformation.service.products.Validator;
import com.medica.reference.misc.PersistenceErrorException;
import com.medica.reference.service.NetworkStatusReferenceService;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.healthplan.ods.provider.transformation.service.utils.TransformationUtil.convertStringToBoolean;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@Slf4j
@Configurable
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class ProviderDto  implements Serializable {
    private static final long serialVersionUID = 6789206961241199004L;
    @JsonProperty("FIRST_NAME")
    private String firstName;

    @JsonProperty("MIDDLE_NAME")
    private String middleName;

    @NotBlank(message = "Provider.lastname should have a non-blank value")
    @JsonProperty("LAST_NAME")
    private String lastName;

    @NotBlank(message = "Provider.identifier should have a non-blank value")
    @JsonProperty("IDENTIFIER")
    private String identifier;

    @JsonProperty("PROV_TYPE")
    private String provType;

    @JsonProperty("MODEL_CODE")
    private String modelCode;

    @JsonProperty("LAST_MAINT_TS")
    private String lastMaintTs;

    @JsonProperty("CREATION_TS")
    private String creationTs;

    @JsonProperty("OPERATOR_ID")
    private String operatorId;

    @JsonProperty("ARTICLES_OF_INC_DT")
    private String articlesOfIncDt;

    @JsonProperty("BY_LAWS_DATE")
    private String byLawsDate;

    @NotBlank(message = "Provider.category should have a non-blank value")
    @JsonProperty("CATEGORY")
    private String category;

    @JsonProperty("UC_FIRST_NAME")
    private String ucFirstName;

    @JsonProperty("UC_MIDDLE_NAME")
    private String ucMiddleName;

    @JsonProperty("UC_LAST_NAME")
    private String ucLastName;

    @JsonProperty("PROCD_CODE_LIST")
    private String procdCodeList;

    @JsonProperty("DESD_COM_METH_IND")
    private String desdComMethInd;

    @JsonProperty("DESD_COMM_KEY")
    private String descCommKey;

    @JsonProperty("ELECTRNIC_SUB_FLAG")
    private String electronicSubFlag;

    @JsonProperty("PRIMARY_ADDRESS")
    private Long primaryAddressId;

    @JsonProperty("PREFERRED_PHONE_ID")
    private Long preferredPhoneId;

    @JsonProperty("PREF_EMAIL_ID")
    private Long prefEmailId;

    @JsonProperty("FK_PROVIDER_ID")
    private String fkProviderId;

    @JsonProperty("MULTIPLE_PROV_IND")
    private String multipleProvInd;

    @MandatoryDate(message = "Provider.effectiveDate is null or invalid format.")
    @JsonProperty("DFLT_EFFECTIVE_DT")
    private String effectiveDate;

    @JsonProperty("BILLING_OFFICE_FG")
    private String billingOfficeFg;

    @JsonProperty("INACTIVE_FLAG")
    private String inactiveFlag;

    @JsonProperty("BILLING_PROXY_IND")
    private String billingProxyInd;

    @JsonProperty("NPI_INDICATOR")
    private String npiIndicator;

    @JsonProperty("PROVIDER_SOURC_IND")
    private String providerSourcInd;

    @JsonProperty("CMPLT_FIRST_NAME")
    private String cmpltFirstName;

    @JsonProperty("CMPLT_MIDDLE_NAME")
    private String cmpltMiddleName;

    @JsonProperty("CMPLT_LAST_NAME")
    private String cmpltLastName;

    @JsonProperty("ORGANIZATION_TYPE")
    private String organizationType;

    @JsonProperty("TAX_CLASSIFICATION")
    private String taxClassification;

    @JsonProperty("BUSINESS_START_DATE")
    private String businessStartDate;

    @JsonProperty("INCORPORATION_FLAG")
    private String incorporationFlag;

    @JsonProperty("INCORPORATION_DATE")
    private String incorporationDate;

    @JsonProperty("REVALIDATION_FLAG")
    private String revalidationFlag;

    @JsonProperty("TAXONOMY_CODE")
    private String taxonomyCode;

    @StringInListOrBlank(acceptedValues={"F", "M", "U", ""}, message="Provider.sex has invalid value.")
    @JsonProperty("SEX")
    private String sex;

    @JsonProperty("OBSTETRICIAN_FlAG")
    private String obstetricianFlag;

    @JsonProperty("DEGREE_CODE")
    private String degreeCode;

    @JsonProperty("PCP_FLG")
    private Boolean pcpFlag;

    @JsonProperty("ADDRESSES")
    private List<Address> addressList;

    @Valid
    @JsonProperty("SPECIALTIES")
    private List<Specialty> specialtyList;

    @JsonProperty("EDUCATION")
    private List<Education> educationList;

    @JsonProperty("DEGREE")
    private List<Degree> degreeList;

    @JsonProperty("SECONDARY_PROVIDERS")
    private List<AlternateId> alternateIds;

    @JsonProperty("NETWORKS")
    private List<Network> networks;

    @JsonProperty("AFFILIATIONS")
    private List<Affiliation> affiliations;

    @JsonProperty("LANGUAGES_SPOKEN")
    private List<Language> languageList;

    @JsonProperty("PANEL")
    private List<Panel> panels;

    @JsonIgnore
    @JsonProperty("ELECTRONIC_ADDRESS")
    private List<ElectronicAddress> electronicAddressList;


    @JsonProperty("CERTIFICATION")
    private List<Certification> certificationList;

    @JsonProperty("SWING_BED_CNT")
    private Integer swingBedCnt;

    @JsonProperty("MEDICARE_BED_CNT")
    private Integer medicareBedCnt;

    @JsonProperty("BILLING_CONFIRMATION_HOLD_FLG")
    private String billingConfirmationHoldFlg= Constants.NO;

    @JsonProperty("SPECIALTY_CD")
    private String specialtyCd="NA";

    @JsonProperty("LONG_TERM_CARE_FACILITY_FLG")
    private String longTermCareFacilityFlg= Constants.NO;

    @JsonProperty("PLACE_OF_SERVICE")
    private String placeOfService= Constants.BLANK;

    @JsonProperty("UNIQUE_RATES_STATUS")
    private String uniqueRateStatus= Constants.NO;

    @JsonProperty("UNIQUE_RATE")
    private String uniqueRate= Constants.BLANK;

    @JsonProperty("CLAIM_HOLD_FLG")
    private String claimHoldFlg= Constants.NO;

    @JsonProperty("ECP_FLG")
    private String ecpFlg= Constants.NO;

    @JsonProperty("FQHC_FLG")
    private String fqhcFlg= Constants.NO;

    @JsonProperty("RHC_FLG")
    private String rhcFlg= Constants.NO;

    @JsonProperty("CAH_FLG")
    private String cahFlg= Constants.NO;

    @JsonProperty("CORF_FLG")
    private String corfFlg= Constants.NO;

    @JsonProperty("SWING_BED_FLG")
    private String swingBedFlg= Constants.NO;

    @JsonProperty("SWING_BED_MEDICARE_NUM")
    private String swingBedMedicateNum;

    @JsonProperty("HOSPICE_CBSA")
    private String hospiceCbsa;

    @JsonProperty("GENETIC_LAB_FLG")
    private String geneticLabFlg= Constants.NO;

    @JsonProperty("DIABETIC_EDUCATION_PROGRAM_FLG")
    private String diabeticEducationProgramFlg= Constants.NO;

    @JsonProperty("SUPPLY_OXYGEN_FLG")
    private String supplyOxygenFlg= Constants.NO;

    @JsonProperty("CULTURAL_COMPETENCY_STATUS")
    private String culturalCompetencyStatus= Constants.NO;

    @JsonProperty("CULTURAL_AWARENESS_FLG")
    private String culturalAwarenessFlg= Constants.NO;

    @JsonProperty("CULTURAL_SAFETY_FLG")
    private String culturalSafetyFlag= Constants.NO;

    @JsonProperty("CULTURAL_COMPETENCE_FLG")
    private String culturalCompetenceFlg= Constants.NO;

    @JsonProperty("AMERICAN_DISABILITY_COMPLIANT_STATUS")
    private String americanDisabilityComplaintStatus=Constants.BLANK;

    @JsonProperty("AMERICAN_DISABILITY_EXAM_ROOMS_STATUS")
    private String americanDisabilityExamRoomsStatus=Constants.BLANK;

    @JsonProperty("AMERICAN_DISABILITY_OFFICE_STATUS")
    private String americanDisabilityOfficeStatus=Constants.BLANK;

    @JsonProperty("AMERICAN_DISABILITY_EQUIPMENT_STATUS")
    private String americanDisabilityEquipmentStatus=Constants.BLANK;

    @JsonProperty("OBGYN_FLAG")
    private Boolean obgynFlag= false;

    @JsonProperty("REFUND_REQUEST_METHOD")
    private String refundRequestMethod;

    @JsonIgnore
    private String siteAddressLine1;
    @JsonIgnore
    private String siteAddressLine2;
    @JsonIgnore
    private String siteAddressLine3;
    @JsonIgnore
    private String siteCity;
    @JsonIgnore
    private String siteStateCd;
    @JsonIgnore
    private String siteZip;
    @JsonIgnore
    private String sitePrimarySpecialty;
    @JsonIgnore
    private String sitePrimaryCrosswalkSpecialty;
    @JsonIgnore
    private String sitePhone;

    @JsonIgnore
    private String xWalkDegreeCd;

    @JsonIgnore
    private String handicappedFlag;

    @JsonIgnore
    private boolean ifbFlag= false;
    @JsonIgnore
    private String endDate;
    @JsonIgnore
    public boolean getIfbFlag() {
        return this.ifbFlag;
    }

    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }



    @JsonIgnore
    private String schemaVersion;
    public void buildLogicalDeleteFlag() {
        this.logicalDeleteFlag= convertStringToBoolean(this.inactiveFlag);
        if(Objects.nonNull(this.getAddressList()))
            this.getAddressList().stream().forEach(Address::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getSpecialtyList()))
            this.getSpecialtyList().stream().forEach(Specialty::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getAlternateIds()))
            this.getAlternateIds().stream().forEach(AlternateId::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getAffiliations()))
            this.getAffiliations().stream().forEach(Affiliation::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getLanguageList()))
            this.getLanguageList().stream().forEach(Language::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getPanels()))
            this.getPanels().forEach(Panel::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getNetworks()))
            this.networks.stream().forEach(Network::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getElectronicAddressList()))
            this.getElectronicAddressList().stream().forEach(ElectronicAddress::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getCertificationList()))
            this.getCertificationList().stream().forEach(Certification::buildLogicalDeleteFlag);
        if(Objects.nonNull(this.getPanels()))
            this.getPanels().stream().forEach(Panel::buildLogicalDeleteFlag);

    }

    @JsonIgnore
    private GENDER_IND genderIndicator;

    @JsonIgnore
    private com.deancare.fsa.provider.PROVIDER_ID_TYPE providerIdType;

    @JsonIgnore
    private com.deancare.fsa.provider.PROVIDER_CATEGORY_CD providerCategoryCd;

    @JsonIgnore
    private String npi;

    @JsonIgnore
    private String taxId;

    @JsonIgnore
    private String medicareOptOutFlag;

    @JsonIgnore
    private Validator validator;

    @JsonIgnore
    private Transformer transformer;

    @JsonIgnore
    private Converter converter;

    @JsonIgnore
    private String transactionId;

    @JsonIgnore
    public String getTransactionId() {
        return this.transactionId;
    }
    public void setTransactionId(String transactionId) {
        this.transactionId= transactionId;
    }
    @JsonIgnore
    public boolean isWellFormed() {
        if(this.validator == null)
            this.validator= new Validator();
        return this.validator.isWellFormed(this);
    }
    public void validate() throws ProviderValidationException {
        if(this.validator == null)
            this.validator= new Validator();
        this.validator.validate(this);
    }
    public void transform() throws ProviderProcessorException {

        if(this.transformer == null)
            this.transformer= new Transformer();

        this.transformer.transform(this);
    }

    @JsonIgnore
    public com.deancare.fsa.provider.Provider convert(NetworkStatusReferenceService networkStatusReferenceService) throws ProviderConversionException, PersistenceErrorException {
        if(this.converter == null)
            this.converter= new Converter( networkStatusReferenceService);
        return this.converter.convert(this);
    }

    @JsonIgnore
    public Optional<Specialty> getActivePrimarySpecialty() {
        if(CollectionUtils.isEmpty(this.specialtyList))
            return Optional.ofNullable(null);
        return this.specialtyList.stream()
                .filter(spe -> convertStringToBoolean(spe.getPrimaryFlag()))
                .filter(spe -> Constants.NO.equalsIgnoreCase(spe.getVoidFlag()))
                .findFirst();
    }
    @JsonIgnore
    public boolean hasPrimarySpecialty() {
        Optional<Specialty> primarySpecialty= this.getActivePrimarySpecialty();
        return Objects.nonNull(primarySpecialty) && this.getActivePrimarySpecialty().isPresent();
    }

    @JsonIgnore
    private AlternateId makeSourceSystemAlternativeId() {
        AlternateId alternateId= new AlternateId();
        alternateId.setIdTypeCode(Constants.ID_TYPE_MTV);
        alternateId.setMtvProviderCategoryCode(this.category);
        alternateId.setMtvProviderTypeCode(this.provType);
        alternateId.setFkProviderId(this.getIdentifier());
        alternateId.setOperatorId(this.getOperatorId());
        alternateId.setEffectiveDate(this.getEffectiveDate());
        alternateId.setIdentifier(this.getIdentifier());
        alternateId.setPrimaryNpiInd(Constants.NO);
        alternateId.setEndDate(Constants.DEFAULT_END_DATE);
//        alternateId.setLogicalDeleteFlag(convertStringToBoolean(this.inactiveFlag));
        alternateId.setTermReasonCode(null);
        alternateId.setVoidFlag(this.inactiveFlag);
        alternateId.setCreationTs(this.creationTs);
        alternateId.setLastMaintTs(this.lastMaintTs);
        return alternateId;
    }

    @JsonIgnore
    public void addAlternativeId(AlternateId alternateId) {
        if(Objects.isNull(alternateId))
            return;
        if(Objects.isNull(this.alternateIds))
            this.alternateIds = new ArrayList<>();
        this.alternateIds.add(alternateId);
    }
    @JsonIgnore
    public void addSpecialty(Specialty specialty) {
        if(Objects.isNull(specialty))
            return;
        if(Objects.isNull(this.specialtyList))
            this.specialtyList = new ArrayList<>();
        this.specialtyList.add(specialty);
    }

    @JsonIgnore
    public void addAddress(Address address) {
        if(Objects.isNull(address))
            return;
        if(Objects.isNull(this.addressList))
            this.addressList = new ArrayList<>();
        this.addressList.add(address);
    }
    @JsonIgnore
    public void addElectronicAddress(ElectronicAddress electronicAddress) {
        if(Objects.isNull(electronicAddress))
            return;
        if(Objects.isNull(this.electronicAddressList)) {
            this.electronicAddressList = new ArrayList<>();
            this.electronicAddressList.add(electronicAddress);
            return;
        }

        Optional<ElectronicAddress> electAddr= this.electronicAddressList
                .stream()
                .filter(electronicAddress1 -> electronicAddress.getElectAddress().equalsIgnoreCase(electronicAddress1.getElectAddress()))
                .findFirst();

        if(electAddr.isPresent()) {
            electAddr.get().updateVoidFlag(electronicAddress.getVoidFlag());
            return;
        }

        this.electronicAddressList.add(electronicAddress);
    }

    @JsonIgnore
    public boolean hasAlternateIdOfType(String altIdType) {
        if(! StringUtils.hasText(altIdType) )
            return false;
        return ListUtil.hasList(this.getAlternateIds(), alternateId -> altIdType.equalsIgnoreCase(alternateId.getIdTypeCode()));

    }
    @JsonIgnore
    public boolean hasAddressCodeOfType(String addressCode) {
        if(Objects.isNull(addressCode) || addressCode.isBlank() || Objects.isNull(this.addressList) || this.addressList.isEmpty())
            return false;
        return ListUtil.hasList(this.addressList, address -> address.hasAddressCode(addressCode));
    }
    @JsonIgnore
    public List<Address> getAddressesOfType(String addressType) {
        return ListUtil.selectFromList(this.addressList, address -> address.hasAddressCode(addressType));
    }
    @JsonIgnore
    public List<Address> getA2sWithPrimaryPhone() {
        if(CollectionUtils.isEmpty(this.addressList))
            return null;
        return ListUtil.selectFromList(this.addressList, address -> address.hasAddressCode(Constants.ADDRESS_TYPE_PHYSICAL_A2) && address.hasPrimaryPhone());
    }

    @JsonIgnore
    public Optional<AlternateId> getAlternateIdOfType(String altIdType) {
        if(Objects.isNull(altIdType) || altIdType.isBlank() || Objects.isNull(this.alternateIds) || this.alternateIds.isEmpty())
            return Optional.ofNullable(null);
        return this.alternateIds.stream().filter(a->altIdType.equalsIgnoreCase(a.getIdTypeCode())).findFirst();
    }

    public void removeAlternateIdOfType(String altIdType) {
        this.alternateIds= ListUtil.selectFromList(this.alternateIds,alternateId -> ! alternateId.hasType(altIdType));
    }
    public void removeAddressOfType(String addressType) {
        this.addressList= ListUtil.removeFromList(this.addressList, alternateId -> alternateId.hasAddressCode(addressType));
    }
    public void removeLegacyAlternativeId() {
        this.alternateIds= ListUtil.removeFromList(this.alternateIds, alternateId -> alternateId.hasType(Constants.ID_TYPE_LGCY));
    }
    @JsonIgnore
    public boolean hasSpecialty() {
        return (Objects.nonNull(this.specialtyList) && ( ! this.specialtyList.isEmpty()));
    }
    @JsonIgnore
    public boolean hasAddress() {
        return (Objects.nonNull(this.addressList) && ( ! this.addressList.isEmpty()));
    }
    @JsonIgnore
    public boolean hasDegreeCode() {
        return StringUtils.hasText(this.degreeCode);
    }
    public void computeGenderIndicator() {
        if(this.isCheckOrg()) {
            this.genderIndicator= null;
            return;
        }

        if(! StringUtils.hasText(this.sex))
            return;
        try{
            this.genderIndicator= GENDER_IND.valueOf(this.sex.trim().toUpperCase());
        } catch(Exception e) {
            log.warn("Provider : " + this.identifier + " has wrong Gender value : " + this.sex);
        }
    }

    @JsonIgnore
    public List<Phone> getAddressesPhones() {
        if(CollectionUtils.isEmpty(this.getAddressList()))
            return null;
        return this.getAddressList()
                .stream()
                .filter(a-> Objects.nonNull(a.getPhoneList()) && (! a.getPhoneList().isEmpty()))
                .map(a->a.getPhoneList())
                .flatMap(a->a.stream())
                .collect(Collectors.toList());
    }

    public void createMtvAlternativeId() {
        this.removeAlternateIdOfType(Constants.ID_TYPE_MTV);
        this.addAlternativeId(makeSourceSystemAlternativeId());
    }
    @JsonIgnore
    public boolean isCheckOrg() {
        boolean flag= ListUtil.hasList(this.getAlternateIds(), alternateId -> alternateId.hasType(Constants.ID_TYPE_TAX));
        return flag || ( ! flag && Constants.CATEGORY_CHECK_ORG.equalsIgnoreCase(this.category));
    }
    @JsonIgnore
    public boolean isPractitioner() {
        return Constants.CATEGORY_PROFESSIONAL.equalsIgnoreCase(this.category);
    }
    @JsonIgnore
    public boolean isUnknown() {
        return Constants.CATEGORY_UNKNOWN.equalsIgnoreCase(this.category);
    }
    @JsonIgnore
    public boolean isSite() {
        return ListUtil.hasList(List.of(Constants.CATEGORY_GROUP_PRACTICE, Constants.CATEGORY_ANCILLARY, Constants.CATEGORY_FACILITY), s -> s.equalsIgnoreCase(this.category));
    }
    @JsonIgnore
    public boolean hasValidCategory() {
        return this.isPractitioner() || this.isCheckOrg() || this.isSite() || this.isUnknown();
    }

    public void cleanWhiteSpaces() {
        this.setLastName(Objects.nonNull(this.lastName) ? this.lastName.trim() : null);
        if(CollectionUtils.isEmpty(this.addressList))
            return;
        this.addressList.stream().forEach(Address::cleanWhiteSpaces);
    }
    public void populateDefaults() {
        if(! StringUtils.hasText(this.inactiveFlag))
            this.inactiveFlag= Constants.NO;
        this.setTransactionId(this.identifier);
    }
    @JsonIgnore
    public boolean isMd5Ready() { //X
        if(! StringUtils.hasText(this.lastName) || this.isPractitioner())
            return false;
        if(! this.hasPrimarySpecialty())
            return false;
        if(! this.hasAddressCodeOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2))
            return false;
        return true;
    }
    public void buildSiteFields() {
        if(this.isPractitioner())
            return;
        Optional<Specialty> primarySpecialty = this.getActivePrimarySpecialty();
        this.setSitePrimarySpecialty(Objects.nonNull(primarySpecialty) && ! primarySpecialty.isEmpty() ? primarySpecialty.get().getSpecialtyCode() : null);
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
}
