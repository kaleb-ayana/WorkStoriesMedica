package com.healthplan.ods.provider.transformation.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

@RestController
@Slf4j
public class Controller {

    @Value("${schema-version}")
    private String schemaVersion;

    @Value("${process-flag}")
    private Boolean processFlag;

    @Value("${process-demographic-only}")
    private Boolean processDemographicOnly;

    @GetMapping("/show-operating-mode")
    public String getSpecialtyCodeset() throws JsonProcessingException {
        return "Schema Version : " + this.schemaVersion +" <<<|>>> \nRecords being processed : " + (Objects.isNull(this.processFlag)? "?" : this.processFlag) +
                "\n <<<|>>> Nullifying Panel, Affiliation, and Network : "+ (Objects.isNull(this.processDemographicOnly)? "?" : this.processDemographicOnly);
    }
}