package com.healthplan.ods.provider.transformation.service.utils;

import com.deancare.fsa.provider.PROVIDER_CATEGORY_CD;
import com.deancare.fsa.provider.PROVIDER_ID_TYPE;
import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.Address;
import com.healthplan.ods.provider.transformation.model.merge.AlternateId;
import com.healthplan.ods.provider.transformation.model.merge.Phone;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.model.misc.Tax;
import com.healthplan.ods.provider.transformation.model.misc.XRefDto;
import com.healthplan.ods.provider.transformation.service.messagers.RestTemplateWrapperService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.SerializationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProviderUtil {

    @Autowired
    private RestTemplateWrapperService restTemplateWrapperService;

    public void buildLocations(ProviderDto provider)  throws ProviderProcessorException{
        if(Objects.isNull(provider))
            return;
        provider.buildSiteFields();
        if(! provider.isMd5Ready())
            return;
        List<Address> addressList= provider.getAddressesOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2);
        if(CollectionUtils.isEmpty(addressList))
            return;
        XRefDto edsSpecialty = null;
        int retry=0;
        while (Objects.isNull(edsSpecialty) && retry++ < 3)
            edsSpecialty =this.restTemplateWrapperService.getEDSSpecialty(provider.getSitePrimarySpecialty());
        provider.setSitePrimaryCrosswalkSpecialty(Objects.nonNull(edsSpecialty) ? edsSpecialty.getDestinationValue1() : null);
        if(! StringUtils.hasText(provider.getSitePrimaryCrosswalkSpecialty()))
            throw new ProviderProcessorException("Specialty crosswalk not found during lookup for provider : " + provider.getIdentifier());
        provider.removeAddressOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2);
        List<String> taxIds= this.getTaxIds(provider);
        List<Tax> taxIdObjects= this.getTaxIdsObjects(provider);
        List<Address> permutedAddresses= new ArrayList<>();
        for(Address add: addressList)
            permutedAddresses.addAll(permuteA2Address(add));
        permutedAddresses= createDistinctA2s(permutedAddresses);
        // Remove or merge duplicates
        List<Address> resultingAddresses= new ArrayList<>();
        for(Address address: permutedAddresses) {
            if(CollectionUtils.isEmpty(taxIdObjects)) {
                Address address1= SerializationUtils.clone(address);
                this.computeMd5Hash(address1, provider.getLastName(), provider.getSitePrimaryCrosswalkSpecialty(), null);
                address1.setLogicalDeleteFlag(address1.getLogicalDeleteFlag());
                resultingAddresses.add(address1);
                continue;
            }
            for(Tax taxId: taxIdObjects) {
                Address address1= SerializationUtils.clone(address);
                this.computeMd5Hash(address1, provider.getLastName(), provider.getSitePrimaryCrosswalkSpecialty(), taxId.getTaxId());
                address1.setLogicalDeleteFlag(address1.getLogicalDeleteFlag() || taxId.isLogicalDeleteFlag());
                resultingAddresses.add(address1);
            }
        }
        provider.getAddressList().addAll(resultingAddresses);
    }

    private List<Address> createDistinctA2s(List<Address> addresses) {
        if(CollectionUtils.isEmpty(addresses))
            return addresses;
        List<Address> resultAddresses= new ArrayList<>();
        for(Address address: addresses) {
            Address address1= getMatchingAddress(resultAddresses, address);
            if(Objects.isNull(address1)) {
                resultAddresses.add(address);
                continue;
            }
            address1.mergeAddress(address);
            resultAddresses.add(address1);
        }
        return resultAddresses;
    }
    private Address getMatchingAddress(List<Address> addresses, Address address) {
        if(CollectionUtils.isEmpty(addresses) || Objects.isNull(address))
            return null;
        for(Address address1: addresses)
            if(address1.equals(address))
                return address1;
        return null;
    }

    public List<ProviderDto> permuteProvider(ProviderDto origProvider) throws ProviderProcessorException {
        if(Objects.isNull(origProvider))
            return null;
        List<ProviderDto> resultProviderList= new ArrayList<>();
        origProvider.buildSiteFields();
        ProviderDto provider= SerializationUtils.clone(origProvider);
        if(! origProvider.isMd5Ready()) {
            resultProviderList.add(provider);
            return resultProviderList;
        }
        List<Address> addressList= origProvider.getAddressesOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2);
        if(CollectionUtils.isEmpty(addressList) ){
            resultProviderList.add(provider);
            return resultProviderList;
        }
        XRefDto edsSpecialty = null;
        int retry=0;
        while (Objects.isNull(edsSpecialty) && retry++ < 3)
            edsSpecialty =this.restTemplateWrapperService.getEDSSpecialty(provider.getSitePrimarySpecialty());

        provider.setSitePrimaryCrosswalkSpecialty(Objects.nonNull(edsSpecialty) ? edsSpecialty.getDestinationValue1() : null);
        if(! StringUtils.hasText(provider.getSitePrimaryCrosswalkSpecialty()))
            throw new ProviderProcessorException("Specialty crosswalk not found during lookup for provider : " + provider.getIdentifier());

        List<ProviderDto> permutedProviderList= new ArrayList<>();

        provider.removeAddressOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2);
        ProviderDto parentProvider= SerializationUtils.clone(provider);
        permutedProviderList.add(parentProvider);
        List<String> taxIds= this.getTaxIds(origProvider);
        for(Address address: addressList) {
            ProviderDto tempProvider= SerializationUtils.clone(provider);
            List<Address> tmpAddressList= permuteA2Address(address);
            if(! CollectionUtils.isEmpty(tmpAddressList)) {
                tmpAddressList.stream().forEach(addr -> {
                            if(Objects.isNull(taxIds) || taxIds.isEmpty())
                                makeLocation(provider, permutedProviderList, parentProvider, tempProvider, addr, null);
                            else
                                for(String taxId: taxIds)
                                    makeLocation(provider, permutedProviderList, parentProvider, tempProvider, addr, taxId);
                        }
                );
            }
        }
        if(! sitesHavePrimarySpecialty(permutedProviderList))
            throw new ProviderProcessorException("Site Primary Specialty not found for one or more created site instances for base provider : " + provider.getIdentifier());
        return permutedProviderList;
    }

    private void makeLocation(ProviderDto provider, List<ProviderDto> permutedProviderList, ProviderDto parentProvider, ProviderDto tempProvider, Address addr, String taxId) {
        ProviderDto tempProvider1= SerializationUtils.clone(tempProvider);
        this.computeMd5Hash(addr, provider.getLastName(), provider.getSitePrimaryCrosswalkSpecialty(), taxId);
        tempProvider1.addAddress(addr);
        tempProvider1.setProviderIdType(PROVIDER_ID_TYPE.MD5);
        tempProvider1.setProviderCategoryCd(PROVIDER_CATEGORY_CD.SITE);
        this.addressDecorateProvider(tempProvider1, addr);
        permutedProviderList.add(tempProvider1);
        parentProvider.addAddress(SerializationUtils.clone(addr));
    }

    private List<String> getTaxIds(ProviderDto providerDto) {
        if(Objects.isNull(providerDto) || CollectionUtils.isEmpty(providerDto.getAlternateIds()))
            return null;
        return providerDto.getAlternateIds()
                .stream()
                .filter(alt-> alt.hasType(Constants.ID_TYPE_TAX)/* && (! alt.isVoided())*/)
                .map(AlternateId::getIdentifier)
                .collect(Collectors.toList());
    }
    private List<Tax> getTaxIdsObjects(ProviderDto providerDto) {
        if(Objects.isNull(providerDto) || CollectionUtils.isEmpty(providerDto.getAlternateIds()))
            return null;
        List<Tax> resultList= providerDto.getAlternateIds()
                .stream()
                .filter(alt-> alt.hasType(Constants.ID_TYPE_TAX)/* && (! alt.isVoided())*/)
                .map(Tax::new)
                .collect(Collectors.toList());
        if(CollectionUtils.isEmpty(resultList) || resultList.size() < 2)
            return resultList;
        List<Tax> distinctList= new ArrayList<>();
        for(Tax tax: resultList) {
            if(CollectionUtils.isEmpty(distinctList)) {
                distinctList.add(tax);
                continue;
            }
            Tax matchingTax= null;
            for(Tax tx: distinctList) {
                if(tx.matches(tax)){
                    matchingTax= tx;
                    break;
                }
            }
            if(Objects.isNull(matchingTax))
                distinctList.add(tax);
            else
                distinctList.add(Tax.merge(tax, matchingTax));
        }
        distinctList= distinctList.stream().filter(Objects::nonNull).collect(Collectors.toList());
        return distinctList;
    }
    private boolean sitesHavePrimarySpecialty( List<ProviderDto> providerList) {
        boolean flag= true;
        for(ProviderDto provider: providerList)
            flag= flag && provider.hasPrimarySpecialty();
        return flag;
    }
    public List<Address> permuteA2Address(Address origAddress) {
        if(Objects.isNull(origAddress) || ! origAddress.isSitePracticeLocation())
            return null;
        List<Address> resultAddressList= new ArrayList<>();
        List<Phone> phoneList= origAddress.getPhonesOfWhoType("AD");

        if(CollectionUtils.isEmpty(phoneList) || phoneList.size() <= 1) {
            resultAddressList.add(SerializationUtils.clone(origAddress));
            return resultAddressList;
        }

        Address address= SerializationUtils.clone(origAddress);
        address.removePhonesOfWhoType("AD");
        List<Address> addressList= new ArrayList<>();
        for(Phone phone: phoneList) {
            Address newAddress= SerializationUtils.clone(address);
            newAddress.addPhone(SerializationUtils.clone(phone));
            addressList.add(newAddress);
        }
        return addressList;
    }
    private void addressDecorateProvider(ProviderDto provider, Address address) {
        provider.setSiteAddressLine1(address.getAddress1());
        provider.setSiteAddressLine2(address.getAddress2());
        provider.setSiteAddressLine3(address.getAddress3());
        provider.setSiteCity(address.getCity());
        provider.setSiteStateCd(address.getStateCode());
        provider.setSiteZip(address.getZip());
        provider.setIdentifier(address.getMd5Hash());
        provider.setEffectiveDate(address.getEffectiveDate());
        provider.setEndDate(address.getEndDate());
        provider.setLogicalDeleteFlag(address.getLogicalDeleteFlag());
        provider.setHandicappedFlag(address.getHandicappedAcctCd());
        Phone phone= address.getSitePhone();
        if(Objects.nonNull(phone))
            provider.setSitePhone(phone.getPhoneNumber());
        provider.setLogicalDeleteFlag( provider.getLogicalDeleteFlag() ||
                address.getLogicalDeleteFlag() ||
                (address.hasSitePhone() ? address.getSitePhone().getLogicalDeleteFlag() : false));

    }
    private void computeMd5Hash(Address address, String name, String primarySpecialty, String taxId) {
        String combinedString= Objects.nonNull(name) ? name.trim() : null ;
        combinedString += address.getAddress1();
        combinedString += address.getAddress2();
        combinedString += address.getAddress3();
        combinedString += address.getCity();
        combinedString += address.getStateCode();
        combinedString += address.getZip();
        combinedString += (address.hasSitePhone() ? address.getSitePhone().getPhoneNumber() : null) ;
        combinedString += primarySpecialty;
        combinedString += Objects.nonNull(taxId) ? taxId.trim() : null;
        address.setMd5Hash(DigestUtils.md5DigestAsHex(combinedString.getBytes()).toUpperCase());
    }


    private List<String> getCountyCodeList(ProviderDto provider) {
        return ListUtil.filterFieldValues(provider.getAddressList(), Address::getCountyCode,true);
    }
    public void crosswalkCountyCode(ProviderDto provider){
        if(Objects.isNull(provider))
            return;
        List<String> countyCodes= this.getCountyCodeList(provider);
        if(CollectionUtils.isEmpty(countyCodes) )
            return;

        Map<String, String> countyMap= this.restTemplateWrapperService.getCountyDescription(this.getCountyCodeList(provider));
        provider.getAddressList().stream().forEach(address -> address.setCountyCrossWalk(countyMap.get(address.getCountyCode())));
    }
}
