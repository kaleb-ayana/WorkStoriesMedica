
package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import lombok.*;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Education  implements Serializable {
    private static final long serialVersionUID = -433644264162575648L;
    @MandatoryDate(message = "Education.Effective Date field should have a non-blank and valid value")
    @JsonProperty("EFF_DT")
    private LocalDate EFF_DT;
    @JsonProperty("INSTITUTION_NAME")
    private String INSTITUTION_NAME;
    @JsonProperty("END_DT")
    private LocalDateTime END_DT;
    @JsonProperty("INSTITUTION_ADDRESS")
    private String INSTITUTION_ADDRESS;
    @JsonProperty("INSTITUTION_CITY")
    private String INSTITUTION_CITY;
    @JsonProperty("INSTITUTION_STATE")
    private String INSTITUTION_STATE;
    @JsonProperty("INSTITUTION_ZIP")
    private String INSTITUTION_ZIP;
    @JsonProperty("INSTITUTION_CNTRY")
    private String INSTITUTION_CNTRY;
    @JsonProperty("DEGREE_PROGRAM")
    private String DEGREE_PROGRAM;
    @JsonProperty("GRADUATE_FLG")
    private Boolean GRADUATE_FLG;
    @JsonProperty("LOGICAL_DELETE_FLG")
    private Boolean LOGICAL_DELETE_FLG;
    @JsonProperty("SOURCE_SYSTEM_CD")
    private String SOURCE_SYSTEM_CD;
    @JsonProperty("SOURCE_SYSTEM_INSERT_DTTM")
    private LocalDateTime SOURCE_SYSTEM_INSERT_DTTM;
    @JsonProperty("SOURCE_SYSTEM_UPDATE_DTTM")
    private LocalDateTime SOURCE_SYSTEM_UPDATE_DTTM;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Education education = (Education) o;
        return Objects.equals(EFF_DT, education.EFF_DT) &&
                Objects.equals(INSTITUTION_NAME, education.INSTITUTION_NAME) &&
                Objects.equals(END_DT, education.END_DT) &&
                Objects.equals(INSTITUTION_ADDRESS, education.INSTITUTION_ADDRESS) &&
                Objects.equals(INSTITUTION_CITY, education.INSTITUTION_CITY) &&
                Objects.equals(INSTITUTION_STATE, education.INSTITUTION_STATE) &&
                Objects.equals(INSTITUTION_ZIP, education.INSTITUTION_ZIP) &&
                Objects.equals(INSTITUTION_CNTRY, education.INSTITUTION_CNTRY) &&
                Objects.equals(DEGREE_PROGRAM, education.DEGREE_PROGRAM) &&
                Objects.equals(GRADUATE_FLG, education.GRADUATE_FLG);
    }

    @Override
    public int hashCode() {
        return Objects.hash(EFF_DT, INSTITUTION_NAME, END_DT, INSTITUTION_ADDRESS, INSTITUTION_CITY, INSTITUTION_STATE, INSTITUTION_ZIP, INSTITUTION_CNTRY, DEGREE_PROGRAM, GRADUATE_FLG);
    }
}
