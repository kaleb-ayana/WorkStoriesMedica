package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.StringInListOrBlank;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Phone  implements Serializable {
    private static final long serialVersionUID = -1181891223881321331L;
    @JsonProperty("IDENTIFIER")
    private String identifier;

    @JsonProperty("WHO_TYPE_INDICATOR")
    private String whoTypeIndicator;

    @JsonProperty("WHO_IDENTIFIER")
    private String whoIdentifier;

    @JsonProperty("PHONE_TYPE")
    private String phoneType;

    @NotBlank(message = "Phone.Phone Type code field should have a non-blank value")
    @JsonProperty("PHONE_CODE")
    private String phoneCode;

    @NotBlank(message = "Phone.Phone number field should have a non-blank value")
    @JsonProperty("PHONE_NUMBER")
    private String phoneNumber;

    @JsonProperty("COUNTRY_ID")
    private String countryId;

    @StringInListOrBlank(acceptedValues = {"Y", "N", "y", "n"}, message = "Phone.primary_flag value is not among the allowed list of values.")
    @JsonProperty("PRIMARY_FLAG")
    private String primaryFlag;

    @JsonProperty("PAGER_PIN_ID")
    private String pagerPinId;

    @JsonProperty("EXTENSION")
    private String extension;

    @JsonProperty("EFFECTIVE_DATE")
    private String effectiveDate;

    @JsonProperty("END_DATE")
    private String endDate;

    @JsonProperty("RECON_DATE")
    private String reconDate;

    @JsonProperty("AUDIT_FLAG")
    private String auditFlag;

    @JsonProperty("VERSION_NUMBER")
    private Integer versionNumber;

    @JsonProperty("OPERATOR_ID")
    private String operatorId;

    @JsonProperty("LAST_MAINT_TS")
    private String lastMaintTs;

    @JsonProperty("CREATION_TS")
    private String creationTs;

    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        this.logicalDeleteFlag= TransformationUtil.convertStringToBoolean(this.auditFlag);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Phone phone = (Phone) o;
        return Objects.equals(phoneNumber, phone.phoneNumber) &&
                Objects.equals(this.whoTypeIndicator, phone.whoTypeIndicator);
    }

    @Override
    public int hashCode() {
        return Objects.hash(phoneNumber);
    }

    public void cleanWhiteSpaces() {
        this.phoneNumber= Objects.nonNull(this.phoneNumber) ? this.phoneNumber.trim() : null;
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }

    @JsonIgnore
    public boolean isFlaggedForAudit(){
        return  "Y".equalsIgnoreCase(auditFlag);
    }

}