package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.io.Serializable;

import static com.healthplan.ods.provider.transformation.service.utils.TransformationUtil.convertStringToBoolean;
@Slf4j
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ElectronicAddress  implements Serializable {
    private static final long serialVersionUID = -7275892391560179248L;
    @JsonProperty("IDENTIFIER")
    public String identifier;
    @JsonProperty("WHO_TYPE_IND")
    public String whoTypeInd;
    @JsonProperty("WHO_IDENTIFIER")
    public String whoIdentifier;
    @JsonProperty("ELECTRONIC_ADDR_CD")
    public String electronicAddrCd;
    @JsonProperty("ELECT_ADDRESS")
    public String electAddress;
    @JsonProperty("EFFECTIVE_DATE")
    public String effectiveDate;
    @JsonProperty("END_DATE")
    public String endDate;
    @JsonProperty("PRIMARY_FLAG")
    public String primaryFlag;
    @JsonProperty("VOID_FLAG")
    public String voidFlag;
    @JsonProperty("RECON_DATE")
    public String reconDate;
    @JsonProperty("AUDIT_FLAG")
    public String auditFlag;
    @JsonProperty("VERSION_NUMBER")
    public String versionNumber;
    @JsonProperty("OPERATOR_ID")
    public String operatorId;
    @JsonProperty("LAST_MAINT_TS")
    public String lastMaintTs;
    @JsonProperty("CREATION_TS")
    public String creationTs;
    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }

    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        logicalDeleteFlag= convertStringToBoolean(this.voidFlag);
    }
    @JsonIgnore
    public static ElectronicAddress createElectronicAddress(Address address) {
        return ElectronicAddress.builder()
                .electronicAddrCd(Constants.ELECTRONIC_ADDRESS_PRIMARY)
                .electAddress(address.getElectAddress())
                .identifier(address.getElectAddress())
                .voidFlag(address.getVoidFlag())
                .effectiveDate(address.getEffectiveDate())
                .endDate(address.endDate)
                .primaryFlag("N")
                .auditFlag(address.getAuditFlag())
                .creationTs(address.getCreationTs())
                .lastMaintTs(address.getLastMaintTs())
                .build();
    }

    public void updateVoidFlag(String voidFlag) {
        if(!StringUtils.hasText(voidFlag))
            return;
        if(Constants.NO.equalsIgnoreCase(voidFlag.trim()))
            this.setVoidFlag(voidFlag.trim());
    }

    @JsonIgnore
    public boolean isVoided() {
        return true == this.logicalDeleteFlag;
    }

    @JsonIgnore
    public boolean isFlaggedForAudit(){
        return  "Y".equalsIgnoreCase(auditFlag);
    }

}
