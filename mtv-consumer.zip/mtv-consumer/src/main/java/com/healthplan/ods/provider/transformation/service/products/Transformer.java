package com.healthplan.ods.provider.transformation.service.products;

import com.deancare.fsa.provider.PROVIDER_CATEGORY_CD;
import com.deancare.fsa.provider.PROVIDER_ID_TYPE;
import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.Address;
import com.healthplan.ods.provider.transformation.model.merge.ElectronicAddress;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.service.utils.ListUtil;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

import static com.healthplan.ods.provider.transformation.service.utils.TransformationUtil.getLowerCasedTrimmedString;

@Setter
@Getter
@Slf4j
public class Transformer implements Serializable {
    private static final long serialVersionUID = -511963704150661194L;


    public void transform(ProviderDto provider) throws ProviderProcessorException {
        if(provider == null)
            throw new ProviderProcessorException("Provider is NULL. Failed to Transform.");
        cleanUp(provider);
        computeTyping(provider);
        buildElectronicAddresses(provider);
        removeAudit(provider);
        buildLogicalDeleteFlag(provider);
        buildSiteFields(provider);
        computePatientAcceptance(provider);
    }

    public void buildElectronicAddresses(ProviderDto provider) {
        provider.setElectronicAddressList(new ArrayList<>());
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getAddressesOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2)))
            return;
        provider
            .getAddressesOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2)
            .stream()
            .filter(Address::hasElectronicAddress)
            .map(ElectronicAddress::createElectronicAddress)
            .forEach(electronicAddress -> provider.addElectronicAddress(electronicAddress));
    }

    private void removeAudit(ProviderDto provider){
        if(!CollectionUtils.isEmpty(provider.getAddressList())){
            provider.setAddressList(provider.getAddressList().stream().filter(address -> ! address.isFlaggedForAudit()).collect(Collectors.toList()));
            provider.getAddressList().forEach(address -> {
                if(!CollectionUtils.isEmpty(address.getPhoneList()))
                    address.setPhoneList(address.getPhoneList().stream().filter(phone -> ! phone.isFlaggedForAudit()).collect(Collectors.toList()));
            });
        }
        if (!CollectionUtils.isEmpty(provider.getElectronicAddressList())){
            provider.setElectronicAddressList(provider.getElectronicAddressList().stream().filter(electronicAddress ->  !electronicAddress.isFlaggedForAudit()).collect(Collectors.toList()));
        }
        if(!CollectionUtils.isEmpty(provider.getNetworks())){
            provider.setNetworks(provider.getNetworks().stream().filter(network -> !network.isFlaggedForAudit()).collect(Collectors.toList()));
        }
    }

    private void removeVoided(ProviderDto provider) {
        if(!CollectionUtils.isEmpty(provider.getAlternateIds()))
            provider.setAlternateIds(provider.getAlternateIds().stream().filter(itm -> ! itm.isVoided()).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(provider.getSpecialtyList()))
            provider.setSpecialtyList(provider.getSpecialtyList().stream().filter(itm -> ! itm.isVoided()).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(provider.getLanguageList()))
            provider.setLanguageList(provider.getLanguageList().stream().filter(itm -> ! itm.isVoided()).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(provider.getAddressList()))
            provider.setAddressList(provider.getAddressList().stream().filter(itm -> !itm.isVoided()).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(provider.getAddressList())) {
            provider.getAddressList().stream().forEach(address -> {
                if(! CollectionUtils.isEmpty(address.getPhoneList()))
                    address.setPhoneList(address.getPhoneList().stream().filter(phone -> ! phone.isVoided()).collect(Collectors.toList()));
            });
            provider.setAddressList(provider.getAddressList().stream().filter(itm -> !itm.isVoided()).collect(Collectors.toList()));
        }
        if(!CollectionUtils.isEmpty(provider.getCertificationList()))
            provider.setCertificationList(provider.getCertificationList().stream().filter(itm -> !itm.isVoided()).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(provider.getPanels()))
            provider.setPanels(provider.getPanels().stream().filter(itm -> !itm.isVoided()).collect(Collectors.toList()));
        if(!CollectionUtils.isEmpty(provider.getElectronicAddressList()))
            provider.setElectronicAddressList(provider.getElectronicAddressList().stream().filter(itm -> !itm.isVoided()).collect(Collectors.toList()));
    }

    public void buildSiteFields(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        provider.buildSiteFields();
    }

    public void postTransform(ProviderDto provider) throws ProviderProcessorException {
        buildSiteLocationIds(provider);
        if(CollectionUtils.isEmpty(provider.getPanels()))
            return;
        boolean flag= ListUtil.hasList(provider.getPanels(), panel -> ! StringUtils.hasText(panel.getMd5hash()));
        if( flag )
            throw new ProviderProcessorException("One or more Panel records have no matching associated MD5Hash location id.");
    }
    public void naturalizePanelLocIds(ProviderDto provider) {
        if(Objects.isNull(provider) ||
                CollectionUtils.isEmpty(provider.getPanels()) ||
                CollectionUtils.isEmpty(provider.getAddressList()))
            return;
        final Map<String, String> locIdToMd5Map= this.getLocIdToMd5Map(provider);
        if(CollectionUtils.isEmpty(locIdToMd5Map))
            return;
        provider.getPanels().forEach(panel -> panel.setMd5Hash(locIdToMd5Map.get(panel.getPracticeLocId())));
    }
    public Map<String, String> getLocIdToMd5Map(ProviderDto providerDto) {
        if(CollectionUtils.isEmpty(providerDto.getAddressList()))
            return new HashMap<>();
        return providerDto.getAddressList()
                .stream()
                .filter(address -> StringUtils.hasText(address.getLocationId()) && StringUtils.hasText(address.getMd5Hash()))
                .collect( Collectors.toMap(Address::getLocationId, Address::getMd5Hash) );
    }

    public void computeTyping(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        populateTypeClassificationFields(provider);
        buildAlternateIds(provider);
        buildMtvProviderTypeCode(provider);
    }

    public void cleanEffectiveDates(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        if(StringUtils.hasText(provider.getEffectiveDate()) && provider.getEffectiveDate().length() > 4 && provider.getEffectiveDate().startsWith("0001") )
            provider.setEffectiveDate(Constants.DATE_1800 +provider.getEffectiveDate().substring(4));
        if(CollectionUtils.isEmpty(provider.getAlternateIds()))
            return;
        provider
                .getAlternateIds()
                .stream()
                .filter(alternateId -> StringUtils.hasText(alternateId.getEffectiveDate()) && alternateId.getEffectiveDate().length() > 4 && alternateId.getEffectiveDate().startsWith("0001"))
                .forEach(alternateId -> alternateId.setEffectiveDate(Constants.DATE_1800 +alternateId.getEffectiveDate().substring(4)) );
    }

    public void buildSiteLocationIds(ProviderDto provider) throws ProviderProcessorException{
        if(Objects.isNull(provider) || (! provider.isMd5Ready()))
            return;
        List<Address> addressList= provider.getAddressesOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2);
        if(CollectionUtils.isEmpty(addressList))
            return;
        if(! StringUtils.hasText(provider.getSitePrimaryCrosswalkSpecialty()))
            throw new ProviderProcessorException("Specialty Crosswalk value is missing for provider : "+ provider.getIdentifier());

        addressList
                .stream()
                .forEach(address -> address.setMd5Hash(computeMd5Hash(address, provider.getLastName(), provider.getSitePrimaryCrosswalkSpecialty())));
    }

    public void buildMtvProviderTypeCode(ProviderDto provider) {
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getAlternateIds()))
            return;
        provider.getAlternateIds().stream().forEach(alternateId -> {
            alternateId.setMtvProviderTypeCode(provider.getProvType());
            alternateId.setMtvProviderTypeCode(provider.getProvType());
            if(StringUtils.hasText(alternateId.getIdTypeCode())) {
                switch(alternateId.getIdTypeCode().trim().toUpperCase()) {
                    case Constants.ID_TYPE_NPI1:
                        alternateId.setMtvProviderCategoryCode(Constants.CATEGORY_PROFESSIONAL);
                        break;
                    case Constants.ID_TYPE_TAX:
                        alternateId.setMtvProviderCategoryCode(Constants.CATEGORY_CHECK_ORG);
                        break;
                    default:
                        alternateId.setMtvProviderCategoryCode(provider.getCategory());

                }
            }
        });
    }

    public void  checkProviderAffiliation(ProviderDto provider){
        if(Objects.nonNull(provider) && (Objects.nonNull(provider.getAffiliations())) && (!provider.getAffiliations().isEmpty())){
            provider.setAffiliations(provider.getAffiliations().stream().filter(aff -> "N".equalsIgnoreCase(provider.getInactiveFlag())).
                    collect(Collectors.toList()));
        }
    }

    public void nullifyEndDateForAff(ProviderDto provider) {
        if(Objects.nonNull(provider) && Objects.nonNull(provider.getAffiliations()) && (!provider.getAffiliations().isEmpty()))
            provider.getAffiliations().stream().forEach(aff -> {
                if(Objects.nonNull(aff.getEndDate()) && aff.getEndDate().equals("9999-12-31 00:00:00")){
                    aff.setEndDate(null);
                }
            });
    }

    public void computePatientAcceptance(ProviderDto provider) {
        if(Objects.isNull(provider) || CollectionUtils.isEmpty(provider.getPanels()))
            return;
        provider.getPanels()
                .stream()
                .forEach(panel -> {
                    panel.setAcceptingNewPatientFlag(Constants.PATIENT_ACCEPTANCE_CD_YN.equalsIgnoreCase(panel.getPatAcceptanceCd()) );
                }
        );
    }

    private String computeMd5Hash(Address address, String name, String primarySpecialty) {
        String combinedString= Objects.nonNull(name) ? name.trim() : null ;
        combinedString += address.getAddress1();
        combinedString += address.getAddress2();
        combinedString += address.getAddress3();
        combinedString += address.getCity();
        combinedString += address.getStateCode();
        combinedString += address.getZip();
        combinedString += (address.hasSitePhone() ? address.getSitePhone().getPhoneNumber() : null) ;
        combinedString += primarySpecialty;
        return DigestUtils.md5DigestAsHex(combinedString.getBytes()).toUpperCase();
    }

    public void buildAlternateIds(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        provider.createMtvAlternativeId();
    }

    public void cleanUp(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        provider.populateDefaults();
        provider.computeGenderIndicator();
        provider.removeLegacyAlternativeId();
        provider.cleanWhiteSpaces();
        cleanEffectiveDates(provider);
        defaultNullEndDates(provider);
        nullifyEndDateForAff(provider);
        cleanElectronicAddress(provider);
    }

    private void cleanElectronicAddress(ProviderDto provider) {

        List<Address> a2Addresses= provider.getAddressesOfType("A2");
        if(CollectionUtils.isEmpty(a2Addresses))
            return;
        a2Addresses
                .stream()
                .filter(Address::hasElectronicAddress)
                .forEach(address -> address.setElectAddress(getLowerCasedTrimmedString(address.getElectAddress())));
    }

    public void defaultNullEndDates(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        if(! CollectionUtils.isEmpty(provider.getAlternateIds()))
            provider.getAlternateIds().stream().filter(alternateId -> ! StringUtils.hasText(alternateId.getEndDate())).forEach(alternateId -> alternateId.setEndDate(Constants.DEFAULT_END_DATE));
        if(! CollectionUtils.isEmpty(provider.getCertificationList()))
            provider.getCertificationList().stream().filter(certification -> ! StringUtils.hasText(certification.getEndDate())).forEach(alternateId -> alternateId.setEndDate(Constants.DEFAULT_END_DATE));
        if(! CollectionUtils.isEmpty(provider.getPanels()))
            provider.getPanels().stream().filter(panel -> ! StringUtils.hasText(panel.getEndDate())).forEach(panel -> panel.setEndDate(Constants.DEFAULT_END_DATE));

    }

    public void populateTypeClassificationFields(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        if(provider.hasAlternateIdOfType(Constants.ID_TYPE_TAX)) {
            provider.setProviderIdType(PROVIDER_ID_TYPE.TAX);
            provider.setProviderCategoryCd(PROVIDER_CATEGORY_CD.PAYTO);
        } else if( provider.hasAlternateIdOfType(Constants.ID_TYPE_NPI1 )) {
            provider.setProviderIdType(PROVIDER_ID_TYPE.NPI1);
            provider.setProviderCategoryCd(PROVIDER_CATEGORY_CD.PRACT);
        } else {
            provider.setProviderIdType(PROVIDER_ID_TYPE.MD5);
            provider.setProviderCategoryCd(PROVIDER_CATEGORY_CD.SITE);
        }
    }

    public void buildLogicalDeleteFlag(ProviderDto provider) {
        if(Objects.isNull(provider) )
            return;
        provider.buildLogicalDeleteFlag();
    }
}
