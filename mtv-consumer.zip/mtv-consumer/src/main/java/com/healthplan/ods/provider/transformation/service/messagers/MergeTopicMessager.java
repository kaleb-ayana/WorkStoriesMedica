package com.healthplan.ods.provider.transformation.service.messagers;

import com.deancare.fsa.provider.Provider;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthplan.ods.provider.transformation.exception.ProviderConversionException;
import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.exception.ProviderValidationException;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.service.utils.ProviderUtil;
import com.medica.reference.service.NetworkStatusReferenceService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

@Service
@Slf4j
public class MergeTopicMessager  {
    @Value("${schema-version}")
    private String schemaVersion;
    @Value("${process-flag}")
    private Boolean processFlag;

    @Value("${process-demographic-only}")
    private Boolean processDemographicOnly;
    @Autowired
    private ProviderUtil providerUtil;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    KafkaTemplateWrapperService kafkaTemplateWrapperService;

    @Autowired
    private NetworkStatusReferenceService networkStatusReferenceService;

    @KafkaListener(topics = {"#{@kafkaConfig.getPrimaryTopic()}"}, containerFactory = "primaryFactory")
    public void consumeMessage(ConsumerRecord<String, String> messageIn, @Headers MessageHeaders messageHeaders) throws Exception {
        this.processMessage(messageIn, messageHeaders);
        log.info(messageHeaders + "Kafka Message Processing Complete.");
    }

    @KafkaListener(topics = {"#{@kafkaConfig.getEnvSpecificRetryTopicName()}"}, containerFactory = "retryFactory")
    public void consumeRetryMessage(ConsumerRecord<String, String> messageIn, @Headers MessageHeaders messageHeaders) throws Exception {
        this.processMessage(messageIn, messageHeaders);
        log.info(messageHeaders + "Kafka Message Processing Complete in Retry.");
    }

    public void processMessage(ConsumerRecord<String, String> messageIn, MessageHeaders messageHeaders) throws Exception {
        if(Boolean.FALSE.equals(this.processFlag)) {
            log.info("Key : " + messageIn.key() + " Skipped. ");
            return;
        }

        if(! StringUtils.hasText(messageIn.value()) || Objects.isNull(messageHeaders) || messageHeaders.isEmpty()) {
            log.warn("Merge topic message payload or header is empty.");
            return;
        }

        ProviderDto providerDto = parseMessage(messageIn.value());
        if(Objects.isNull(providerDto)) {
            log.warn("Error encountered parsing provider merge topic. Message content ... [[ " + messageIn.value() + " ]]" );
            return;
        }
        if(Boolean.TRUE.equals(processDemographicOnly))
            removeNonDemographic(providerDto);

        if(! providerDto.isWellFormed()) {
            log.warn("Provider is not well formed. Provider ID : " + providerDto.getIdentifier()+"\n"+"-".repeat(50) + " [" + this.objectMapper.writeValueAsString(providerDto) + "]" );
            return;
        }
        try{
            providerDto.transform();
            if(providerDto.isVoided()) { // TODO: Remove during realtime operation mode
                log.warn("< " + messageIn.key() + " , " + providerDto.getIdentifier() + " > is Voided ==> " + providerDto );
                return;
            }
            providerDto.validate();
            providerUtil.buildLocations(providerDto);
            providerUtil.crosswalkCountyCode(providerDto);
            final Provider providerTmp= providerDto.convert(networkStatusReferenceService);
            kafkaTemplateWrapperService.produceConsumerTopicMessage(providerTmp)
                    .addCallback(
                            result -> log.info("Consumer topic produced for provider : [" + providerTmp.getPayload().getPROVIDERID() + "]" + providerTmp.toString()),
                            x -> kafkaTemplateWrapperService.produceConsumerTopicDltMessage(providerTmp)
                    );
        } catch( ProviderConversionException e) {
            logErroredPayload(providerDto, "ProviderConversionException error raised for provider : [ " + providerDto.getIdentifier() + "]. Error detail ... "  + e.getMessage());
            //throw e;
        } catch(ProviderValidationException | ProviderProcessorException e) {
            logErroredPayload(providerDto, "Validation | ProviderProcessorException error encountered for provider : [ " + providerDto.getIdentifier() + " ]. " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            logErroredPayload(providerDto, "Exception encountered. " + e.getMessage() + "... Provider : " + providerDto.getIdentifier());
            throw e;
        }

    }

    private void removeNonDemographic(ProviderDto provider) {
        if(Objects.isNull(provider))
            return;
        log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        provider.setNetworks(new ArrayList<>());
        provider.setPanels(new ArrayList<>());
        provider.setAffiliations(new ArrayList<>());
    }
    private void logErroredPayload(ProviderDto provider, String warningMessage) {
        try {
            log.warn(warningMessage);
            log.warn("-".repeat(25) + " [" + this.objectMapper.writeValueAsString(provider) + "]");
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
    private ProviderDto parseMessage(String message) {
        try{
            ProviderDto providerDto=  objectMapper.readValue(this.sanitizeMessage(message), ProviderDto.class);
            providerDto.setSchemaVersion(this.schemaVersion);
            return providerDto;
        } catch (IOException e) {
            return null;
        }
    }

    private String sanitizeMessage(String messageString) {
        if(Objects.isNull(messageString) || messageString.isBlank())
            return messageString;
        try{
            return messageString.substring(messageString.indexOf("{"));
        } catch(Exception e) {
            return messageString;
        }
    }

}