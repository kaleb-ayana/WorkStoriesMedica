package com.healthplan.ods.provider.transformation.model.misc;

import com.healthplan.ods.provider.transformation.model.merge.AlternateId;
import lombok.Data;

import java.util.Objects;

@Data
public class Tax {
    private String taxId;
    private boolean logicalDeleteFlag;

    public Tax(AlternateId alternateId) {
        this.taxId= alternateId.getIdentifier();
        this.logicalDeleteFlag= alternateId.getLogicalDeleteFlag();
    }
    public Tax() {}
    public boolean hasTaxId(String taxId) {
        if(Objects.isNull(taxId))
            return this.taxId == taxId;
        return taxId.equalsIgnoreCase(this.taxId);
    }
    public static Tax merge(Tax tax1, Tax tax2) {

        if(Objects.isNull(tax1) || Objects.isNull(tax2))
            return null;

        if(! tax1.hasTaxId(tax2.taxId))
            return null;
        Tax resultTax= new Tax();
        resultTax.setTaxId(tax1.taxId);

        resultTax.logicalDeleteFlag= tax1.logicalDeleteFlag || tax2.logicalDeleteFlag;
        return resultTax;
    }
    public boolean matches(Tax tax) {
        return (Objects.isNull(tax) || (! this.hasTaxId(tax.taxId))) ? false : this.hasTaxId(tax.taxId);
    }
}
