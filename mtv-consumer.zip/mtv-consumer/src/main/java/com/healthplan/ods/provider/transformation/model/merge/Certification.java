package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import com.healthplan.ods.provider.transformation.config.validation.OptionalDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

import java.io.Serializable;

import static com.healthplan.ods.provider.transformation.service.utils.TransformationUtil.convertStringToBoolean;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Certification implements Serializable {
    private static final long serialVersionUID = 7089148213562554784L;
    @NotBlank(message = "Certification.CertificationCode field should have a non-blank value")
    @JsonProperty("CERTIFICATION_CODE")
    public String certificationCode;
    @MandatoryDate(message = "Certification.Effective Date field should have a non-blank and valid value")
    @JsonProperty("EFFECTIVE_DATE")
    public String effectiveDate;
    @OptionalDate(message = "Address.enddate field has invalid format.")
    @JsonProperty("END_DATE")
    public String endDate;
    @JsonProperty("VOID_FLAG")
    public String voidFlag;
    @JsonProperty("CREATION_TS")
    public String creationTs;
    @JsonProperty("LAST_MAINT_TS")
    public String lastMaintTs;
    @JsonProperty("OPERATOR_ID")
    public String operatorId;
    @JsonProperty("FK_PROV_ID")
    public String fkProvId;
    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }

    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        logicalDeleteFlag= convertStringToBoolean(this.voidFlag);
    }

    @JsonIgnore
    public boolean isVoided() {
        return this.logicalDeleteFlag == true;
    }
}