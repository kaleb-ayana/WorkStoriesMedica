package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.*;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Network implements Serializable {
    private static final long serialVersionUID = -8532036526379213469L;

    @JsonProperty("MTV_PROVIDER_ID")
    private String mtvProviderId;

    @JsonProperty("PROVIDER_FIRST_NAME")
    private String providerFirstName;

    @JsonProperty("PROVIDER_LAST_NAME")
    private String providerLastName;

    @JsonProperty("PROVIDER_MIDDLE_NAME")
    private String providerMiddleName;

    @JsonProperty("MTV_PRACTICE_LOCATION_ID")
    private String mtvPracticeLocationId;

    @JsonProperty("PRACTICE_LOCATION_NAME")
    private String practiceLocationName;

    @JsonProperty("ADDRESS_LINE_1")
    private String addressLine1;

    @JsonProperty("ADDRESS_LINE_2")
    private String addressLine2;

    @JsonProperty("ADDRESS_LINE_3")
    private String addressLine3;

    @JsonProperty("CITY")
    private String city;

    @JsonProperty("STATE")
    private String state;

    @JsonProperty("ZIP")
    private String zip;

    @JsonProperty("COUNTY")
    private String county;

    @JsonProperty("MTV_NETWORK_ID")
    private String mtvNetworkId;

    @JsonProperty("EFFECTIVE_DT")
    private String effectiveDt;

    @JsonProperty("END_DT")
    private String endDt;

    @JsonProperty("DIRECTORY_FLG")
    private String directoryFlg;

    @JsonProperty("INTERFACE_FLG")
    private String interfaceFlg;

    @JsonProperty("AUDIT_FLG")
    private String auditFlg;

    @JsonProperty("VOID_FLG")
    private String voidFlg;

    @JsonProperty("UPDATED_USER_ID")
    private String updateUserId;

    @JsonProperty("CREATED_DTTM")
    private String createdDttm;

    @JsonProperty("UPDATED_DTTM")
    private String updatedDttm;

    @JsonProperty("ADDRESS_IDENTIFIER")
    public String addressIdentifier;

    @JsonIgnore
    private boolean logicalDeleteFlag;

    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        logicalDeleteFlag = TransformationUtil.convertStringToBoolean(this.voidFlg);
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.logicalDeleteFlag;
    }

    @JsonIgnore
    public boolean isFlaggedForAudit(){
        return  "Y".equalsIgnoreCase(auditFlg);
    }

}
