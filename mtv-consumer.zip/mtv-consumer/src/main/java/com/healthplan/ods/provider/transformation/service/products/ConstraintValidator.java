package com.healthplan.ods.provider.transformation.service.products;

import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Slf4j
public class ConstraintValidator implements Serializable {
    private static final long serialVersionUID = -4526710969442735247L;
    
    final static Validator validator = Validation
            .buildDefaultValidatorFactory()
            .getValidator();

    public static <T> boolean isValid(T domainObject) {
        return ((Objects.nonNull(domainObject)) && (! validator.validate(domainObject)
                .stream()
                .map(ConstraintViolation::getMessage)
                .peek(log::warn)
                .findAny()
                .isPresent()));
    }
    public static <T> boolean isValidList(List<T> domainObjects) {
        if(CollectionUtils.isEmpty(domainObjects))
            return true;
        boolean flag= true;
        for(T domObj: domainObjects) {
            if(Objects.isNull(domObj))
                continue;
            flag= flag && isValid(domObj);
        }
        return flag;
    }
    public static boolean isValidProvider(ProviderDto provider) {
        if(Objects.isNull(provider))
            return false;

        return isValid(provider) &&
                isValidList(provider.getSpecialtyList())  &&
                isValidList(provider.getAddressList()) &&
                isValidList(provider.getAddressesPhones()) &&
                isValidList(provider.getAlternateIds()) &&
                isValidList(provider.getAffiliations()) &&
                isValidList(provider.getEducationList()) &&
                isValidList(provider.getDegreeList()) &&
                isValidList(provider.getPanels()) &&
                isValidList(provider.getLanguageList()) &&
                isValidList(provider.getCertificationList()) ;
    }
}