package com.healthplan.ods.provider.transformation.service.utils;

import com.deancare.fsa.provider.TransactionType;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.Objects;

@Slf4j
public class TransformationUtil {

    public static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.US);
    public static final DateTimeFormatter formatterTimestamp = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSSSS", Locale.US);

    private TransformationUtil() {}
    public static TransactionType getTransactionType(String opType) {
        switch (opType) {
            case "U":
                return TransactionType.UPDATE;
            case "D":
                return TransactionType.DELETE;
            default:
                return TransactionType.READ;
        }
    }

    public static Boolean getLogicalDeleteFlag(String data) {
        return convertStringToBoolean(data);
    }

    public static String getFormattedString(String data) {
        if (data == null) return null;
        return data.trim();
    }

    public static String getLowerCasedTrimmedString(String data) {
        if (data == null) return null;
        return data.trim().toLowerCase();
    }
    public static String getZip5(String data) {
        if(data == null || data.trim().isBlank())
            return null;
        if(data.trim().length() <= 5)
            return data.trim();
        return data.trim().substring(0, 5);
    }

    public static String getZipExt(String data) {
        if(data == null || data.trim().isBlank() || data.trim().length() <= 5)
            return null;
        String trimmedString= data.substring(5);
        return trimmedString.trim().length() <= 4 ? trimmedString.trim() : trimmedString.substring(0, 4);
    }

    public static LocalDate convertStringToLocalDate(String date) {
        try {
            return LocalDate.parse(date, formatter);
        } catch(Exception e) {
            return null;
        }
    }

    public static LocalDateTime convertStringToLocalDateTime(String date) {
        return convertTimestampStringToLocalDateTime(date);

    }

    public static boolean hasValue(String field) {
        return Objects.nonNull(field) && (! field.isBlank());
    }

    public static boolean convertStringToBoolean(String value) {
        return Objects.nonNull(value) && (! value.isBlank()) && value.trim().equalsIgnoreCase(Constants.YES);
    }
    public static LocalDateTime convertTimestampStringToLocalDateTime(String timestamp) {
        if(Objects.isNull(timestamp) || timestamp.isBlank())
            return null;
        try{
            return Timestamp.valueOf(timestamp).toLocalDateTime();
        } catch (Exception e) {
            return null;
        }
    }

/*    public static boolean hasNonExpiredEndDate(String endDate) {
        return hasNonExpiredEndDate(endDate, "2022-12-31");

*//*        if(endDate == null || endDate.isBlank()) {
            endDate = "9999-12-12";
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate  currentDate = LocalDate.now();
        LocalDate endDateFormatted=null;
        try {
            endDateFormatted = LocalDate.parse(endDate, formatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return currentDate.equals(endDateFormatted) || currentDate.isBefore(endDateFormatted);*//*
    }*/
    public static boolean hasNonExpiredEndDate(String endDate, String expirationDate) {
        if(endDate == null || endDate.isBlank()) {
            endDate = "9999-12-12";
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate  expiryDate;
        LocalDate endDateFormatted;
        try {
            expiryDate= LocalDate.parse(expirationDate, formatter);
            endDateFormatted = LocalDate.parse(endDate, formatter);
        } catch (DateTimeParseException e) {
            return false;
        }
        return endDateFormatted.isAfter(expiryDate);
    }
    private static String substring(String string, int beginnnigIndex) {
        if(! StringUtils.hasText(string) || beginnnigIndex > string.length())
            return "";
        return string.substring(beginnnigIndex);
    }
    public static String getMinMTVDateString(String dateString1, String dateString2) {
        LocalDate firstDate= parseMTVDate(dateString1);
        LocalDate secondDate= parseMTVDate(dateString2);
        if(Objects.isNull(firstDate))
            return Objects.nonNull(secondDate) ? secondDate+substring(dateString2,10) : null;
        if(Objects.isNull(secondDate))
            return firstDate+dateString1.substring(10);
        return firstDate.isBefore(secondDate) ? firstDate+substring(dateString1,10) : secondDate+substring(dateString2,10);
    }
    public static String getMaxMTVDateString(String dateString1, String dateString2) {
        LocalDate firstDate= parseMTVDate(dateString1);
        LocalDate secondDate= parseMTVDate(dateString2);
        if(Objects.isNull(firstDate))
            return Objects.nonNull(secondDate) ? secondDate+substring(dateString2, 10) : null;
        if(Objects.isNull(secondDate))
            return firstDate+dateString1.substring(10);
        return firstDate.isAfter(secondDate) ? firstDate+substring(dateString1, 10) : secondDate+substring(dateString2, 10);
    }
    public static LocalDate parseMTVDate(String date) {
        if(! StringUtils.hasText(date) || date.length() != 19 )
            return null;
        try {
            return LocalDate.parse(date, Constants.MTV_DATE_FORMATTER);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
}
