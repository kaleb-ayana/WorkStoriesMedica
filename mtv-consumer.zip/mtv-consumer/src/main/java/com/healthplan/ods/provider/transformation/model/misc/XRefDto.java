package com.healthplan.ods.provider.transformation.model.misc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@Builder
public class XRefDto implements Serializable {
    private static final long serialVersionUID = 7428492905290850886L;
    @JsonProperty("XREF_TYPE")
    private String xRefType;

    @JsonProperty("SOURCE_SYSTEM_CD")
    private String sourceSystemCd;

    @JsonProperty("DESTINATION_SYSTEM_CD")
    private String destinationSystemCd;

    @JsonProperty("EFF_DT")
    private String effDate;

    @JsonProperty("END_DT")
    private String endDate;

    @JsonProperty("SOURCE_VALUE_1_TYPE")
    private String sourceValue1Type;

    @JsonProperty("SOURCE_VALUE_1")
    private String sourceValue1;

    @JsonProperty("SOURCE_VALUE_2_TYPE")
    private String sourceValue2Type;

    @JsonProperty("SOURCE_VALUE_2")
    private String sourceValue2;

    @JsonProperty("SOURCE_VALUE_3_TYPE")
    private String sourceValue3Type;

    @JsonProperty("SOURCE_VALUE_3")
    private String sourceValue3;

    @JsonProperty("SOURCE_VALUE_4_TYPE")
    private String sourceValue4Type;

    @JsonProperty("SOURCE_VALUE_4")
    private String sourceValue4;

    @JsonProperty("DESTINATION_VALUE_1_TYPE")
    private String destinationValue1Type;

    @JsonProperty("DESTINATION_VALUE_1")
    private String destinationValue1;

    @JsonProperty("DESTINATION_VALUE_2_TYPE")
    private String destinationValue2Type;

    @JsonProperty("DESTINATION_VALUE_2")
    private String destinationValue2;

    @JsonProperty("DESTINATION_VALUE_3_TYPE")
    private String destinationValue3Type;

    @JsonProperty("DESTINATION_VALUE_3")
    private String destinationValue3;

    @JsonProperty("DESTINATION_VALUE_4_TYPE")
    private String destinationValue4Type;

    @JsonProperty("DESTINATION_VALUE_4")
    private String destinationValue4;

}
