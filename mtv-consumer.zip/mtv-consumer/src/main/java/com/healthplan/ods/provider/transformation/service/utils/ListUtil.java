package com.healthplan.ods.provider.transformation.service.utils;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ListUtil {

    public static <T> boolean hasList(List<T> list, Predicate<T> condition) {
        return nonEmpty(selectFromList(list, condition));
    }
    public static <T> List<T> selectFromList(List<T> list, Predicate<T> condition) {
        if(Objects.isNull(list) || list.isEmpty())
            return list;
        if(Objects.isNull(condition))
            return null;
        return list.stream().filter(condition).collect(Collectors.toList());
    }
    public static <T> List<T> removeFromList(List<T> list, Predicate<T> condition) {
        if(Objects.isNull(list) || list.isEmpty() || Objects.isNull(condition))
            return list;
        return list.stream().filter(condition.negate()).collect(Collectors.toList());
    }
    public static <T> boolean nullOrEmpty(List<T> list) {
        return Objects.isNull(list) || list.isEmpty();
    }
    public static <T> boolean nonEmpty(List<T> list) {
        return ! nullOrEmpty(list);
    }
    public static <T, String> List<String> filterFieldValues(List<T> list, Function<T, String> mapFunction) {
        return filterFieldValues(list, mapFunction, false);
    }
    public static <T, String> List<String> filterFieldValues(List<T> list, Function<T, String> mapFunction, boolean uniqueFlag) {
        if(Objects.isNull(list) || list.isEmpty())
            return null;
        List<String> stringList= list.stream().map(mapFunction).filter(item -> Objects.nonNull(item) && ! item.toString().isBlank()).collect(Collectors.toList());
        if(! uniqueFlag || nullOrEmpty(stringList))
            return stringList;
        return new ArrayList<>(new HashSet<String>(stringList));
    }

}
