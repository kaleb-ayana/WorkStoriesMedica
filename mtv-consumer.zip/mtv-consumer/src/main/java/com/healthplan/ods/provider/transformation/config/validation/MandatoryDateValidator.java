package com.healthplan.ods.provider.transformation.config.validation;

import lombok.extern.slf4j.Slf4j;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Objects;

@Slf4j
public class MandatoryDateValidator implements ConstraintValidator<MandatoryDate, String> {
    public static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.US);

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        try{
            return Objects.nonNull(value) && (! value.isBlank())&& Objects.nonNull(LocalDate.parse(value, formatter));
        } catch( Exception e) {
            return false;
        }
    }

}