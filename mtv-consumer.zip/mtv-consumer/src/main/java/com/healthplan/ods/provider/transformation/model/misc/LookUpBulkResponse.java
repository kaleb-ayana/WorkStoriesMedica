package com.healthplan.ods.provider.transformation.model.misc;

import lombok.Data;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
public class LookUpBulkResponse {
    private List<XRefDto> resultList;
    private List<CodesetRef> codesetRefs;

    public Map<String, String> getCodeSetsAsMap() {
        return CollectionUtils.isEmpty(codesetRefs) ? new HashMap<>() : this.codesetRefs.stream().collect(Collectors.toMap(CodesetRef::getCD_VALUE, CodesetRef::getSTANDARDIZED_DESCR));
    }
}
