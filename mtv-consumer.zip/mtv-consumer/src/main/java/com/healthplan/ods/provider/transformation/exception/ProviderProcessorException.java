package com.healthplan.ods.provider.transformation.exception;

public class ProviderProcessorException extends Exception {
    private static final long serialVersionUID = -5160724226423752923L;

    public ProviderProcessorException(String s) {
        super(s);
    }
}
