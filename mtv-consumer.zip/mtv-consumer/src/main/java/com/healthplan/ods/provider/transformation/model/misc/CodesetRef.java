package com.healthplan.ods.provider.transformation.model.misc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CodesetRef {
    @JsonProperty("OCM_CDSET_REFERENCE_SK")
    private String OCM_CDSET_REFERENCE_SK;

    @JsonProperty("CODESET_NAME")
    private String CODESET_NAME;

    @JsonProperty("DESCR")
    private String DESCR;

    @JsonProperty("CD_VALUE")
    private String CD_VALUE;

    @JsonProperty("INSERT_DTTM")
    private String INSERT_DTTM;

    @JsonProperty("INSERT_PROCESS_ID")
    private String INSERT_PROCESS_ID;

    @JsonProperty("UPDATE_DTTM")
    private String UPDATE_DTTM;

    @JsonProperty("UPDATE_PROCESS_ID")
    private String UPDATE_PROCESS_ID;

    @JsonProperty("SOURCE_SYSTEM_CD")
    private String SOURCE_SYSTEM_CD;

    @JsonProperty("STANDARDIZED_CD_VALUE")
    private String STANDARDIZED_CD_VALUE;

    @JsonProperty("STANDARDIZED_DESCR")
    private String STANDARDIZED_DESCR;

    @JsonProperty("LOGICAL_DELETE_FLG")
    private boolean LOGICAL_DELETE_FLG;
}
