package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.*;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProvContQual  implements Serializable {
    private static final long serialVersionUID = -6733322028075125492L;
    @JsonProperty("IDENTIFIER")
    private String identifier;

    @JsonProperty("EFFECTIVE_DATE")
    private String effective_Date;

    @JsonProperty("END_DATE")
    private String end_Date;

    @JsonProperty("GROUP_PROV_ID")
    private String group_Prov_Id;

    @JsonProperty("PROVIDER_ORG_ID")
    private String provider_Org_Id;

    @JsonProperty("PRACTICE_LOC_ID")
    private String practice_Loc_Id;

    @JsonProperty("BILLING_PR_TAX_ID")
    private String billing_Pr_Tax_Id;

    @JsonProperty("CLAIMS_PAY_TO_IND")
    private String claims_Pay_To_Ind;

    @JsonProperty("CAP_PAY_TO_IND")
    private String cap_Pay_To_Ind;

    @JsonProperty("VOID_FLAG")
    private String void_Flag;

    @JsonProperty("OPERATOR_ID")
    private String operator_Id;

    @JsonProperty("FK_POINTS_CONT_ID")
    private String fk_Points_Cont_Id;

    @JsonProperty("CLMS_PAY_TO_TAX_ID")
    private String clms_Pay_To_Tax_Id;

    @JsonProperty("CAP_PAY_TO_TAX_ID")
    private String cap_Pay_To_Tax_Id;

    @JsonProperty("USER_DEFINED_FLAG")
    private String user_Defined_Flag;

    @JsonProperty("AUTH_PENALTY_IND")
    private String auth_Penalty_Ind;

    @JsonProperty("TOT_COMP_THRU_MNTH")
    private String tot_Comp_Thru_Mnth;

    @JsonProperty("TOT_COMP_THRU_YR")
    private String tot_Comp_Thru_Yr;

    @JsonProperty("CREATION_TS")
    private String creation_Ts;

    @JsonProperty("LAST_MAINT_TS")
    private String last_Maint_Ts;

    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        this.logicalDeleteFlag= TransformationUtil.convertStringToBoolean(this.void_Flag);
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
}
