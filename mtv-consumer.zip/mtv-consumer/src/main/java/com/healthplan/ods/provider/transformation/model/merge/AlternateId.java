package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.config.validation.MandatoryDate;
import com.healthplan.ods.provider.transformation.config.validation.OptionalDate;
import com.healthplan.ods.provider.transformation.config.validation.StringInListOrBlank;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlternateId  implements Serializable {
    private static final long serialVersionUID = 9169481037484085873L;
    @StringInListOrBlank(acceptedValues = {"Y", "N", "y", "n"})
    @JsonProperty("VOID_FLAG")
    private String voidFlag;

    @NotBlank(message = "AlternateId.prov_type_ind field should have a non-blank value")
    @JsonProperty("PROV_TYPE_IND")
    private String idTypeCode;

    @NotBlank(message = "AlternateId.identifier field should have a non-blank value")
    @JsonProperty("PROVIDER_ID")
    private String identifier;

    @OptionalDate(message = "AlternateId.enddate field has invalid format.")
    @JsonProperty("END_DATE")
    private String endDate;

    @MandatoryDate(message = "AlternateId.effectiveDate is null or invalid format.")
    @JsonProperty("EFFECTIVE_DATE")
    private String effectiveDate;

    @JsonProperty("CREATION_TS")
    private String creationTs;

    @JsonProperty("LAST_MAINT_TS")
    private String lastMaintTs;

    @JsonProperty("OPERATOR_ID")
    private String operatorId;

    @JsonProperty("FK_PROV_ID")
    private String fkProviderId;

    @JsonProperty("TERM_REASON_CODE")
    private String termReasonCode;

    @JsonProperty("PRIMARY_NPI_IND")
    private String primaryNpiInd;

    @JsonProperty("MTV_PROVIDER_TYPE_CD")
    private String mtvProviderTypeCode;

    @JsonProperty("MTV_PROVIDER_CATEGORY_CD")
    private String mtvProviderCategoryCode;

    @JsonProperty("ENTITY_NAME")
    private String entityName;

    @JsonIgnore
    private boolean logicalDeleteFlag;

    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        this.logicalDeleteFlag= TransformationUtil.convertStringToBoolean(this.getVoidFlag());
    }
    @Override
    public boolean equals(Object object) {
        if(Objects.isNull(object))
            return false;
        if(! (object instanceof AlternateId) )
            return false;
        AlternateId alternateId= (AlternateId) object;
        return TransformationUtil.hasValue(this.idTypeCode) &&
                TransformationUtil.hasValue(alternateId.idTypeCode) &&
                alternateId.idTypeCode.equals(this.idTypeCode) &&
                TransformationUtil.hasValue(this.identifier) &&
                TransformationUtil.hasValue(alternateId.identifier) &&
                alternateId.identifier.equals(this.identifier) ;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idTypeCode, identifier);
    }

    @JsonIgnore
    public boolean hasType(String type) {
        if(Objects.isNull(type) || Objects.isNull(this.idTypeCode))
            return this.idTypeCode == type;
        return type.trim().equalsIgnoreCase(this.idTypeCode.trim());
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
}
