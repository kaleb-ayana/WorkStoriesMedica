package com.healthplan.ods.provider.transformation.exception;

public class ProviderConversionException extends Exception {
    private static final long serialVersionUID = -5669199344764166270L;

    public ProviderConversionException(String s) {
        super(s);
    }
}
