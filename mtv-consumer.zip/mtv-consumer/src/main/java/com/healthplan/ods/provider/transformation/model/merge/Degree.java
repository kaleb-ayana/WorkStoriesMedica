
package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Degree  implements Serializable {
    private static final long serialVersionUID = -5353651800777272442L;
    @NotBlank(message = "DEGREE.DEGREE_CD field should have a non-blank value")
    @JsonProperty("DEGREE_CD")
    private String DEGREE_CD;
    @JsonProperty("LOGICAL_DELETE_FLG")
    private Boolean LOGICAL_DELETE_FLG;
    @JsonProperty("SOURCE_SYSTEM_CD")
    private String SOURCE_SYSTEM_CD;
    @JsonProperty("SOURCE_SYSTEM_INSERT_DTTM")
    private LocalDateTime SOURCE_SYSTEM_INSERT_DTTM;
    @JsonProperty("SOURCE_SYSTEM_UPDATE_DTTM")
    private LocalDateTime SOURCE_SYSTEM_UPDATE_DTTM;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Degree degree = (Degree) o;
        return Objects.equals(DEGREE_CD, degree.DEGREE_CD);
    }

    @Override
    public int hashCode() {
        return Objects.hash(DEGREE_CD);
    }

}
