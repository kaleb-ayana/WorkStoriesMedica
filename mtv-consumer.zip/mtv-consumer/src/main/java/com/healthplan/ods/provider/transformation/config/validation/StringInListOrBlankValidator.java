package com.healthplan.ods.provider.transformation.config.validation;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class StringInListOrBlankValidator implements ConstraintValidator<StringInListOrBlank, String> {

    private List<String> valueList;

    @Override
    public void initialize(StringInListOrBlank constraintAnnotation) {
        valueList = new ArrayList<>();
        for(String val : constraintAnnotation.acceptedValues())
            if(Objects.nonNull(val) && (! val.isBlank()))
                valueList.add(val.toUpperCase());

        if(! valueList.isEmpty())
            valueList.stream().forEach(value -> value= value.trim().toUpperCase());
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return Objects.isNull(value) || value.isBlank() || valueList.contains(value.toUpperCase());
    }

}