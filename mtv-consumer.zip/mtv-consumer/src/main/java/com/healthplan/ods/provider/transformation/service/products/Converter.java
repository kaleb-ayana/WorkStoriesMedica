package com.healthplan.ods.provider.transformation.service.products;

import com.deancare.fsa.provider.*;
import com.healthplan.ods.provider.transformation.exception.ProviderConversionException;
import com.healthplan.ods.provider.transformation.model.merge.*;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import com.medica.reference.misc.InvalidObjectStateException;
import com.medica.reference.misc.PersistenceErrorException;
import com.medica.reference.model.NetworkStatusReference;
import com.medica.reference.model.NetworkStatusReferenceGroup;
import com.medica.reference.model.NetworkStatusReferenceInput;
import com.medica.reference.service.NetworkStatusReferenceService;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.AvroMissingFieldException;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.healthplan.ods.provider.transformation.service.utils.TransformationUtil.*;
import static com.healthplan.ods.provider.transformation.service.utils.TransformationUtil.convertStringToLocalDate;

@Slf4j
@NoArgsConstructor
public class Converter  implements Serializable {

    private static final long serialVersionUID = -7582024408004766191L;

    public Converter(NetworkStatusReferenceService networkStatusReferenceService){
        this.networkStatusReferenceService = networkStatusReferenceService;
    }

        private NetworkStatusReferenceService networkStatusReferenceService;

    public void performCustomConversion(Payload payload, ProviderDto provider) {
        /* Intentionally left blank ! */
    }

    public Provider convert(ProviderDto provider) throws ProviderConversionException, PersistenceErrorException {
/*        ObjectMapper OBJECT_MAPPER =
                new ObjectMapper();
        String json= "{\\r\\n  \\\"Metadata\\\": {\\r\\n    \\\"transactionID\\\": \\\"120690221381\\\",\\r\\n    \\\"UserID\\\": \\\"MTV\\\",\\r\\n    \\\"EventTimestamp\\\": \\\"2023-08-04T14:13:10.884\\\",\\r\\n    \\\"TransactionType\\\": \\\"UPDATE\\\",\\r\\n    \\\"SourceSystem\\\": \\\"MTV\\\",\\r\\n    \\\"SchemaVersion\\\": \\\"1.0\\\"\\r\\n  },\\r\\n  \\\"Payload\\\": {\\r\\n    \\\"PROVIDER_ID\\\": \\\"120690221381\\\",\\r\\n    \\\"PROVIDER_ID_TYPE\\\": \\\"MD5\\\",\\r\\n    \\\"SOURCE_SYSTEM_CD\\\": \\\"MTV\\\",\\r\\n    \\\"PROVIDER_CATEGORY_CD\\\": \\\"SITE\\\",\\r\\n    \\\"LAST_NAME_OR_ORG_NAME\\\": \\\"sdfs\\\",\\r\\n    \\\"FIRST_NAME\\\": \\\"sdsds\\\",\\r\\n    \\\"MIDDLE_NAME\\\": \\\"\\\",\\r\\n    \\\"DEGREE_CD\\\": \\\" \\\",\\r\\n    \\\"OBGYN_FLG\\\": false,\\r\\n    \\\"EFF_DT\\\": \\\"2023-07-06\\\",\\r\\n    \\\"INSERT_DTTM\\\": \\\"2023-07-06T10:22:13.822\\\",\\r\\n    \\\"INSERT_PROCESS_ID\\\": \\\"MTV\\\",\\r\\n    \\\"UPDATE_DTTM\\\": \\\"2023-07-06T10:22:13.822\\\",\\r\\n    \\\"UPDATE_PROCESS_ID\\\": \\\"MTV\\\",\\r\\n    \\\"SOURCE_SYSTEM_INSERT_DTTM\\\": \\\"2023-07-06T10:22:13.822\\\",\\r\\n    \\\"SOURCE_SYSTEM_UPDATE_DTTM\\\": \\\"2023-07-06T10:22:13.822\\\",\\r\\n    \\\"IFB_FLG\\\": false,\\r\\n    \\\"OPV_PROVIDER_PANEL\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_NETWORK_DIRECTORY\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_ELEC_ADDRESS\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_REMARK\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_TAXONOMY\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_LANGUAGE\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_AFFILIATION\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_LICENSE\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_CERTIFICATION\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_ADDRESS\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_SPECIALTY\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_ALTERNATE_ID\\\": [\\r\\n      {\\r\\n        \\\"ALTERNATE_ID\\\": \\\"120690221381\\\",\\r\\n        \\\"ALTERNATE_ID_TYPE_CD\\\": \\\"MTV\\\",\\r\\n        \\\"EFF_DT\\\": \\\"2023-07-06\\\",\\r\\n        \\\"END_DT\\\": \\\"9999-12-31\\\",\\r\\n        \\\"MTV_PROVIDER_CATEGORY_CD\\\": \\\"P\\\",\\r\\n        \\\"MTV_PROVIDER_TYPE_CD\\\": \\\"PH\\\",\\r\\n        \\\"SOURCE_SYSTEM_CD\\\": \\\"MTV\\\",\\r\\n        \\\"LOGICAL_DELETE_FLG\\\": false,\\r\\n        \\\"SOURCE_SYSTEM_INSERT_DTTM\\\": \\\"2023-07-06T10:22:13.822\\\",\\r\\n        \\\"SOURCE_SYSTEM_UPDATE_DTTM\\\": \\\"2023-07-06T10:22:13.822\\\"\\r\\n      }\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_EDUCATION\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_DEGREE\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"OPV_PROVIDER_CONTACTS\\\": [\\r\\n\\r\\n    ],\\r\\n    \\\"LARGE_SYSTEMS\\\": [\\r\\n\\r\\n    ]\\r\\n  }\\r\\n}";

            try {
                json= OBJECT_MAPPER.writeValueAsString(provider);
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }

        Provider p= JsonToAvroConverter.convertToSpecificRecord(json ,Provider.class, Provider.SCHEMA$);
            log.info("p = " + p.toString());*/
        if(provider == null)
            throw new ProviderConversionException("Provider for conversion is NULL.");

        Payload.Builder payloadBuilder = Payload.newBuilder();
        Payload payload = null;
        try {
            payload = performPostProcessing(provider,
            populateNetworks(provider,
            populateElectronicAddresses(provider,
            populateDegrees(provider,
            populateEducations(provider,
            populateAlternativeIds(provider,
            populateCertifications(provider,
            populateLicenses(provider,
            populateAffiliations(provider,
            populateLanguages(provider,
            populateTaxonomies(provider,
            populateRemarks(provider,
            populateNetworkDirectories(provider,
            populatePanel(provider,
            populateSpecialties(provider,
            populateAddresses(provider,
            populateDemography(provider,
            populateContacts(provider,
//            populateServiceDescriptions(provider,
            //populateGlobalBillings(provider,
            //populateExtendedServiceAreas(provider,
            populateLargeSystems(provider, payloadBuilder))))))))))))))))))).build();
        } catch(AvroMissingFieldException e) {
            throw new ProviderConversionException("Conversion Error- Avro Missing Field(s) Exception raised for provider : [ " + provider.getIdentifier() + " ]. " + e.getMessage());
        } catch(PersistenceErrorException pee) {
            throw pee;
        }catch(Exception e) {
            throw new ProviderConversionException("Conversion Error encoutered for provider : [ " + provider.getIdentifier() + " ]. " + e.getMessage());
        }
        Metadata metadata= createMetaData(provider);
        performCustomConversion(payload, provider);
        return Provider.newBuilder().setMetadata(metadata).setPayload(payload).build();
    }



    public Metadata createMetaData(ProviderDto providerDto) {
        return Metadata.newBuilder()
                .setEventTimestamp(LocalDateTime.now())
                .setSourceSystem(Constants.PRV_SOURCE_SYSTEM_CD)
                .setTransactionID(providerDto.getTransactionId())
                .setTransactionType(getTransactionType(Constants.OPERATION_UPDATE))
                .setUserID(Constants.PRV_SOURCE_SYSTEM_CD)
                .setSchemaVersion(providerDto.getSchemaVersion())
                .build();
    }
    public Payload.Builder populateDemography(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder
                .setPROVIDERID(provider.getIdentifier())
                .setPROVIDERIDTYPE(provider.getProviderIdType())
                .setPROVIDERCATEGORYCD(provider.getProviderCategoryCd())
                .setEFFDT(TransformationUtil.convertStringToLocalDate(provider.getEffectiveDate()))
                .setTERMDT(TransformationUtil.convertStringToLocalDate(provider.getEndDate()))
                .setNPI(provider.getNpi())
                .setTAXID(provider.getTaxId())
                .setPCPFLG(provider.getPcpFlag())
                .setLASTNAMEORORGNAME(TransformationUtil.getFormattedString(provider.getLastName()))
                .setFIRSTNAME(TransformationUtil.getFormattedString(provider.getFirstName()))
                .setMIDDLENAME(TransformationUtil.getFormattedString(provider.getMiddleName()))
                .setNAMESUFFIX(null)
                .setIFBFLG(provider.getIfbFlag())
                .setSITEADDRESSLINE1(provider.getSiteAddressLine1())
                .setSITEADDRESSLINE2(provider.getSiteAddressLine2())
                .setSITEADDRESSLINE3(provider.getSiteAddressLine3())
                .setSITECITY(provider.getSiteCity())
                .setSITESTATECD(provider.getSiteStateCd())
                .setSITEZIPCD(provider.getSiteZip())
                .setSITEPHONE(provider.getSitePhone())
                .setSITEPRIMARYSPECIALITY(provider.getSitePrimaryCrosswalkSpecialty())
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setINSERTDTTM(convertTimestampStringToLocalDateTime(provider.getCreationTs()))
                .setINSERTPROCESSID(Constants.PRV_SOURCE_SYSTEM_CD)
                .setUPDATEDTTM(convertTimestampStringToLocalDateTime(provider.getLastMaintTs()))
                .setUPDATEPROCESSID(Constants.PRV_SOURCE_SYSTEM_CD)
                .setSOURCESYSTEMINSERTDTTM(convertTimestampStringToLocalDateTime(provider.getCreationTs()))
                .setSOURCESYSTEMUPDATEDTTM(convertTimestampStringToLocalDateTime(provider.getLastMaintTs()))
                .setDEGREECD(StringUtils.hasText(provider.getXWalkDegreeCd()) ? provider.getXWalkDegreeCd() : provider.getDegreeCode())
//                .setSPECIALTYCD(provider.getSpecialtyCd()) //TODO recheck vlaid
                .setOBGYNFLG(convertStringToBoolean(provider.getObstetricianFlag()))
                .setHANDICAPACCESSFLG(StringUtils.hasText(provider.getHandicappedFlag()) ? convertStringToBoolean(provider.getHandicappedFlag()) : null)
                .setGENDERINDICATOR(provider.getGenderIndicator());

        return payloadBuilder;
    }

    public List<OPV_PROVIDER_AFFILIATION> createOpvProviderAffiliations(ProviderDto providerDto) {
        List<OPV_PROVIDER_AFFILIATION> opvProviderAffiliations = new ArrayList<>();

        if(Objects.isNull(providerDto.getAffiliations()) || providerDto.getAffiliations().isEmpty())
            return opvProviderAffiliations;

        providerDto.getAffiliations()
                .stream()
                .forEach(affiliation-> opvProviderAffiliations.add(convertToOpvProviderAffiliation(affiliation)));
        return opvProviderAffiliations;
    }

    public Payload.Builder populateNetworks(ProviderDto provider, Payload.Builder payloadBuilder) throws PersistenceErrorException {
        List<OPV_PROVIDER_NETWORK_DIRECTORY> networkDirectories = createOpvProviderNetworkDirectory(provider);
        payloadBuilder.setOPVPROVIDERNETWORKDIRECTORY(networkDirectories);

        return payloadBuilder;
    }
    public Payload.Builder populateGlobalBillings(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setGLOBALBILLINGS(new ArrayList<>());
        return payloadBuilder;
    }
    public Payload.Builder populateLargeSystems(ProviderDto provider, Payload.Builder payloadBuilder) {

        payloadBuilder.setLARGESYSTEMS(createLargeSystems(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateExtendedServiceAreas(ProviderDto provider, Payload.Builder payloadBuilder) {

        payloadBuilder.setEXTENDEDSERVICEAREAS(new ArrayList<>());
        return payloadBuilder;
    }

    private List<LARGE_SYSTEM> createLargeSystems(ProviderDto provider){
        List<LARGE_SYSTEM> largeSystems= new ArrayList<>();
        return largeSystems;
    }

//    public Payload.Builder populateServiceDescriptions(ProviderDto provider, Payload.Builder payloadBuilder) {
//        payloadBuilder.setOPVSERVICEDESCRIPTORS(createOpvServiceDescriptions(provider));
//        return payloadBuilder;
//    }
//
//    private List<SERVICE_DESCRIPTOR> createOpvServiceDescriptions(ProviderDto provider){
//        List<SERVICE_DESCRIPTOR> serviceDescriptions= new ArrayList<>();
//        return serviceDescriptions;
//    }



    public Payload.Builder populateContacts(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERCONTACTS(createProviderContact(provider));
        return payloadBuilder;
    }

    private List<PROVIDER_CONTACT> createProviderContact(ProviderDto provider){
        List<PROVIDER_CONTACT> contactList = new ArrayList<>();
        return contactList;
    }


    public List<OPV_PROVIDER_NETWORK_DIRECTORY> createOpvProviderNetworkDirectory(ProviderDto providerDto) throws PersistenceErrorException {

        List<OPV_PROVIDER_NETWORK_DIRECTORY> opvProviderNetworkDirectories = new ArrayList<>();

       if(Objects.isNull(providerDto.getNetworks()) || providerDto.getNetworks().isEmpty()){
            return opvProviderNetworkDirectories;
        }
        NetworkStatusReferenceInput networkStatusReferenceInput = new NetworkStatusReferenceInput();
        providerDto.getNetworks()
                .stream()
                .forEach(n-> {
                    networkStatusReferenceInput.addReferenceId(providerDto.getIdentifier(),Constants.PRV_SOURCE_SYSTEM_CD,  n.getMtvNetworkId());
                });
        try {
        final  NetworkStatusReferenceGroup networkStatusReferenceGroup = networkStatusReferenceService.find(networkStatusReferenceInput);
        if (networkStatusReferenceGroup != null && !networkStatusReferenceGroup.isEmpty()) {
            providerDto.getNetworks()
                    .stream()
                    .forEach(n -> {
                        Optional<NetworkStatusReference> networkStatusReference = networkStatusReferenceGroup.getForProvider(providerDto.getIdentifier(), Constants.PRV_SOURCE_SYSTEM_CD, n.getMtvNetworkId());
                         networkStatusReference.ifPresent(reference -> {
                            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

                            LocalDate networkEffDate = LocalDate.parse(n.getEffectiveDt(), dateFormat);
                            LocalDate networkEndDate = LocalDate.parse(n.getEndDt(), dateFormat);
                            if (networkEffDate.isBefore(networkEndDate)) {
                                 LocalDate referenceEffDate = LocalDate.parse(reference.getEffDt(), dateFormat);
                                LocalDate referenceEndDate = LocalDate.parse(reference.getEndDt(), dateFormat);
                                boolean referenceLogicalDeleteFlag = reference.isLogicalDeleteFlg();

                                LocalDate effDate = networkEffDate.isAfter(referenceEffDate) ? networkEffDate : referenceEffDate;
                                LocalDate endDate = (networkEndDate.isBefore(referenceEndDate) || networkEndDate.isEqual(referenceEndDate)) ? networkEndDate : referenceEndDate;
                                boolean logicalDeleteFlag = n.getLogicalDeleteFlag() && referenceLogicalDeleteFlag ? true : false;
                                if (endDate.toString().equals("9999-12-31")) {
                                    endDate = null;
                                }
                                opvProviderNetworkDirectories.add(convertToOpvProviderNetworkDirectory(n, effDate, endDate, logicalDeleteFlag));
                            }
                        });

                    });
        }
        }catch (InvalidObjectStateException e) {
            //Ignore this error and move forward
            log.error("",e);
        } catch (PersistenceErrorException e) {
            log.error("Persistence error occurred when looking for network status reference record for the provider: "+providerDto.getIdentifier());
            throw e;
        }

        return opvProviderNetworkDirectories;
    }

    public Payload.Builder populateDegrees(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERDEGREE(new ArrayList<>());
        return payloadBuilder;
    }
    public Payload.Builder populateEducations(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDEREDUCATION(new ArrayList<>());
        return payloadBuilder;
    }
    public Payload.Builder populateAlternativeIds(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERALTERNATEID(createOpvProviderAlternativeIds(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateCertifications(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERCERTIFICATION(createOpvProviderCertifications(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateLicenses(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERLICENSE(createOpvProviderLicenses(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateAffiliations(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERAFFILIATION(createOpvProviderAffiliations(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateLanguages(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERLANGUAGE(createOpvProviderLanguages(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateTaxonomies(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERTAXONOMY(createOpvProviderTaxonomies(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateRemarks(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERREMARK(createOpvProviderRemarks(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateElectronicAddresses(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERELECADDRESS(createOpvProviderElecAddresses(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateNetworkDirectories(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERNETWORKDIRECTORY(createOpvProviderNetworkDirectories(provider));
        return payloadBuilder;
    }
    public Payload.Builder populatePanel(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERPANEL(createOpvProviderPanels(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateAddresses(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERADDRESS(createOpvProviderAddress(provider));
        return payloadBuilder;
    }
    public Payload.Builder populateSpecialties(ProviderDto provider, Payload.Builder payloadBuilder) {
        payloadBuilder.setOPVPROVIDERSPECIALTY(createOpvProviderSpecialities(provider));
        return payloadBuilder;
    }
    public Payload.Builder performPostProcessing(ProviderDto provider, Payload.Builder payloadBuilder) {
        return payloadBuilder;
    }
    public List<OPV_PROVIDER_ALTERNATE_ID> createOpvProviderAlternativeIds(ProviderDto providerDto) {
        List<OPV_PROVIDER_ALTERNATE_ID> opvProviderAlternateIds = new ArrayList<>();
        if(CollectionUtils.isEmpty(providerDto.getAlternateIds()))
            return opvProviderAlternateIds;
        return providerDto.getAlternateIds().stream().map(alternateId -> convertToOpvProviderAlternativeId(alternateId)).collect(Collectors.toList());
    }
    public List<OPV_PROVIDER_PANEL> createOpvProviderPanels(ProviderDto providerDto) {
        List<OPV_PROVIDER_PANEL> panels= new ArrayList<>();
        if(Objects.isNull(providerDto) || Objects.isNull(providerDto.getPanels()) || providerDto.getPanels().isEmpty())
            return panels;
        return providerDto.getPanels().stream().map(dtoPanel -> this.convertToOpvProviderPanel(dtoPanel)).collect(Collectors.toList());
    }
    public List<OPV_PROVIDER_NETWORK_DIRECTORY> createOpvProviderNetworkDirectories(ProviderDto providerDto) {
        return new ArrayList<>();
    }
    public List<OPV_PROVIDER_ELEC_ADDRESS> createOpvProviderElecAddresses(ProviderDto providerDto) {
        List<OPV_PROVIDER_ELEC_ADDRESS> electronicAddresses= new ArrayList<>();
        if(CollectionUtils.isEmpty(providerDto.getElectronicAddressList()))
            return electronicAddresses;

        return providerDto
                .getElectronicAddressList()
                .stream()
                .map(electAddr-> this.convertToOpvProviderElectronicAddress(electAddr))
                .collect(Collectors.toList());
    }
    public List<OPV_PROVIDER_REMARK> createOpvProviderRemarks(ProviderDto providerDto) {
        return new ArrayList<>();
    }
    public List<OPV_PROVIDER_TAXONOMY> createOpvProviderTaxonomies(ProviderDto providerDto) {
        return new ArrayList<>();
    }
    public List<OPV_PROVIDER_LICENSE> createOpvProviderLicenses(ProviderDto providerDto) {
        return new ArrayList<>();
    }

    public List<OPV_PROVIDER_CERTIFICATION> createOpvProviderCertifications(ProviderDto providerDto) {
        List<OPV_PROVIDER_CERTIFICATION> certifications= new ArrayList<>();
        if(CollectionUtils.isEmpty(providerDto.getCertificationList()))
            return certifications;
        return providerDto.getCertificationList().stream().map(cert -> this.convertToOpvProviderCertification(cert)).collect(Collectors.toList());

    }
    public List<OPV_PROVIDER_LANGUAGE> createOpvProviderLanguages(ProviderDto providerDto) {
        List<OPV_PROVIDER_LANGUAGE> languages= new ArrayList<>();
        if(Objects.isNull(providerDto) || Objects.isNull(providerDto.getLanguageList()) || providerDto.getLanguageList().isEmpty())
            return languages;
        return providerDto.getLanguageList().stream().map(lang-> this.convertToOpvProviderLanguage(lang)).collect(Collectors.toList());
    }
    public List<OPV_PROVIDER_ADDRESS> createOpvProviderAddress(ProviderDto providerDto) {
        List<OPV_PROVIDER_ADDRESS> opvProviderAddresses = new ArrayList<>();
        if (Objects.isNull(providerDto.getAddressList()) || providerDto.getAddressList().isEmpty())
            return opvProviderAddresses;
        return providerDto.getAddressList().stream().map(address -> convertToOpvProviderAddress(address,providerDto)).filter(addr->Objects.nonNull(addr)).collect(Collectors.toList());
    }
    public List<OPV_PROVIDER_SPECIALTY> createOpvProviderSpecialities(ProviderDto providerDto) {
        List<OPV_PROVIDER_SPECIALTY> opvProviderSpecialties = new ArrayList<>();
        if (providerDto.getSpecialtyList() == null || providerDto.getSpecialtyList().isEmpty())
            return opvProviderSpecialties;
        return providerDto.getSpecialtyList().stream().map(specialty-> this.convertToOpvProviderSpeciality(specialty)).collect(Collectors.toList());
    }

    public OPV_PROVIDER_AFFILIATION convertToOpvProviderAffiliation(Affiliation affiliation) {
        return OPV_PROVIDER_AFFILIATION
                .newBuilder()
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setAFFILIATEPROVIDERID(affiliation.getFkJoiningProId())
                .setAFFILIATEPROVIDERIDTYPE(affiliation.getAffiliationCode().equals("MOG") ||
                        affiliation.getAffiliationCode().equals("MORG") ? "TAX" : "MD5")
                .setAFFILIATIONTYPE(affiliation.getAffiliationCode().equals("MOG") || affiliation.getAffiliationCode().equals("MORG") ? AFFILIATION_TYPE.PAYTO : affiliation.getAffiliationCode().equals("ADMT") ? AFFILIATION_TYPE.HOSP : AFFILIATION_TYPE.SITE)
                .setMTVAFFILIATEPROVIDERID(affiliation.getFkJoinedProvId())
                .setHOSPITALAFFILIATIONTYPE(affiliation.getAffiliationCode().equals("ADMT") ? "ADMT" :" ")
                .setEFFDT(LocalDate.parse(affiliation.getEffectiveDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .setENDDT(Objects.isNull(affiliation.getEndDate()) ? null : LocalDate.parse(affiliation.getEndDate(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .setPRIMARYFLG(false)
                .setPCPFLG(null)
                .setLOGICALDELETEFLG(affiliation.getLogicalDeleteFlag())
                .setSOURCESYSTEMINSERTDTTM(LocalDateTime.parse(affiliation.getCreationTs(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.nnnnnnnnn")))
                .setSOURCESYSTEMUPDATEDTTM(LocalDateTime.parse(affiliation.getLastMaintTs(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.nnnnnnnnn")))
                .setOPVPROVIDERAFFSPECIALTY(new ArrayList<>())
                .build();
    }

    public OPV_PROVIDER_NETWORK_DIRECTORY convertToOpvProviderNetworkDirectory(Network n, LocalDate effDate, LocalDate endDate, boolean logicalDeleteFlag) {
        return OPV_PROVIDER_NETWORK_DIRECTORY
                .newBuilder()
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setPRACLOCPROVIDERID(n.getAddressIdentifier())
                .setPRACLOCPROVIDERIDTYPE(Constants.ID_TYPE_MTV)
                .setNETWORKID(n.getMtvNetworkId())
                .setEFFDT(effDate)
                .setENDDT(endDate)
                .setDIRECTORYSUPPRESSIND("N".equals(n.getDirectoryFlg()) ? DIRECTORY_SUPPRESS_IND.Y : DIRECTORY_SUPPRESS_IND.N) // TODO: Verify
                .setINCLUDEININTERFACESFLG("Y".equals(n.getInterfaceFlg()))
                .setLOGICALDELETEFLG(logicalDeleteFlag)
                .setSOURCESYSTEMINSERTDTTM(LocalDateTime.parse(n.getCreatedDttm(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .setSOURCESYSTEMUPDATEDTTM(LocalDateTime.parse(n.getUpdatedDttm(), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")))
                .build();
    }

    public OPV_PROVIDER_ADDRESS convertToOpvProviderAddress(Address providerAddress,ProviderDto providerDto) {
        if(Objects.isNull(providerDto) || Objects.isNull(providerAddress))
            return null;

        OPV_PROVIDER_ADDRESS opvProviderAddress = null;
        //

        try {
            opvProviderAddress = OPV_PROVIDER_ADDRESS.newBuilder()
                    .setADDRESSTYPECD(providerAddress.getAddressCode())
                    .setEFFDT(convertStringToLocalDate(providerAddress.getEffectiveDate()))
                    .setENDDT(convertStringToLocalDate(providerAddress.getEndDate()))
                    .setADDRESSLINE1(getFormattedString(providerAddress.getAddress1()))
                    .setADDRESSLINE2(getFormattedString(providerAddress.getAddress2()))
                    .setADDRESSLINE3(getFormattedString(providerAddress.getAddress3()))
                    .setCITY(getFormattedString(providerAddress.getCity()))
                    .setSTATECD(getFormattedString(providerAddress.getStateCode()))
                    .setZIPCD5(getZip5(providerAddress.getZip()))
                    .setZIPCD4(getZipExt(providerAddress.getZip()))
                    .setPRIMARYFLG(convertStringToBoolean(providerAddress.getPrimaryFlag()))
                    .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                    .setLOGICALDELETEFLG(providerAddress.getLogicalDeleteFlag())
                    .setNAME(providerAddress.getName())
                    .setCOUNTY(providerAddress.getCountyCrossWalk())
                    .setMTVADDRID(providerAddress.getIdentifier())
                    .setADDRMD5HASH(providerAddress.getMd5Hash())
                    .setMTVHANDICAPACCESSFLG(StringUtils.hasText(providerAddress.getHandicappedAcctCd()) ? convertStringToBoolean(providerAddress.getHandicappedAcctCd()) : null)
                    .setOPVPROVIDERPHONE(convertToOpvProviderPhone(providerAddress))
                    .build();
        } catch( AvroMissingFieldException e) {
            log.warn("AVRO error happened. " + e.getMessage());
        }
        return opvProviderAddress;
    }
    public OPV_PROVIDER_PHONE convertToOpvProviderPhone(Phone phone) {
        return  OPV_PROVIDER_PHONE.newBuilder()
                .setPHONENUM(getFormattedString(phone.getPhoneNumber()))
                .setPHONETYPECD(getFormattedString(phone.getPhoneCode()))
                .setPRIMARYFLG(convertStringToBoolean(phone.getPrimaryFlag()))
                .setEXTENSION(getFormattedString(phone.getExtension()))
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setLOGICALDELETEFLG(phone.getLogicalDeleteFlag())
                .setSOURCESYSTEMINSERTDTTM(convertTimestampStringToLocalDateTime(phone.getCreationTs()))
                .setSOURCESYSTEMUPDATEDTTM(convertTimestampStringToLocalDateTime(phone.getLastMaintTs()))
                .build();
    }
    public OPV_PROVIDER_ALTERNATE_ID convertToOpvProviderAlternativeId(AlternateId altIdDto) {
        return OPV_PROVIDER_ALTERNATE_ID
                .newBuilder()
                .setALTERNATEID(altIdDto.getIdentifier())
                .setALTERNATEIDTYPECD(altIdDto.getIdTypeCode())
                .setEFFDT(convertStringToLocalDate(altIdDto.getEffectiveDate()))
                .setENDDT(convertStringToLocalDate(altIdDto.getEndDate()))
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setLOGICALDELETEFLG(altIdDto.getLogicalDeleteFlag())
                .setENTITYNAME(altIdDto.getEntityName())
                .setMTVPROVIDERCATEGORYCD(altIdDto.getMtvProviderCategoryCode())
                .setMTVPROVIDERTYPECD(altIdDto.getMtvProviderTypeCode())
                .setSOURCESYSTEMINSERTDTTM(convertTimestampStringToLocalDateTime(altIdDto.getCreationTs()))
                .setSOURCESYSTEMUPDATEDTTM(convertTimestampStringToLocalDateTime(altIdDto.getLastMaintTs()))
                .build();
    }
    public OPV_PROVIDER_SPECIALTY convertToOpvProviderSpeciality(Specialty specialty) {
        return OPV_PROVIDER_SPECIALTY.newBuilder()
                .setEFFDT(convertStringToLocalDate(specialty.getEffectiveDate()))
                .setSPECIALTYCD(specialty.getSpecialtyCode())
                .setENDDT(convertStringToLocalDate(specialty.getEndDate()))
                .setLOGICALDELETEFLG(specialty.getLogicalDeleteFlag())
                .setPRIMARYFLG(convertStringToBoolean(specialty.getPrimaryFlag()))
                .setBOARDCERTIFIEDFLG(convertStringToBoolean(specialty.getBoardCertFlag()))
                .setSPECIALTYCD(specialty.getSpecialtyCode())
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setSOURCESYSTEMINSERTDTTM(convertTimestampStringToLocalDateTime(specialty.getCreationTs()))
                .setSOURCESYSTEMUPDATEDTTM(convertTimestampStringToLocalDateTime(specialty.getLastMaintTs()))
                .build();
    }
    public OPV_PROVIDER_LANGUAGE convertToOpvProviderLanguage(Language language) {
        return OPV_PROVIDER_LANGUAGE
                .newBuilder()
                .setLANGUAGECD(language.getLangSpokenInd())
                .setLOGICALDELETEFLG(language.getLogicalDeleteFlag())
                .setPRIMARYFLG(TransformationUtil.convertStringToBoolean(language.getPrimaryFlag()))
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setSOURCESYSTEMINSERTDTTM(convertTimestampStringToLocalDateTime(language.getCreationTs()))
                .setSOURCESYSTEMUPDATEDTTM(convertTimestampStringToLocalDateTime(language.getLastMaintTs()))
                .build();
    }
    public OPV_PROVIDER_PANEL convertToOpvProviderPanel(Panel panel) {
        return OPV_PROVIDER_PANEL
                .newBuilder()
                .setACCEPTINGNEWPATIENTFLG(panel.getAcceptingNewPatientFlag())
                .setPATIENTACCEPTANCECD(panel.getPatAcceptanceCd())
                .setEFFDT(convertStringToLocalDate(panel.getEffectiveDate()))
                .setENDDT(convertStringToLocalDate(panel.getEndDate()))
                .setMAXMEMBERCNT(Integer.valueOf(panel.getMaxMbrCount()))
                .setLOGICALDELETEFLG(panel.getLogicalDeleteFlag())
                .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
                .setPRACLOCPROVIDERID(panel.getAddressId())
                .setPRACLOCPROVIDERIDTYPE(Constants.ID_TYPE_MTV)
                .setSOURCESYSTEMINSERTDTTM(convertTimestampStringToLocalDateTime(panel.getCreationTs()))
                .setSOURCESYSTEMUPDATEDTTM(convertTimestampStringToLocalDateTime(panel.getLastMaintTs()))
                .build();
    }
    private OPV_PROVIDER_ELEC_ADDRESS convertToOpvProviderElectronicAddress(ElectronicAddress electAddr) {
        return OPV_PROVIDER_ELEC_ADDRESS
            .newBuilder()
            .setELECADDRESSTYPECD(electAddr.getElectronicAddrCd())
            .setELECTRONICADDRESS(electAddr.getElectAddress())
            .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
            .setPRIMARYFLG(false)
            .setLOGICALDELETEFLG(electAddr.getLogicalDeleteFlag())
            .setSOURCESYSTEMINSERTDTTM(null)
            .setSOURCESYSTEMUPDATEDTTM(null)
            .build();
    }
    private OPV_PROVIDER_CERTIFICATION convertToOpvProviderCertification(Certification certification) {
        return OPV_PROVIDER_CERTIFICATION
            .newBuilder()
            .setCERTIFICATIONCD(certification.getCertificationCode())
            .setSOURCESYSTEMCD(Constants.PRV_SOURCE_SYSTEM_CD)
            .setLIFETMCERTFLG(false)
                .setSTATECD((! certification.getLogicalDeleteFlag()) ? "Y" : "N") // TODO: Verify
            .setEFFDT(convertStringToLocalDate(certification.getEffectiveDate()))
            .setENDDT(convertStringToLocalDate(certification.getEndDate()))
            .setLOGICALDELETEFLG(certification.getLogicalDeleteFlag())
            .setSOURCESYSTEMINSERTDTTM(convertTimestampStringToLocalDateTime(certification.getCreationTs()))
            .setSOURCESYSTEMUPDATEDTTM(convertTimestampStringToLocalDateTime(certification.getLastMaintTs()))
            .build();
    }
    public List<OPV_PROVIDER_PHONE> convertToOpvProviderPhone(Address addressPhone) {
        List<OPV_PROVIDER_PHONE> opvProviderPhones = new ArrayList<>();
        if (addressPhone.getPhoneList() == null || addressPhone.getPhoneList().isEmpty())
            return opvProviderPhones;
        return addressPhone.getPhoneList()
                .stream()
                .map(phone -> this.convertToOpvProviderPhone(phone))
                .collect(Collectors.toList());
    }
}
