package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Language  implements Serializable {
    private static final long serialVersionUID = 9193193161867295903L;
    @NotBlank(message = "Language.Language Spoken Indicator field should have a non-blank value")
    @JsonProperty("LANG_SPOKEN_IND")
    private String langSpokenInd;

    @JsonProperty("PRIMARY_FLAG")
    private String primaryFlag;

    @JsonProperty("FK_PROV_ID")
    private String fkProvId;

    @JsonProperty("OPERATOR_ID")
    private String operatorId;

    @JsonProperty("LAST_MAINT_TS")
    private String lastMaintTs;

    @JsonProperty("CREATION_TS")
    private String creationTs;
    @JsonProperty("VOID_FLAG")
    public String voidFlag;
    @JsonIgnore
    private boolean logicalDeleteFlag;

    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        logicalDeleteFlag= TransformationUtil.convertStringToBoolean(this.voidFlag);
    }

    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Language language = (Language) o;
        return Objects.equals(langSpokenInd, language.langSpokenInd) &&
                Objects.equals(fkProvId, language.fkProvId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(langSpokenInd, fkProvId);
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
}
