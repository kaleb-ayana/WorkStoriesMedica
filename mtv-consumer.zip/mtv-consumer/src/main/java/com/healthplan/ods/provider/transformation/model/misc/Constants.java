package com.healthplan.ods.provider.transformation.model.misc;

import java.time.format.DateTimeFormatter;

public class Constants {
    public static DateTimeFormatter MTV_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public static final String VOID = "VOID";
    public static final String MD_5 = "MD5";
    public static final String DATE_9999_12_31 = "9999-12-31 00:00:00";
    public static final String ELECTRONIC_ADDRESS_PRIMARY = "PRIMARY";
    public static final String DATE_1800 = "1800";

    private Constants() {}
    public static final String SERVICE_NAME = "mtv-consumer-service";
    public static final String PRV_SOURCE_SYSTEM_CD = "MTV";

    public static final String OPERATION_UPDATE="U";

    public static final String CATEGORY_PRACTICE_LOCATION = "PL";
    public static final String CATEGORY_PROFESSIONAL = "P";
    public static final String CATEGORY_CHECK_ORG = "O";
    public static final String CATEGORY_GROUP_PRACTICE = "G";
    public static final String CATEGORY_ANCILLARY = "A";
    public static final String CATEGORY_FACILITY = "F";
    public static final String CATEGORY_UNKNOWN = "UNKNOWN";

    public static final String YES = "Y";
    public static final String NO = "N";
    public static final String BLANK = " ";

    public static final String ID_TYPE_LGCY = "LGCY";
    public static final String ID_TYPE_NPI1 = "NPI1";
    public static final String ID_TYPE_NPI2 = "NPI2";
    public static final String ID_TYPE_TAX = "TAX";
    public static final String ID_TYPE_MTV = "MTV";


    public static final String ADDRESS_TYPE_BILLING_BA ="BA";
    public static final String ADDRESS_TYPE_PHYSICAL_AP ="AP";
    public static final String ADDRESS_TYPE_PHYSICAL_A2 ="A2";

    public static final String AFFILIATION_TYPE="PAYTO";
    public static final String PATIENT_ACCEPTANCE_CD_YN="YN";
    public static final String CONTRACT_TYPE_IGNORE="M";

    public static final String DEFAULT_END_DATE= "9999-12-31 00:00:00";

    public static final String X_REF_TYPE_SPECiALTY = "EDS_PROVIDER_PRIMARY_SPECIALTY_SITE_KEY";
    public static final String X_REF_TYPE_LANGUAGE = "PROVIDER_LANGUAGE";
    public static final String X_REF_TYPE_DEGREE = "PROVIDER_DEGREE";

}