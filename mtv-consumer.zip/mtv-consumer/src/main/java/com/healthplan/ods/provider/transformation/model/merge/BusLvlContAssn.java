package com.healthplan.ods.provider.transformation.model.merge;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusLvlContAssn implements Serializable{
    private static final long serialVersionUID = -5399594709419984333L;
    @JsonProperty("BUS_LEVEL_1_ID")
    private String bus_Level_1_Id;

    @JsonProperty("BUS_LEVEL_2_ID")
    private String bus_Level_2_Id;

    @JsonProperty("BUS_LEVEL_3_ID")
    private String bus_Level_3_Id;

    @JsonProperty("BUS_LEVEL_4_ID")
    private String bus_Level_4_Id;

    @JsonProperty("BUS_LEVEL_5_ID")
    private String bus_Level_5_Id;

    @JsonProperty("BUS_LEVEL_6_ID")
    private String bus_Level_6_Id;

    @JsonProperty("BUS_LEVEL_7_ID")
    private String bus_Level_7_Id;

    @JsonProperty("NETWORK_ID")
    private String network_Id;

    @JsonProperty("EFFECTIVE_DATE")
    private String effective_Date;

    @JsonProperty("END_DATE")
    private String end_Date;

    @JsonProperty("PROP_TO_MSTRS_FLAG")
    private String prop_To_Mstrs_Flag;

    @JsonProperty("ORIG_OPERATOR_ID")
    private String orig_Operator_Id;

    @JsonProperty("VOID_FLAG")
    private String void_Flag;

    @JsonProperty("CREATION_TS")
    private String creation_Ts;

    @JsonProperty("LAST_MAINT_TS")
    private String last_Maint_Ts;

    @JsonProperty("OPERATOR_ID")
    private String Operator_Id;

    @JsonProperty("BUS_LVL_CNT_ASN_ID")
    private String bus_Lvl_Cnt_Asn_Id;

    @JsonProperty("WILDCARD_INDICATOR")
    private String wildcard_Indicator;

    @JsonProperty("SPLIT_BILL_HISTORY_DY")
    private String split_Bill_History_Dy;

    @JsonProperty("SPLT_BILL_OVRRD_FG")
    private String splt_Bill_Ovrrd_Fg;

    @JsonProperty("TIMELY_FILING_LIMIT")
    private String timely_Filing_Limit;

    @JsonProperty("TFL_OVERRIDE_FLAG")
    private String Tfl_Override_Flag;

    @JsonIgnore
    private boolean logicalDeleteFlag;
    @JsonIgnore
    public boolean getLogicalDeleteFlag() {
        return this.logicalDeleteFlag;
    }
    @JsonIgnore
    public void buildLogicalDeleteFlag() {
        this.logicalDeleteFlag= TransformationUtil.convertStringToBoolean(this.void_Flag);
    }

    @JsonIgnore
    public boolean hasNetwork(String networkId) {
        if(Objects.isNull(networkId) || networkId.isBlank())
            return false;
        return networkId.trim().equalsIgnoreCase(this.network_Id);
    }
    @JsonIgnore
    public boolean hasNetworkIn(List<String> networkIds) {
        if(Objects.isNull(networkIds) || networkIds.isEmpty())
            return false;
        return networkIds.stream().filter(bcas -> bcas.equalsIgnoreCase(this.network_Id)).findFirst().isPresent();
    }
    @JsonIgnore
    public boolean isVoided() {
        return true == this.getLogicalDeleteFlag();
    }
}
