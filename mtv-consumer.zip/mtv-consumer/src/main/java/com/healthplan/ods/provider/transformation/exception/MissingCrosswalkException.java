package com.healthplan.ods.provider.transformation.exception;

import java.io.Serializable;

public class MissingCrosswalkException extends Exception implements Serializable {
    private static final long serialVersionUID = -1845767064473085552L;

    public MissingCrosswalkException(String s) {
        super(s);
    }
}
