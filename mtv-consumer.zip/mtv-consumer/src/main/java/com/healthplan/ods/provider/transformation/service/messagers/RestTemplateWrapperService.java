package com.healthplan.ods.provider.transformation.service.messagers;

import com.healthplan.ods.provider.transformation.model.misc.LookUpBulkRequest;
import com.healthplan.ods.provider.transformation.model.misc.LookUpBulkResponse;
import com.healthplan.ods.provider.transformation.model.misc.XRefDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Slf4j
@Service
public class RestTemplateWrapperService {

    @Value("${lookup-endpoints.specialty}")
    private String specialtySearchUrl;

    @Value("${lookup-endpoints.county}")
    private String countySearchUrl;

    public XRefDto getEDSSpecialty(String sourceValue1) throws RestClientException{
        if(! StringUtils.hasText(sourceValue1) )
            return null;
        RestTemplate restTemplate= new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        Map<String, String> map = new HashMap<>();
        map.put("code", sourceValue1);
        try {
            return restTemplate.getForEntity(this.specialtySearchUrl, XRefDto.class, map).getBody();
        } catch (Exception e ) {
            log.warn("Error encountered while querying Specialty crosswalk in EDS." + e.getMessage());
            return null;
        }
    }

    public Map<String, String> getCountyDescription(List<String> countyCodes) {
        if (CollectionUtils.isEmpty(countyCodes))
            return new HashMap<>();
        RestTemplate restTemplate= new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity <LookUpBulkRequest> requestEntity = new HttpEntity<>(LookUpBulkRequest.builder().countyCodes(countyCodes).build(), headers);
        LookUpBulkResponse response= restTemplate.exchange(countySearchUrl, HttpMethod.POST, requestEntity, LookUpBulkResponse.class).getBody();

        try {
            return Objects.nonNull(response) ? response.getCodeSetsAsMap() : new HashMap<>();
        } catch (Exception e ) {
            log.warn("Error encountered while querying Specialty crosswalk in EDS." + e.getMessage());
            return new HashMap<>();
        }
    }
}