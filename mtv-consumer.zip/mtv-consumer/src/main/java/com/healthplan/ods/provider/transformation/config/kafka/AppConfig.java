package com.healthplan.ods.provider.transformation.config.kafka;

import com.deancare.fsa.provider.Provider;
import com.healthplan.ods.provider.load.config.KafkaConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import lombok.Getter;
import lombok.Setter;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
public class AppConfig {
    String targetTopic;

    @Autowired
    KafkaConfig kafkaConfig;

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();
    }
    public String getEnvSpecificTargetTopic(){
        return kafkaConfig.getEnvSpecificTopicName(getTargetTopic());
    }

    @Bean
    @Qualifier("producerConsumer")
    public ProducerFactory<String, Provider> producerFactorySecondary(KafkaProperties properties) {
        Map<String, Object> producerProperties = properties.buildProducerProperties();
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
//        producerProperties.put(ProducerConfig.MAX_REQUEST_SIZE_CONFIG, "10485760");

        // inject SSL related properties
        producerProperties.putAll(properties.getSsl().buildProperties());
        producerProperties.putAll(properties.getProperties());

        return new DefaultKafkaProducerFactory(producerProperties);
    }
    @Bean
    @Qualifier("kafkaTemplateProduceConsumer")
    public KafkaTemplate<String, Provider> kafkaTemplateProviderString(@Qualifier("producerConsumer") ProducerFactory<String, Provider> producerConsumer) {
        return new KafkaTemplate(producerConsumer);
    }

}
