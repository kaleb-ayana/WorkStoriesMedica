package com.healthplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.azure.spring.data.cosmos.repository.config.EnableReactiveCosmosRepositories;

import javax.annotation.PostConstruct;

@SpringBootApplication
@EnableReactiveCosmosRepositories("com.medica.reference.repository")
public class MTVConsumerService {
    public static void main(String[] args) {
        SpringApplication.run(MTVConsumerService.class, args);
    }



}