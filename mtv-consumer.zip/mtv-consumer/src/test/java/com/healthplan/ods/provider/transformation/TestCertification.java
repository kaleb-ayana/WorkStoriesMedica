package com.healthplan.ods.provider.transformation;

import com.deancare.fsa.provider.OPV_PROVIDER_CERTIFICATION;
import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.Certification;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.service.products.ConstraintValidator;
import com.healthplan.ods.provider.transformation.service.products.Converter;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class TestCertification {
    private Transformer transformer;
    private ProviderDto providerDto;
    private Converter converter;
    @BeforeEach
    public void setUp() {
        this.transformer= new Transformer();
        this.converter= new Converter();
        this.providerDto= TestUtil.getBasicProviderDto();
        providerDto.setAddressList(null);
        providerDto.setAlternateIds(null);
        providerDto.setSpecialtyList(null);
        providerDto.setLanguageList(null);
    }

    @Test
    public void testConstaintValidator() {
        List<Certification> certifications= new ArrayList<>();
        certifications.add(this.getCertification());
        assertThat(ConstraintValidator.isValidList(certifications)).isTrue();
        certifications.add(this.getCertification());
        certifications.get(1).setEffectiveDate(null);
        assertThat(ConstraintValidator.isValidList(certifications)).isFalse();
    }
    @Test
    public void testCertificateTransformerValidator() throws ProviderProcessorException {
        List<Certification> certifications= new ArrayList<>();
        certifications.add(this.getCertification());
        certifications.get(0).setEndDate(null);
        providerDto.setCertificationList(certifications);
        transformer.transform(providerDto);
        assertThat(providerDto.getCertificationList().get(0).getEndDate()).isNotEmpty();
    }

    @Test
    public void testCertificationConverter() {
        List<Certification> certifications= new ArrayList<>();
        certifications.add(this.getCertification());
        assertThat(ConstraintValidator.isValidList(certifications)).isTrue();
        certifications.add(this.getCertification());
        providerDto.setCertificationList(certifications);
        List<OPV_PROVIDER_CERTIFICATION> convertedList= converter.createOpvProviderCertifications(providerDto);
        assertThat(convertedList.size()).isEqualTo(2);
    }
    private Certification getCertification() {
        Certification certification=  Certification
                .builder()
                .certificationCode("CC")
                .fkProvId("1111111111111111")
                .voidFlag("N")
                .effectiveDate("2022-10-10 02:23:23")
                .endDate("2022-10-10 02:23:23")
                .lastMaintTs("2022-08-11 16:44:19.174016000")
                .creationTs("2022-08-11 16:44:19.174023000")
                .build();
        certification.buildLogicalDeleteFlag();
        return certification;
    }
}
