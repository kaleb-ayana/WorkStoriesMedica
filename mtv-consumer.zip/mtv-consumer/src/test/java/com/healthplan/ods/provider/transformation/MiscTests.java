package com.healthplan.ods.provider.transformation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.healthplan.ods.provider.transformation.model.merge.Address;
import com.healthplan.ods.provider.transformation.model.merge.Phone;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.healthplan.ods.provider.transformation.model.misc.Constants.MTV_DATE_FORMATTER;
import static org.assertj.core.api.Assertions.assertThat;

public class MiscTests {

   /*@Test
    public void testParseDate() {
        LocalDate localDate= LocalDate.parse("9999-12-31 00:00:00", MTV_DATE_FORMATTER);
        assertThat(localDate).isNotNull();
        assertThat(localDate.getYear()).isEqualTo(9999);
        localDate= LocalDate.parse("", MTV_DATE_FORMATTER);
        assertThat(localDate).isNull();
        localDate= LocalDate.parse("XXXX", MTV_DATE_FORMATTER);
        assertThat(localDate).isNull();
        localDate= LocalDate.parse("9999-12-31 00:00:00", MTV_DATE_FORMATTER);
        assertThat(localDate.toString()).isEqualTo("9999-12-31 00:00:00");


    }*/

    @Test
    public void testStreamCollect() {
        List<String> someList= new ArrayList<>();
        List<String> resultList= someList.stream().filter(s -> s.length() > 10).collect(Collectors.toList());
        assertThat(resultList).isNotNull();
        assertThat(resultList.isEmpty()).isTrue();
    }
    @Test
    public void testCommonUtilMethods() {
        assertThat(StringUtils.hasText(null)).isFalse();
        assertThat(StringUtils.hasText("")).isFalse();
        assertThat(StringUtils.hasText("  ")).isFalse();
        assertThat(StringUtils.hasText(" ")).isFalse();
        assertThat(StringUtils.hasText("a ")).isTrue();
        assertThat(StringUtils.hasText("  a")).isTrue();
        assertThat(StringUtils.hasText("  a  ")).isTrue();

        List<String> list= null;
        assertThat(CollectionUtils.isEmpty(list)).isTrue();
        assertThat(CollectionUtils.isEmpty(new ArrayList<String>())).isTrue();
        list= List.of("One", "Two", "Three");
        assertThat(CollectionUtils.isEmpty(list)).isFalse();
        list= List.of("One");
        assertThat(CollectionUtils.isEmpty(list)).isFalse();
    }
    @Test
    public void testAddressPhonePrimaryExistence() {
        Address address= new Address();
        assertThat(address.hasPrimaryPhone()).isFalse();
        Phone phone= new Phone();
        phone.setPrimaryFlag("N");
        phone.setPhoneNumber("1");
        address.addPhone(phone);
        assertThat(address.hasPrimaryPhone()).isFalse();
        phone.setPrimaryFlag("N");
        assertThat(address.hasPrimaryPhone()).isFalse();
        phone.setPrimaryFlag("Y");
        assertThat(address.hasPrimaryPhone()).isTrue();
        phone.setPrimaryFlag("N");
        Phone phone1= new Phone();
        phone1.setPrimaryFlag("N");
        phone1.setPhoneNumber("2");
        address.addPhone(phone1);
        assertThat(address.hasPrimaryPhone()).isFalse();
        phone1.setPrimaryFlag("Y");
        assertThat(address.hasPrimaryPhone()).isTrue();
    }
    @Test
    public void testProviderDtoGetAlternativeIdOfType() throws JsonProcessingException {
        ProviderDto provider= TestUtil.getBasicProviderDto();
        assertThat(provider.getAlternateIds().size()).isEqualTo(1);
        assertThat(provider.getLanguageList().size()).isEqualTo(1);
    }
}
