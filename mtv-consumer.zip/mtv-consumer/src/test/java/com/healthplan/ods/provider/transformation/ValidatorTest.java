package com.healthplan.ods.provider.transformation;

import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.exception.ProviderValidationException;
import com.healthplan.ods.provider.transformation.model.merge.*;
import com.healthplan.ods.provider.transformation.service.products.ConstraintValidator;
import com.healthplan.ods.provider.transformation.service.products.Validator;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.*;

public class ValidatorTest {
    @Test
    public void testPanelValidation() {
        List<Panel> list=
            List.of(
                    Panel.builder().patAcceptanceCd("someCode").practiceLocId("xxx").effectiveDate("2022-01-01 00:00:00").endDate("2022-01-01 00:00:00").providerId("345").build(),
                    Panel.builder().patAcceptanceCd("someCode").practiceLocId("xxx").effectiveDate("2022-01-01 00:00:00").endDate("2022-01-01 00:00:00").providerId("345").build()
            );
        assertThat(ConstraintValidator.isValidList(list)).isTrue();
        list.get(0).setEndDate(null);
        assertThat(ConstraintValidator.isValidList(list)).isTrue();
        list.get(0).setEffectiveDate(null);
        assertThat(ConstraintValidator.isValidList(list)).isFalse();
        list.get(0).setEffectiveDate("2022-01-01 00:00:00");
        assertThat(ConstraintValidator.isValidList(list)).isTrue();
        list.get(0).setEffectiveDate("2022-");
        assertThat(ConstraintValidator.isValidList(list)).isFalse();
        list.get(0).setEffectiveDate("2022-01-01 00:00:00");
        assertThat(ConstraintValidator.isValidList(list)).isTrue();
        list.get(0).setEndDate("2022-");
        assertThat(ConstraintValidator.isValidList(list)).isFalse();
    }
    @Test
    public void testIsWellFormed() {
        ProviderDto provider= new ProviderDto();
        Validator validator= new Validator();
        provider.setIdentifier("123454");
        provider.setCategory("P");
        provider.setProvType("PH");
        provider.setLastName("Wilwakee Professionals");
        assertThat(validator.isWellFormed(provider)).isFalse();
        provider.setEffectiveDate("2022-01-01 00:00:00");
        assertThat(validator.isWellFormed(provider)).isTrue();
    }
    @Test
    public void testValidate() throws ProviderValidationException {
        ProviderDto provider= new ProviderDto();
        Validator validator= new Validator();
        provider.setIdentifier("123454");
        provider.setCategory("P");
        provider.setProvType("PH");
        provider.setLastName("Wilwakee Professionals");
        assertThatThrownBy(()-> {
            validator.validate(provider);
        }).isInstanceOf(ProviderValidationException.class)
                .hasMessageContaining("Provider has one or more missing required or inappropriately formatted field(s).");
        provider.setEffectiveDate("2022-01-01 00:00:00");
        assertThatNoException().isThrownBy(() -> validator.validate(provider));

    }
    @Test
    public void testValidate2() throws ProviderValidationException {
        ProviderDto provider= new ProviderDto();
        Validator validator= new Validator();
        provider.setIdentifier("123454");
        provider.setCategory("P");
        provider.setProvType("PH");
        provider.setLastName("Wilwakee Professionals");
        provider.setEffectiveDate("2022-01-01 00:00:00");
        assertThatNoException().isThrownBy(() -> validator.validate(provider));
        provider.addAlternativeId(
                AlternateId
                        .builder()
                        .identifier("234")
                        .idTypeCode("TAX")
                        .effectiveDate("2022-02-02 00:00:00")
                        .build());
        assertThatNoException().isThrownBy(() -> validator.validate(provider));
        provider.getAlternateIds().get(0).setEffectiveDate(null);
        assertThat(ConstraintValidator.isValidList(provider.getAlternateIds())).isFalse();
        assertThat(ConstraintValidator.isValidProvider(provider)).isFalse();
        assertThatThrownBy(()-> validator.validate(provider)).isInstanceOf(ProviderValidationException.class);
        provider.getAlternateIds().get(0).setEffectiveDate("2022-02-02 00:00:00");
        assertThatNoException().isThrownBy(() -> validator.validate(provider));
        assertThat(ConstraintValidator.isValidList(provider.getAlternateIds())).isTrue();
        assertThat(ConstraintValidator.isValidProvider(provider)).isTrue();

        provider.addAddress(
                Address
                        .builder()
                        .address1("234 Random Street")
                        .city("Madision")
                        .stateCode("WI")
                        .zip("56789")
                        .effectiveDate("2022-02-02 00:00:00")
                        .build()
        );
        assertThat(ConstraintValidator.isValidList(provider.getAddressList())).isTrue();
        assertThat(ConstraintValidator.isValidProvider(provider)).isTrue();

        provider.getAddressList().get(0).setEffectiveDate(null);
        assertThat(ConstraintValidator.isValidList(provider.getAddressList())).isFalse();
        assertThat(ConstraintValidator.isValidProvider(provider)).isFalse();
        assertThatThrownBy(()-> validator.validate(provider)).isInstanceOf(ProviderValidationException.class);

        provider.getAddressList().get(0).setEffectiveDate("2022-02-02 00:00:00");
        assertThat(ConstraintValidator.isValidList(provider.getAddressList())).isTrue();
        assertThat(ConstraintValidator.isValidProvider(provider)).isTrue();

        provider.getAddressList().get(0).setEffectiveDate(null);
        provider.getAlternateIds().get(0).setEffectiveDate(null);
        assertThat(ConstraintValidator.isValidList(provider.getAddressList())).isFalse();
        assertThat(ConstraintValidator.isValidList(provider.getAlternateIds())).isFalse();
        assertThat(ConstraintValidator.isValidProvider(provider)).isFalse();
        assertThatThrownBy(()-> validator.validate(provider)).isInstanceOf(ProviderValidationException.class);
    }
    @Test
    public void testProviderConstraints() throws ProviderProcessorException {
        ProviderDto provider= TestUtil.getBasicCheckOrgProcessed();
        assertThat(ConstraintValidator.isValidList(null)).isTrue();
        assertThat(ConstraintValidator.isValid(provider)).isTrue();
        provider.setIdentifier(null);
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setIdentifier("");
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setIdentifier("123456");
        provider.setLastName(null);
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setLastName("");
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setLastName("Tom");
        assertThat(ConstraintValidator.isValid(provider)).isTrue();
        provider.setSex("K");
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setSex(null);
        assertThat(ConstraintValidator.isValid(provider)).isTrue();
        provider.setSex("m");
        assertThat(ConstraintValidator.isValid(provider)).isTrue();
        provider.setEffectiveDate(null);
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setEffectiveDate("");
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setEffectiveDate("2022-09-20");
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setEffectiveDate("2022-09-20 01:01:01");
        assertThat(ConstraintValidator.isValid(provider)).isTrue();
        provider.setEffectiveDate("2022-09-20 01:01");
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setEffectiveDate("2022-09 01:01:01");
        assertThat(ConstraintValidator.isValid(provider)).isFalse();
        provider.setEffectiveDate("2022-09-20 01:01:01");
        assertThat(ConstraintValidator.isValid(provider)).isTrue();
    }

    @Test
    public void testChildRecords() throws ProviderProcessorException {
        ProviderDto provider= TestUtil.getBasicCheckOrgProcessed();
        provider.setSpecialtyList(null);
        assertThat(ConstraintValidator.isValidProvider(provider)).isFalse();
        provider.addSpecialty(TestUtil.getBasicSpecialty());
        Specialty specialty= TestUtil.getBasicSpecialty();
        assertThat(ConstraintValidator.isValid(specialty)).isTrue();
        specialty.setPrimaryFlag("P");
        assertThat(ConstraintValidator.isValid(specialty)).isTrue();
        specialty.setPrimaryFlag("Y");
        specialty.setEndDate(null);
        assertThat(ConstraintValidator.isValid(specialty)).isTrue();
        specialty.setEndDate("");
        assertThat(ConstraintValidator.isValid(specialty)).isTrue();
        specialty.setEndDate("2022-01-01");
        assertThat(ConstraintValidator.isValid(specialty)).isFalse();
        specialty.setEndDate("2022-01-01 01:01:01");
        assertThat(ConstraintValidator.isValid(specialty)).isTrue();

        specialty.setEffectiveDate(null);
        assertThat(ConstraintValidator.isValid(specialty)).isFalse();
        specialty.setEffectiveDate("");
        assertThat(ConstraintValidator.isValid(specialty)).isFalse();
        specialty.setEffectiveDate("2022-01-01");
        assertThat(ConstraintValidator.isValid(specialty)).isFalse();
        specialty.setEffectiveDate("2022-01-01 01:01:01");
        assertThat(ConstraintValidator.isValid(specialty)).isTrue();
    }
    @Test
    public void testDateAnnotations() throws ProviderProcessorException {
        ProviderDto provider= TestUtil.getBasicCheckOrgProcessed();
        provider.setSpecialtyList(null);
        assertThat(ConstraintValidator.isValid(provider)).isTrue();
    }
}
