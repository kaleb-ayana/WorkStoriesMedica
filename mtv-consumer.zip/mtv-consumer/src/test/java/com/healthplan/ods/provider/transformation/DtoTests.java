package com.healthplan.ods.provider.transformation;

import com.healthplan.ods.provider.transformation.model.merge.Address;
import com.healthplan.ods.provider.transformation.model.merge.AlternateId;
import com.healthplan.ods.provider.transformation.model.merge.Phone;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class DtoTests {
    @Test
    public void addressAddPhoneTest() {
        Phone phone1= Phone
                .builder()
                .phoneType("AD")
                .phoneNumber("1212121212")
                .build();
        Phone phone2= Phone
                .builder()
                .phoneType("AD")
                .phoneNumber("1313131313")
                .build();
        Address address= Address
                .builder()
                .build();
        address.addPhone(phone1);
        address.addPhone(phone1);
    }
    @Test
    public void testAddressEquality() {
        Address address1= Address
                .builder()
                .address3("a3")
                .address2("a2")
                .city("c")
                .build();
        Address address2= Address
                .builder()
                .address3("a3")
                .address2("a2")
                .city("c")
                .build();
        assertThat(address1.equals(address2)).isTrue();
        address2.setCity("cc");
        assertThat(address1.equals(address2)).isFalse();
    }
    @Test
    public void testPhoneEquality() {
        Phone phone1= Phone
                .builder()
                .phoneNumber("123")
                .whoTypeIndicator("AD")
                .build();
        Phone phone2= Phone
                .builder()
                .phoneNumber("123")
                .whoTypeIndicator("AD")
                .build();
        assertThat(phone1.equals(phone2)).isTrue();
        phone2.setPhoneNumber("1234");
        assertThat(phone1.equals(phone2)).isFalse();
        phone1.setPhoneNumber("1234");
        phone2.setWhoTypeIndicator(null);
        phone1.setWhoTypeIndicator(null);
        assertThat(phone1.equals(phone2)).isTrue();
    }
    @Test
    public void testIsPermutedA2() {
        Address address= Address
                .builder()
                .addressCode(Constants.ADDRESS_TYPE_PHYSICAL_AP)
                .build();
        assertThat(address.isPermutedA2()).isFalse();
        address.setAddressCode(Constants.ADDRESS_TYPE_PHYSICAL_A2);
        assertThat(address.isPermutedA2()).isTrue();
        address.addPhone(Phone
                .builder()
                        .phoneNumber("234")
                .build());
        assertThat(address.isPermutedA2()).isTrue();
        address.addPhone(Phone
                .builder()
                .phoneNumber("2342")
                .build());
        assertThat(address.isPermutedA2()).isFalse();
        address.getPhoneList().clear();
        address.addPhone(Phone
                .builder()
                .phoneNumber("2342")
                .build());
        assertThat(address.isPermutedA2()).isTrue();
    }
    @Test
    public void testGetAddressesOfType() {
        ProviderDto provider= new ProviderDto();
        provider.addAddress(Address.builder().address1("Address-1").addressCode(Constants.ADDRESS_TYPE_PHYSICAL_A2).build());
        provider.addAddress(Address.builder().address1("Address-2").addressCode(Constants.ADDRESS_TYPE_PHYSICAL_A2).build());
        provider.addAddress(Address.builder().address1("Address-2").addressCode(Constants.ADDRESS_TYPE_PHYSICAL_AP).build());

        assertThat(provider.getAddressesOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2)).isNotEmpty();
        assertThat(provider.getAddressesOfType(Constants.ADDRESS_TYPE_PHYSICAL_A2).size()).isEqualTo(2);
    }
    @Test
    public void testTypeChecking() {
        ProviderDto provider= new ProviderDto();
        assertThat(provider.isSite()).isFalse();
        assertThat(provider.isPractitioner()).isFalse();
        assertThat(provider.isCheckOrg()).isFalse();
        provider.setCategory("P");
        assertThat(provider.isPractitioner()).isTrue();
        provider.setCategory("p");
        assertThat(provider.isPractitioner()).isTrue();
        provider.setCategory("O");
        assertThat(provider.isCheckOrg()).isTrue();
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_TAX).build());
        assertThat(provider.isCheckOrg()).isTrue();
        provider.setCategory("G");
        assertThat(provider.isCheckOrg()).isTrue();
        assertThat(provider.isPractitioner()).isFalse();
        assertThat(provider.isSite()).isTrue();
        provider.setCategory("A");
        assertThat(provider.isSite()).isTrue();
        provider.setCategory("F");
        assertThat(provider.isSite()).isTrue();
        provider.setCategory("Z");
        assertThat(provider.hasValidCategory()).isTrue();
        provider.setAlternateIds(null);
        assertThat(provider.hasValidCategory()).isFalse();
        provider.setCategory("O");
        assertThat(provider.isCheckOrg()).isTrue();
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_NPI1).build());
        assertThat(provider.isCheckOrg()).isTrue();
        provider.setCategory("P");
        assertThat(provider.isCheckOrg()).isFalse();
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_TAX).build());
        assertThat(provider.isCheckOrg()).isTrue();
        provider.getAlternateIds().remove(1);
        assertThat(provider.isCheckOrg()).isFalse();
    }
    @Test
    public void testGetA2sWithPrimaryPhone() {

        ProviderDto provider= new ProviderDto();
        assertThat(provider.getA2sWithPrimaryPhone()).isNull();
        Address address= Address.builder().addressCode("AP").build();
        provider.addAddress(address);
        assertThat(provider.getA2sWithPrimaryPhone()).isNullOrEmpty();
        address= Address.builder().addressCode("A2").build();
        provider.addAddress(address);
        assertThat(provider.getA2sWithPrimaryPhone().size()).isEqualTo(0);
        Phone phone= Phone.builder().primaryFlag("Y").build();
        provider.getAddressList().get(0).addPhone(phone);
        assertThat(provider.getA2sWithPrimaryPhone().size()).isEqualTo(0);
        provider.getAddressList().get(1).addPhone(phone);
        assertThat(provider.getA2sWithPrimaryPhone().size()).isEqualTo(1);
        address= Address.builder().addressCode("A2").build();
        provider.addAddress(address);
        assertThat(provider.getA2sWithPrimaryPhone().size()).isEqualTo(1);
        address.addPhone(Phone.builder().primaryFlag("Y").build());
        assertThat(provider.getA2sWithPrimaryPhone().size()).isEqualTo(2);
    }
    @Test
    public void hasAddressCodeOfTypeTest() {
        List<Address> addressList= List.of(
                Address.builder().identifier("11").addressCode("AP").logicalDeleteFlag(true).build(),
                Address.builder().identifier("22").addressCode("A2").logicalDeleteFlag(true).build(),
                Address.builder().identifier("33").addressCode("BA").logicalDeleteFlag(false).build(),
                Address.builder().identifier("44").addressCode("AP").logicalDeleteFlag(true).build()
        );
        ProviderDto provider= new ProviderDto();
        provider.setAddressList(addressList);
        assertThat(provider.hasAddressCodeOfType(null)).isFalse();
        assertThat(provider.hasAddressCodeOfType("")).isFalse();
        assertThat(provider.hasAddressCodeOfType("AP")).isTrue();
        assertThat(provider.hasAddressCodeOfType("ap")).isTrue();
        assertThat(provider.hasAddressCodeOfType("BA")).isTrue();
        assertThat(provider.hasAddressCodeOfType("ba")).isTrue();
        assertThat(provider.hasAlternateIdOfType("tax")).isFalse();
        provider.setAddressList(null);
        assertThat(provider.hasAlternateIdOfType("AP")).isFalse();

    }
    @Test
    public void testHasAltIdOfType() {
        List<AlternateId> alternateIdList= List.of(
                AlternateId.builder().identifier("11").idTypeCode("TAX").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("22").idTypeCode("NPI1").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("33").idTypeCode("TAX").logicalDeleteFlag(false).build(),
                AlternateId.builder().identifier("33").idTypeCode("NPI2").logicalDeleteFlag(true).build()
        );
        ProviderDto provider= new ProviderDto();
        provider.setAlternateIds(alternateIdList);
        assertThat(provider.hasAlternateIdOfType("TAX")).isTrue();
        assertThat(provider.hasAlternateIdOfType("tax")).isTrue();
        provider.setAlternateIds(null);
    }
    @Test
    public void testRemoveLegacyAlternativeId() {
        List<AlternateId> alternateIdList= List.of(
                AlternateId.builder().identifier("11").idTypeCode("TAX").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("22").idTypeCode("NPI1").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("33").idTypeCode("TAX").logicalDeleteFlag(false).build(),
                AlternateId.builder().identifier("33").idTypeCode("LGCY").logicalDeleteFlag(false).build(),
                AlternateId.builder().identifier("33").idTypeCode("NPI2").logicalDeleteFlag(true).build()
        );
        ProviderDto provider= new ProviderDto();
        provider.setAlternateIds(alternateIdList);
        provider.removeLegacyAlternativeId();
        assertThat(provider.getAlternateIds().size()).isEqualTo(4);
        provider.setAlternateIds(null);
        provider.removeLegacyAlternativeId();
        assertThat(provider.getAlternateIds()).isNull();
        provider.setAlternateIds(new ArrayList<>());
        provider.removeLegacyAlternativeId();
        assertThat(provider.getAlternateIds()).isNullOrEmpty();
    }
    @Test
    public void testAddressHasCode() {
        Address address= Address.builder().addressCode(null).build();
        assertThat(address.hasAddressCode(null)).isTrue();
        assertThat(address.hasAddressCode("")).isFalse();
    }
    @Test
    public void testAltIdTypeCheck() {
        AlternateId alternateId= AlternateId
                .builder()
                .idTypeCode(null)
                .build();
        assertThat(alternateId.hasType(null)).isTrue();
        assertThat(alternateId.hasType("")).isFalse();
        assertThat(alternateId.hasType(" ")).isFalse();
        alternateId.setIdTypeCode("TAX");
        assertThat(alternateId.hasType(null)).isFalse();
        assertThat(alternateId.hasType("")).isFalse();
        assertThat(alternateId.hasType(" ")).isFalse();
        assertThat(alternateId.hasType("NPI1")).isFalse();
        assertThat(alternateId.hasType("TAX")).isTrue();
        assertThat(alternateId.hasType(" TAX")).isTrue();
        assertThat(alternateId.hasType(" TAX ")).isTrue();
        assertThat(alternateId.hasType("TAX ")).isTrue();

    }

}
