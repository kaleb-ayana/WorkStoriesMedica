package com.healthplan.ods.provider.transformation;

import com.deancare.fsa.provider.AFFILIATION_TYPE;
import com.deancare.fsa.provider.OPV_PROVIDER_AFFILIATION;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.service.products.Converter;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ProviderAffiliation {
    Converter impl = new Converter();

  @Test
    public void testPAflType1(){
      OPV_PROVIDER_AFFILIATION opvProviderAffiliation = impl.convertToOpvProviderAffiliation(TestUtil.getBasicAffiliation());
      assertThat(opvProviderAffiliation.getHOSPITALAFFILIATIONTYPE().isBlank());
      assertThat(opvProviderAffiliation.getAFFILIATEPROVIDERIDTYPE()).isEqualTo("TAX");
      assertThat(opvProviderAffiliation.getAFFILIATIONTYPE()).isEqualTo(AFFILIATION_TYPE.PAYTO);
    }
@Test
     public void testPAfltype2(){
    Transformer transformer = new Transformer();
    ProviderDto basicProviderDto = TestUtil.getBasicProviderDto();
    transformer.checkProviderAffiliation(basicProviderDto);
    assertThat(basicProviderDto.getInactiveFlag()).isEqualTo("N");
    }

 @Test
 public void testPAfltype3(){
     OPV_PROVIDER_AFFILIATION opvProviderAffiliation = impl.convertToOpvProviderAffiliation(TestUtil.getBasicAffiliation());
     assertThat(opvProviderAffiliation.getSOURCESYSTEMCD()).isEqualTo("MTV");
          }
 @Test
  public void testPAfltype4(){
        OPV_PROVIDER_AFFILIATION opvProviderAffiliation = impl.convertToOpvProviderAffiliation(TestUtil.getBasicAffiliation());
        assertThat(!opvProviderAffiliation.getAFFILIATEPROVIDERID().isEmpty());
    }

    @Test
    public void testPAfltype5(){
        OPV_PROVIDER_AFFILIATION opvProviderAffiliation = impl.convertToOpvProviderAffiliation(TestUtil.getPAffiliationAdmt());
        assertThat(opvProviderAffiliation.getAFFILIATEPROVIDERIDTYPE()).isEqualTo("MD5");
        assertThat(opvProviderAffiliation.getAFFILIATIONTYPE()).isEqualTo(AFFILIATION_TYPE.HOSP);
        assertThat(opvProviderAffiliation.getHOSPITALAFFILIATIONTYPE()).isEqualTo("ADMT");
    }

    @Test
    public void testPAfltype8(){
        OPV_PROVIDER_AFFILIATION opvProviderAffiliation = impl.convertToOpvProviderAffiliation(TestUtil.getPAffiliationType());
        assertThat(opvProviderAffiliation.getAFFILIATEPROVIDERIDTYPE()).isEqualTo("MD5");
        assertThat(opvProviderAffiliation.getAFFILIATIONTYPE()).isEqualTo(AFFILIATION_TYPE.SITE);
        assertThat(opvProviderAffiliation.getHOSPITALAFFILIATIONTYPE()).isBlank();
    }
}