package com.healthplan.ods.provider.transformation;

import com.deancare.fsa.provider.OPV_PROVIDER_ELEC_ADDRESS;
import com.healthplan.ods.provider.transformation.model.merge.Address;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.service.products.Converter;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class ElectronicAddressTests {
    private Converter converter;
    private Transformer transformer;
    private ProviderDto provider;
    @BeforeEach
    public void beforeEach() {
        transformer= new Transformer();
        converter= new Converter();
        provider= TestUtil.getBasicProviderDto();
        provider.setAddressList(null);
    }
    @Test
    public void converterTestNull() {
        provider.addAddress(getA2Address(" http://www.someurl", "N"));
        provider.addAddress(getA2Address(" http://www.someurl", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl", "N"));
        provider.addAddress(getA2Address(" http://www.someurl1", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl1", "N"));
        provider.addAddress(getA2Address(" http://www.someurl", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl2", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl2", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl3", "N"));
        provider.addAddress(getA2Address(" http://www.someurl3", "Y"));
        transformer.buildElectronicAddresses(provider);

        List<OPV_PROVIDER_ELEC_ADDRESS> convertedElectAddresses= converter.createOpvProviderElecAddresses(provider);
        assertThat(convertedElectAddresses.isEmpty()).isFalse();
        assertThat(convertedElectAddresses.size()).isEqualTo(4);
    }
    @Test
    public void testEmptyElectronicAddress() {
        transformer.buildElectronicAddresses(provider);
        assertThat(provider.getElectronicAddressList().size()).isEqualTo(0);
    }
    @Test
    public void testEmptyElectronicAddress1() {
        provider.addAddress(getA2Address(" http://www.someurl", "N"));
        provider.addAddress(getA2Address(" http://www.someurl", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl", "N"));
        provider.addAddress(getA2Address(" http://www.someurl1", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl1", "N"));
        provider.addAddress(getA2Address(" http://www.someurl", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl2", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl2", "Y"));
        provider.addAddress(getA2Address(" http://www.someurl3", "N"));
        provider.addAddress(getA2Address(" http://www.someurl3", "Y"));

        transformer.buildElectronicAddresses(provider);
        assertThat(provider.getElectronicAddressList().size()).isEqualTo(4);
        assertThat(provider.getElectronicAddressList().get(0).getVoidFlag()).isEqualTo("N");
        assertThat(provider.getElectronicAddressList().get(1).getVoidFlag()).isEqualTo("N");
        assertThat(provider.getElectronicAddressList().get(2).getVoidFlag()).isEqualTo("Y");
        assertThat(provider.getElectronicAddressList().get(3).getVoidFlag()).isEqualTo("N");
    }
    private Address getA2Address(String email, String voidFlag) {
        return Address
                .builder()
                .electAddress(email)
                .voidFlag(voidFlag)
                .addressCode("A2")
                .build();
    }
    private Address getVoidedA2Address(String email) {
        return getA2Address(email, "Y");
    }
    private Address getNonVoidedA2Address(String email) {
        return getA2Address(email, "N");
    }

}
