package com.healthplan.ods.provider.transformation;

import com.deancare.fsa.provider.PROVIDER_CATEGORY_CD;
import com.deancare.fsa.provider.PROVIDER_ID_TYPE;
import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.*;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

public class TransformationTests {
    @Test
    public void testGetLocIdToMd5Map() {
        ProviderDto provider= new ProviderDto();
        provider.addAddress(
                Address
                        .builder()
                        .locationId("11")
                        .md5Hash("X11X")
                        .build()
        );
        provider.addAddress(
                Address
                        .builder()
                        .locationId("22")
                        .md5Hash("X22X")
                        .build()
        );
        provider.addAddress(
                Address
                        .builder()
                        .locationId("33")
                        .md5Hash("X33X")
                        .build()
        );
        Transformer transformer= new Transformer();
        Map<String, String> mapResult= transformer.getLocIdToMd5Map(provider);
        assertThat(mapResult).isNotEmpty();
        assertThat(mapResult.size()).isEqualTo(3);
        assertThat(mapResult.get("11")).isEqualTo("X11X");
        assertThat(mapResult.get("22")).isEqualTo("X22X");
        assertThat(mapResult.get("33")).isEqualTo("X33X");
        provider.getAddressList().clear();

        provider.addAddress(
                Address
                        .builder()
                        .locationId("11")
                        .md5Hash(null)
                        .build()
        );
        provider.addAddress(
                Address
                        .builder()
                        .locationId("22")
                        .md5Hash("X22X")
                        .build()
        );
        provider.addAddress(
                Address
                        .builder()
                        .locationId("33")
                        .md5Hash("X33X")
                        .build()
        );
        transformer = new Transformer();
        mapResult= transformer.getLocIdToMd5Map(provider);
        assertThat(mapResult.size()).isEqualTo(2);
        assertThat(mapResult.get("22")).isEqualTo("X22X");
        assertThat(mapResult.get("33")).isEqualTo("X33X");
        assertThat(mapResult.get("222")).isNull();

        provider.setAddressList(new ArrayList<>());
        mapResult= transformer.getLocIdToMd5Map(provider);
        assertThat(mapResult).isNotNull();
        assertThat(mapResult).isEmpty();

    }
    @Test
    public void testNaturalizePanelLocIds() {
        ProviderDto provider= new ProviderDto();
        provider.setAddressList(List.of(
                Address.builder().locationId("11").md5Hash("X11X").build(),
                Address.builder().locationId("22").md5Hash("X22X").build(),
                Address.builder().locationId("33").md5Hash("X33X").build()
        ));
        provider.setPanels(List.of(
                Panel.builder().practiceLocId("11").build(),
                Panel.builder().practiceLocId("22").build(),
                Panel.builder().practiceLocId("33").build()
        ));
        Transformer transformer= new Transformer();
        transformer.naturalizePanelLocIds(provider);
        assertThat(provider.getPanels().get(0).getMd5hash()).isEqualTo("X11X");
        assertThat(provider.getPanels().get(1).getMd5hash()).isEqualTo("X22X");
        assertThat(provider.getPanels().get(2).getMd5hash()).isEqualTo("X33X");
    }
    @Test
    public void testBuildSiteLocationIds() throws ProviderProcessorException {
        ProviderDto provider= new ProviderDto();
        provider.setSitePrimaryCrosswalkSpecialty("0005");
        provider.setLastName("Z Clinic");
        provider.addSpecialty(Specialty.builder().specialtyCode("04").primaryFlag("Y").voidFlag("N").build());
        provider.addAddress(Address
                .builder()
                .addressCode("A2")
                .address1("someAddress")
                .address2("34")
                .city("Madison")
                .stateCode("WI")
                .phoneList(List.of(Phone.builder().phoneNumber("23456").primaryFlag("Y").build()))
                .build());
        Transformer transformer= new Transformer();
        transformer.buildSiteLocationIds(provider);
        assertThat(provider.getAddressList().get(0).getMd5Hash()).isNotEmpty();
        provider.getAddressList().get(0).setPhoneList(null);
        transformer.buildSiteLocationIds(provider);
        assertThat(provider.getAddressList().get(0).getMd5Hash()).isNotEmpty();
    }
    @Test
    public void testComputePanelPatientAcceptance() {
        ProviderDto provider= new ProviderDto();
        provider.setPanels(List.of(Panel.builder().patAcceptanceCd("YN").build(), Panel.builder().patAcceptanceCd("N").build(),
                        Panel.builder().patAcceptanceCd("Y").build(),Panel.builder().patAcceptanceCd("YN").build()));
        Transformer transformer= new Transformer();
        transformer.computePatientAcceptance(provider);
        assertThat(provider.getPanels().get(0).getAcceptingNewPatientFlag()).isTrue();
        assertThat(provider.getPanels().get(1).getAcceptingNewPatientFlag()).isFalse();
        assertThat(provider.getPanels().get(2).getAcceptingNewPatientFlag()).isFalse();
        assertThat(provider.getPanels().get(3).getAcceptingNewPatientFlag()).isTrue();
    }
    @Test
    public void testBuildMtvProviderTypeCode() {
        ProviderDto provider= new ProviderDto();
        provider.setCategory("P");
        provider.setProvType("PH");
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_TAX).build());
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_NPI1).build());
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_NPI2).build());
        Transformer transformer= new Transformer();
        transformer.buildMtvProviderTypeCode(provider);
        assertThat(provider.getAlternateIds().get(0).getMtvProviderCategoryCode()).isEqualTo(Constants.CATEGORY_CHECK_ORG);
        assertThat(provider.getAlternateIds().get(0).getMtvProviderTypeCode()).isEqualTo("PH");
        assertThat(provider.getAlternateIds().get(1).getMtvProviderCategoryCode()).isEqualTo(Constants.CATEGORY_PROFESSIONAL);
        assertThat(provider.getAlternateIds().get(1).getMtvProviderTypeCode()).isEqualTo("PH");
        assertThat(provider.getAlternateIds().get(2).getMtvProviderCategoryCode()).isEqualTo(Constants.CATEGORY_PROFESSIONAL);
        assertThat(provider.getAlternateIds().get(2).getMtvProviderTypeCode()).isEqualTo("PH");

        provider.setCategory("O");
        provider.setProvType("CL");
        transformer.buildMtvProviderTypeCode(provider);
        assertThat(provider.getAlternateIds().get(0).getMtvProviderCategoryCode()).isEqualTo(Constants.CATEGORY_CHECK_ORG);
        assertThat(provider.getAlternateIds().get(0).getMtvProviderTypeCode()).isEqualTo("CL");
        assertThat(provider.getAlternateIds().get(1).getMtvProviderCategoryCode()).isEqualTo(Constants.CATEGORY_PROFESSIONAL);
        assertThat(provider.getAlternateIds().get(1).getMtvProviderTypeCode()).isEqualTo("CL");
        assertThat(provider.getAlternateIds().get(2).getMtvProviderCategoryCode()).isEqualTo(Constants.CATEGORY_CHECK_ORG);
        assertThat(provider.getAlternateIds().get(2).getMtvProviderTypeCode()).isEqualTo("CL");
    }
    @Test
    public void testBuildAlternateIds() {
        ProviderDto provider= new ProviderDto();
        provider.setIdentifier("3434");
        provider.setCategory("P");
        provider.setProvType("PH");
        provider.setInactiveFlag("Y");
        provider.setOperatorId("operator");
        provider.setEffectiveDate("2021-01-01");
        provider.setEffectiveDate("9999-01-01");
        Transformer transformer= new Transformer();
        transformer.buildAlternateIds(provider);
        assertThat(provider.hasAlternateIdOfType(Constants.ID_TYPE_MTV)).isTrue();
        transformer.buildAlternateIds(provider);
        assertThat(provider.getAlternateIds().size()).isEqualTo(1);
    }
    @Test
    public void providerTypePopulationTests() throws ProviderProcessorException {
        Transformer transformer = new Transformer();
        ProviderDto provider = TestUtil.getBasicProfessional();
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_TAX).build());

        transformer.populateTypeClassificationFields(provider);
        assertThat(provider.getProviderIdType()).isEqualTo(PROVIDER_ID_TYPE.TAX);
        assertThat(provider.getProviderCategoryCd()).isEqualTo(PROVIDER_CATEGORY_CD.PAYTO);

        provider.removeAlternateIdOfType(Constants.ID_TYPE_TAX);
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_NPI1).build());
        transformer.populateTypeClassificationFields(provider);
        assertThat(provider.getProviderIdType()).isEqualTo(PROVIDER_ID_TYPE.NPI1);
        assertThat(provider.getProviderCategoryCd()).isEqualTo(PROVIDER_CATEGORY_CD.PRACT);

        provider.removeAlternateIdOfType(Constants.ID_TYPE_NPI1);
        provider.addAlternativeId(AlternateId.builder().idTypeCode(Constants.ID_TYPE_NPI2).build());
        transformer.populateTypeClassificationFields(provider);
        assertThat(provider.getProviderIdType()).isEqualTo(PROVIDER_ID_TYPE.MD5);
        assertThat(provider.getProviderCategoryCd()).isEqualTo(PROVIDER_CATEGORY_CD.SITE);

    }

    @Test
    public void testDefaultNullEndDates() {
        ProviderDto provider=null;
        Transformer transformer= new Transformer();
        transformer.defaultNullEndDates(provider);
        assertThat(provider).isNull();
        provider=new ProviderDto();
        provider.addAlternativeId(AlternateId.builder().endDate(null).build());
        provider.addAlternativeId(AlternateId.builder().endDate("1800-01-01").build());
        transformer.defaultNullEndDates(provider);
        assertThat(provider.getAlternateIds().get(0).getEndDate()).isEqualTo(Constants.DEFAULT_END_DATE);
        assertThat(provider.getAlternateIds().get(1).getEndDate()).isNotEqualTo(Constants.DEFAULT_END_DATE);
        provider.addAlternativeId(AlternateId.builder().endDate(" ").build());
        transformer.defaultNullEndDates(provider);
        assertThat(provider.getAlternateIds().get(2).getEndDate()).isEqualTo(Constants.DEFAULT_END_DATE);

    }
    @Test
    public void TestleanEffectiveDates() {
        ProviderDto provider= new ProviderDto();
        provider.setEffectiveDate("2022");
        Transformer transformer= new Transformer();
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getEffectiveDate()).isEqualTo("2022");

        provider.setEffectiveDate("0001");
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getEffectiveDate()).isEqualTo("0001");

        provider.setEffectiveDate("0001-");
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getEffectiveDate()).isEqualTo("1800-");

        provider.setEffectiveDate("0001-01-01");
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getEffectiveDate()).isEqualTo("1800-01-01");

        AlternateId alternateId= new AlternateId();
        provider.addAlternativeId(alternateId);

        alternateId.setEffectiveDate("0001");
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getAlternateIds().get(0).getEffectiveDate()).isEqualTo("0001");

        alternateId.setEffectiveDate("0001-01-01");
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getAlternateIds().get(0).getEffectiveDate()).isEqualTo("1800-01-01");

        provider.getAlternateIds().get(0).setEffectiveDate("0001");
        alternateId= new AlternateId();
        alternateId.setEffectiveDate("0001");
        provider.addAlternativeId(alternateId);
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getAlternateIds().get(0).getEffectiveDate()).isEqualTo("0001");
        assertThat(provider.getAlternateIds().get(1).getEffectiveDate()).isEqualTo("0001");

        provider.getAlternateIds().get(0).setEffectiveDate("0001-01-01");
        provider.getAlternateIds().get(1).setEffectiveDate("0001-01-01");
        transformer.cleanEffectiveDates(provider);
        assertThat(provider.getAlternateIds().get(0).getEffectiveDate()).isEqualTo("1800-01-01");
        assertThat(provider.getAlternateIds().get(1).getEffectiveDate()).isEqualTo("1800-01-01");
    }
}
