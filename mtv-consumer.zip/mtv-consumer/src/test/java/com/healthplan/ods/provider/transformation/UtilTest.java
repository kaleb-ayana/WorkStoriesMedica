package com.healthplan.ods.provider.transformation;

import com.deancare.fsa.provider.TransactionType;
import com.healthplan.ods.provider.transformation.service.utils.TransformationUtil;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class UtilTest {
    @Test
    public void testMinDate() {
        assertThat(TransformationUtil.getMinMTVDateString("9999-12-31 00:00:00", "9999-12-31 00:00:00")).isEqualTo("9999-12-31 00:00:00");
        assertThat(TransformationUtil.getMinMTVDateString("9999-12-31 00:00:00", "9997-12-31 00:00:00")).isEqualTo("9997-12-31 00:00:00");
        assertThat(TransformationUtil.getMinMTVDateString("9998-12-31 00:00:00", "9999-12-31 00:00:00")).isEqualTo("9998-12-31 00:00:00");
        assertThat(TransformationUtil.getMinMTVDateString("9998-12-31 00:00:00", null)).isEqualTo("9998-12-31 00:00:00");
        assertThat(TransformationUtil.getMinMTVDateString(null,"9998-12-31 00:00:00" )).isEqualTo("9998-12-31 00:00:00");
        assertThat(TransformationUtil.getMinMTVDateString("9999-12-31 00:00:00", "9998-12-31 00:00")).isEqualTo("9999-12-31 00:00:00");
        assertThat(TransformationUtil.getMinMTVDateString("9994-12-31 00:00", "9998-12-31 00:00")).isEqualTo(null);
    }
    @Test
    public void testMaxDate() {
        assertThat(TransformationUtil.getMaxMTVDateString("9999-12-31 00:00:00", "9999-12-31 00:00:00")).isEqualTo("9999-12-31 00:00:00");
        assertThat(TransformationUtil.getMaxMTVDateString("9999-12-31 00:00:00", "9997-12-31 00:00:00")).isEqualTo("9999-12-31 00:00:00");
        assertThat(TransformationUtil.getMaxMTVDateString("9998-12-31 00:00:00", "9999-12-31 00:00:00")).isEqualTo("9999-12-31 00:00:00");
        assertThat(TransformationUtil.getMaxMTVDateString("9998-12-31 00:00:00", null)).isEqualTo("9998-12-31 00:00:00");
        assertThat(TransformationUtil.getMaxMTVDateString(null,"9998-12-31 00:00:00" )).isEqualTo("9998-12-31 00:00:00");
        assertThat(TransformationUtil.getMaxMTVDateString("9999-12-31 00:00:00", "9998-12-31 00:00")).isEqualTo("9999-12-31 00:00:00");
        assertThat(TransformationUtil.getMaxMTVDateString("9994-12-31 00:00", "9998-12-31 00:00")).isEqualTo(null);
    }
    @Test
    public void testParseMtvDate() {
        assertThat(TransformationUtil.parseMTVDate("")).isNull();
        assertThat(TransformationUtil.parseMTVDate(null)).isNull();
        assertThat(TransformationUtil.parseMTVDate("null")).isNull();
        assertThat(TransformationUtil.parseMTVDate("9999-12-31 00:00:00")).isNotNull();
        assertThat(TransformationUtil.parseMTVDate("9999-12-31 00:00")).isNull();
        assertThat(TransformationUtil.parseMTVDate("9999-12-31 00:00:00:")).isNull();
    }
    @Test
    public void testTransactionTypeMethods() {

        assertEquals(TransactionType.DELETE, TransformationUtil.getTransactionType("D"));
        assertEquals(TransactionType.UPDATE, TransformationUtil.getTransactionType("U"));
        assertEquals(TransactionType.READ, TransformationUtil.getTransactionType("R"));

        assertThat(TransformationUtil.getLogicalDeleteFlag("U")).isFalse();
        assertThat(TransformationUtil.getLogicalDeleteFlag("Y")).isTrue();
        assertThat(TransformationUtil.getLogicalDeleteFlag("N")).isFalse();

        assertThat(TransformationUtil.getFormattedString(null)).isNull();
        assertThat(TransformationUtil.getFormattedString("SomeText")).isEqualTo("SomeText");
        assertThat(TransformationUtil.getFormattedString(" SomeText  ")).isEqualTo("SomeText");

        assertThat(TransformationUtil.getZip5(null)).isNull();
        assertThat(TransformationUtil.getZip5("")).isNull();
        assertThat(TransformationUtil.getZip5("2345678")).isEqualTo("23456");
        assertThat(TransformationUtil.getZip5("234")).isEqualTo("234");

        assertThat(TransformationUtil.convertStringToLocalDateTime("2022-01-01 01:01:01")).isEqualTo(LocalDateTime.of(2022, 1, 1, 1, 1, 1));
        assertThat(TransformationUtil.hasValue("2022-01-01 01:01:01")).isTrue();
        assertThat(TransformationUtil.hasValue(null)).isFalse();
        assertThat(TransformationUtil.hasValue("  ")).isFalse();
    }
    @Test
    public void testZip4Extract() {
        assertThat(TransformationUtil.getZipExt(null)).isNull();
        assertThat(TransformationUtil.getZipExt("")).isNull();
        assertThat(TransformationUtil.getZipExt("2345678")).isEqualTo("78");
        assertThat(TransformationUtil.getZipExt("234")).isNull();
        assertThat(TransformationUtil.getZipExt("234567890")).isEqualTo("7890");
        assertThat(TransformationUtil.getZipExt("123234567890")).isEqualTo("4567");
    }
    @Test
    public void testParseDateAndCheckExpiration2() {
        assertThat(TransformationUtil.hasNonExpiredEndDate("", "2022-12-31")).isTrue();
        assertThat(TransformationUtil.hasNonExpiredEndDate(" ", "2022-12-31")).isTrue();
        assertThat(TransformationUtil.hasNonExpiredEndDate(null, "2022-12-31")).isTrue();
        assertThat(TransformationUtil.hasNonExpiredEndDate("01-01-2023", "2022-12-31")).isFalse();
        assertThat(TransformationUtil.hasNonExpiredEndDate("01-01-2021", "2022-12-31")).isFalse();
        assertThat(TransformationUtil.hasNonExpiredEndDate("2022-11-09", "2022-12-31")).isFalse();
        assertThat(TransformationUtil.hasNonExpiredEndDate("2022-11-10", "2022-12-31")).isFalse();
        assertThat(TransformationUtil.hasNonExpiredEndDate("2023-11-09", "2022-12-31")).isTrue();
        assertThat(TransformationUtil.hasNonExpiredEndDate("2023-11-10", "2022-12-31")).isTrue();
        assertThat(TransformationUtil.hasNonExpiredEndDate("2022-11-08", "2022-12-31")).isFalse();
        assertThat(TransformationUtil.hasNonExpiredEndDate("2022-12-31", "2022-12-31")).isFalse();
    }
}
