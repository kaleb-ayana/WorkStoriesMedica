package com.healthplan.ods.provider.transformation;

import com.deancare.fsa.provider.*;
import com.healthplan.ods.provider.transformation.exception.ProviderConversionException;
import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.*;
import com.healthplan.ods.provider.transformation.service.products.Converter;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import com.medica.reference.misc.InvalidObjectStateException;
import com.medica.reference.misc.PersistenceErrorException;
import com.medica.reference.model.NetworkStatusReferenceGroup;
import com.medica.reference.service.NetworkStatusReferenceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ConverterTests {

    NetworkStatusReferenceService networkStatusReferenceService = Mockito.mock(NetworkStatusReferenceService.class);
    @InjectMocks
    @Spy
    private Converter converter= new Converter(networkStatusReferenceService);
    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
    }
    @Test
    void testConvert() throws ProviderConversionException {
        try {
            ProviderDto providerDto = new ProviderDto();
            Provider outProvider = converter.convert(providerDto);
            assertNotNull(outProvider);
            assertNotNull(outProvider.getPayload());

        } catch (Exception e) {
            // TODO: handle exception
        }
    }
    @Test
    public void testCreateOpvProviderNetworkDirectory() throws PersistenceErrorException, InvalidObjectStateException {
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        ProviderDto providerDto= TestUtil.getBasicProviderDto();
        providerDto.setIdentifier("170191255241");
        List<Network> networks = new ArrayList<>();
        networks.add(TestUtil.getNetwork("C4KCCHPLVL2","170191255241","2011-03-02 00:00:00","2012-12-01 00:00:00",true));
        networks.add(TestUtil.getNetwork("C4KCCHPLVL3","170191255241","2010-12-02 00:00:00","2012-09-01 00:00:00",true));
        providerDto.setNetworks(networks);

        NetworkStatusReferenceGroup networkStatusReferenceGroup = new NetworkStatusReferenceGroup();
        networkStatusReferenceGroup.addOrReplace(TestUtil.getNetworkStatusReference("C4KCCHPLVL2","170191255241","2011-02-02 00:00:00","2012-11-01 00:00:00",true));
        networkStatusReferenceGroup.addOrReplace(TestUtil.getNetworkStatusReference("C4KCCHPLVL3","170191255241","2011-01-02 00:00:00","2012-12-01 00:00:00",false));
        Mockito.when(networkStatusReferenceService.find(Mockito.any())).thenReturn(networkStatusReferenceGroup);

        List<OPV_PROVIDER_NETWORK_DIRECTORY>  opvProviderNetworkDirectories = converter.createOpvProviderNetworkDirectory(providerDto);

        OPV_PROVIDER_NETWORK_DIRECTORY opvProviderNetworkDirectory =  opvProviderNetworkDirectories.get(0);
        assertThat(opvProviderNetworkDirectory.getLOGICALDELETEFLG()).isEqualTo(true);
        assertThat(opvProviderNetworkDirectory.getEFFDT()).isEqualTo(LocalDate.parse("2011-03-02 00:00:00", dateFormat));
        assertThat(opvProviderNetworkDirectory.getENDDT()).isEqualTo(LocalDate.parse("2012-11-01 00:00:00", dateFormat));

        opvProviderNetworkDirectory =  opvProviderNetworkDirectories.get(1);
        assertThat(opvProviderNetworkDirectory.getLOGICALDELETEFLG()).isEqualTo(false);
        assertThat(opvProviderNetworkDirectory.getEFFDT()).isEqualTo(LocalDate.parse("2011-01-02 00:00:00", dateFormat));
        assertThat(opvProviderNetworkDirectory.getENDDT()).isEqualTo(LocalDate.parse("2012-09-01 00:00:00", dateFormat));

    }

    @Test
    public void testConvertToOpvProviderPanel() throws ProviderConversionException, ProviderProcessorException, PersistenceErrorException {
        ProviderDto provider= TestUtil.getBasicProviderDto();
        Panel panel= TestUtil.getBasicPanel();
        panel.setMd5Hash("SSSSSSSSSS");
        panel.setAddressId("addr1234");
        provider.setPanels(List.of(panel));
        OPV_PROVIDER_PANEL opvProviderPanel= converter.convertToOpvProviderPanel(panel);
        assertThat(opvProviderPanel).isNotNull();
        new Transformer().transform(provider);
        Provider providerRes= converter.convert(provider);
        assertThat(providerRes).isNotNull();
        assertThat(providerRes.getPayload().getOPVPROVIDERPANEL().size()).isEqualTo(1);
    }
    @Test
    public void testconvertToOpvProviderAddress() throws ProviderConversionException, PersistenceErrorException, ProviderProcessorException {
        ProviderDto provider= TestUtil.getBasicProviderDto();
        Address address= TestUtil.getBasicAddress();
        provider.addAddress(address);
        OPV_PROVIDER_ADDRESS opvProviderAddress= converter.convertToOpvProviderAddress(address, provider);
        assertThat(opvProviderAddress).isNotNull();
        new Transformer().transform(provider);
        Provider providerRes= converter.convert(provider);
        assertThat(providerRes).isNotNull();
        assertThat(providerRes.getPayload().getOPVPROVIDERADDRESS().size()).isEqualTo(2);
    }
    @Test
    public void testConvertToOpvProviderSpeciality() throws ProviderConversionException, PersistenceErrorException, ProviderProcessorException {
        ProviderDto provider= TestUtil.getBasicProviderDto();
        Specialty specialty= TestUtil.getBasicSpecialty();
        provider.addSpecialty(specialty);
        OPV_PROVIDER_SPECIALTY opvProviderSpecialty= converter.convertToOpvProviderSpeciality(specialty);
        assertThat(opvProviderSpecialty).isNotNull();
        new Transformer().transform(provider);
        Provider providerRes= converter.convert(provider);
        assertThat(providerRes).isNotNull();
        assertThat(providerRes.getPayload().getOPVPROVIDERSPECIALTY().size()).isEqualTo(2);
    }
    @Test
    public void testConvertToOpvProviderAlternativeId() throws ProviderConversionException, PersistenceErrorException, ProviderProcessorException {
        ProviderDto provider= TestUtil.getBasicProviderDto();
        AlternateId alternateId= TestUtil.getBasicAlternateId();
        provider.addAlternativeId(alternateId);
        OPV_PROVIDER_ALTERNATE_ID opvProviderAlternateId= converter.convertToOpvProviderAlternativeId(alternateId);
        assertThat(opvProviderAlternateId).isNotNull();
        new Transformer().transform(provider);
        Provider providerRes= converter.convert(provider);
        assertThat(providerRes).isNotNull();
        assertThat(providerRes.getPayload().getOPVPROVIDERALTERNATEID().size()).isEqualTo(3);
    }

}
