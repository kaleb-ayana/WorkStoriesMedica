package com.healthplan.ods.provider.transformation;

import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.Address;
import com.healthplan.ods.provider.transformation.model.merge.Phone;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.model.merge.Specialty;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.model.misc.XRefDto;
import com.healthplan.ods.provider.transformation.service.messagers.RestTemplateWrapperService;
import com.healthplan.ods.provider.transformation.service.utils.ProviderUtil;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ProviderUtilTests {
    @InjectMocks
    private ProviderUtil providerUtil;

    @Mock
    private RestTemplateWrapperService wrapperService;


    @Test
    public void testPermuteA2Address() {
        Address address=Address.builder().addressCode(Constants.ADDRESS_TYPE_PHYSICAL_A2).address1("Address-1").build();
        assertThat(providerUtil.permuteA2Address(address).size()).isEqualTo(1);
        address.addPhone(Phone.builder().phoneNumber("2451456").build());
        assertThat(providerUtil.permuteA2Address(address).size()).isEqualTo(1);
        address.addPhone(Phone.builder().whoTypeIndicator("AD").phoneNumber("2454506").build());
        assertThat(providerUtil.permuteA2Address(address).size()).isEqualTo(1);
        assertThat(providerUtil.permuteA2Address(address).get(0).getPhoneList().size()).isEqualTo(2);
        address.addPhone(Phone.builder().phoneNumber("2454596").build());
        assertThat(providerUtil.permuteA2Address(address).size()).isEqualTo(1);
        address.addPhone(Phone.builder().whoTypeIndicator("AD").phoneNumber("2454564").build());
        assertThat(address.getPhonesOfWhoType("AD").size()).isEqualTo(2);
        assertThat(providerUtil.permuteA2Address(address).size()).isEqualTo(2);
        assertThat(providerUtil.permuteA2Address(address).get(0).getPhoneList().size()).isEqualTo(3);
        assertThat(providerUtil.permuteA2Address(address).get(1).getPhoneList().size()).isEqualTo(3);
        address.addPhone(Phone.builder().phoneNumber("245456").build());
        assertThat(providerUtil.permuteA2Address(address).size()).isEqualTo(2);
        address.addPhone(Phone.builder().phoneNumber("24500456").build());
        assertThat(providerUtil.permuteA2Address(address).size()).isEqualTo(2);
        assertThat(providerUtil.permuteA2Address(address).get(0).getPhoneList().size()).isEqualTo(5);
        assertThat(providerUtil.permuteA2Address(address).get(1).getPhoneList().size()).isEqualTo(5);
    }

    @Test
    public void testProviderPermute0() throws ProviderProcessorException {
        ProviderDto provider= this.makeProvider("12", "P", "LN");
        when(this.wrapperService.getEDSSpecialty(anyString())).thenReturn(XRefDto.builder().destinationValue1("0005K").build());
        List<ProviderDto> resultList= this.providerUtil.permuteProvider(provider);
        assertThat(resultList).isNotEmpty();
        assertThat(resultList.size()).isEqualTo(1);
    }

        @Test
        public void testProviderPermute1() throws ProviderProcessorException {
            ProviderDto provider= this.makeProvider("12", "P", "LN");
            when(this.wrapperService.getEDSSpecialty(anyString())).thenReturn(XRefDto.builder().destinationValue1("0005K").build());
            provider.addSpecialty(Specialty.builder().specialtyCode("04").primaryFlag("Y").build());
            List<ProviderDto> resultList= this.providerUtil.permuteProvider(provider);
            assertThat(resultList).isNotEmpty();
            assertThat(resultList.size()).isEqualTo(1);
        }
        @Test
        public void testProviderPermute2() throws ProviderProcessorException {
            ProviderDto provider= this.makeProvider("12", "P", "LN");
            when(this.wrapperService.getEDSSpecialty(anyString())).thenReturn(XRefDto.builder().destinationValue1("0005K").build());
            provider.addSpecialty(this.makeSpecialty("04", "Y"));
            provider.addAddress(this.makeA2Address("A0",0));
            assertThat(provider.isMd5Ready()).isFalse();
            List<ProviderDto> resultList= this.providerUtil.permuteProvider(provider);
            assertThat(resultList).isNotEmpty();
            assertThat(resultList.size()).isEqualTo(1);

            provider.setCategory("G");
            assertThat(provider.isMd5Ready()).isTrue();
            resultList= this.providerUtil.permuteProvider(provider);
            assertThat(resultList).isNotEmpty();
            assertThat(resultList.size()).isEqualTo(2);

            provider.addAddress(this.makeA2Address("A1", 0));
            resultList= this.providerUtil.permuteProvider(provider);
            assertThat(resultList.size()).isEqualTo(3);

            provider.addSpecialty(this.makeSpecialty("05", "N"));
            resultList= this.providerUtil.permuteProvider(provider);
            assertThat(resultList.size()).isEqualTo(3);
            assertThat(resultList.get(0).getSpecialtyList().size()).isEqualTo(2);
            assertThat(resultList.get(1).getSpecialtyList().size()).isEqualTo(2);
            assertThat(resultList.get(2).getSpecialtyList().size()).isEqualTo(2);
            provider.addAddress(Address.builder().address1("4567").addressCode(Constants.ADDRESS_TYPE_PHYSICAL_AP).build());
            resultList= this.providerUtil.permuteProvider(provider);
            assertThat(resultList.size()).isEqualTo(3);
            assertThat(resultList.get(0).getSpecialtyList().size()).isEqualTo(2);
            assertThat(resultList.get(1).getSpecialtyList().size()).isEqualTo(2);
            assertThat(resultList.get(2).getSpecialtyList().size()).isEqualTo(2);
            assertThat(resultList.get(0).getAddressList().size()).isEqualTo(3);
            assertThat(resultList.get(1).getAddressList().size()).isEqualTo(2);
            assertThat(resultList.get(2).getAddressList().size()).isEqualTo(2);
        }
    @Test
    public void testProviderPermute3() throws ProviderProcessorException {
        ProviderDto provider= this.makeProvider("12", "G", "LN");
        when(this.wrapperService.getEDSSpecialty(anyString())).thenReturn(XRefDto.builder().destinationValue1("0005K").build());
        provider.addSpecialty(this.makeSpecialty("04", "Y"));
        provider.addAddress(this.makeA2Address("A0",0));
        assertThat(provider.isMd5Ready()).isTrue();
        List<ProviderDto> resultList= this.providerUtil.permuteProvider(provider);
        assertThat(resultList).isNotEmpty();
        assertThat(resultList.size()).isEqualTo(2);

        assertThat(resultList.get(0).getSpecialtyList().size()).isEqualTo(1);
        assertThat(resultList.get(0).getSpecialtyList().get(0).getSpecialtyCode()).isEqualTo("04");
        assertThat(resultList.get(0).getAddressList().size()).isEqualTo(1);
        assertThat(resultList.get(0).getAddressList().get(0).getAddress1()).isEqualTo("A0");
        assertThat(resultList.get(0).getAddressList().get(0).getAddress1()).isEqualTo("A0");
        assertThat(resultList.get(0).getIdentifier()).isEqualTo(provider.getIdentifier());

        assertThat(resultList.get(1).getIdentifier()).isNotEqualTo(provider.getIdentifier());
        assertThat(resultList.get(1).getSiteAddressLine1()).isEqualTo("A0");
        assertThat(resultList.get(1).getSitePhone()).isEqualTo(null);
    }
    @Test
    public void testProviderPermute4() throws ProviderProcessorException {
        ProviderDto provider= this.makeProvider("12", "G", "LN");
        when(this.wrapperService.getEDSSpecialty(anyString())).thenReturn(XRefDto.builder().destinationValue1("0005K").build());
        provider.addSpecialty(this.makeSpecialty("04", "Y"));
        provider.addAddress(this.makeA2Address("A0",1));
        assertThat(provider.isMd5Ready()).isTrue();
        List<ProviderDto> resultList= this.providerUtil.permuteProvider(provider);
        assertThat(resultList).isNotEmpty();
        assertThat(resultList.size()).isEqualTo(2);

        assertThat(resultList.get(0).getSpecialtyList().size()).isEqualTo(1);
        assertThat(resultList.get(0).getSpecialtyList().get(0).getSpecialtyCode()).isEqualTo("04");
        assertThat(resultList.get(0).getAddressList().size()).isEqualTo(1);
        assertThat(resultList.get(0).getAddressList().get(0).getAddress1()).isEqualTo("A0");
        assertThat(resultList.get(0).getAddressList().get(0).getAddress1()).isEqualTo("A0");
        assertThat(resultList.get(0).getIdentifier()).isEqualTo(provider.getIdentifier());

        assertThat(resultList.get(1).getIdentifier()).isNotEqualTo(provider.getIdentifier());
        assertThat(resultList.get(1).getSiteAddressLine1()).isEqualTo("A0");
        assertThat(resultList.get(1).getSitePhone()).isEqualTo("1230");

        provider.getAddressList().get(0).addPhone(Phone.builder().phoneNumber("456").whoTypeIndicator("OFFICE").build());

        resultList= this.providerUtil.permuteProvider(provider);
        assertThat(resultList).isNotEmpty();
        assertThat(resultList.size()).isEqualTo(2);

        assertThat(resultList.get(0).getSpecialtyList().size()).isEqualTo(1);
        assertThat(resultList.get(0).getSpecialtyList().get(0).getSpecialtyCode()).isEqualTo("04");
        assertThat(resultList.get(0).getAddressList().size()).isEqualTo(1);
        assertThat(resultList.get(0).getAddressList().get(0).getAddress1()).isEqualTo("A0");
        assertThat(resultList.get(0).getAddressList().get(0).getAddress1()).isEqualTo("A0");
        assertThat(resultList.get(0).getIdentifier()).isEqualTo(provider.getIdentifier());

        assertThat(resultList.get(1).getIdentifier()).isNotEqualTo(provider.getIdentifier());
        assertThat(resultList.get(1).getSiteAddressLine1()).isEqualTo("A0");
        assertThat(resultList.get(1).getSitePhone()).isEqualTo("1230");

        provider.getAddressList().get(0).addPhone(Phone.builder().phoneNumber("4563").whoTypeIndicator("AD").build());
        resultList= this.providerUtil.permuteProvider(provider);
        assertThat(resultList).isNotEmpty();
        assertThat(resultList.size()).isEqualTo(3);

        provider.addAddress(this.makeA2Address("A1",2));
        resultList= this.providerUtil.permuteProvider(provider);
        assertThat(resultList).isNotEmpty();
        assertThat(resultList.size()).isEqualTo(5);
    }

    private ProviderDto makeProvider(String identifier, String category, String lastName) {
        ProviderDto provider= new ProviderDto();
        provider.setIdentifier(identifier);
        provider.setCategory(category);
        provider.setLastName(lastName);
        return provider;
    }
    private Specialty makeSpecialty(String specialtyCd, String primaryFlag) {
        return Specialty.builder().specialtyCode(specialtyCd).voidFlag("N").primaryFlag(primaryFlag).build();
    }
    private Address makeA2Address(String address1, int numADPhones) {
        Address address= Address
                .builder()
                .addressCode(Constants.ADDRESS_TYPE_PHYSICAL_A2)
                .address1(address1)
                .build();
        if(numADPhones <= 0)
            return address;
        for(int i=0; i < numADPhones; i++)
            address.addPhone(Phone.builder().phoneNumber("123"+i).whoTypeIndicator("AD").build());
        return address;
    }
    /*
            return Objects.nonNull(provider) &&
                StringUtils.hasText(provider.getIdentifier()) &&
                StringUtils.hasText(provider.getProvType()) &&
                StringUtils.hasText(provider.getCategory()) &&
                StringUtils.hasText(provider.getLastName()) &&
                StringUtils.hasText(provider.getEffectiveDate()) ;
    * */
}
