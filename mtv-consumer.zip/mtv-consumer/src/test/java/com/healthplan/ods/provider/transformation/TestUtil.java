package com.healthplan.ods.provider.transformation;

import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.*;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.medica.reference.model.NetworkStatusReference;
import com.medica.reference.model.NetworkStatusReferenceGroup;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TestUtil {

    public static List<BusLvlContAssn> getBusLvls(){
        List<BusLvlContAssn> busLvlContList = new ArrayList<>();
        BusLvlContAssn busLvlCont = new BusLvlContAssn();
        busLvlCont.setBus_Level_1_Id("bus_Level_1_Id");
        busLvlCont.setBus_Level_2_Id("bus_Level_2_Id");
        busLvlCont.setBus_Level_3_Id("bus_Level_3_Id");
        busLvlCont.setBus_Level_4_Id("bus_Level_4_Id");
        busLvlCont.setBus_Level_5_Id("bus_Level_5_Id");
        busLvlCont.setBus_Level_6_Id("bus_Level_6_Id");
        busLvlCont.setBus_Level_7_Id("bus_Level_7_Id");
        busLvlCont.setEffective_Date("2022-10-10 02:23:23");
        busLvlCont.setEnd_Date("2022-10-10 02:23:23");
        busLvlCont.setCreation_Ts(TestUtil.getDateTIme());
        busLvlCont.setLast_Maint_Ts(TestUtil.getDateTIme());
        busLvlCont.setVoid_Flag(Constants.YES);
        busLvlContList.add(busLvlCont);
        BusLvlContAssn busLvlCont2 = new BusLvlContAssn();
        busLvlCont2.setBus_Level_1_Id("bus_Level_1_Id");
        busLvlCont2.setBus_Level_2_Id("bus_Level_2_Id");
        busLvlCont2.setBus_Level_3_Id("bus_Level_3_Id");
        busLvlCont2.setBus_Level_4_Id("bus_Level_4_Id");
        busLvlCont2.setBus_Level_5_Id("bus_Level_5_Id");
        busLvlCont2.setBus_Level_6_Id("bus_Level_6_Id");
        busLvlCont2.setBus_Level_7_Id("different");
        busLvlCont2.setEffective_Date("2022-10-10 02:23:23");
        busLvlCont2.setEnd_Date("2022-10-10 02:23:23");
        busLvlCont2.setCreation_Ts(TestUtil.getDateTIme());
        busLvlCont2.setLast_Maint_Ts(TestUtil.getDateTIme());
        busLvlCont2.setVoid_Flag(Constants.YES);
        busLvlContList.add(busLvlCont2);
        busLvlContList.add(busLvlCont2);
        return busLvlContList;
    }

    public static List<ProvContQual> getProvContQuals(){
        List<ProvContQual> provContQualList = new ArrayList<>();
        ProvContQual provContQual = new ProvContQual();
        provContQual.setProvider_Org_Id("Provider_Org_Id");
        provContQual.setClaims_Pay_To_Ind(Constants.CATEGORY_CHECK_ORG);
        provContQual.setClms_Pay_To_Tax_Id("Clms_Pay_To_Tax_Id");
        provContQual.setEffective_Date("2022-10-10 02:23:23");
        provContQual.setEnd_Date("2022-10-10 02:23:23");
        provContQual.setCreation_Ts(TestUtil.getDateTIme());
        provContQual.setLast_Maint_Ts(TestUtil.getDateTIme());
        provContQual.setVoid_Flag(Constants.YES);
        provContQualList.add(provContQual);
        return provContQualList;
    }

    public static List<ProvContGenTerm> getProvContGenTerms(){
        List<ProvContGenTerm> genTerms = new ArrayList<>();
        ProvContGenTerm provContGenTerm = new ProvContGenTerm();
        provContGenTerm.setEffective_Date("2022-10-10 02:23:23");
        provContGenTerm.setEnd_Date("2022-10-10 02:23:23");
        provContGenTerm.setCreation_Ts(TestUtil.getDateTIme());
        provContGenTerm.setLast_Maint_Ts(TestUtil.getDateTIme());
        provContGenTerm.setProv_Stat_Code("Stat_Code");
        provContGenTerm.setVoid_Flag(Constants.YES);
        genTerms.add(provContGenTerm);
        return genTerms;
    }

    public static ProviderDto getBasicProviderDto() {
        ProviderDto provider= new ProviderDto();
        provider.setFirstName("Won");
        provider.setMiddleName(" ");
        provider.setLastName("Rig");
        provider.setIdentifier("120096441916");
        provider.setProvType("PH");
        provider.setModelCode(" ");
        provider.setLastMaintTs("2022-08-11 16:44:19.174016000");
        provider.setCreationTs("2022-08-11 16:44:19.174023000");
        provider.setOperatorId("DPOTHI");
        provider.setArticlesOfIncDt("0001-01-01 00:00:00");
        provider.setByLawsDate("0001-01-01 00:00:00");
        provider.setCategory("P");
        provider.setUcFirstName("WON");
        provider.setUcMiddleName(" ");
        provider.setUcLastName("RIG");
        provider.setProcdCodeList(" ");
        provider.setDesdComMethInd("N");
        provider.setDescCommKey(" ");
        provider.setElectronicSubFlag("N");
        provider.setPrimaryAddressId(0L);
        provider.setPreferredPhoneId(0L);
        provider.setPrefEmailId(0L);
        provider.setFkProviderId(null);
        provider.setMultipleProvInd("I");
        provider.setEffectiveDate("2022-08-11 00:00:00");
        provider.setBillingOfficeFg("N");
        provider.setInactiveFlag("N");
        provider.setBillingProxyInd("N");
        provider.setNpiIndicator("N");
        provider.setProviderSourcInd(" ");
        provider.setCmpltFirstName("Won");
        provider.setCmpltMiddleName(" ");
        provider.setCmpltLastName("Rig");
        provider.setOrganizationType(" ");
        provider.setTaxClassification(" ");
        provider.setBusinessStartDate("0001-01-01 00:00:00");
        provider.setIncorporationFlag("N");
        provider.setIncorporationDate("0001-01-01 00:00:00");
        provider.setRevalidationFlag("N");
        provider.setTaxonomyCode(null);
        provider.setDegreeCode(null);
        provider.addAlternativeId(getBasicAlternateId());
        provider.addAddress(getBasicAddress());
        provider.addSpecialty(getBasicSpecialty());
        provider.setLanguageList(List.of(getBasicLanguage(provider.getIdentifier())));
        return provider;
    }
    public static Panel getBasicPanel() {
        return Panel
                .builder()
                .accumType("CPCTY")
                .maxMbrCount(9999999)
                .maxPatCntEffDt("2022-11-30 00:00:00")
                .patCutOffPctNum(0)
                .maxPatCutOffNbr(0)
                .patCntAsOfTs("2022-11-30 16:16:43.594258000")
                .patientTypeCode(" ")
                .patTypeSexAgeDt("0001-01-01 00:00:00")
                .patSexAgeCode(" ")
                .patAcceptanceCd("PA")
                .effectiveDate("2022-11-30 16:16:43")
                .endDate(null)
                .providerId("1111111111")
                .busLevel4Id("************")
                .busLevel5Id("************")
                .busLevel6Id("************")
                .busLevel7Id("************")
                .providerGroupId("************")
                .practiceLocId("22222222222")
                .creationTs("2022-11-30 16:16:43.594264000")
                .lastMaintTs("2022-11-30 16:16:43.594269000")
                .operatorId("SSSS")
                .providerOrgId("333333333")
                .diseaseMgmtCode(" ")
                .networkId(" ")
                .busLevel1Id(" ")
                .busLevel2Id(" ")
                .busLevel3Id(" ")
                .identifier("444444444")
                .build();


    }
    public static AlternateId getBasicAlternateId() {
        AlternateId alternateId= new AlternateId();
        alternateId.setVoidFlag("N");
        alternateId.setIdTypeCode("NPI1");
        alternateId.setIdentifier("1578889937");
        alternateId.setEndDate("9999-12-31 00:00:00");
        alternateId.setEffectiveDate("2022-05-09 00:00:00");
        alternateId.setCreationTs("2022-08-09 12:24:58.037697000");
        alternateId.setLastMaintTs("2022-08-09 12:24:58.037697000");
        alternateId.setOperatorId("CISUSER");
        alternateId.setFkProviderId("120096441916");
        alternateId.setTermReasonCode(" ");
        alternateId.setPrimaryNpiInd("N");
        return alternateId;
    }

    public static Specialty getBasicSpecialty() {
        Specialty specialty= new Specialty();
        specialty.setEffectiveDate("2022-08-02 00:00:00");
        specialty.setEndDate("9999-12-31 00:00:00");
        specialty.setSpecialtyCode("A0");
        specialty.setLastMaintTs("2022-08-02 14:52:11.258749000");
        specialty.setCreationTs("2022-08-02 14:52:11.258761000");
        specialty.setOperatorId("NTEEGA0");
        specialty.setPrimaryFlag("Y");
        specialty.setFkProvId("196094481337");
        specialty.setBoardCertFlag("N");
        specialty.setVoidFlag("N");

        return specialty;
    }
    public static Phone getBasicPhone() {
        Phone phone= new Phone();
        phone.setIdentifier("7716452358");
        phone.setWhoTypeIndicator("AD");
        phone.setWhoIdentifier("615716452350");
        phone.setPhoneType("OTHER");
        phone.setPhoneCode("CELL");
        phone.setPhoneNumber("9823901839");
        phone.setCountryId("001");
        phone.setPrimaryFlag("Y");
        phone.setPagerPinId(" ");
        phone.setExtension(" ");
        phone.setEffectiveDate("0001-01-01 00:00:00");
        phone.setEndDate("9999-12-31 00:00:00");
        phone.setReconDate("0001-01-01 00:00:00");
        phone.setAuditFlag("N");
        phone.setVersionNumber(0);
        phone.setOperatorId("DPOTHI");
        phone.setLastMaintTs("2022-08-11 16:45:23.580097000");
        phone.setCreationTs("2022-08-11 16:45:23.564262000");
        return phone;

    }
    public static Language getBasicLanguage() {
        Language language= new Language();
        language.setLastMaintTs("2022-08-11 16:45:23.580097000");
        language.setCreationTs("2022-08-11 16:45:23.564262000");
        language.setFkProvId("TBD");
        language.setPrimaryFlag("N");
        language.setOperatorId("Operator-1");
        language.setLangSpokenInd("EN");
        language.buildLogicalDeleteFlag();
        return language;
    }
    public static Language getBasicLanguage(String providerId) {
        Language language= getBasicLanguage();
        language.setFkProvId(providerId);
        return language;
    }
    public static Address getBasicAddress() {
        Address address= new Address() ;
        address.setWhoTypeInd("PR");
        address.setWhoIdentifier("120096441916");
        address.setWhoIdentifer1(null);
        address.setIdentifier("615716452350");
        address.setAddress1("123213");
        address.setUcAddress("123213");
        address.setAddressCode("BA");
        address.setAddress2(" ");
        address.setAddress3(" ");
        address.setCity("Madison");
        address.setUcCity("MADISON");
        address.setStateCode("WI");
        address.setZip("53719");
        address.setCountryCode(" ");
        address.setCountryCode("USA");
        address.setGeoCode(" ");
        address.setEffProcessDate("0001-01-01 00:00:00");
        address.setEffectiveDate("2022-08-11 16:45:23");
        address.setVoidFlag("N");
        address.setVersionNumber(0);
        address.setAuditFlag("N");
        address.setOperatorId("DPOTHI");
        address.setLastMaintTs("2022-08-11 16:45:23.506172000");
        address.setCreationTs("2022-08-11 16:45:23.506179000");
        address.setReconDate("0001-01-01 00:00:00");
        address.setStateCode(" ");
        address.setPurgeFlag(" ");
        address.setLatitudeCoordinate(0.0);
        address.setLongitudeCoordinate(0.0);
        address.addPhone(getBasicPhone());
        return address;
    }

    public static ProviderDto getBasicCheckOrg() {
        ProviderDto providerDto= getBasicProviderDto();
        providerDto.setCategory("O");
        providerDto.setProvType("CL");
        providerDto.getAlternateIds().get(0).setIdTypeCode(Constants.ID_TYPE_TAX);
        providerDto.getAddressList().get(0).setAddressCode(Constants.ADDRESS_TYPE_BILLING_BA);
        providerDto.getAddressList().get(0).getPhoneList().get(0).setPhoneType("OFFICE");
        return providerDto;
    }
    public static ProviderDto getBasicCheckOrgProcessed() throws ProviderProcessorException {
        ProviderDto provider= getBasicCheckOrg();
        Transformer transformer= new Transformer();
        transformer.transform(provider);
        return provider;
    }



    public static ProviderDto getBasicProfessional() {
        ProviderDto providerDto= getBasicProviderDto();
        providerDto.setCategory("P");
        providerDto.setProvType("PH");
        providerDto.getAddressList().get(0).setAddressCode(Constants.ADDRESS_TYPE_PHYSICAL_AP);
        return providerDto;
    }
    public static Network getNetwork(String networkId , String providerId, String effDt , String endDt, boolean logicalDeleteFlag){
        Network network = new Network();

        network.setMtvNetworkId(networkId);
        network.setMtvProviderId(providerId);
        network.setEffectiveDt(effDt);
        network.setEndDt(endDt);
        network.setLogicalDeleteFlag(logicalDeleteFlag);
        network.setAddressIdentifier("2342341235");
        network.setDirectoryFlg("Y");
        network.setInterfaceFlg("Y");
        network.setCreatedDttm("2011-02-02 00:00:00");
        network.setUpdatedDttm("2011-02-02 00:00:00");

        return network;
    }
    public static NetworkStatusReference getNetworkStatusReference(String networkId , String providerId, String effDt , String endDt, boolean logicalDeleteFlag){
        NetworkStatusReference networkStatusReference = new NetworkStatusReference();
        networkStatusReference.setSourceSystemCd("MTV");
        networkStatusReference.setNetworkId(networkId);
        networkStatusReference.setProviderId(providerId);
        networkStatusReference.setEffDt(effDt);
        networkStatusReference.setEndDt(endDt);
        networkStatusReference.setLogicalDeleteFlg(logicalDeleteFlag);
        networkStatusReference.setTransactionId(providerId+"_MTV_"+networkId);
        return networkStatusReference;
    }

    public static ProvContQual getBasicContractQualifier() {
        ProvContQual provContQual= new ProvContQual();
        provContQual.setIdentifier("919310171405");
        provContQual.setEffective_Date("2022-09-27 00:00:00");
        provContQual.setEnd_Date("9999-12-31 00:00:00");
        provContQual.setGroup_Prov_Id("117112352220");
        provContQual.setPractice_Loc_Id(" ");
        provContQual.setBilling_Pr_Tax_Id("0");
        provContQual.setClaims_Pay_To_Ind("0");
        provContQual.setCap_Pay_To_Ind("P");
        provContQual.setVoid_Flag("N");
        provContQual.setLast_Maint_Ts("2022-09-27 10:17:14.059218000");
        provContQual.setOperator_Id("GREDDYV");
        provContQual.setCreation_Ts("2022-09-27 10:17:14.059229000");
        provContQual.setFk_Points_Cont_Id("348510171390");
        provContQual.setClms_Pay_To_Tax_Id("450929516");
        provContQual.setCap_Pay_To_Tax_Id("0");
        provContQual.setUser_Defined_Flag("N");
        provContQual.setAuth_Penalty_Ind("N");
        provContQual.setTot_Comp_Thru_Mnth("0");
        provContQual.setTot_Comp_Thru_Yr("0");
        return provContQual;
    }
    public static ProvContGenTerm getBasicContractGenTerms() {
        ProvContGenTerm term= new ProvContGenTerm();
        term.setIdentifier("439815245567");
        term.setEffective_Date("022-09-21 00:00:00");
        term.setEnd_Date("9999-12-31 00:00:00");
        term.setProv_Stat_Code("P");
        term.setPay_Less_Ind("A");
        term.setClass_Code("SP");
        term.setMed_Svc_Area_Cd(" ");
        term.setCreation_Ts("2022-09-21 15:24:55.674413000");
        term.setLast_Maint_Ts("2022-09-21 15:24:55.674421000");
        term.setOperator_Id("GREDDYV");
        return term;
    }
    /*public static ProvContGenTerm getContractGenTermWithParticipationCode(String participationCode) {
        ProvContGenTerm term= getBasicContractGenTerms();
        term.setProv_Stat_Code(participationCode);
        return term;
    }
    public static BusLvlContAssn getBasicBusLvlContAssn() {
        BusLvlContAssn businessLevel= new BusLvlContAssn();

        businessLevel.setBus_Level_1_Id("DEAN HEALTH");
        businessLevel.setBus_Level_2_Id(" ");
        businessLevel.setBus_Level_3_Id(" ");
        businessLevel.setBus_Level_6_Id(" ");
        businessLevel.setBus_Level_4_Id("COMM PROG");
        businessLevel.setBus_Level_5_Id("SELF FUNDED");
        businessLevel.setBus_Level_7_Id("PPO");
        businessLevel.setNetwork_Id("WFEHPLVL2");
        businessLevel.setEffective_Date("2022-09-27 00:00:00");
        businessLevel.setEnd_Date("9999-12-31 00:00:00");
        businessLevel.setProp_To_Mstrs_Flag("Y");
        businessLevel.setOrig_Operator_Id(" ");
        businessLevel.setVoid_Flag("Y");
        businessLevel.setCreation_Ts("2022-09-27 10:17:14.043986000");
        businessLevel.setLast_Maint_Ts("2022-09-27 10:17:29.118466000");
        businessLevel.setOperator_Id("GREDDYV");
        businessLevel.setBus_Lvl_Cnt_Asn_Id("397510171404");
        businessLevel.setWildcard_Indicator("*");
        businessLevel.setSplit_Bill_History_Dy("0");
        businessLevel.setSplt_Bill_Ovrrd_Fg("N");
        businessLevel.setTimely_Filing_Limit(" ");
        businessLevel.setTfl_Override_Flag("N");
        return businessLevel;
    }*/
    /*public static BusLvlContAssn getBusLvlContAssignWithNetwork(String networkId) {
        BusLvlContAssn busLvlContAssn= getBasicBusLvlContAssn();
        busLvlContAssn.setNetwork_Id(networkId);
        return busLvlContAssn;
    }
    public static Contract getBasicContract() {
        Contract contractInfo = new Contract();
        contractInfo.setIdentifier("348510171390");
        contractInfo.setOwner_Prov_Id("125200155524");
        contractInfo.setVoid_Flag("N");
        contractInfo.setEffective_Date("2022-09-27 00:00:00");
        contractInfo.setEnd_Date("9999-12-31 00:00:00");
        contractInfo.setRole_Code("SP");
        contractInfo.setContract_Type("B");
        contractInfo.setCreation_Ts("2022-09-27 10:17:13.903520000");
        contractInfo.setLast_Maint_Ts("2022-09-27 11:23:51.477042000");
        contractInfo.setOperator_Id("GREDDYV");
        contractInfo.setMaster_Contract_Id("752815245562");
        contractInfo.setUc_Contract_Name("MASTER-MASTER-H2FUTURETESTSEP21ST ONE");
        contractInfo.setContract_Id(" ");
        contractInfo.setTaxonomy_Code(" ");


        return contractInfo;
    }*/
    public static Affiliation getBasicAffiliation() {
        long surrogateId = 623511133818L;
        Affiliation affiliation = new Affiliation();
        affiliation.setSurrogateId(surrogateId);
        affiliation.setAffiliation_type("PP");
        affiliation.setSpecialtyCode(null);
        affiliation.setEffectiveDate("2022-11-09 00:00:00");
        affiliation.setEndDate("9999-12-31 00:00:00");
        affiliation.setCreationTs("2022-11-09 11:13:38.186248000");
        affiliation.setLastMaintTs("2022-11-09 11:13:38.186255000");
        affiliation.setOperatorId("AUTO");
        affiliation.setFkJoiningProId("102951082991");
        affiliation.setFkJoinedProvId("117112352220");
        affiliation.setPrivilegeType(null);
        affiliation.setVoidFlag("N");
        affiliation.setAffiliationCode("MORG");
        return affiliation;
    }

        public static Affiliation getPAffiliationAdmt()
        {
            long surrogateId=623511133818L;
            Affiliation affiliation2= new Affiliation();
            affiliation2.setSurrogateId(surrogateId);
            affiliation2.setAffiliation_type("PP");
            affiliation2.setSpecialtyCode(null);
            affiliation2.setEffectiveDate("2022-11-09 00:00:00");
            affiliation2.setEndDate("9999-12-31 00:00:00");
            affiliation2.setCreationTs("2022-11-22 11:13:38.186248000");
            affiliation2.setLastMaintTs("2022-11-22 11:13:38.186255000");
            affiliation2.setOperatorId("AUTO");
            affiliation2.setFkJoiningProId("102951082991");
            affiliation2.setFkJoinedProvId("117112352220");
            affiliation2.setPrivilegeType(null);
            affiliation2.setVoidFlag("N");
            affiliation2.setAffiliationCode("ADMT");
            return affiliation2;
    }

    public static Affiliation getPAffiliationType()
    {
        long surrogateId=623511133818L;
        Affiliation affiliation3= new Affiliation();
        affiliation3.setSurrogateId(surrogateId);
        affiliation3.setAffiliation_type("PP");
        affiliation3.setSpecialtyCode(null);
        affiliation3.setEffectiveDate("2022-11-22 00:00:00");
        affiliation3.setEndDate("9999-12-31 00:00:00");
        affiliation3.setCreationTs("2022-11-09 11:13:38.186248000");
        affiliation3.setLastMaintTs("2022-11-09 11:13:38.186255000");
        affiliation3.setOperatorId("AUTO");
        affiliation3.setFkJoiningProId("102951082994");
        affiliation3.setFkJoinedProvId("117112352220");
        affiliation3.setPrivilegeType(null);
        affiliation3.setVoidFlag("N");
        affiliation3.setAffiliationCode("");
        return affiliation3;
    }

    public static String getDateTIme() {
         DateTimeFormatter sysFor = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.nnnnnnnnn");
         LocalDateTime time = LocalDateTime.now();
         return sysFor.format(time);
    }
}
