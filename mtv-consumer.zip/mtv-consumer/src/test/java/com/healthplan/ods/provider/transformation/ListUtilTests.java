package com.healthplan.ods.provider.transformation;

import com.healthplan.ods.provider.transformation.model.merge.AlternateId;
import com.healthplan.ods.provider.transformation.model.merge.ProviderDto;
import com.healthplan.ods.provider.transformation.service.utils.ListUtil;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import static org.assertj.core.api.Assertions.assertThat;

public class ListUtilTests {

    @Test
    public void testdeleteFromList() {
        List<AlternateId> alternateIdList= List.of(
                AlternateId.builder().identifier("11").idTypeCode("TAX").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("22").idTypeCode("NPI1").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("33").idTypeCode("TAX").logicalDeleteFlag(false).build(),
                AlternateId.builder().identifier("33").idTypeCode("NPI2").logicalDeleteFlag(true).build()
        );
        List<AlternateId> resultList= ListUtil.removeFromList(alternateIdList, alternateId -> alternateId.hasType("TAX"));
        assertThat(resultList.size()).isEqualTo(2);
        assertThat(resultList).doesNotContain(AlternateId.builder().identifier("11").idTypeCode("TAX").logicalDeleteFlag(true).build());
        assertThat(resultList).contains(AlternateId.builder().identifier("33").idTypeCode("NPI2").logicalDeleteFlag(true).build());
        resultList= ListUtil.removeFromList(alternateIdList, alternateId -> alternateId.hasType("M2"));
        assertThat(resultList.size()).isEqualTo(4);

    }
    @Test
    public void testHasList() {
        List<AlternateId> alternateIdList= List.of(
                AlternateId.builder().identifier("11").idTypeCode("TAX").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("22").idTypeCode("NPI1").logicalDeleteFlag(true).build(),
                AlternateId.builder().identifier("33").idTypeCode("TAX").logicalDeleteFlag(false).build(),
                AlternateId.builder().identifier("33").idTypeCode("NPI2").logicalDeleteFlag(true).build()
        );

        assertThat(ListUtil.hasList(alternateIdList, alternateId -> alternateId.hasType("TAX"))).isTrue();
        assertThat(ListUtil.hasList(alternateIdList, alternateId -> alternateId.hasType("NPI2"))).isTrue();
        Predicate<AlternateId> predicate= alternateId -> alternateId.getLogicalDeleteFlag() == false;
        assertThat(ListUtil.hasList(alternateIdList, predicate.and(alternateId -> alternateId.hasType("TAX")))).isTrue();
        alternateIdList.get(2).setLogicalDeleteFlag(true);
        assertThat(ListUtil.hasList(alternateIdList, predicate.and(alternateId -> alternateId.hasType("TAX")))).isFalse();
        assertThat(ListUtil.hasList(alternateIdList, alternateId -> alternateId.hasType("M2"))).isFalse();

    }
    @Test
    public void testFilterFieldValuesMethod() {
        List<AlternateId> list= List.of(AlternateId.builder().identifier("111").effectiveDate("2022-01-01").build(),
                AlternateId.builder().identifier("222").effectiveDate("2022-02-02").build());
        assertThat(ListUtil.filterFieldValues(list, AlternateId::getIdentifier)).isEqualTo(List.of("111","222"));
        assertThat(ListUtil.filterFieldValues(list, AlternateId::getEffectiveDate)).isEqualTo(List.of("2022-01-01", "2022-02-02"));
        list.get(1).setEffectiveDate("2022-01-01");
        assertThat(ListUtil.filterFieldValues(list, AlternateId::getEffectiveDate, true)).isEqualTo(List.of("2022-01-01"));
        list= null;
        assertThat(ListUtil.filterFieldValues(list, AlternateId::getEffectiveDate, true)).isNull();
        list= new ArrayList<>();
        assertThat(ListUtil.filterFieldValues(list, AlternateId::getEffectiveDate, true)).isNullOrEmpty();
    }

    @Test
    public void listTests() {
        assertThat(ListUtil.nonEmpty(List.of("Value-1"))).isTrue();
        assertThat(ListUtil.nonEmpty(new ArrayList<String>())).isFalse();
        assertThat(ListUtil.nonEmpty(null)).isFalse();

        assertThat(ListUtil.nullOrEmpty(List.of("Value-1"))).isFalse();
        assertThat(ListUtil.nullOrEmpty(null)).isTrue();
        assertThat(ListUtil.nullOrEmpty(new ArrayList<String>())).isTrue();
    }
    @Test
    public void testFilterList() {
        ProviderDto provider= new ProviderDto();
        provider.setIdentifier("5678");
        provider.addAlternativeId(AlternateId.builder().identifier("1111").build());
        provider.addAlternativeId(AlternateId.builder().identifier("2222").build());
        provider.addAlternativeId(AlternateId.builder().identifier("1111").build());

        assertThat(ListUtil.selectFromList(provider.getAlternateIds(), alternateId -> alternateId.getIdentifier().equalsIgnoreCase("1111")).isEmpty()).isFalse();
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(), alternateId -> alternateId.getIdentifier().equalsIgnoreCase("1111")).size()).isEqualTo(2);
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(), alternateId -> alternateId.getIdentifier().equalsIgnoreCase("2222")).size()).isEqualTo(1);
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(), alternateId -> alternateId.getIdentifier().equalsIgnoreCase("4444")).size()).isEqualTo(0);
        Predicate<AlternateId> predicate= alternateId -> alternateId.getIdentifier().equalsIgnoreCase("1111");
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(),predicate ).size()).isEqualTo(2);
        predicate= predicate.or(alternateId -> alternateId.getIdentifier().equalsIgnoreCase("2222"));
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(),predicate ).size()).isEqualTo(3);
        predicate= predicate.negate();
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(),predicate ).size()).isEqualTo(0);
        provider.addAlternativeId(AlternateId.builder().identifier("55555").build());
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(),predicate ).size()).isEqualTo(1);
        assertThat(ListUtil.selectFromList(provider.getAlternateIds(),null )).isNull();
    }
}
