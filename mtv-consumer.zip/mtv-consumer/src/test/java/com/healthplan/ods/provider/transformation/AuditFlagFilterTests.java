package com.healthplan.ods.provider.transformation;

import com.healthplan.ods.provider.transformation.exception.ProviderProcessorException;
import com.healthplan.ods.provider.transformation.model.merge.*;
import com.healthplan.ods.provider.transformation.model.misc.Constants;
import com.healthplan.ods.provider.transformation.service.products.Transformer;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;

public class AuditFlagFilterTests {

    /**
     * This test ensures that auditFlagged data elements are removed from the provider
     * @throws ProviderProcessorException
     */
    @Test
    void testRemoveAudit() throws ProviderProcessorException {

        ProviderDto provider= new ProviderDto();

        List<Phone> phones1 = new ArrayList<>();
        List<ElectronicAddress> electronicList1 = new ArrayList<>();

        phones1.add(buildPhone("11","1111111","N"));
        phones1.add(buildPhone("22","2222222","Y"));
        phones1.add(buildPhone("33","3333333","N"));

        List<Phone> phones2 = new ArrayList<>();
        phones2.add(buildPhone("11","1111111","Y"));
        phones2.add(buildPhone("22","2222222","Y"));

        List<Phone> phones3 = new ArrayList<>();
        phones3.add(buildPhone("11","1111111","N"));
        phones3.add(buildPhone("22","2222222","N"));


        List<Network> networkList = new ArrayList<>();
        networkList.add(buildNetwork("mtvNetworkId1","N"));
        networkList.add(buildNetwork("mtvNetworkId2","Y"));
        networkList.add(buildNetwork("mtvNetworkId3","N"));


        provider.addAddress(buildAddress("11","X11X","Y","http://www.someurl1",phones1));
        provider.addAddress(buildAddress("22","X22X","N","http://www.someurl2",phones2));
        provider.addAddress(buildAddress("33","X33X","N","http://www.someurl3",phones3));
        provider.addAddress(buildAddress("44","X44X","N","http://www.someurl4",phones1));

        electronicList1.addAll(provider.getAddressList().stream().map(address ->ElectronicAddress.createElectronicAddress(address)).collect(Collectors.toList()));

        provider.setElectronicAddressList(electronicList1);
        provider.setNetworks(networkList);

        Transformer transformer= new Transformer();
        transformer.transform(provider);

        assertThat(provider.getAddressList().size()).isEqualTo(3);
        assertThat(provider.getAddressesPhones().size()).isEqualTo(4);
        assertThat(provider.getElectronicAddressList().size()).isEqualTo(3);
        assertThat(provider.getNetworks().size()).isEqualTo(2);

        assertThat(provider.getAddressList().get(0).getLocationId()).isEqualTo("22");
        assertThat(provider.getAddressList().get(1).getLocationId()).isEqualTo("33");
        assertThat(provider.getAddressList().get(2).getLocationId()).isEqualTo("44");

        assertThat(provider.getAddressesPhones().get(0).getPhoneCode()).isEqualTo("11");
        assertThat(provider.getAddressesPhones().get(1).getPhoneCode()).isEqualTo("22");
        assertThat(provider.getAddressesPhones().get(2).getPhoneCode()).isEqualTo("11");
        assertThat(provider.getAddressesPhones().get(3).getPhoneCode()).isEqualTo("33");

        assertThat(provider.getNetworks().get(0).getMtvNetworkId()).isEqualTo("mtvNetworkId1");
        assertThat(provider.getNetworks().get(1).getMtvNetworkId()).isEqualTo("mtvNetworkId3");

    }
    private Address buildAddress(String locationId, String md5Hash, String auditFlag,String electAddress, List<Phone> phones){
        Address address = Address
                .builder()
                .locationId(locationId)
                .md5Hash(md5Hash)
                .auditFlag(auditFlag)
                .addressCode(Constants.ADDRESS_TYPE_PHYSICAL_A2)
                .electAddress(electAddress)
                .build();
        phones.stream().forEach(phone -> address.addPhone(phone));
      return  address;
    }

    private Phone buildPhone(String phoneCode,String phoneNumber,String auditFlag){
        return Phone.builder()
                .phoneCode(phoneCode)
                .phoneNumber(phoneNumber)
                .auditFlag(auditFlag)
                .build();
    }

    private Network buildNetwork(String mtvNetworkId,String auditFlag){
        return Network.builder()
                .mtvNetworkId(mtvNetworkId)
                .auditFlg(auditFlag)
                .build();
    }

}
